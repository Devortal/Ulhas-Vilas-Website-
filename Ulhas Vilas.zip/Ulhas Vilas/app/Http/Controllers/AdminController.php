<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    // =========================================================================
    // 🔐 1. ADMIN AUTHENTICATION & PROFILE
    // =========================================================================

    public function admin_login(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        $login = DB::table('admin')->where(['email' => $email, 'password' => $password, 'status' => '1'])->first();

        if (is_null($login)) {
            return response()->json(['success' => '0', 'message' => 'Invalid email or password']);
        } else {
            $data = DB::table('admin')->where(['email' => $email, 'password' => $password, 'status' => '1'])->get();
            session()->put('admin_login', $data);
            return response()->json([
                'data' => $data,
                'success' => '1',
            ]);
        }
    }

    public function admin_logout(Request $request)
    {
        session()->forget('admin_login');
        return redirect('/login');
    }

    public function changepasswordset(Request $request)
    {
        $admin_id = $request->admin_id;
        $opass = $request->opass;
        $npass = $request->npass;
        $cpass = $request->cpass;

        $check = DB::table('admin')->where('id', $admin_id)->first();

        if (!$check || $check->password != $opass) {
            return response()->json(['success' => 'old_pass']);
        }

        if ($npass != $cpass) {
            return response()->json(['success' => 'opass_npass']);
        }

        $up = DB::table('admin')->where('id', $admin_id)->update(['password' => $npass]);
        return response()->json(['success' => $up ? 'success' : 'not_match']);
    }

    public function updateprofile(Request $request)
    {
        $admin_id = $request->admin_id;
        $updatedata = [
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
        ];

        if ($admin_id) {
            DB::table('admin')->where('id', $admin_id)->update($updatedata);
            $data = DB::table('admin')->where('id', $admin_id)->get();
            session()->forget('admin_login');
            session()->put('admin_login', $data);
            return response()->json(['success' => 'success']);
        }
        return response()->json(['success' => 'error']);
    }

    // =========================================================================
    // 📊 2. ADMIN DASHBOARD (ONLY THE 5 REQUIRED CARDS & SUMMARY)
    // =========================================================================

    public function AdminDashboard()
    {
        $data['residences_count'] = DB::table('residences')->count();
        $data['categories_count'] = DB::table('categories')->count();
        $data['amenities_count'] = DB::table('amenities')->count();
        $data['galleries_count'] = DB::table('galleries')->count();
        $data['blogs_count'] = DB::table('blogs')->count();
        $data['reviews_count'] = DB::table('reviews')->count();
        $data['contacts_count'] = DB::table('contacts')->count();
        $data['enquiries_count'] = $data['contacts_count'];
        $data['subadmins_count'] = DB::table('admin')->where('user_type', 'subadmin')->count();
        $data['recent_contacts'] = DB::table('contacts')->orderBy('id', 'desc')->limit(6)->get();
        $data['recent_enquiries'] = $data['recent_contacts'];
        $data['recent_residences'] = DB::table('residences')->orderBy('id', 'desc')->limit(6)->get();

        return view('Admin.index', $data);
    }

    // =========================================================================
    // 👥 3. SUBADMIN MANAGEMENT
    // =========================================================================

    public function Subadmin()
    {
        $admin = session()->get('admin_login');
        if (!empty($admin)) {
            $first = is_iterable($admin) ? (is_object(collect($admin)->first()) ? collect($admin)->first() : (object) collect($admin)->first()) : null;
            if ($first && isset($first->user_type) && $first->user_type !== 'admin') {
                return redirect('/admin-dashboard');
            }
        }
        return view('Admin.pages.subadmin');
    }

    public function ShowSubadmin(Request $request)
    {
        $search = $request->search;
        $query = DB::table('admin');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('name', 'like', '%' . $search . '%')
                    ->orWhere('email', 'like', '%' . $search . '%')
                    ->orWhere('mobile', 'like', '%' . $search . '%');
            });
        }

        $enquiries = $query->where('user_type', 'subadmin')->orderBy('id', 'desc')->paginate(10);

        return response()->json([
            'data' => $enquiries->items(),
            'current_page' => $enquiries->currentPage(),
            'last_page' => $enquiries->lastPage(),
            'per_page' => $enquiries->perPage(),
            'total' => $enquiries->total(),
            'success' => 'success',
        ]);
    }

    public function AddSubadmin(Request $request)
    {
        $permsInput = $request->permissions ?? $request->tags ?? [];
        if (!is_array($permsInput)) {
            $permsInput = !empty($permsInput) ? explode(',', $permsInput) : [];
        }
        $request->merge(['permissions' => $permsInput, 'tags' => $permsInput]);

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:admin,email',
            'mobile' => 'required|digits:10|unique:admin,mobile',
            'password' => 'required',
            'permissions' => 'required|array|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => 'error', 'errors' => $validator->errors()]);
        }

        $permissions = implode(',', $permsInput);

        DB::table('admin')->insert([
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'password' => $request->password,
            'permissions' => $permissions,
            'user_type' => 'subadmin',
            'status' => '1',
            'created_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success']);
    }

    public function EditSubadmin($id)
    {
        $admin = session()->get('admin_login');
        if (!empty($admin)) {
            $first = is_iterable($admin) ? (is_object(collect($admin)->first()) ? collect($admin)->first() : (object) collect($admin)->first()) : null;
            if ($first && isset($first->user_type) && $first->user_type !== 'admin') {
                return redirect('/admin-dashboard');
            }
        }
        $edit_admin = DB::table('admin')->where(['id' => $id, 'user_type' => 'subadmin'])->first();
        return view('Admin.pages.edit_subadmin', ['edit_admin' => $edit_admin]);
    }

    public function UpdateSubadmin(Request $request)
    {
        $permsInput = $request->permissions ?? $request->tags ?? [];
        if (!is_array($permsInput)) {
            $permsInput = !empty($permsInput) ? explode(',', $permsInput) : [];
        }
        $request->merge(['permissions' => $permsInput, 'tags' => $permsInput]);

        $validator = Validator::make($request->all(), [
            'id' => 'required|integer|exists:admin,id',
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:admin,email,' . $request->id,
            'mobile' => 'required|digits:10|unique:admin,mobile,' . $request->id,
            'password' => 'required',
            'permissions' => 'required|array|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => 'error', 'errors' => $validator->errors()]);
        }

        $permissions = implode(',', $permsInput);

        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'password' => $request->password,
            'permissions' => $permissions,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        DB::table('admin')->where('id', $request->id)->update($data);

        return response()->json(['success' => 'success']);
    }

    public function DeleteSubadmin(Request $request)
    {
        DB::table('admin')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success']);
    }

    public function CheckMobileExist(Request $request)
    {
        $mobile = $request->mobile;
        $id = $request->id;

        $query = DB::table('admin')->where('mobile', $mobile);
        if (!empty($id)) {
            $query->where('id', '!=', $id);
        }

        $exists = $query->exists();

        return response()->json([
            'exists' => $exists,
            'message' => $exists ? 'Mobile number already exists' : 'Mobile number is available'
        ]);
    }

    // =========================================================================
    // 🏷️ 4. CATEGORIES & SUBCATEGORIES MANAGEMENT
    // =========================================================================

    public function category()
    {
        return view('Admin.pages.category');
    }

    public function searchdata(Request $request)
    {
        $search = $request->search;
        $status = $request->status;
        $date = $request->date;
        $query = DB::table('categories');

        if ($search) {
            $query->where('category_name', 'like', '%' . $search . '%');
        }
        if (isset($status) && $status !== null && $status !== '') {
            $query->where('status', (string) $status);
        }

        if ($date) {
            $dateRange = explode(' to ', $date);
            if (count($dateRange) == 2) {
                $query
                    ->whereDate('created_at', '>=', trim($dateRange[0]))
                    ->whereDate('created_at', '<=', trim($dateRange[1]));
            } else {
                $query->whereDate('created_at', trim($dateRange[0]));
            }
        }

        $cats = $query->orderBy('id', 'asc')->paginate(10);
        return response()->json([
            'data' => $cats->items(),
            'current_page' => $cats->currentPage(),
            'last_page' => $cats->lastPage(),
            'per_page' => $cats->perPage(),
            'total' => $cats->total(),
            'success' => 'success'
        ]);
    }

    public function add_category(Request $request)
    {
        $name = $request->category_name ?? $request->name;
        $image = '';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('storage/Admin/category'), $filename);
            $image = 'storage/Admin/category/' . $filename;
        }

        DB::table('categories')->insert([
            'category_name' => $name,
            'image' => $image,
            'status' => '1',
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success']);
    }

    public function update_category(Request $request)
    {
        $id = $request->id;
        $name = $request->category_name ?? $request->edit_category_name ?? $request->name;

        $data = [
            'updated_at' => $this->datetime,
        ];

        if ($name !== null && $name !== '') {
            $data['category_name'] = $name;
        }

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('storage/Admin/category'), $filename);
            $data['image'] = 'storage/Admin/category/' . $filename;
        }

        DB::table('categories')->where('id', $id)->update($data);
        return response()->json(['success' => 'success']);
    }

    public function delete_category(Request $request)
    {
        DB::table('categories')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success']);
    }

    public function switch_status_update(Request $request)
    {
        $id = $request->id;
        $status = $request->status;
        $table = $request->table ?? $request->tableName ?? 'categories';
        DB::table($table)->where('id', $id)->update([
            'status' => $status,
            'updated_at' => $this->datetime,
        ]);
        return response()->json(['success' => 'success']);
    }

    public function subcategory()
    {
        $categories = DB::table('categories')->where('status', '1')->orderBy('id', 'asc')->get();
        return view('Admin.pages.subcategory', compact('categories'));
    }

    public function show_subcategory(Request $request)
    {
        $search = $request->search;
        $query = DB::table('sub_categories')
            ->leftJoin('categories', 'sub_categories.category_id', '=', 'categories.id')
            ->select('sub_categories.*', 'categories.category_name');

        if ($search) {
            $query->where('sub_categories.subcategory_name', 'like', '%' . $search . '%');
        }

        $subs = $query->orderBy('sub_categories.id', 'desc')->paginate(10);
        return response()->json([
            'data' => $subs->items(),
            'current_page' => $subs->currentPage(),
            'last_page' => $subs->lastPage(),
            'per_page' => $subs->perPage(),
            'total' => $subs->total(),
            'success' => 'success'
        ]);
    }

    public function add_subcategory(Request $request)
    {
        $image = '';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('storage/Admin/subcategory'), $filename);
            $image = 'storage/Admin/subcategory/' . $filename;
        }

        DB::table('sub_categories')->insert([
            'category_id' => $request->category_id,
            'subcategory_name' => $request->subcategory_name,
            'image' => $image,
            'status' => '1',
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success']);
    }

    public function update_subcategory(Request $request)
    {
        $id = $request->id;
        $data = [
            'category_id' => $request->category_id,
            'subcategory_name' => $request->subcategory_name,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('storage/Admin/subcategory'), $filename);
            $data['image'] = 'storage/Admin/subcategory/' . $filename;
        }

        DB::table('sub_categories')->where('id', $id)->update($data);
        return response()->json(['success' => 'success']);
    }

    public function delete_subcategory(Request $request)
    {
        DB::table('sub_categories')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success']);
    }

    // =========================================================================
    // 🏡 5. RESIDENCES MANAGEMENT (1 BHK, 2 BHK, 3 BHK, 4 BHK)
    // =========================================================================

    public function Residence()
    {
        $categories = DB::table('categories')->where('status', '1')->orderBy('id', 'asc')->get();
        $amenities = DB::table('amenities')->where('status', '1')->get();
        return view('Admin.pages.residence', compact('categories', 'amenities'));
    }

    public function ShowResidence(Request $request)
    {
        $search = $request->search;
        $categoryId = $request->category_id;
        $status = $request->status;
        $startDate = $request->start_date;
        $endDate = $request->end_date;
        $date = $request->date;
        $query = DB::table('residences');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('name', 'like', '%' . $search . '%')
                    ->orWhere('carpet_area', 'like', '%' . $search . '%')
                    ->orWhere('suites', 'like', '%' . $search . '%')
                    ->orWhere('price', 'like', '%' . $search . '%')
                    ->orWhere('short_description', 'like', '%' . $search . '%');
            });
        }

        if ($categoryId) {
            $query->where('category_id', $categoryId);
        }

        if (isset($status) && $status !== null && $status !== '') {
            $query->where('status', (int) $status);
        }

        if ($date) {
            $dateRange = explode(' to ', $date);
            if (count($dateRange) == 2) {
                $query
                    ->whereDate('created_at', '>=', trim($dateRange[0]))
                    ->whereDate('created_at', '<=', trim($dateRange[1]));
            } else {
                $query->whereDate('created_at', trim($dateRange[0]));
            }
        } elseif ($startDate || $endDate) {
            if ($startDate) {
                $query->whereDate('created_at', '>=', $startDate);
            }
            if ($endDate) {
                $query->whereDate('created_at', '<=', $endDate);
            }
        }

        $residences = $query->orderBy('id', 'asc')->paginate(10);

        // Preload categories and amenities for matching details
        $allCategories = DB::table('categories')->get()->keyBy('id');
        $allAmenities = DB::table('amenities')->get()->keyBy('id');

        $items = $residences->items();
        foreach ($items as $item) {
            // Match category name strictly from categories table by category_id
            $catId = $item->category_id ?? null;
            if (is_string($catId) && str_starts_with(trim($catId), '[')) {
                $cArr = json_decode($catId, true);
                $catId = is_array($cArr) && count($cArr) > 0 ? $cArr[0] : null;
            }
            if ($catId && isset($allCategories[$catId])) {
                $item->category_name = $allCategories[$catId]->category_name;
            } else {
                $item->category_name = '-';
            }

            // Match amenities by ID and get name & image
            $amenityList = [];
            $rawAmenity = $item->amenity_id ?? null;
            $amenityIdArray = [];
            if ($rawAmenity) {
                if (is_string($rawAmenity)) {
                    if (str_starts_with(trim($rawAmenity), '[')) {
                        $amenityIdArray = json_decode($rawAmenity, true) ?: [];
                    } else {
                        $amenityIdArray = array_filter(array_map('trim', explode(',', $rawAmenity)));
                    }
                } elseif (is_array($rawAmenity)) {
                    $amenityIdArray = $rawAmenity;
                }
            }
            foreach ($amenityIdArray as $aId) {
                if (isset($allAmenities[$aId])) {
                    $amenityList[] = [
                        'id' => $allAmenities[$aId]->id,
                        'name' => $allAmenities[$aId]->name,
                        'image' => $allAmenities[$aId]->image,
                    ];
                }
            }
            $item->amenities_data = $amenityList;
        }

        return response()->json([
            'data' => $items,
            'current_page' => $residences->currentPage(),
            'last_page' => $residences->lastPage(),
            'per_page' => $residences->perPage(),
            'total' => $residences->total(),
            'success' => 'success',
        ]);
    }

    public function AddResidence(Request $request)
    {
        $images = [];
        if ($request->hasFile('image')) {
            $files = is_array($request->file('image')) ? $request->file('image') : [$request->file('image')];
            foreach ($files as $file) {
                if ($file && $file->isValid()) {
                    $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('storage/Admin/residence/image'), $fileName);
                    $images[] = 'storage/Admin/residence/image/' . $fileName;
                }
            }
        }
        $imageString = !empty($images) ? implode(',', $images) : null;

        $slug = Str::slug($request->name);
        $count = DB::table('residences')->where('slug', $slug)->count();
        if ($count > 0) {
            $slug = $slug . '-' . time();
        }

        // Single category selection handling (e.g. 1 or 2)
        $categoryId = $request->category_id ?? null;
        if (is_array($categoryId)) {
            $categoryId = count($categoryId) > 0 ? $categoryId[0] : null;
        } elseif (is_string($categoryId) && str_starts_with(trim($categoryId), '[')) {
            $cArr = json_decode($categoryId, true);
            $categoryId = is_array($cArr) && count($cArr) > 0 ? $cArr[0] : null;
        }

        $categoryName = 'Villa';
        if ($categoryId) {
            $catRecord = DB::table('categories')->where('id', $categoryId)->first();
            if ($catRecord) {
                $categoryName = $catRecord->category_name;
            }
        }

        // Multiple amenities selection handling (comma-separated e.g. 1,2,3 via implode)
        $amenityId = null;
        $rawAmenities = $request->amenity_id ?? ($request->amenity_ids ?? null);
        if ($rawAmenities) {
            if (is_array($rawAmenities)) {
                $amenityId = implode(',', array_filter($rawAmenities));
            } else {
                $amenityId = $rawAmenities;
            }
        }

        // Handle Layout Plans
        $layoutPlans = [];
        if ($request->has('layout_titles')) {
            $titles = $request->layout_titles;
            $files = $request->file('layout_images') ?? [];
            $existingLayouts = $request->existing_layout_images ?? [];
            foreach ($titles as $idx => $title) {
                $imgPath = $existingLayouts[$idx] ?? null;
                if (isset($files[$idx]) && $files[$idx] && $files[$idx]->isValid()) {
                    $layoutDir = public_path('storage/Admin/residence/layouts');
                    if (!file_exists($layoutDir)) {
                        mkdir($layoutDir, 0777, true);
                    }
                    $fileName = 'layout_' . uniqid() . '.' . $files[$idx]->getClientOriginalExtension();
                    $files[$idx]->move($layoutDir, $fileName);
                    $imgPath = 'storage/Admin/residence/layouts/' . $fileName;
                }
                if (!empty(trim($title ?? '')) || !empty($imgPath)) {
                    $layoutPlans[] = [
                        'title' => trim($title ?? ''),
                        'image' => $imgPath ?? ''
                    ];
                }
            }
        }

        DB::table('residences')->insert([
            'name' => $request->name,
            'slug' => $slug,
            'category_id' => $categoryId ? (string) $categoryId : null,
            'category_name' => $categoryName,
            'amenity_id' => $amenityId,
            'carpet_area' => $request->carpet_area,
            'rooms' => $request->rooms ?? ($request->suites ?? '2 Rooms'),
            'd_room' => $request->d_room ?? '1 D Room',
            'balconies' => $request->balconies ?? '2 Balconies',
            'toilets' => $request->toilets ?? ($request->bathrooms ?? '2 Toilets'),
            'pantry' => $request->pantry ?? '1 Pantry',
            'suites' => $request->suites ?? ($request->rooms ?? '2 Rooms'),
            'highlight_feature' => $request->highlight_feature,
            'bathrooms' => $request->bathrooms ?? ($request->toilets ?? '2 Toilets'),
            'capacity' => $request->capacity,
            'price' => $request->price,
            'view_type' => null,
            'image' => $imageString,
            'layout_plans' => !empty($layoutPlans) ? json_encode($layoutPlans) : null,
            'short_description' => $request->short_description,
            'description' => $request->description,
            'status' => $request->status ?? 1,
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success', 'message' => 'Residence added successfully!']);
    }

    public function UpdateResidence(Request $request)
    {
        $id = $request->id;
        $residence = DB::table('residences')->where('id', $id)->first();
        if (!$residence) {
            return response()->json(['success' => 'error', 'message' => 'Residence not found!']);
        }

        // Single category selection handling (e.g. 1 or 2)
        $categoryId = $request->category_id ?? ($residence->category_id ?? null);
        if (is_array($categoryId)) {
            $categoryId = count($categoryId) > 0 ? $categoryId[0] : null;
        } elseif (is_string($categoryId) && str_starts_with(trim($categoryId), '[')) {
            $cArr = json_decode($categoryId, true);
            $categoryId = is_array($cArr) && count($cArr) > 0 ? $cArr[0] : null;
        }

        $categoryName = $residence->category_name ?? 'Villa';
        if ($categoryId) {
            $catRecord = DB::table('categories')->where('id', $categoryId)->first();
            if ($catRecord) {
                $categoryName = $catRecord->category_name;
            }
        }

        // Multiple amenities selection handling (comma-separated e.g. 1,2,3 via implode)
        $amenityId = $residence->amenity_id ?? null;
        if (is_string($amenityId) && str_starts_with(trim($amenityId), '[')) {
            $aArr = json_decode($amenityId, true);
            $amenityId = is_array($aArr) ? implode(',', $aArr) : null;
        }

        if ($request->has('amenity_id') || $request->has('amenity_ids')) {
            $rawAmenities = $request->amenity_id ?? $request->amenity_ids;
            if (is_array($rawAmenities)) {
                $amenityId = implode(',', array_filter($rawAmenities));
            } else {
                $amenityId = $rawAmenities;
            }
        }

        $data = [
            'name' => $request->name,
            'category_id' => $categoryId ? (string) $categoryId : null,
            'category_name' => $categoryName,
            'amenity_id' => $amenityId,
            'carpet_area' => $request->carpet_area,
            'rooms' => $request->rooms ?? ($request->suites ?? ($residence->rooms ?? '2 Rooms')),
            'd_room' => $request->d_room ?? ($residence->d_room ?? '1 D Room'),
            'balconies' => $request->balconies ?? ($residence->balconies ?? '2 Balconies'),
            'toilets' => $request->toilets ?? ($request->bathrooms ?? ($residence->toilets ?? '2 Toilets')),
            'pantry' => $request->pantry ?? ($residence->pantry ?? '1 Pantry'),
            'suites' => $request->suites ?? ($request->rooms ?? $residence->suites),
            'highlight_feature' => $request->highlight_feature,
            'bathrooms' => $request->bathrooms ?? ($request->toilets ?? $residence->bathrooms),
            'capacity' => $request->capacity ?? $residence->capacity,
            'price' => $request->price,
            'short_description' => $request->short_description,
            'description' => $request->description,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        // Handle Multiple Images (Retained existing + newly uploaded)
        $retainedImages = [];
        if ($request->has('existing_images') || $request->has('existing_image')) {
            $rawExisting = $request->existing_images ?? $request->existing_image;
            if (is_array($rawExisting)) {
                $retainedImages = $rawExisting;
            } elseif (is_string($rawExisting)) {
                if (str_starts_with(trim($rawExisting), '[')) {
                    $retainedImages = json_decode($rawExisting, true) ?: [];
                } else {
                    $retainedImages = array_filter(array_map('trim', explode(',', $rawExisting)));
                }
            }
        } elseif (!empty($residence->image)) {
            if (str_starts_with(trim($residence->image), '[')) {
                $retainedImages = json_decode($residence->image, true) ?: [];
            } else {
                $retainedImages = array_filter(array_map('trim', explode(',', $residence->image)));
            }
        }

        $newImages = [];
        if ($request->hasFile('image')) {
            $files = is_array($request->file('image')) ? $request->file('image') : [$request->file('image')];
            foreach ($files as $file) {
                if ($file && $file->isValid()) {
                    $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('storage/Admin/residence/image'), $fileName);
                    $newImages[] = 'storage/Admin/residence/image/' . $fileName;
                }
            }
        }

        if ($request->has('existing_images') || $request->has('existing_image') || $request->hasFile('image')) {
            $merged = array_merge($retainedImages, $newImages);
            $data['image'] = !empty($merged) ? implode(',', array_values(array_filter($merged))) : null;
        }

        // Handle Layout Plans (Optional)
        $layoutPlans = [];
        if ($request->has('layout_titles')) {
            $titles = $request->layout_titles;
            $files = $request->file('layout_images') ?? [];
            $existingLayouts = $request->existing_layout_images ?? [];
            foreach ($titles as $idx => $title) {
                $imgPath = $existingLayouts[$idx] ?? null;
                if (isset($files[$idx]) && $files[$idx] && $files[$idx]->isValid()) {
                    $layoutDir = public_path('storage/Admin/residence/layouts');
                    if (!file_exists($layoutDir)) {
                        mkdir($layoutDir, 0777, true);
                    }
                    $fileName = 'layout_' . uniqid() . '.' . $files[$idx]->getClientOriginalExtension();
                    $files[$idx]->move($layoutDir, $fileName);
                    $imgPath = 'storage/Admin/residence/layouts/' . $fileName;
                }
                if (!empty(trim($title ?? '')) || !empty($imgPath)) {
                    $layoutPlans[] = [
                        'title' => trim($title ?? ''),
                        'image' => $imgPath ?? ''
                    ];
                }
            }
        }
        $data['layout_plans'] = !empty($layoutPlans) ? json_encode($layoutPlans) : null;

        DB::table('residences')->where('id', $id)->update($data);
        return response()->json(['success' => 'success', 'message' => 'Residence updated successfully!']);
    }

    public function DeleteResidence(Request $request)
    {
        DB::table('residences')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Residence deleted successfully!']);
    }

    // =========================================================================
    // ✨ 6. AMENITIES MANAGEMENT (Simplified: Amenity Name + Image only)
    // =========================================================================

    public function Amenities()
    {
        return view('Admin.pages.amenities');
    }

    public function ShowAmenities(Request $request)
    {
        $search = $request->search;
        $status = $request->status;
        $query = DB::table('amenities');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', '%' . $search . '%');
            });
        }

        if (isset($status) && $status !== null && $status !== '') {
            $query->where('status', (int) $status);
        }

        $amenities = $query->orderBy('id', 'desc')->paginate(10);
        return response()->json([
            'data' => $amenities->items(),
            'current_page' => $amenities->currentPage(),
            'last_page' => $amenities->lastPage(),
            'per_page' => $amenities->perPage(),
            'total' => $amenities->total(),
            'success' => 'success',
        ]);
    }

    public function AddAmenity(Request $request)
    {
        $imagePath = '';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/amenities'), $fileName);
            $imagePath = 'storage/Admin/amenities/' . $fileName;
        }

        $name = $request->name ?? $request->title ?? $request->amenity_name;

        DB::table('amenities')->insert([
            'name' => $name,
            'image' => $imagePath,
            'status' => $request->status ?? 1,
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success', 'message' => 'Amenity added successfully!']);
    }

    public function UpdateAmenity(Request $request)
    {
        $id = $request->id;
        $name = $request->amenity_name;

        $data = [
            'name' => $name,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/amenities'), $fileName);
            $data['image'] = 'storage/Admin/amenities/' . $fileName;
        }

        DB::table('amenities')->where('id', $id)->update($data);
        return response()->json(['success' => 'success', 'message' => 'Amenity updated successfully!']);
    }

    public function DeleteAmenity(Request $request)
    {
        DB::table('amenities')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Amenity deleted successfully!']);
    }

    // =========================================================================
    // 📰 7. BLOGS MANAGEMENT
    // =========================================================================

    public function Blogs()
    {
        return view('Admin.pages.blogs');
    }

    public function ShowBlogs(Request $request)
    {
        $search = $request->search;
        $status = $request->status;
        $query = DB::table('blogs');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('title', 'like', '%' . $search . '%')
                    ->orWhere('category', 'like', '%' . $search . '%')
                    ->orWhere('short_description', 'like', '%' . $search . '%')
                    ->orWhere('description', 'like', '%' . $search . '%');
            });
        }

        if (isset($status) && $status !== null && $status !== '') {
            $query->where('status', (int) $status);
        }

        $blogs = $query->orderBy('id', 'desc')->paginate(10);
        return response()->json([
            'data' => $blogs->items(),
            'current_page' => $blogs->currentPage(),
            'last_page' => $blogs->lastPage(),
            'per_page' => $blogs->perPage(),
            'total' => $blogs->total(),
            'success' => 'success',
        ]);
    }

    public function AddBlog(Request $request)
    {
        $imagePath = '';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/blogs'), $fileName);
            $imagePath = 'storage/Admin/blogs/' . $fileName;
        }

        $slug = Str::slug($request->title);
        $count = DB::table('blogs')->where('slug', $slug)->count();
        if ($count > 0) {
            $slug = $slug . '-' . time();
        }

        $description = $request->description ?? $request->content ?? '';

        DB::table('blogs')->insert([
            'title' => $request->title,
            'slug' => $slug,
            'category' => $request->category ?? 'Architecture',
            'blog_date' => $request->blog_date ?? date('Y-m-d'),
            'image' => $imagePath,
            'short_description' => $request->short_description,
            'description' => $description,
            'status' => $request->status ?? 1,
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);

        return response()->json(['success' => 'success', 'message' => 'Blog added successfully!']);
    }

    public function UpdateBlog(Request $request)
    {
        $id = $request->id;
        $description = $request->description ?? $request->content ?? '';
        $data = [
            'title' => $request->title,
            'category' => $request->category ?? 'Architecture',
            'blog_date' => $request->blog_date ?? date('Y-m-d'),
            'short_description' => $request->short_description,
            'description' => $description,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/blogs'), $fileName);
            $data['image'] = 'storage/Admin/blogs/' . $fileName;
        }

        DB::table('blogs')->where('id', $id)->update($data);
        return response()->json(['success' => 'success', 'message' => 'Blog updated successfully!']);
    }

    public function DeleteBlog(Request $request)
    {
        DB::table('blogs')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Blog deleted successfully!']);
    }

    // =========================================================================
    // ❓ 8. FAQS MANAGEMENT (QUESTION & ANSWER ONLY)
    // =========================================================================

    public function Faq()
    {
        return view('Admin.pages.faq');
    }

    public function ShowFaq(Request $request)
    {
        $search = $request->search;
        $query = DB::table('faqs');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('question', 'like', '%' . $search . '%')
                    ->orWhere('answer', 'like', '%' . $search . '%');
            });
        }

        $faqs = $query->orderBy('id', 'asc')->paginate(10);
        return response()->json([
            'data' => $faqs->items(),
            'current_page' => $faqs->currentPage(),
            'last_page' => $faqs->lastPage(),
            'per_page' => $faqs->perPage(),
            'total' => $faqs->total(),
            'success' => 'success',
        ]);
    }

    public function AddFaq(Request $request)
    {
        DB::table('faqs')->insert([
            'question' => $request->question,
            'answer' => $request->answer,
            'status' => $request->status ?? '1',
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ]);
        return response()->json(['success' => 'success', 'message' => 'FAQ added successfully!']);
    }

    public function UpdateFaq(Request $request)
    {
        $data = [
            'question' => $request->question,
            'answer' => $request->answer,
            'updated_at' => $this->datetime,
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        DB::table('faqs')->where('id', $request->id)->update($data);
        return response()->json(['success' => 'success', 'message' => 'FAQ updated successfully!']);
    }

    public function DeleteFaq(Request $request)
    {
        DB::table('faqs')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'FAQ deleted successfully!']);
    }

    // =========================================================================
    // 🖼️ 9. GALLERY MANAGEMENT
    // =========================================================================

    public function Gallery()
    {
        $categories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
        return view('Admin.pages.gallery', compact('categories'));
    }

    public function ShowGallery(Request $request)
    {
        $search = $request->search;
        $status = $request->status;
        $categoryId = $request->category_id;
        $query = DB::table('galleries')
            ->leftJoin('categories', 'galleries.category_id', '=', 'categories.id')
            ->select('galleries.*', 'categories.category_name');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('galleries.title', 'like', '%' . $search . '%')
                    ->orWhere('galleries.description', 'like', '%' . $search . '%')
                    ->orWhere('categories.category_name', 'like', '%' . $search . '%');
            });
        }

        if (isset($categoryId) && $categoryId !== null && $categoryId !== '') {
            $query->where('galleries.category_id', $categoryId);
        }

        if (isset($status) && $status !== null && $status !== '') {
            $query->where('galleries.status', (int) $status);
        }

        $galleries = $query->orderBy('galleries.id', 'desc')->paginate(10);

        $data = collect($galleries->items())->map(function ($item) {
            $img = $item->image ?? '';
            if (!empty($img)) {
                if (!str_starts_with($img, 'http') && !str_starts_with($img, '/')) {
                    $img = asset($img);
                }
            } else {
                $img = asset('Admin/assets/images/ulhas_logo.png');
            }
            return [
                'id' => $item->id,
                'category_id' => $item->category_id,
                'category_name' => $item->category_name ?? '-',
                'title' => $item->title ?? '-',
                'description' => $item->description ?? '',
                'image' => $img,
                'status' => $item->status ?? 1,
                'created_at' => $item->created_at ?? $this->datetime,
                'updated_at' => $item->updated_at ?? $this->datetime
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $galleries->currentPage(),
            'last_page' => $galleries->lastPage(),
            'per_page' => $galleries->perPage(),
            'total' => $galleries->total(),
            'success' => 'success',
        ]);
    }

    public function AddGallery(Request $request)
    {
        try {
            $destinationPath = public_path('storage/Admin/gallery');
            if (!file_exists($destinationPath)) {
                @mkdir($destinationPath, 0777, true);
            }
            @chmod($destinationPath, 0777);

            $file = null;
            if ($request->hasFile('image')) {
                $file = $request->file('image');
            } elseif ($request->hasFile('images')) {
                $file = $request->file('images');
            } elseif (!empty($request->allFiles())) {
                $allFiles = $request->allFiles();
                $first = reset($allFiles);
                $file = is_array($first) ? $first[0] : $first;
            }

            if (is_array($file) && count($file) > 0) {
                $file = $file[0];
            }

            $imagePath = '';
            if ($file) {
                if ($file->isValid()) {
                    $ext = $file->getClientOriginalExtension();
                    if (empty($ext)) {
                        $ext = $file->guessExtension() ?: 'jpg';
                    }
                    $fileName = time() . '_' . uniqid() . '.' . strtolower($ext);
                    $file->move($destinationPath, $fileName);
                    $imagePath = 'storage/Admin/gallery/' . $fileName;
                } else {
                    return response()->json([
                        'success' => 'error',
                        'message' => 'Image upload failed: ' . $file->getErrorMessage()
                    ]);
                }
            }

            if (empty($imagePath)) {
                if ($request->filled('image') && is_string($request->image)) {
                    $imagePath = $request->image;
                } else {
                    return response()->json([
                        'success' => 'error',
                        'message' => 'Please select a valid image file to upload.'
                    ]);
                }
            }

            DB::table('galleries')->insert([
                'category_id' => $request->category_id ?? null,
                'title' => $request->title ?? 'Gallery Image',
                'description' => $request->description ?? '',
                'image' => $imagePath,
                'status' => $request->status ?? 1,
                'created_at' => $this->datetime ?? currentDateTime(),
                'updated_at' => $this->datetime ?? currentDateTime(),
            ]);

            return response()->json(['success' => 'success', 'message' => 'Gallery photo added successfully!']);
        } catch (\Exception $e) {
            return response()->json(['success' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function UpdateGallery(Request $request)
    {
        try {
            $id = $request->id;
            $data = [
                'category_id' => $request->category_id ?? null,
                'title' => $request->title,
                'description' => $request->description,
                'updated_at' => $this->datetime ?? currentDateTime(),
            ];

            if ($request->has('status') && $request->status !== null && $request->status !== '') {
                $data['status'] = $request->status;
            }

            $destinationPath = public_path('storage/Admin/gallery');
            if (!file_exists($destinationPath)) {
                @mkdir($destinationPath, 0777, true);
            }
            @chmod($destinationPath, 0777);

            $file = null;
            if ($request->hasFile('image')) {
                $file = $request->file('image');
            } elseif ($request->hasFile('images')) {
                $file = $request->file('images');
            } elseif (!empty($request->allFiles())) {
                $allFiles = $request->allFiles();
                $first = reset($allFiles);
                $file = is_array($first) ? $first[0] : $first;
            }

            if (is_array($file) && count($file) > 0) {
                $file = $file[0];
            }

            if ($file) {
                if ($file->isValid()) {
                    $ext = $file->getClientOriginalExtension();
                    if (empty($ext)) {
                        $ext = $file->guessExtension() ?: 'jpg';
                    }
                    $fileName = time() . '_' . uniqid() . '.' . strtolower($ext);
                    $file->move($destinationPath, $fileName);
                    $data['image'] = 'storage/Admin/gallery/' . $fileName;

                    // Delete old image if exists
                    $oldGallery = DB::table('galleries')->where('id', $id)->first();
                    if ($oldGallery && !empty($oldGallery->image)) {
                        $oldFilePath = public_path($oldGallery->image);
                        if (file_exists($oldFilePath) && is_file($oldFilePath)) {
                            @unlink($oldFilePath);
                        }
                    }
                } else {
                    return response()->json([
                        'success' => 'error',
                        'message' => 'Image upload failed: ' . $file->getErrorMessage()
                    ]);
                }
            }

            DB::table('galleries')->where('id', $id)->update($data);
            return response()->json(['success' => 'success', 'message' => 'Gallery photo updated successfully!']);
        } catch (\Exception $e) {
            return response()->json(['success' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    public function DeleteGallery(Request $request)
    {
        try {
            $gallery = DB::table('galleries')->where('id', $request->id)->first();
            if ($gallery && !empty($gallery->image)) {
                $filePath = public_path($gallery->image);
                if (file_exists($filePath) && is_file($filePath)) {
                    @unlink($filePath);
                }
            }
            DB::table('galleries')->where('id', $request->id)->delete();
            return response()->json(['success' => 'success', 'message' => 'Gallery photo deleted successfully!']);
        } catch (\Exception $e) {
            return response()->json(['success' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
        }
    }

    // =========================================================================
    // 💬 10. GUEST REVIEWS & TESTIMONIALS MANAGEMENT
    // =========================================================================

    public function Review()
    {
        return view('Admin.pages.reviews');
    }

    public function ShowReview(Request $request)
    {
        $search = $request->search;
        $query = DB::table('reviews');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('name', 'like', '%' . $search . '%')
                    ->orWhere('designation', 'like', '%' . $search . '%')
                    ->orWhere('city', 'like', '%' . $search . '%')
                    ->orWhere('feedback', 'like', '%' . $search . '%');
            });
        }

        $reviews = $query->orderBy('id', 'desc')->paginate(10);
        return response()->json([
            'data' => $reviews->items(),
            'current_page' => $reviews->currentPage(),
            'last_page' => $reviews->lastPage(),
            'per_page' => $reviews->perPage(),
            'total' => $reviews->total(),
            'success' => 'success',
        ]);
    }

    public function AddReview(Request $request)
    {
        $imagePath = '';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/review'), $fileName);
            $imagePath = 'storage/Admin/review/' . $fileName;
        }

        DB::table('reviews')->insert([
            'name' => $request->name,
            'designation' => $request->designation,
            'city' => $request->designation ?? $request->city,
            'image' => $imagePath,
            'rating' => $request->rating ?? '5',
            'feedback' => $request->feedback,
            'status' => $request->status ?? '1',
            'created_at' => currentDateTime(),
            'updated_at' => currentDateTime(),
        ]);

        return response()->json(['success' => 'success', 'message' => 'Guest review added successfully!']);
    }

    public function UpdateReview(Request $request)
    {
        $id = $request->id;
        $data = [
            'name' => $request->name,
            'designation' => $request->designation,
            'city' => $request->designation ?? $request->city,
            'rating' => $request->rating ?? '5',
            'feedback' => $request->feedback,
            'updated_at' => currentDateTime(),
        ];

        if ($request->has('status') && $request->status !== null && $request->status !== '') {
            $data['status'] = $request->status;
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('storage/Admin/review'), $fileName);
            $data['image'] = 'storage/Admin/review/' . $fileName;
        }

        DB::table('reviews')->where('id', $id)->update($data);
        return response()->json(['success' => 'success', 'message' => 'Guest review updated successfully!']);
    }

    public function DeleteReview(Request $request)
    {
        DB::table('reviews')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Guest review deleted successfully!']);
    }

    // =========================================================================
    // 📞 11. CONTACTS & INQUIRIES MANAGEMENT
    // =========================================================================

    public function contact()
    {
        return view('Admin.pages.contact');
    }

    public function showContact(Request $request)
    {
        $search = $request->search;
        $startDate = $request->start_date;
        $endDate = $request->end_date;
        $date = $request->date;

        $query = DB::table('contacts')
            ->leftJoin('residences', 'contacts.residence_id', '=', 'residences.id')
            ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
            ->select(
                'contacts.*',
                'residences.name as residence_name',
                DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name')
            );

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q
                    ->where('contacts.name', 'like', '%' . $search . '%')
                    ->orWhere('contacts.email', 'like', '%' . $search . '%')
                    ->orWhere('contacts.mobile', 'like', '%' . $search . '%')
                    ->orWhere('contacts.subject', 'like', '%' . $search . '%')
                    ->orWhere('contacts.message', 'like', '%' . $search . '%')
                    ->orWhere('residences.name', 'like', '%' . $search . '%')
                    ->orWhere('categories.category_name', 'like', '%' . $search . '%');
            });
        }

        if ($date) {
            $dateRange = explode(' to ', $date);
            if (count($dateRange) == 2) {
                $query
                    ->whereDate('contacts.created_at', '>=', trim($dateRange[0]))
                    ->whereDate('contacts.created_at', '<=', trim($dateRange[1]));
            } else {
                $query->whereDate('contacts.created_at', trim($dateRange[0]));
            }
        } elseif ($startDate || $endDate) {
            if ($startDate) {
                $query->whereDate('contacts.created_at', '>=', $startDate);
            }
            if ($endDate) {
                $query->whereDate('contacts.created_at', '<=', $endDate);
            }
        }

        $contacts = $query->orderBy('contacts.id', 'desc')->paginate(10);
        $data = collect($contacts->items())->map(function ($item) {
            return [
                'id' => $item->id,
                'name' => $item->name,
                'mobile' => $item->mobile,
                'email' => $item->email,
                'city' => $item->city ?? '-',
                'residence_id' => $item->residence_id,
                'residence_name' => $item->residence_name ?? ($item->subject ?? '-'),
                'category_name' => $item->category_name ?? '-',
                'subject' => $item->subject,
                'message' => $item->message,
                'created_at' => $item->created_at ?? $this->datetime,
                'updated_at' => $item->updated_at ?? $this->datetime,
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $contacts->currentPage(),
            'last_page' => $contacts->lastPage(),
            'per_page' => $contacts->perPage(),
            'total' => $contacts->total(),
            'success' => 'success',
        ]);
    }

    public function DeleteEnquiry(Request $request)
    {
        DB::table('contacts')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Contact message deleted successfully!']);
    }

    // =========================================================================
    // ⚙️ 11. WEBSITE INFORMATION, BROCHURE FILE & DYNAMIC PAGE SEO
    // =========================================================================

    public function Information()
    {
        $result = DB::table('information')->first();
        $info = $result;
        $page_seos = DB::table('page_seos')->get();
        return view('Admin.pages.website', compact('result', 'info', 'page_seos'));
    }

    public function UpdateWebsite(Request $request)
    {
        if ($request->isMethod('get')) {
            return redirect('/admin-website');
        }

        try {
            $data = [
                'notice' => $request->notice,
                'footer_about' => $request->footer_about,
                'mobile' => $request->mobile,
                'email' => $request->email,
                'rera_number' => $request->rera_number,
                'office_time' => $request->office_time,
                'address' => $request->address,
                'map_link' => $request->map_link,
                'instagram_link' => $request->instagram_link,
                'facebook_link' => $request->facebook_link,
                'youtube_link' => $request->youtube_link,
                'linkedin_link' => $request->linkedin_link,
                'term_condition' => $request->term_condition,
                'privacy_policy' => $request->privacy_policy,
                'return_policy' => $request->return_policy,
                'updated_at' => $this->datetime,
            ];

            $infoExists = DB::table('information')->first();

            // Header Logo
            if ($request->hasFile('header_logo')) {
                if (!empty($infoExists) && !empty($infoExists->header_logo)) {
                    $oldLogoPath = public_path($infoExists->header_logo);
                    if (file_exists($oldLogoPath) && is_file($oldLogoPath)) {
                        @unlink($oldLogoPath);
                    }
                }
                $file = $request->file('header_logo');
                $filename = 'header_logo_' . time() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('storage/Admin/logo'), $filename);
                $data['header_logo'] = 'storage/Admin/logo/' . $filename;
            }

            // Footer Logo
            if ($request->hasFile('footer_logo')) {
                if (!empty($infoExists) && !empty($infoExists->footer_logo)) {
                    $oldFooterPath = public_path($infoExists->footer_logo);
                    if (file_exists($oldFooterPath) && is_file($oldFooterPath)) {
                        @unlink($oldFooterPath);
                    }
                }
                $file = $request->file('footer_logo');
                $filename = 'footer_logo_' . time() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('storage/Admin/logo'), $filename);
                $data['footer_logo'] = 'storage/Admin/logo/' . $filename;
            }

            // Save Brochure File (PDF/Image) in information table and delete old brochure from folder
            if ($request->hasFile('brochure_file')) {
                $brochureDir = public_path('storage/Admin/brochures');
                if (!file_exists($brochureDir)) {
                    @mkdir($brochureDir, 0777, true);
                }

                if (!empty($infoExists) && !empty($infoExists->brochure_file)) {
                    $oldBrochureRel = ltrim($infoExists->brochure_file, '/\\');
                    // Avoid deleting seed static assets
                    if (!str_contains($oldBrochureRel, 'Website/assets') && !str_contains($oldBrochureRel, 'Admin/assets')) {
                        $oldBrochurePath = public_path($oldBrochureRel);
                        if (file_exists($oldBrochurePath) && is_file($oldBrochurePath)) {
                            @unlink($oldBrochurePath);
                        }
                        $storageSub = preg_replace('#^/?storage/#', '', $oldBrochureRel);
                        $oldStoragePath = storage_path('app/public/' . $storageSub);
                        if (file_exists($oldStoragePath) && is_file($oldStoragePath)) {
                            @unlink($oldStoragePath);
                        }
                    }
                }

                $file = $request->file('brochure_file');
                $ext = strtolower($file->getClientOriginalExtension());
                $filename = 'ulhas_vilas_brochure_' . time() . '.' . $ext;
                $file->move($brochureDir, $filename);
                $data['brochure_file'] = 'storage/Admin/brochures/' . $filename;
            }

            if ($infoExists) {
                DB::table('information')->where('id', $infoExists->id)->update($data);
            } else {
                $data['created_at'] = $this->datetime;
                DB::table('information')->insert($data);
            }

            // Dynamic Page SEO Updates (From form arrays: seo_titles, seo_descriptions, seo_keywords, seo_scripts, and file uploads for seo_og_images)
            $seoTitles = $request->input('seo_titles', []);
            $seoDescs = $request->input('seo_descriptions', []);
            $seoKeywords = $request->input('seo_keywords', []);
            $seoScripts = $request->input('seo_scripts', []);

            // Ensure public/storage/Admin/seo directory exists
            if (!file_exists(public_path('storage/Admin/seo'))) {
                mkdir(public_path('storage/Admin/seo'), 0777, true);
            }

            if (is_array($seoTitles)) {
                foreach ($seoTitles as $pageKey => $metaTitle) {
                    $pageName = ucwords(str_replace('_', ' ', $pageKey));
                    $metaDesc = $seoDescs[$pageKey] ?? null;
                    $metaKey = $seoKeywords[$pageKey] ?? null;
                    $metaScript = $seoScripts[$pageKey] ?? null;

                    $seoData = [
                        'page_name' => $pageName,
                        'meta_title' => $metaTitle,
                        'meta_description' => $metaDesc,
                        'meta_keywords' => $metaKey,
                        'custom_script' => $metaScript,
                        'updated_at' => $this->datetime,
                    ];

                    // Handle OG Image File Upload for this page
                    if ($request->hasFile("seo_og_images.{$pageKey}")) {
                        $file = $request->file("seo_og_images.{$pageKey}");
                        if ($file && $file->isValid()) {
                            $filename = 'og_' . $pageKey . '_' . time() . '.' . $file->getClientOriginalExtension();
                            $file->move(public_path('storage/Admin/seo'), $filename);
                            $seoData['og_image'] = 'storage/Admin/seo/' . $filename;
                        }
                    }

                    DB::table('page_seos')->updateOrInsert(
                        ['page_key' => $pageKey],
                        $seoData
                    );
                }
            }

            if ($request->ajax()) {
                return response()->json(['success' => 'success', 'message' => 'Website information & Dynamic SEO updated successfully!']);
            }

            return redirect()->back()->with('success', 'Website settings updated successfully!');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json(['success' => 'error', 'message' => $e->getMessage()], 500);
            }
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // =========================================================================
    // 📰 12. NEWSLETTER SUBSCRIBERS MANAGEMENT
    // =========================================================================

    public function Newsletter()
    {
        return view('Admin.pages.newsletter');
    }

    public function ShowNewsletter(Request $request)
    {
        $search = $request->search;
        $query = DB::table('newsletter_subscribers');

        if ($search) {
            $query->where('email', 'like', '%' . $search . '%');
        }

        $subscribers = $query->orderBy('id', 'desc')->paginate(15);

        return response()->json([
            'data' => $subscribers->items(),
            'current_page' => $subscribers->currentPage(),
            'last_page' => $subscribers->lastPage(),
            'per_page' => $subscribers->perPage(),
            'total' => $subscribers->total(),
            'success' => 'success',
        ]);
    }

    public function DeleteNewsletter(Request $request)
    {
        DB::table('newsletter_subscribers')->where('id', $request->id)->delete();
        return response()->json(['success' => 'success', 'message' => 'Newsletter subscriber deleted successfully!']);
    }
}
