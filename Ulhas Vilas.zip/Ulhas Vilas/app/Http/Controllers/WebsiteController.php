<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class WebsiteController extends Controller
{
    /**
     * Helper to get common website data
     */
    private function getCommonData()
    {
        $info = DB::table('information')->first();
        $categories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('category_name', 'asc')->get();
        $residences = DB::table('residences')
            ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
            ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
            ->where('residences.status', 1)
            ->orderBy('residences.id', 'asc')
            ->get();
        return [
            'info' => $info,
            'categories' => $categories,
            'residences' => $residences,
        ];
    }

    /**
     * 1. Home Page
     */
    public function index()
    {
        $data = $this->getCommonData();
        $data['amenities'] = DB::table('amenities')->where('status', 1)->orderBy('id', 'asc')->get();
        $data['galleries'] = DB::table('galleries')
            ->leftJoin('categories', 'galleries.category_id', '=', 'categories.id')
            ->select('galleries.*', 'categories.category_name')
            ->whereIn('galleries.status', [1, '1'])
            ->orderBy('galleries.id', 'asc')
            ->limit(4)
            ->get();

        // Blog query: prioritize upcoming / nearest blog date, or recent blogs
        $today = date('Y-m-d');
        $data['blogs'] = DB::table('blogs')
            ->whereIn('status', [1, '1'])
            ->orderByRaw("CASE WHEN blog_date >= '{$today}' THEN 0 ELSE 1 END, blog_date DESC, id DESC")
            ->limit(4)
            ->get();

        $data['reviews'] = DB::table('reviews')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
        $data['faqs'] = DB::table('faqs')->where('status', 1)->orderBy('id', 'asc')->limit(6)->get();
        return view('Website.index', $data);
    }

    /**
     * 2. About Us Page
     */
    public function about()
    {
        $data = $this->getCommonData();
        return view('Website.about', $data);
    }

    /**
     * 3. Residences Listing Page
     */
    public function residences()
    {
        $data = $this->getCommonData();
        return view('Website.residences', $data);
    }

    /**
     * 4. Match Category ID -> Redirect to Residence Slug
     */
    public function residenceByCategory($categoryId)
    {
        $residence = DB::table('residences')->where('category_id', $categoryId)->where('status', 1)->first();
        if (!$residence) {
            $residence = DB::table('residences')->where('category_id', $categoryId)->first();
        }

        if ($residence && !empty($residence->slug)) {
            return redirect('/residence/' . $residence->slug);
        }

        return redirect('/residences');
    }

    /**
     * 5. Residence Detail Page by Slug
     */
    public function residenceDetail($slug)
    {
        $data = $this->getCommonData();

        // If numeric ID is passed (e.g. category_id or residence id), redirect to its slug URL
        if (is_numeric($slug)) {
            $matched = DB::table('residences')->where('category_id', $slug)->first();
            if (!$matched) {
                $matched = DB::table('residences')->where('id', $slug)->first();
            }
            if ($matched && !empty($matched->slug)) {
                return redirect('/residence/' . $matched->slug);
            }
        }

        $residence = DB::table('residences')
            ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
            ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
            ->where('residences.slug', $slug)
            ->first();

        if (!$residence) {
            $residence = DB::table('residences')
                ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
                ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
                ->where('residences.id', $slug)
                ->first();
        }

        if (!$residence) {
            return redirect('/residences');
        }

        $data['residence'] = $residence;
        $data['all_residences'] = DB::table('residences')
            ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
            ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
            ->where('residences.status', 1)
            ->where('residences.id', '!=', $residence->id)
            ->get();

        // Fetch Amenities specified in $residence->amenity_id
        $amenityIds = [];
        if (!empty($residence->amenity_id)) {
            $amenityIds = array_filter(array_map('trim', explode(',', $residence->amenity_id)));
        }
        if (!empty($amenityIds)) {
            $data['residence_amenities'] = DB::table('amenities')
                ->whereIn('id', $amenityIds)
                ->where('status', 1)
                ->orderBy('id', 'asc')
                ->get();
        } else {
            $data['residence_amenities'] = DB::table('amenities')->where('status', 1)->orderBy('id', 'asc')->get();
        }

        // Fetch Galleries BHK-wise for current residence only
        $residenceCatId = $residence->category_id;
        if (is_string($residenceCatId) && str_starts_with(trim($residenceCatId), '[')) {
            $parsed = json_decode($residenceCatId, true);
            $residenceCatId = is_array($parsed) && count($parsed) > 0 ? $parsed[0] : null;
        }

        $galleryQuery = DB::table('galleries')
            ->leftJoin('categories', 'galleries.category_id', '=', 'categories.id')
            ->select('galleries.*', 'categories.category_name')
            ->whereIn('galleries.status', [1, '1']);

        if (!empty($residenceCatId)) {
            $galleryQuery->where('galleries.category_id', $residenceCatId);
        }

        $galleries = $galleryQuery->orderBy('galleries.id', 'desc')->get();

        if ($galleries->isEmpty()) {
            $galleries = DB::table('galleries')
                ->leftJoin('categories', 'galleries.category_id', '=', 'categories.id')
                ->select('galleries.*', 'categories.category_name')
                ->whereIn('galleries.status', [1, '1'])
                ->orderBy('galleries.id', 'desc')
                ->limit(8)
                ->get();
        }

        $data['galleries'] = $galleries;

        // Fetch FAQs
        $data['faqs'] = DB::table('faqs')->where('status', 1)->orderBy('id', 'asc')->get();

        return view('Website.residence_detail', $data);
    }

    /**
     * 5. Amenities & Wellness Page
     */
    public function amenities()
    {
        $data = $this->getCommonData();
        $data['amenities'] = DB::table('amenities')->where('status', 1)->orderBy('id', 'desc')->get();
        $data['reviews'] = DB::table('reviews')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
        return view('Website.amenities', $data);
    }

    /**
     * 6. Visual Gallery Page
     */
    public function gallery()
    {
        $data = $this->getCommonData();
        $data['categories'] = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
        $data['galleries'] = DB::table('galleries')
            ->leftJoin('categories', 'galleries.category_id', '=', 'categories.id')
            ->select('galleries.*', 'categories.category_name')
            ->whereIn('galleries.status', [1, '1'])
            ->orderBy('galleries.id', 'asc')
            ->get();
        return view('Website.gallery', $data);
    }

    /**
     * 7. Blogs List Page
     */
    public function blogs()
    {
        $data = $this->getCommonData();
        $today = date('Y-m-d');

        // Feature article: upcoming closest date, or latest published
        $featuredBlog = DB::table('blogs')
            ->where('status', 1)
            ->whereNotNull('blog_date')
            ->where('blog_date', '>=', $today)
            ->orderBy('blog_date', 'asc')
            ->first();

        if (!$featuredBlog) {
            $featuredBlog = DB::table('blogs')
                ->where('status', 1)
                ->orderBy('blog_date', 'desc')
                ->orderBy('id', 'desc')
                ->first();
        }

        $featuredId = $featuredBlog ? $featuredBlog->id : 0;

        $blogsQuery = DB::table('blogs')
            ->where('status', 1)
            ->where('id', '!=', $featuredId)
            ->orderBy('blog_date', 'desc')
            ->orderBy('id', 'desc');

        $data['featuredBlog'] = $featuredBlog;
        $data['blogs'] = $blogsQuery->paginate(9);
        return view('Website.blog', $data);
    }

    /**
     * 8. Blog Detail Page
     */
    public function blogDetail($slug)
    {
        $data = $this->getCommonData();
        $blog = DB::table('blogs')->where('slug', $slug)->first();
        if (!$blog) {
            $blog = DB::table('blogs')->where('id', $slug)->first();
        }
        if (!$blog) {
            $blog = DB::table('blogs')->where('status', 1)->orderBy('id', 'desc')->first();
        }
        if (!$blog) {
            return redirect('/blogs');
        }

        $data['blog'] = $blog;
        $data['recent_blogs'] = DB::table('blogs')->where('status', 1)->where('id', '!=', $blog->id)->limit(4)->get();
        return view('Website.blog-detail', $data);
    }

    /**
     * 9. FAQs Page
     */
    public function faq()
    {
        $data = $this->getCommonData();
        $data['faqs'] = DB::table('faqs')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
        return view('Website.faq', $data);
    }

    /**
     * 10. Contact Us Page
     */
    public function contact()
    {
        $data = $this->getCommonData();
        return view('Website.contact', $data);
    }

    /**
     * 11. Contact Form Submit Handler with Validation & Brochure Download
     */
    public function contactSubmit(Request $request)
    {
        // Support 'phone' as alias for 'mobile'
        if (!$request->has('mobile') && $request->has('phone')) {
            $request->merge(['mobile' => $request->phone]);
        }

        // Auto-generate message if empty
        if (!$request->has('message') || empty(trim((string) $request->message))) {
            $configName = $request->configuration ?? $request->residence_name ?? $request->subject ?? 'Residence';
            $msg = 'Inquiry for ' . $configName;
            if ($request->has('request_type')) {
                $msg .= ' | Request: ' . $request->request_type;
            }
            if ($request->has('date') && !empty($request->date)) {
                $msg .= ' | Date: ' . $request->date;
            }
            $request->merge(['message' => $msg]);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|min:2|max:100',
            'mobile' => 'required|regex:/^[0-9]{10}$/',
            'email' => 'required|email|max:150',
            'city' => 'nullable|string|max:100',
            'residence_id' => 'nullable',
            'configuration' => 'nullable|string|max:150',
            'message' => 'required|string|min:3|max:1000',
        ], [
            'name.required' => 'Please enter your full name.',
            'name.min' => 'Full name must be at least 2 characters.',
            'mobile.required' => 'Please enter your 10-digit mobile number.',
            'mobile.regex' => 'Mobile number must be exactly 10 digits.',
            'email.required' => 'Please enter your email address.',
            'email.email' => 'Please enter a valid email address.',
            'message.required' => 'Please enter your message or requirements.',
            'message.min' => 'Message must be at least 3 characters.',
        ]);

        if ($validator->fails()) {
            if ($request->ajax() || $request->wantsJson() || $request->expectsJson() || $request->header('Accept') === 'application/json') {
                return response()->json(['success' => false, 'message' => $validator->errors()->first()], 422);
            }
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $residenceId = $request->residence_id;
        $residence = null;

        if (!empty($residenceId) && is_numeric($residenceId)) {
            $residence = DB::table('residences')
                ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
                ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
                ->where('residences.id', $residenceId)
                ->first();
        } elseif (!empty($request->configuration) && is_numeric($request->configuration)) {
            $residence = DB::table('residences')
                ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
                ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
                ->where('residences.id', $request->configuration)
                ->first();
            $residenceId = $residence ? $residence->id : null;
        } elseif (!empty($request->configuration)) {
            $residence = DB::table('residences')
                ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
                ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
                ->where('residences.name', $request->configuration)
                ->first();
            $residenceId = $residence ? $residence->id : null;
        }

        $residenceName = $residence ? $residence->name : null;
        $categoryName = $residence ? $residence->category_name : null;

        $config = $residenceName ? ($residenceName . ($categoryName ? ' (' . $categoryName . ')' : '')) : ($request->configuration ?? $request->subject ?? 'General Residence Inquiry');

        $contactData = [
            'name' => $request->name,
            'mobile' => $request->mobile,
            'email' => $request->email,
            'city' => $request->city ?? null,
            'residence_id' => $residenceId,
            'subject' => $config,
            'message' => $request->message ?? ('Contact form enquiry for ' . $config),
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ];

        // Save to contacts
        DB::table('contacts')->insert($contactData);

        $info = DB::table('information')->first();
        $brochureInfo = $this->resolveBrochureFileInfo();
        $brochureUrl = $brochureInfo['url'];

        $mailData = [
            'name' => $request->name,
            'mobile' => $request->mobile,
            'email' => $request->email,
            'city' => $request->city ?? 'Not specified',
            'subject' => $config,
            'configuration' => $config,
            'message' => $request->message ?? '',
            'brochure_url' => $brochureInfo['exists'] ? $brochureUrl : null,
            'brochure_file_path' => $brochureInfo['path'],
            'has_brochure' => $brochureInfo['exists'],
            'brochure_type' => $brochureInfo['type_label'],
            'brochure_ext' => $brochureInfo['ext'],
            'is_pdf' => $brochureInfo['is_pdf'],
            'is_image' => $brochureInfo['is_image'],
            'company_phone' => $info->phone ?? $info->mobile ?? '9876543210',
            'company_email' => $info->email ?? 'info@theulhasvilas.com',
            'company_address' => $info->address ?? 'Solan, Himachal Pradesh, India',
            'created_at' => $this->datetime,
            'updated_at' => $this->datetime,
        ];

        // Send Confirmation Email with Brochure directly to the User
        try {
            if (!empty($request->email)) {
                Mail::to($request->email)->send(new \App\Mail\ContactMail($mailData));
            }
        } catch (\Throwable $e) {
            Log::error('User contact form email notification failed: ' . $e->getMessage());
        }

        session()->flash('form_submitted', true);
        session()->put('allow_thankyou', time());

        if ($request->ajax() || $request->wantsJson() || $request->expectsJson() || $request->header('Accept') === 'application/json') {
            return response()->json([
                'success' => true,
                'message' => 'Thank you! Your enquiry has been submitted successfully.',
                'download_url' => $brochureUrl,
                'redirect_url' => url('/thank-you'),
                'has_brochure' => $brochureInfo['exists'],
                'brochure_type' => $brochureInfo['type_label'],
            ]);
        }

        return redirect('/thank-you')->with([
            'success' => 'Thank you! Your enquiry has been received.',
            'brochure_url' => $brochureUrl,
        ]);
    }

    /**
     * Resolve the master brochure file path and metadata (PDF or Image)
     */
    public function resolveBrochureFileInfo()
    {
        $info = DB::table('information')->first();
        $brochureRel = (!empty($info) && !empty($info->brochure_file)) ? trim($info->brochure_file) : null;
        $fullPath = null;
        $isDynamic = false;

        // 1. Primary: Dynamic brochure file from information table (PDF or Image)
        if ($brochureRel) {
            $cleaned = ltrim($brochureRel, '/\\');
            if (file_exists(public_path($cleaned)) && is_file(public_path($cleaned))) {
                $fullPath = public_path($cleaned);
                $isDynamic = true;
            } elseif (file_exists(public_path($brochureRel)) && is_file(public_path($brochureRel))) {
                $fullPath = public_path($brochureRel);
                $isDynamic = true;
            } else {
                $storageSub = preg_replace('#^/?storage/#', '', $cleaned);
                if (file_exists(storage_path('app/public/' . $storageSub)) && is_file(storage_path('app/public/' . $storageSub))) {
                    $fullPath = storage_path('app/public/' . $storageSub);
                    $isDynamic = true;
                } elseif (file_exists(public_path('storage/' . $storageSub)) && is_file(public_path('storage/' . $storageSub))) {
                    $fullPath = public_path('storage/' . $storageSub);
                    $isDynamic = true;
                }
            }
        }

        // 2. Default Static Fallback: Website/assets/images/brochure.pdf or Admin/assets/images/brochure.pdf
        if (!$fullPath || !file_exists($fullPath)) {
            $fallbackPaths = [
                public_path('Website/assets/images/brochure.pdf'),
                public_path('Admin/assets/images/brochure.pdf'),
                public_path('storage/Admin/brochures/brochure.pdf'),
            ];
            foreach ($fallbackPaths as $fallback) {
                if (file_exists($fallback) && is_file($fallback)) {
                    $fullPath = $fallback;
                    break;
                }
            }
        }

        // 3. Last Fallback: Auto-generate default PDF if needed
        if (!$fullPath || !file_exists($fullPath)) {
            $defaultPdfPath = public_path('Website/assets/images/brochure.pdf');
            $dir = dirname($defaultPdfPath);
            if (!file_exists($dir)) {
                @mkdir($dir, 0777, true);
            }
            try {
                $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('Pdf.brochure');
                $pdf->setPaper('A4', 'portrait');
                $pdf->save($defaultPdfPath);
                if (file_exists($defaultPdfPath)) {
                    $fullPath = $defaultPdfPath;
                }
            } catch (\Throwable $e) {
                Log::error('PDF brochure generation error: ' . $e->getMessage());
            }
        }

        $exists = !empty($fullPath) && file_exists($fullPath);
        $rawExt = $exists ? strtolower(pathinfo($fullPath, PATHINFO_EXTENSION)) : 'pdf';
        $isPdf = ($rawExt === 'pdf');
        $isImage = in_array($rawExt, ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg']);
        $typeLabel = $isPdf ? 'PDF' : ($isImage ? strtoupper($rawExt) : strtoupper($rawExt));

        $mimeTypes = [
            'pdf' => 'application/pdf',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'webp' => 'image/webp',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ];

        $mime = $mimeTypes[$rawExt] ?? ($exists && function_exists('mime_content_type') ? (mime_content_type($fullPath) ?: 'application/octet-stream') : 'application/octet-stream');

        return [
            'path' => $fullPath,
            'exists' => $exists,
            'is_dynamic' => $isDynamic,
            'raw_ext' => $rawExt,
            'ext' => strtoupper($rawExt),
            'is_pdf' => $isPdf,
            'is_image' => $isImage,
            'type_label' => $typeLabel,
            'mime' => $mime,
            'download_name' => 'The_Ulhas_Vilas_Official_Brochure.' . $rawExt,
            'url' => url('/download-brochure'),
        ];
    }

    /**
     * 12. Thank You Page
     */
    public function thankYou(Request $request)
    {
        $hasSessionSubmission = session()->has('form_submitted') || session()->has('success');
        $allowTimestamp = session()->get('allow_thankyou');
        $isRecent = $allowTimestamp && ((time() - (int) $allowTimestamp) <= 120);

        // Direct URL access without recent form submission redirects to /contact
        if (!$hasSessionSubmission && !$isRecent) {
            return redirect('/contact');
        }

        // Invalidate immediately so refreshing or reopening URL cannot access thank you page again
        session()->forget(['form_submitted', 'success', 'allow_thankyou']);

        $data = $this->getCommonData();
        $brochureInfo = $this->resolveBrochureFileInfo();
        $data['brochure_url'] = $brochureInfo['url'];
        $data['has_brochure'] = $brochureInfo['exists'];
        $data['brochure_type'] = $brochureInfo['type_label'];
        $data['brochure_ext'] = $brochureInfo['ext'];
        $data['is_pdf'] = $brochureInfo['is_pdf'];
        $data['is_image'] = $brochureInfo['is_image'];
        return view('Website.thankyou', $data);
    }

    /**
     * 13. Official Brochure Download with Dynamic PDF / Image & Fallback Handling
     */
    public function downloadBrochure()
    {
        $brochureInfo = $this->resolveBrochureFileInfo();

        // If the brochure file exists on disk (either dynamic admin upload or static fallback)
        if ($brochureInfo['exists'] && is_file($brochureInfo['path'])) {
            $fullPath = $brochureInfo['path'];
            $downloadName = $brochureInfo['download_name'];
            $mime = $brochureInfo['mime'];

            return response()->download(
                $fullPath,
                $downloadName,
                [
                    'Content-Type' => $mime,
                    'Cache-Control' => 'no-cache, must-revalidate',
                    'Content-Disposition' => 'attachment; filename="' . $downloadName . '"',
                ]
            );
        }

        return redirect('/contact')->with('error', 'Brochure is currently being updated. Our concierge team will email it to you.');
    }

    /**
     * 13. Newsletter Subscription Handler
     */
    public function newsletterSubmit(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:150',
        ], [
            'email.required' => 'Please enter your email address.',
            'email.email' => 'Please enter a valid email address.',
        ]);

        $isJson = $request->ajax() || $request->wantsJson() || $request->expectsJson() || $request->header('Accept') === 'application/json';

        if ($validator->fails()) {
            $errorMsg = $validator->errors()->first() ?? 'Please provide a valid email address.';
            if ($isJson) {
                return response()->json([
                    'success' => false,
                    'message' => $errorMsg,
                ], 422);
            }
            return redirect()->back()->with('error', $errorMsg);
        }

        $email = trim(strtolower($request->email));

        // Check if already subscribed
        $existing = DB::table('newsletter_subscribers')->where('email', $email)->first();
        if ($existing) {
            $msg = 'You are already subscribed to our exclusive updates.';
            if ($isJson) {
                return response()->json([
                    'success' => true,
                    'already_subscribed' => true,
                    'message' => $msg,
                ]);
            }
            return redirect()->back()->with('success', $msg);
        }

        $currentTime = function_exists('currentDateTime') ? currentDateTime() : date('Y-m-d h:i A');

        DB::table('newsletter_subscribers')->insert([
            'email' => $email,
            'created_at' => $currentTime,
            'updated_at' => $currentTime,
        ]);

        $successMsg = 'Thank you for subscribing to The Ulhas Vilas newsletter!';
        if ($isJson) {
            return response()->json([
                'success' => true,
                'message' => $successMsg,
            ]);
        }

        return redirect()->back()->with('success', $successMsg);
    }

    /**
     * 14. Terms & Conditions Page
     */
    public function terms()
    {
        $data = $this->getCommonData();
        $info = $data['info'] ?? null;
        $data['content'] = !empty($info->term_condition) ? $info->term_condition : '';
        return view('Website.terms', $data);
    }

    /**
     * 15. Privacy Policy Page
     */
    public function privacy()
    {
        $data = $this->getCommonData();
        $info = $data['info'] ?? null;
        $data['content'] = !empty($info->privacy_policy) ? $info->privacy_policy : '';
        return view('Website.privacy', $data);
    }

    /**
     * 16. Disclaimer & RERA Compliance Notes Page
     */
    public function disclaimer()
    {
        $data = $this->getCommonData();
        $info = $data['info'] ?? null;
        $data['content'] = !empty($info->return_policy) ? $info->return_policy : '';
        return view('Website.disclaimer', $data);
    }
}
