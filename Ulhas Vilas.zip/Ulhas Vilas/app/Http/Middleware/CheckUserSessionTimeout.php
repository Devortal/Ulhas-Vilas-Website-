<?php
 
namespace App\Http\Middleware;
 
use Closure;
use Carbon\Carbon;
use Illuminate\Http\Request;
 
class CheckUserSessionTimeout
{
    public function handle(Request $request, Closure $next)
    {
        if (session()->has('user_login')) {
 
            $loginTime = session()->get('user_login_time');
 
            // ✅ SIRF YE NUMBER CHANGE KARO (minutes mein)
            $timeoutMinutes = 1051200; // 2 years baad logout
 
            $now     = Carbon::now('Asia/Kolkata')->timestamp;
            $timeout = $timeoutMinutes * 60;
 
            if ($loginTime && ($now - $loginTime) > $timeout) {
                $request->session()->flush();
                session()->forget('user_login');
                session()->forget('user_login_time');
                return redirect('/user-login');
            }
        }
 
        return $next($request);
    }
}