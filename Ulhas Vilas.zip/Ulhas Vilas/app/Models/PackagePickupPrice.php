<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PackagePickupPrice extends Model
{
    protected $table = 'package_pickup_prices';

    protected $fillable = ['package_id', 'pickup_point_id', 'price', 'offer_price'];

    public function package()
    {
        return $this->belongsTo(Package::class, 'package_id');
    }

    public function pickupPoint()
    {
        return $this->belongsTo(PickupPoint::class, 'pickup_point_id');
    }
}
