<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    protected $table = 'packages';

    protected $fillable = [
        'destination', 'package_name', 'journey_point', 'category_id', 
        'price', 'offer_price', 'duration', 'best_time', 'avg_temp', 
        'distance', 'description', 'about', 'highlights', 'inclusions', 
        'exclusions', 'travel_tips', 'image', 'status', 'date'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    public function pickupPrices()
    {
        return $this->hasMany(PackagePickupPrice::class, 'package_id');
    }

    public function pickupPoints()
    {
        return $this->belongsToMany(PickupPoint::class, 'package_pickup_prices', 'package_id', 'pickup_point_id')
                    ->withTimestamps();
    }

    public function activities()
    {
        return $this->belongsToMany(Activity::class, 'package_activities', 'package_id', 'activity_id')
                    ->withTimestamps();
    }
}
