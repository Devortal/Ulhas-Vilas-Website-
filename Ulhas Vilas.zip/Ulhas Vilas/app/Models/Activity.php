<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    protected $table = 'activities';

    protected $fillable = ['name'];

    public function packages()
    {
        return $this->belongsToMany(Package::class, 'package_activities', 'activity_id', 'package_id')
                    ->withTimestamps();
    }
}
