<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PickupPoint extends Model
{
    protected $table = 'pickup_points';

    protected $fillable = ['name'];

    public function packages()
    {
        return $this->belongsToMany(Package::class, 'package_pickup_prices', 'pickup_point_id', 'package_id')
                    ->withPivot('price', 'offer_price')
                    ->withTimestamps();
    }
}
