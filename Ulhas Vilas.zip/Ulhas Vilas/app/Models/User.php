<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    public $timestamps = false;
    protected $attributes = [
        'logout_status' => 'false',
    ];

    protected $fillable = [
        'user_type',
        'status',
        'otp',
        'platform',
        'name',
        'mobile',
        'email',
        'dob',
        'gotra',
        'city',
        'password',
        'created_at',
        'updated_at',
        'app_version',
        'logout_status',
        'platform',
        'company_name',
        'addhar_card',
        'bussiness_card_number'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'logout_status' => 'string'
    ];
}
