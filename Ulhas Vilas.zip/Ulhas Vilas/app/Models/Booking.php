<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Booking extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'bookings';

    protected $fillable = [
        'booking_id',
        'user_id',
        'package_id',
        'package_title',
        'name',
        'email',
        'mobile',
        'address',
        'travel_date',
        'passengers',
        'adults',
        'children',
        'total_price',
        'paid_amount',
        'due_amount',
        'payment_status',
        'booking_status',
        'special_request',
        'notes',
        'created_at',
        'updated_at'
    ];

    protected static function booted(): void
    {
        static::creating(function (Booking $booking) {
            $booking->created_at = $booking->created_at ?: self::kolkataDateTime();
            $booking->updated_at = $booking->updated_at ?: $booking->created_at;
        });

        static::updating(function (Booking $booking) {
            $booking->updated_at = self::kolkataDateTime();
        });
    }

    private static function kolkataDateTime(): string
    {
        return Carbon::now('Asia/Kolkata')->format('Y-m-d h:i A');
    }
}
