<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Events\NonVerifiedUserNotificationEvent;
use Carbon\Carbon;

class NonVerifiedUserNotificationCron extends Command
{
    protected $signature = 'notify:nonverified';
    protected $description = 'Trigger NonVerifiedUserNotificationEvent for non-verified users';

    public function handle()
    {
        $today = Carbon::now('Asia/Kolkata')->format('Y-m-d');
        event(new NonVerifiedUserNotificationEvent($today));

        $this->info("✅ NonVerifiedUserNotificationEvent triggered successfully for {$today}");
    }
}
