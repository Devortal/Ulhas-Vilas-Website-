<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Events\DailyNotificationEvent;
use Carbon\Carbon;

class DailyNotificationCron extends Command
{

    protected $signature = 'daily:notification';
    protected $description = 'Trigger daily notification event at 8 AM';

    public function handle()
    {
        $today = Carbon::now('Asia/Kolkata')->format('Y-m-d');
        event(new DailyNotificationEvent($today));
        $this->info("✅ DailyNotificationEvent triggered successfully for {$today}");
    }
}
