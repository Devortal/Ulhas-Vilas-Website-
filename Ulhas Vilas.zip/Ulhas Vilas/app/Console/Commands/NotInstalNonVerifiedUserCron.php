<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Events\NotInstalNonVerifiedUserEvent;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class NotInstalNonVerifiedUserCron extends Command
{
    
    protected $signature = 'notify:notinstalnonverified';
    protected $description = 'Send notification to users who installed today but are not verified';

    public function handle()
    {
        try {
            // ✅ Always use IST timezone
            $nowIST = Carbon::now('Asia/Kolkata');
            $today = $nowIST->toDateString();

            // Log::info("🔁 [Cron] NotInstalNonVerifiedUserCron started at {$nowIST}");

            // ✅ Fetch users created today and still unverified
            $users = User::where('is_verified', 'false')
                ->whereDate('created_at', $today)
                ->get();

            // 🧩 Log total users found
            // Log::info("👀 Found {$users->count()} unverified users created on {$today}");

            if ($users->isNotEmpty()) {
                // ✅ Fire the event and log confirmation
                event(new NotInstalNonVerifiedUserEvent($today));
                // Log::info("🚀 Event NotInstalNonVerifiedUserEvent dispatched successfully for date: {$today}");
            } else {
                Log::info("ℹ️ No unverified users found for {$today}");
            }

            // ✅ Console output (for manual run visibility)
            $this->info("🕒 Checked at: {$nowIST->format('Y-m-d h:i A')} (IST)");
            $this->info("✅ Command executed successfully.");

        } catch (\Throwable $e) {
            // ❌ Log and print any exception clearly
            Log::error('❌ Error in NotInstalNonVerifiedUserCron: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
            ]);
            $this->error('Something went wrong: ' . $e->getMessage());
        }
    }
}
