<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Events\UpcomingEventsEvent;
use Illuminate\Support\Facades\Log;

class UpcomingEventsCron extends Command
{
    protected $signature = 'upcoming:events';
    protected $description = 'Dispatch UpcomingEventsEvent to send event notifications';

    public function handle(): int
    {
        Log::info('Cron Triggered: upcoming:events command running...');
        event(new UpcomingEventsEvent());
        Log::info('UpcomingEventsEvent dispatched successfully!');
        $this->info('Upcoming Events Cron executed successfully.');

        return Command::SUCCESS;
    }
}
