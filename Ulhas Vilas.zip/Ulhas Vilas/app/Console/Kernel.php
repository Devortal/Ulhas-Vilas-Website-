<?php
namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        \App\Console\Commands\UpcomingEventsCron::class,
        \App\Console\Commands\DailyNotificationCron::class,
        \App\Console\Commands\NonVerifiedUserNotificationCron::class,
        \App\Console\Commands\NotInstalNonVerifiedUserCron::class,
    ];

    protected function schedule(Schedule $schedule): void
    {
        // Worker to process queued jobs
        // $schedule->command('queue:work --stop-when-empty')->everyMinute();
        // Queue worker (handles push + default)

        // Queue worker (push + default)
        $schedule
            ->command('queue:work --queue=push,default --sleep=3 --tries=3 --stop-when-empty')
            ->everyMinute()
            ->name('queue-worker:push-default')
            ->withoutOverlapping()
            ->onOneServer();

        // Morning 9:00 AM
        $schedule
            ->command('daily:notification')
            ->timezone('Asia/Kolkata')
            ->dailyAt('09:00')  // Morning 9:00 AM
            ->name('daily-notification-09:00')
            ->withoutOverlapping()
            ->onOneServer();

        // xample: upcoming events at 10:00 AM IST
        $schedule
            ->command('upcoming:events')
            ->timezone('Asia/Kolkata')
            ->dailyAt('10:00')
            ->withoutOverlapping();

        // Eample: Non-verified user notification at 09:30 AM IST
        $schedule
            ->command('notify:nonverified')
            ->timezone('Asia/Kolkata')
            ->dailyAt('09:30')
            ->withoutOverlapping();

        // Not-installed user notification
        $schedule
            ->command('notify:notinstalnonverified')
            ->timezone('Asia/Kolkata')
            ->everyMinute()
            ->withoutOverlapping();
    }

    protected function commands(): void
    {
        $this->load(__DIR__ . '/Commands');
        require base_path('routes/console.php');
    }
}
