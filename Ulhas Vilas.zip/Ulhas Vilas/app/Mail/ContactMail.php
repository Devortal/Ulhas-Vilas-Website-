<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMail extends Mailable
{
    use Queueable, SerializesModels;

    public $mailData;

    /**
     * Create a new message instance.
     */
    public function __construct($mailData)
    {
        $this->mailData = $mailData;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        $subject = !empty($this->mailData['configuration']) ? $this->mailData['configuration'] : ($this->mailData['subject'] ?? 'Luxury Residence');

        return new Envelope(
            subject: "✨ Thank you for choosing The Ulhas Vilas — {$subject} Details & Brochure",
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'Mailer.contact_mail',
            with: [
                'data' => $this->mailData,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     */
    public function attachments(): array
    {
        $attachments = [];

        $filePath = !empty($this->mailData['brochure_file_path']) ? $this->mailData['brochure_file_path'] : null;

        // Fallback: If brochure_file_path is missing or does not exist on disk, check default brochure.pdf
        if (empty($filePath) || !file_exists($filePath)) {
            $fallbacks = [
                public_path('Website/assets/images/brochure.pdf'),
                public_path('Admin/assets/images/brochure.pdf'),
                public_path('storage/Admin/brochures/brochure.pdf'),
            ];
            foreach ($fallbacks as $fb) {
                if (file_exists($fb) && is_file($fb)) {
                    $filePath = $fb;
                    break;
                }
            }
        }

        // Attach dynamic brochure file (PDF or Image) or fallback brochure.pdf
        if (!empty($filePath) && file_exists($filePath) && is_file($filePath)) {
            $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) ?: 'pdf';
            $mime = match ($ext) {
                'pdf' => 'application/pdf',
                'png' => 'image/png',
                'jpg', 'jpeg' => 'image/jpeg',
                'webp' => 'image/webp',
                'gif' => 'image/gif',
                'svg' => 'image/svg+xml',
                default => (function_exists('mime_content_type') ? (mime_content_type($filePath) ?: 'application/octet-stream') : 'application/octet-stream'),
            };
            $filename = 'The_Ulhas_Vilas_Official_Brochure.' . $ext;

            $attachments[] = Attachment::fromPath($filePath)
                ->as($filename)
                ->withMime($mime);
        }

        return $attachments;
    }
}
