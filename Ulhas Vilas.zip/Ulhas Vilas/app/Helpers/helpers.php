<?php

use Carbon\Carbon;

if (!function_exists('currentDateTime')) {
    /**
     * Get current Asia/Kolkata timestamp formatted as 'Y-m-d h:i A' (e.g. 2026-09-09 09:58 AM)
     *
     * @param string $format
     * @return string
     */
    function currentDateTime($format = 'Y-m-d h:i A')
    {
        return Carbon::now('Asia/Kolkata')->format($format);
    }
}

if (!function_exists('currentDate')) {
    /**
     * Get current Asia/Kolkata date formatted as 'Y-m-d'
     *
     * @param string $format
     * @return string
     */
    function currentDate($format = 'Y-m-d')
    {
        return Carbon::now('Asia/Kolkata')->format($format);
    }
}

if (!function_exists('formatAppDateTime')) {
    /**
     * Format any timestamp / date string to standardized 'Y-m-d h:i A'
     *
     * @param mixed $date
     * @param string $format
     * @return string
     */
    function formatAppDateTime($date, $format = 'Y-m-d h:i A')
    {
        if (empty($date) || $date === '-' || $date === 'null') {
            return '-';
        }

        try {
            if ($date instanceof Carbon) {
                return $date->setTimezone('Asia/Kolkata')->format($format);
            }
            return Carbon::parse($date)->setTimezone('Asia/Kolkata')->format($format);
        } catch (\Exception $e) {
            $ts = strtotime($date);
            return $ts ? date($format, $ts) : (string) $date;
        }
    }
}
