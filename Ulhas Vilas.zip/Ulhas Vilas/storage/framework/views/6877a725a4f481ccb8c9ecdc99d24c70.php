<?php
    $info = DB::table('information')->first();
    $footerCategories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('category_name', 'asc')->get();
    $footerLogo = (!empty($info) && !empty($info->footer_logo)) ? asset($info->footer_logo) : ((!empty($info) && !empty($info->info_footer_logo)) ? asset($info->info_footer_logo) : ((!empty($info) && !empty($info->header_logo)) ? asset($info->header_logo) : asset('Website/assets/images/ulhas-logo.png')));
    $footerAbout = (!empty($info) && !empty($info->footer_about)) ? $info->footer_about : ((!empty($info) && !empty($info->info_about)) ? $info->info_about : 'Perched in the pine-scented hills of Himachal Pradesh — a private sanctuary where architecture meets nature in timeless elegance.');
    $reraNo = (!empty($info) && !empty($info->rera_number)) ? $info->rera_number : ((!empty($info) && !empty($info->info_deals)) ? $info->info_deals : 'HP/RERA/2024/001');
?>

<!-- ═══════════════════════════════════════════════
     SITE FOOTER
════════════════════════════════════════════════ -->
<footer class="site-footer" id="site-footer">

    <?php if(!request()->is('thank-you') && !request()->is('thankyou*')): ?>
    <!-- Newsletter Banner -->
    <div class="footer-newsletter-banner">
        <!-- Background Video -->
        <video class="footer-newsletter-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM (1).jpeg')); ?>">
            <source src="<?php echo e(asset('Website/assets/images/footer_video.mp4')); ?>" type="video/mp4">
            Your browser does not support HTML5 video.
        </video>
        <div class="footer-newsletter-overlay"></div>
        <!-- Content -->
        <div class="footer-newsletter-inner">
            <div class="footer-newsletter-text">
                <p class="footer-newsletter-eyebrow">Stay Informed</p>
                <h3 class="footer-newsletter-heading">Be the First to Experience Serenity</h3>
                <p class="footer-newsletter-sub">Subscribe to our newsletter for exclusive updates and private previews.</p>
            </div>
            <div class="footer-newsletter-action-box" style="width: min(480px, 100%); flex-shrink: 0; display: flex; flex-direction: column; gap: 8px;">
                <form id="footerNewsletterForm" class="footer-newsletter-form" method="POST" action="<?php echo e(url('/newsletter-submit')); ?>" style="width: 100%; margin: 0;">
                    <?php echo csrf_field(); ?>
                    <input type="email" id="footerNewsletterEmail" name="email" class="footer-newsletter-input" placeholder="Enter your email address" aria-label="Email address" required maxlength="150" autocomplete="email">
                    <button type="submit" id="footerNewsletterBtn" class="footer-newsletter-btn">
                        <span>Subscribe</span>
                    </button>
                </form>
                <div id="footerNewsletterMsg" style="display:none; font-size:13px; font-weight:600; padding: 6px 14px; border-radius: 8px; text-shadow:0 1px 3px rgba(0,0,0,0.85); transition: all 0.3s ease;"></div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Main Footer Body -->
    <div class="footer-main">
        <div class="footer-main-inner">

            <!-- Column 1: Brand -->
            <div class="footer-col footer-col--brand">
                <a href="<?php echo e(url('/')); ?>" class="footer-logo-link">
                    <img src="<?php echo e($footerLogo); ?>" alt="The Ulhas Vilas" class="footer-logo-img">
                    <span class="footer-brand-copy">
                        <span class="footer-brand-name">The Ulhas Vilas</span>
                        <span class="footer-brand-subtitle">Where serenity whispers joy!</span>
                    </span>
                </a>
                <p class="footer-brand-desc">
                    <?php echo e($footerAbout); ?>

                </p>
                <?php
                    $fb = $info->facebook_link ?? $info->info_facebook_link ?? null;
                    $insta = $info->instagram_link ?? $info->info_instagram_link ?? null;
                    $tw = $info->twitter_link ?? $info->info_twitter_link ?? $info->info_xtwitter_link ?? null;
                    $yt = $info->youtube_link ?? null;
                    $li = $info->linkedin_link ?? null;
                ?>
                <?php if(!empty($fb) || !empty($insta) || !empty($tw) || !empty($yt) || !empty($li)): ?>
                <div class="footer-social-row">
                    <?php if(!empty($insta)): ?>
                        <a href="<?php echo e($insta); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="Instagram" title="Instagram">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if(!empty($fb)): ?>
                        <a href="<?php echo e($fb); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="Facebook" title="Facebook">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if(!empty($tw)): ?>
                        <a href="<?php echo e($tw); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="X (Twitter)" title="X (Twitter)">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if(!empty($yt)): ?>
                        <a href="<?php echo e($yt); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="YouTube" title="YouTube">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if(!empty($li)): ?>
                        <a href="<?php echo e($li); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="LinkedIn" title="LinkedIn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Column 2: Explore (Matching Header Menu) -->
            <div class="footer-col">
                <h4 class="footer-col-heading">Explore</h4>
                <ul class="footer-nav-list">
                    <li><a href="<?php echo e(url('/')); ?>" class="footer-nav-link">Home</a></li>
                    <li><a href="<?php echo e(url('/about')); ?>" class="footer-nav-link">About Us</a></li>
                    <li><a href="<?php echo e(url('/residences')); ?>" class="footer-nav-link">Residences</a></li>
                    <li><a href="<?php echo e(url('/amenities-wellness')); ?>" class="footer-nav-link">Amenities &amp; Wellness</a></li>
                    <li><a href="<?php echo e(url('/gallery')); ?>" class="footer-nav-link">Estate Gallery</a></li>
                    <li><a href="<?php echo e(url('/blogs')); ?>" class="footer-nav-link">Latest Blogs</a></li>
                    <li><a href="<?php echo e(url('/faq')); ?>" class="footer-nav-link">FAQs</a></li>
                    <li><a href="<?php echo e(url('/contact')); ?>" class="footer-nav-link">Contact Us</a></li>
                </ul>
            </div>

            <!-- Column 3: Legal & Compliance -->
            <div class="footer-col footer-col--legal">
                <h4 class="footer-col-heading">Legal &amp; Compliance</h4>
                <ul class="footer-nav-list">
                    <li><a href="<?php echo e(url('/terms-and-conditions')); ?>" class="footer-nav-link">Terms &amp; Conditions</a></li>
                    <li><a href="<?php echo e(url('/privacy-policy')); ?>" class="footer-nav-link">Privacy Policy</a></li>
                    <li><a href="<?php echo e(url('/disclaimer')); ?>" class="footer-nav-link">Disclaimer &amp; Compliance</a></li>
                    <li><a href="<?php echo e(url('/disclaimer')); ?>" class="footer-nav-link">RERA Certificate Info</a></li>
                </ul>
                <a href="<?php echo e(url('/disclaimer')); ?>" style="text-decoration: none; display: block;">
                    <div class="footer-rera-badge" style="cursor: pointer; transition: transform 0.25s ease;" onmouseover="this.style.transform='scale(1.03)'" onmouseout="this.style.transform='scale(1)'">
                        <span class="footer-rera-label">HP RERA No.</span>
                        <span class="footer-rera-number"><?php echo e($reraNo); ?></span>
                    </div>
                </a>
            </div>

            <!-- Column 4: Contact Us -->
            <div class="footer-col">
                <h4 class="footer-col-heading"><a href="<?php echo e(url('/contact')); ?>" style="color: inherit; text-decoration: none;">Contact Concierge</a></h4>
                <ul class="footer-contact-list">
                    <?php
                        $address = $info->address ?? $info->info_address ?? 'Shimla Highway, Himachal Pradesh, India';
                        $phone = $info->mobile ?? $info->info_contact_one ?? '+91 98765 43210';
                        $email = $info->email ?? $info->info_email_one ?? 'enquiries@ulhasvilas.com';
                        $officeTime = $info->office_time ?? '24/7 White-glove Concierge Line';
                    ?>
                    <li class="footer-contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span><?php echo e($address); ?></span>
                    </li>
                    <li class="footer-contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.12 6.12l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $phone)); ?>" style="color: inherit; text-decoration: none;"><?php echo e($phone); ?></a>
                    </li>
                    <li class="footer-contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <a href="mailto:<?php echo e($email); ?>" style="color: inherit; text-decoration: none;"><?php echo e($email); ?></a>
                    </li>
                    <?php if(!empty($officeTime)): ?>
                    <li class="footer-contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <span><?php echo e($officeTime); ?></span>
                    </li>
                    <?php endif; ?>
                </ul>

            </div>

        </div>
    </div>

    <!-- Footer Bottom Bar -->
    <div class="footer-bottom">
        <div class="footer-bottom-inner">
            <p class="footer-copyright">© <?php echo e(date('Y')); ?> The Ulhas Vilas Estates. All rights reserved.</p>
            <p class="footer-crafted">Crafted with care in Himachal Pradesh.</p>
        </div>
    </div>

</footer>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var nlForm = document.getElementById('footerNewsletterForm');
    var nlEmail = document.getElementById('footerNewsletterEmail');
    var nlBtn = document.getElementById('footerNewsletterBtn');
    var nlMsg = document.getElementById('footerNewsletterMsg');

    if (nlForm) {
        nlForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var emailVal = nlEmail ? nlEmail.value.trim() : '';
            if (!emailVal) return;

            var origBtnHtml = nlBtn ? nlBtn.innerHTML : '<span>Subscribe</span>';
            if (nlBtn) {
                nlBtn.disabled = true;
                nlBtn.innerHTML = '<span style="display:inline-block;width:12px;height:12px;border:2px solid rgba(7,9,11,0.3);border-top-color:#07090b;border-radius:50%;animation:spin 0.6s linear infinite;margin-right:5px;vertical-align:middle;"></span><span>Subscribing...</span>';
            }
            if (nlMsg) {
                nlMsg.style.display = 'none';
                nlMsg.innerHTML = '';
            }

            var formData = new FormData(nlForm);

            fetch("<?php echo e(url('/newsletter-submit')); ?>", {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(function(res) {
                return res.json().then(function(data) {
                    return { ok: res.ok, status: res.status, data: data };
                }).catch(function() {
                    return { ok: res.ok, status: res.status, data: null };
                });
            })
            .then(function(result) {
                if (nlBtn) {
                    nlBtn.disabled = false;
                    nlBtn.innerHTML = origBtnHtml;
                }
                var data = result.data;
                if (result.ok && data && data.success) {
                    if (nlEmail) nlEmail.value = '';
                    var successText = data.message || 'Thank you for subscribing to The Ulhas Vilas newsletter!';
                    if (nlMsg) {
                        nlMsg.style.background = 'rgba(220, 182, 88, 0.18)';
                        nlMsg.style.border = '1px solid rgba(220, 182, 88, 0.5)';
                        nlMsg.style.color = '#DCB658';
                        nlMsg.innerHTML = '✨ ' + successText;
                        nlMsg.style.display = 'block';
                    }
                } else {
                    var errText = (data && data.message) ? data.message : 'Please check your email address and try again.';
                    if (nlMsg) {
                        nlMsg.style.background = 'rgba(239, 68, 68, 0.18)';
                        nlMsg.style.border = '1px solid rgba(239, 68, 68, 0.5)';
                        nlMsg.style.color = '#fca5a5';
                        nlMsg.innerHTML = '⚠️ ' + errText;
                        nlMsg.style.display = 'block';
                    }
                }
            })
            .catch(function() {
                if (nlBtn) {
                    nlBtn.disabled = false;
                    nlBtn.innerHTML = origBtnHtml;
                }
                if (nlMsg) {
                    nlMsg.style.background = 'rgba(239, 68, 68, 0.18)';
                    nlMsg.style.border = '1px solid rgba(239, 68, 68, 0.5)';
                    nlMsg.style.color = '#fca5a5';
                    nlMsg.innerHTML = '⚠️ A network error occurred. Please try again.';
                    nlMsg.style.display = 'block';
                }
            });
        });
    }
});
</script>


<?php echo $__env->make('Website.includes.QuoteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\DOWNLOADS\ulhas-vilas\ulhas-vilas.partnersindia.com\resources\views/Website/includes/Footer.blade.php ENDPATH**/ ?>