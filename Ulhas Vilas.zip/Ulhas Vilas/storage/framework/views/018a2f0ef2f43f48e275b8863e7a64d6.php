<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    :is(.about-title, .location-title, .villas-title, .amenities-title, .investment-title, .testimonials-title, .gallery-title, .faq-title)::after {
    content: '';
    display: block;
    width: 80px;
    height: 2px;
    background: var(--color-accent-amber);
    border-radius: 2px;
    margin: 0.75rem auto 0.85rem auto;
}
.amenities-subtitle {
    max-width: 720px;
    margin: 0 auto 2.5rem auto;
    font-size: 1.05rem;
    line-height: 1.7;
    color: rgba(255, 255, 255, 0.78);
    font-weight: 300;
    margin-bottom: -40px !important;
}
.amenities-dots {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.6rem;
     margin-top: 0rem !important; 
     margin-bottom: -30px !important; 
}
.blog-subtitle {
    font-family: var(--font-body);
    font-size: 0.7rem;
    line-height: 1.6;
    color: rgba(255, 255, 255, 0.75);
    text-align: center;
    margin-bottom: 1.25rem;
    max-width: 620px;
}

</style>

    <!-- HERO SECTION -->
    <section class="hero-section">
        <!-- Fullscreen Background Video & Instant Fallback Poster -->
        <div class="hero-video-wrapper" style="background-image: url('<?php echo e(asset('Website/assets/images/hero_image.jpeg')); ?>'); background-size: cover; background-position: center center;">
            <img id="heroBgFallbackImg" class="hero-bg-fallback-img" src="<?php echo e(asset('Website/assets/images/hero_image.jpeg')); ?>" alt="The Ulhas Vilas" fetchpriority="high">
            <video id="bgVideo" class="hero-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="auto" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/hero_image.jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/home_hero_video.mp4')); ?>" type="video/mp4">
                Your browser does not support video playback.
            </video>
            <div class="hero-overlay"></div>
        </div>

        <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main Body Hero Content -->
        <main class="hero-body">
            <div class="title-slider-container">

                <!-- Slide 1 -->
                <div class="title-slide active">
                    <h1 class="hero-title">Built From <span class="hero-highlight">Context</span><br>Designed For Permanence</h1>
                    <p class="hero-subtitle">We build with an understanding of context, a focus on function, and a drive for architectural clarity.</p>
                </div>

                <!-- Slide 2 -->
                <div class="title-slide">
                    <h1 class="hero-title">Architectural <span class="hero-highlight">Distinction</span><br>Crafted For Generations</h1>
                    <p class="hero-subtitle">Every space is curated to synthesize natural light, expansive views, and timeless minimalist luxury.</p>
                </div>

                <!-- Slide 3 -->
                <div class="title-slide">
                    <h1 class="hero-title">Sanctuary Of <span class="hero-highlight">Elegance</span><br>Refined In Every Detail</h1>
                    <p class="hero-subtitle">Discover an unprecedented living experience where modern craftsmanship meets uncompromised serenity.</p>
                </div>

                <!-- Slide 4 -->
                <div class="title-slide">
                    <h1 class="hero-title">Pinnacle Of <span class="hero-highlight">Refinement</span><br>Engineering Visual Harmony</h1>
                    <p class="hero-subtitle">Creating environments that endure through time, tailored for modern sophistication and effortless luxury.</p>
                </div>

            </div>

            <!-- Action Buttons -->
            <div class="hero-actions">
                <a href="<?php echo e(url('/residences')); ?>" class="btn-primary">
                    Explore Residences <span class="btn-arrow">→</span>
                </a>
                <a href="<?php echo e(url('/contact')); ?>" class="btn-secondary">
                    Download Brochure
                </a>
            </div>

            <div class="hero-specs-bar hero-specs-bar--mobile">
                <div class="spec-item">
                    <span class="spec-value stat-counter" data-count-to="12500" data-format="comma">0</span>
                    <span class="spec-label">Sq Ft Living Area</span>
                </div>
                <div class="spec-divider"></div>
                <div class="spec-item">
                    <span class="spec-value stat-counter" data-count-to="6" data-pad="2">00</span>
                    <span class="spec-label">Private Suites</span>
                </div>
                <div class="spec-divider"></div>
                <div class="spec-item">
                    <span class="spec-value stat-counter" data-count-to="100" data-suffix="%">0%</span>
                    <span class="spec-label">Bespoke Design</span>
                </div>
            </div>

        </main>



        <!-- Bottom Stats & Description Bar -->
        <footer class="hero-footer">
            <div class="hero-footer-inner">
                <div class="footer-description">
                    Designing buildings that respond to real needs and real environments, with a focus on clarity, purpose, and long-term value.
                </div>

                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-number stat-counter" data-count-to="12500" data-format="comma">0</span>
                        <span class="stat-label">Sq Ft Living Area</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number stat-counter" data-count-to="6" data-pad="2">00</span>
                        <span class="stat-label">Private Suites</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number stat-counter" data-count-to="100" data-suffix="%">0%</span>
                        <span class="stat-label">Bespoke Design</span>
                    </div>
                </div>
            </div>
        </footer>
    </section>

    <!-- ABOUT US SECTION (Luxury Architectural Living & Ojas Gram Vision) -->
    <section class="about-section" id="about">
        <div class="about-grid">
            
            <!-- LEFT COLUMN: Overlapping Layered Image Collage -->
            <div class="about-collage-container">
                <!-- Main Top-Right Image Card -->
                <div class="about-video-card about-video-main">
                    <img src="<?php echo e(asset('Website/assets/images/night-villa.jpg')); ?>" alt="Luxury Architectural Living" class="about-video about-img" loading="lazy">
                </div>

                <!-- Overlapping Bottom-Left Image Card -->
                <div class="about-video-card about-video-sub">
                    <img src="<?php echo e(asset('Website/assets/images/home2.jpeg')); ?>" alt="Crafting Timeless Residences" class="about-video about-img" loading="lazy">
                </div>
            </div>

            <!-- RIGHT COLUMN: Expanded Editorial Narrative & Features -->
            <div class="about-info-content">
                <span class="about-tagline">WHERE SERENITY WHISPERS JOY</span>
                
                <h2 class="about-title">Luxury Architectural Living</h2>

                <p class="about-lead-paragraph">
                    Tucked away in the peaceful Himalayan peaks of Himachal Pradesh, Ulhas Vilas is more than just a place to stay; it's an opportunity to feel pure joy surrounded by nature. An exclusive master community, Ulhas Vilas curates a one-of-a-kind living experience with endless breathtaking sunrises and sunsets.
                </p>
                
                <p class="about-secondary-paragraph">
                    Crafted with a vision to unite individuals in wellness, nature, and the pursuit of a fulfilling lifestyle, Ulhas Vilas is a part of the unique community living concept by the esteemed developers, <strong>M/s Ojas Gram</strong>.
                </p>

                <!-- Developer Vision & Leadership Showcase Card -->
                <div class="about-vision-card">
                    <div class="vision-card-header">
                        <span class="vision-quote-icon">“</span>
                        <p class="vision-leadership-text">
                            Under the esteemed guidance of <strong>Sh. Rohit Bansal</strong>, <strong>Sh. Pankaj Bansal</strong>, and <strong>Sh. Surinder Kumar</strong>, M/s Ojas Gram is dedicated to creating serene and sustainable habitats.
                        </p>
                    </div>
                    <p class="vision-core-text">
                        Their commitment to integrating natural materials, minimizing energy use, and promoting organic agriculture is at the heart of Ulhas Vilas, ensuring a harmonious blend of luxury and sustainability.
                    </p>
                </div>

                <!-- Action CTA Button -->
                <a href="#residences" class="about-cta-btn">
                    <span>EXPLORE RESIDENCES</span> <span class="btn-arrow">→</span>
                </a>
            </div>

        </div>
    </section>

    <!-- RESIDENCES / VILLAS SHOWCASE SECTION (Dark Background + Ambient Video + 1BHK, 2BHK, 3BHK, 4BHK) -->
    <section class="villas-section" id="residences">
        <!-- Background Ambient Video Player -->
        <div class="villas-video-wrapper">
            <video class="villas-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM (1).jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/residencies.mp4')); ?>" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="villas-video-overlay"></div>
        </div>

        <div class="villas-container">
            <!-- Section Header -->
            <div class="villas-header" style="margin-top: -30px !important;">
                <span class="villas-tagline">Curated Villa Portfolio</span>
                <h2 class="villas-title">The Residences Collection</h2>
                <!--<p class="villas-subtitle" style="font-size: 13px !important;">Distinct architectural typologies engineered for luxury, privacy, and seamless coastal living.</p>-->

                <!-- Villa Type Filter Tabs -->
                <div class="villa-filter-tabs">
                    <button class="villa-tab-btn active" data-filter="all">All Residences</button>
                    <?php if(!empty($categories) && count($categories) > 0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="villa-tab-btn" data-filter="cat-<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Villas Grid (Dynamic Residences) -->
            <div class="villas-grid">
                <?php if(!empty($residences) && count($residences) > 0): ?>
                    <?php $__currentLoopData = $residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $slideImages = [];
                            if (!empty($res->image)) {
                                if (str_starts_with(trim($res->image), '[')) {
                                    $rawImgs = json_decode($res->image, true) ?: [];
                                } else {
                                    $rawImgs = explode(',', $res->image);
                                }
                                foreach ($rawImgs as $rImg) {
                                    $rImg = trim($rImg);
                                    if (!empty($rImg)) {
                                        $slideImages[] = \Illuminate\Support\Str::startsWith($rImg, 'http') ? $rImg : asset($rImg);
                                    }
                                }
                            }
                            if (empty($slideImages)) {
                                $slideImages[] = asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg');
                            }

                            $pricePrefix = !empty($res->price_prefix) ? $res->price_prefix : 'From';
                            $priceText = '';
                            if (!empty($res->price)) {
                                $priceText = $pricePrefix . ' ₹' . $res->price;
                                if (!str_contains(strtolower($res->price), 'lac') && !str_contains(strtolower($res->price), 'cr')) {
                                    $priceText .= ' Lacs';
                                }
                            } else {
                                $priceText = 'Price on Request';
                            }
                            $detailUrl = url('/residence/' . (!empty($res->slug) ? $res->slug : $res->id));
                        ?>
                        <article class="villa-card" data-category="cat-<?php echo e($res->category_id); ?>">
                            <div class="villa-image-wrapper">
                                <div class="villa-image-slider">
                                    <?php $__currentLoopData = $slideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($sImg); ?>" alt="<?php echo e($res->name); ?>" class="villa-slide-img <?php echo e($imgIdx === 0 ? 'active' : ''); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <span class="villa-type-badge"><?php echo e($res->category_name ?? 'Villa'); ?></span>
                                <?php if(count($slideImages) > 1): ?>
                                    <div class="villa-slider-dots">
                                        <?php $__currentLoopData = $slideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="dot <?php echo e($imgIdx === 0 ? 'active' : ''); ?>"></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="villa-img-overlay"></div>
                            </div>
                            <div class="villa-card-content">
                                <div class="villa-card-header">
                                    <h3 class="villa-name"><?php echo e($res->name); ?></h3>
                                    <span class="villa-price"><?php echo e($priceText); ?></span>
                                </div>
                                <p class="villa-short-desc"><?php echo e($res->short_description ?? 'Intimate minimalist sanctuary featuring a private courtyard and plunge garden.'); ?></p>
                                
                                <div class="villa-specs-row">
                                    <div class="villa-spec" title="Carpet Area">
                                        <svg class="spec-icon-svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFAE36" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                                        <?php echo e($res->carpet_area ?? '1000.2 SQ FT'); ?>

                                    </div>
                                    <div class="villa-spec" title="Rooms">
                                        <svg class="spec-icon-svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFAE36" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8M4 10V6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v4M12 10V6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v4"/></svg>
                                        <?php echo e($res->rooms ?? ($res->suites ?? '2 Rooms')); ?>

                                    </div>
                                    <div class="villa-spec" title="Drawing / Dining">
                                        <svg class="spec-icon-svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFAE36" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v2"/><path d="M2 11v5a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/><path d="M4 18v2M20 18v2M8 11v3M16 11v3"/></svg>
                                        <?php echo e($res->d_room ?? '1 D Room'); ?>

                                    </div>
                                </div>

                                <!-- Action Buttons in Same Row -->
                                <div class="villa-card-actions">
                                    <button type="button" class="villa-btn villa-btn-quote open-residence-quote-btn" data-residence-id="<?php echo e($res->id); ?>" data-residence-name="<?php echo e($res->name); ?>" data-category-name="<?php echo e($res->category_name ?? ''); ?>">Send Quote</button>
                                    <a href="<?php echo e($detailUrl); ?>" class="villa-btn villa-btn-details">View Details</a>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-12 text-center py-5 text-muted">
                        <p>No residences found at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- NEARBY ESCAPES & LOCATION SECTION (Pure White Background + Luxury Interactive Leaflet Map & Auto Photo Showcase) -->
    <section class="location-section" id="location">
        <div class="location-container">
            <div class="location-grid">
                
                <!-- LEFT COLUMN: Editorial Narrative & Auto-Interactive Destinations Menu -->
                <div class="location-info-content">
                    <span class="location-tagline">PRIME LOCATION & ACCESSIBILITY</span>
                    
                    <h2 class="location-title">Nearby Escapes: Waiting at Your Doorstep</h2>

                    <p class="location-narrative">
                        Perched in an elevated private sanctuary among the pine-scented hills of Himachal Pradesh, Ulhas Vilas Estates offers an unparalleled synthesis of secluded tranquillity and effortless connectivity.
                    </p>

                    <!-- Interactive Compact Light Theme 2-Column Places Navigation Grid -->
                    <div class="location-places-grid" id="places-menu">
                        <div class="place-grid-card active" data-place-id="chail">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m12 2-7 10h4l-4 8h14l-4-8h4z"/>
                                    <path d="M12 20v2"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Chail Town</h4>
                                <span class="place-time">16 KMS • 25 MINS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="kufri">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m8 3 4 8 5-5 5 15H2L8 3z"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Kufri</h4>
                                <span class="place-time">33 KMS • 50 MINS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="sanjauli">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="9"/>
                                    <path d="M12 7v10M8 12h8"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Sanjauli Helipad</h4>
                                <span class="place-time">43 KMS • AIR TRANSIT</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="kandaghat">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <rect width="16" height="16" x="4" y="3" rx="2"/>
                                    <path d="M4 11h16M12 3v8M8 19l-3 3M16 19l3 3M8 15h.01M16 15h.01"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Kandaghat</h4>
                                <span class="place-time">44.3 KMS • 1.1 HRS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="naldhera">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 22V2l10 5-10 5"/>
                                    <ellipse cx="12" cy="20" rx="8" ry="2"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Naldhera</h4>
                                <span class="place-time">57 KMS • 1.4 HRS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="shimla">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 22h16M4 2h16M6 6v12M10 6v12M14 6v12M18 6v12M2 6h20M2 18h20"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Shimla</h4>
                                <span class="place-time">48 KMS • 1.2 HRS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="chandigarh">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3.5c-.5-.5-2.5 0-4 1.5L13.5 8.5 5.3 6.7c-.8-.2-1.6.1-2 .8l-.8 1.4 5.3 3.5-3.5 3.5-2.3-.5c-.4-.1-.9.1-1.1.5L.2 17c-.3.4-.2 1 .2 1.3l3.5 2.5 2.5 3.5c.3.4.9.5 1.3.2l1.1-.7c.4-.2.6-.7.5-1.1l-.5-2.3 3.5-3.5 3.5 5.3c.7.4 1.6.2 1.8-.6l1.4-.8c.7-.4 1-.12.8-2z"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Chandigarh</h4>
                                <span class="place-time">121 KMS • 3.0 HRS</span>
                            </div>
                        </div>

                        <div class="place-grid-card" data-place-id="delhi">
                            <div class="card-icon-box">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H7.5a1 1 0 0 0-.8.4L4 11l-2.16.36A1 1 0 0 0 1 12.35V16h3"/>
                                    <circle cx="6.5" cy="16.5" r="2.5"/>
                                    <circle cx="16.5" cy="16.5" r="2.5"/>
                                </svg>
                            </div>
                            <div class="card-meta">
                                <h4 class="place-name">Delhi NCR</h4>
                                <span class="place-time">354 KMS • 6.0 HRS</span>
                            </div>
                        </div>
                    </div>

                    <!-- CTA Button -->
                    <a href="#send-quote" class="location-cta-btn">
                        ENQUIRE NOW <span class="btn-arrow">→</span>
                    </a>
                </div>

                <!-- RIGHT COLUMN: Luxury Interactive Map & Auto-Changing Photo Showcase Overlay -->
                <div class="luxury-map-card">
                    <!-- Map Header Controls Bar -->
                    <div class="map-control-bar">
                        <div class="map-status">
                            <span class="status-pulse"></span>
                            <span class="status-text">EXPLORE HILLSIDE CONNECTIVITY</span>
                        </div>
                        <span class="map-hint">Click destination to explore</span>
                    </div>

                    <!-- Leaflet Map Container & Fallback Canvas -->
                    <div class="map-canvas-wrapper" id="map-wrapper">
                        <div id="leaflet-map" class="leaflet-map-element"></div>

                        <!-- Floating Climate & Elevation Highlights (Top Overlay) -->
                        <div class="map-floating-climate-card">
                            <div class="floating-climate-item">
                                <div class="floating-climate-icon">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="m8 3 4 8 5-5 5 15H2L8 3z"/>
                                    </svg>
                                </div>
                                <div class="floating-climate-meta">
                                    <span class="floating-climate-lbl">ALTITUDE</span>
                                    <span class="floating-climate-val">5500 Ft <span class="floating-climate-sub">(Mid Hills)</span></span>
                                </div>
                            </div>
                            <div class="floating-climate-divider"></div>
                            <div class="floating-climate-item">
                                <div class="floating-climate-icon">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/>
                                    </svg>
                                </div>
                                <div class="floating-climate-meta">
                                    <span class="floating-climate-lbl">TEMPERATURE</span>
                                    <span class="floating-climate-val">-2 °C to 28 °C</span>
                                </div>
                            </div>
                        </div>

                        <!-- Floating Luxury Destination Card Overlay (No Image) -->
                        <div class="featured-photo-card active" id="featured-photo-card">
                            <div class="photo-card-body">
                                <div class="photo-card-top-meta">
                                    <span class="photo-dist-pill" id="featured-dist">16 KMS AWAY</span>
                                    <span class="photo-card-time" id="featured-time">25 Mins Drive</span>
                                </div>
                                <div class="photo-card-header">
                                    <h4 class="photo-card-title" id="featured-title">Chail Town</h4>
                                </div>
                                <p class="photo-card-desc" id="featured-desc">
                                    Encircled by pristine pine forests, home to the world's highest cricket ground, scenic sanctuary trails, and heritage royal retreats.
                                </p>

                                <!-- Slideshow Progress Indicators -->
                                <div class="photo-progress-dots" id="photo-dots">
                                    <span class="dot active" data-index="0"></span>
                                    <span class="dot" data-index="1"></span>
                                    <span class="dot" data-index="2"></span>
                                    <span class="dot" data-index="3"></span>
                                    <span class="dot" data-index="4"></span>
                                    <span class="dot" data-index="5"></span>
                                    <span class="dot" data-index="6"></span>
                                    <span class="dot" data-index="7"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- AMENITIES & WELLNESS SECTION (Dark Background + Living Room Video + Glass Reference Cards) -->
   <!-- AMENITIES & WELLNESS SECTION (Dark Background + Living Room Video + Glass Reference Cards) -->
    <section class="amenities-section" id="amenities">
        <!-- Background Ambient Video Player -->
        <div class="amenities-video-wrapper">
            <video class="amenities-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/amenities.mp4')); ?>" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="amenities-video-overlay"></div>
        </div>

        <div class="amenities-container">
            <!-- Section Header -->
            <div class="amenities-header text-center" style="margin-top: -30px !important;">
                <span class="amenities-tagline">HOLISTIC LIVING & REFRESHMENT</span>
                <h2 class="amenities-title">Amenities & Wellness</h2>
                <p class="amenities-subtitle">Immerse yourself in our curated sanctuaries of peace, comfort and recreation designed for elevated estate living.</p>
            </div>

            <!-- Carousel Controls & Cards Slider Wrapper -->
            <div class="amenities-carousel-wrapper">
                <button class="amenities-nav-btn prev-amenity-btn" aria-label="Previous Amenities" title="Previous">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                </button>

                <div class="amenities-slider-track" id="amenitiesTrack">
                    
                    <!-- 1. Ayurvedic Restaurant -->
                    <article class="amenity-card" data-category="dining" data-title="Ayurvedic Restaurant" data-desc="Authentic Ayurvedic gastronomy, organic farm-to-table dining, and wellness-tailored nutritious cuisine prepared by holistic culinary masters." data-duration="Breakfast • Lunch • Dinner" data-level="Holistic Dining">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/ayurvedic-rest.jpg')); ?>" alt="Ayurvedic Restaurant" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Ayurvedic Restaurant">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 11a8 8 0 0 0 16 0H4z"/>
                                    <path d="M12 3v8"/>
                                    <path d="M9 7l3-4 3 4"/>
                                    <path d="M8 19c2 2 6 2 8 0"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Ayurvedic Restaurant</h3>
                            <p class="amenity-card-desc">Authentic Ayurvedic gastronomy, organic farm-to-table dining, and holistic nutritious cuisine.</p>
                            <button class="amenity-view-btn" data-modal-target="ayurvedic-restaurant">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 2. International Restaurant -->
                    <article class="amenity-card" data-category="dining" data-title="International Restaurant" data-desc="Fine dining gourmet restaurant offering curated multi-cuisine delicacies, world-class culinary artistry, and panoramic Himalayan vistas." data-duration="All-Day Dining" data-level="Fine Dining">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/international-rest.jpg')); ?>" alt="International Restaurant" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="International Restaurant">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M18 2v20M18 2a3 3 0 0 1 3 3v6h-3M6 2v20M3 2v6a3 3 0 0 0 3 3h0a3 3 0 0 0 3-3V2"/>
                                    <circle cx="12" cy="12" r="4"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">International Restaurant</h3>
                            <p class="amenity-card-desc">Fine dining gourmet restaurant offering curated multi-cuisine delicacies and mountain views.</p>
                            <button class="amenity-view-btn" data-modal-target="international-restaurant">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 3. Multipurpose Hall -->
                    <article class="amenity-card" data-category="events" data-title="Multipurpose Hall" data-desc="Elegant, versatile grand multipurpose hall equipped for private banquets, cultural gatherings, corporate retreats, and celebrations." data-duration="Private Booking" data-level="Grand Banquets">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/hall.jpg')); ?>" alt="Multipurpose Hall" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Multipurpose Hall">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 21h18M5 21V7l7-4 7 4v14M9 10h6M9 14h6M9 18h6"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Multipurpose Hall</h3>
                            <p class="amenity-card-desc">Grand versatile event pavilion for private celebrations, corporate retreats, and banquets.</p>
                            <button class="amenity-view-btn" data-modal-target="multipurpose-hall">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 4. Yoga Room -->
                    <article class="amenity-card" data-category="wellness" data-title="Yoga Room" data-desc="Serene pine-facing yoga sanctuary designed for mindful movement, breathwork, morning pranayama, and private guided sessions." data-duration="Sunrise to Sunset" data-level="Mind & Movement">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/yoga-room.jpg')); ?>" alt="Yoga Room" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Yoga Room">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="5" r="2"/>
                                    <path d="M4 17l4-2 4 4 4-4 4 2M12 7v6M7 11h10"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Yoga Room</h3>
                            <p class="amenity-card-desc">Dedicated pine-facing sanctuary designed for pranayama, mindful movement, and yoga.</p>
                            <button class="amenity-view-btn" data-modal-target="yoga-room">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 5. Bar -->
                    <article class="amenity-card" data-category="lounge" data-title="Bar" data-desc="Sophisticated mountain lounge bar serving signature handcrafted cocktails, aged spirits, fine wines, and artisanal mocktails." data-duration="4:00 PM - 11:30 PM" data-level="Mountain Lounge">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/bar.jpg')); ?>" alt="Bar" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Bar">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M8 22h8M12 11v11M5 3l7 8 7-8H5z"/>
                                    <path d="M12 6h.01"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Bar</h3>
                            <p class="amenity-card-desc">Refined mountain lounge bar serving signature cocktails, fine wines, and artisanal spirits.</p>
                            <button class="amenity-view-btn" data-modal-target="bar">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 6. Indoor Swimming Pool -->
                    <article class="amenity-card" data-category="wellness" data-title="Indoor Swimming Pool" data-desc="Temperature-controlled all-season indoor heated pool with glass skylights, hydro-massage jets, and relaxing poolside cabanas." data-duration="6:00 AM - 10:00 PM" data-level="Heated Hydro-Pool">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/Swimming-pool.jpg')); ?>" alt="Indoor Swimming Pool" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Indoor Swimming Pool">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M2 12h20M2 16c2.5 1.5 5.5 1.5 8 0s5.5-1.5 8 0 2.5 1.5 4 0M2 20c2.5 1.5 5.5 1.5 8 0s5.5-1.5 8 0 2.5 1.5 4 0"/>
                                    <circle cx="12" cy="6" r="2"/>
                                    <path d="M10 8.5l2 1.5 4-2"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Indoor Swimming Pool</h3>
                            <p class="amenity-card-desc">Temperature-controlled all-season indoor heated pool with panoramic mountain skylights.</p>
                            <button class="amenity-view-btn" data-modal-target="indoor-swimming-pool">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 7. Spa Suites -->
                    <article class="amenity-card" data-category="wellness" data-title="Spa Suites" data-desc="Private luxury spa suites offering traditional Ayurvedic therapies, signature massages, steam chambers, and therapeutic body rituals." data-duration="On-Demand / Bookings" data-level="Luxury Spa Sanctuary">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/Spa-Suites.jpg')); ?>" alt="Spa Suites" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Spa Suites">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <ellipse cx="12" cy="18" rx="7" ry="3"/>
                                    <ellipse cx="12" cy="12" rx="5" ry="2.5"/>
                                    <ellipse cx="12" cy="7" rx="3.5" ry="2"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Spa Suites</h3>
                            <p class="amenity-card-desc">Private luxury therapy suites featuring traditional Ayurvedic treatments, massages, and sauna.</p>
                            <button class="amenity-view-btn" data-modal-target="spa-suites">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                    <!-- 8. Meditation Hall -->
                    <article class="amenity-card" data-category="wellness" data-title="Meditation Hall" data-desc="Peaceful sanctuary of absolute silence and tranquility for deep meditation, sound healing, reflection, and inner calm." data-duration="Open 24/7" data-level="Zen Sanctuary">
                        <div class="amenity-image-wrapper">
                            <div class="amenity-img-box">
                                <img src="<?php echo e(asset('Website/assets/images/meditation-hall.jpg')); ?>" alt="Meditation Hall" class="amenity-card-img">
                            </div>
                            <div class="amenity-icon-badge" title="Meditation Hall">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="6" r="2.2"/>
                                    <path d="M7 19c1-3 3-5 5-5s4 2 5 5"/>
                                    <path d="M5 21h14"/>
                                    <path d="M12 2v2M4 7l2 1M20 7l-2 1"/>
                                </svg>
                            </div>
                        </div>
                        <div class="amenity-card-body">
                            <h3 class="amenity-card-title">Meditation Hall</h3>
                            <p class="amenity-card-desc">Tranquil sanctuary of absolute silence and calm for deep meditation and inner peace.</p>
                            <button class="amenity-view-btn" data-modal-target="meditation-hall">
                                VIEW DETAILS <span class="btn-arrow">→</span>
                            </button>
                        </div>
                    </article>

                </div>

                <button class="amenities-nav-btn next-amenity-btn" aria-label="Next Amenities" title="Next">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </button>
            </div>

            <!-- Carousel Pagination Dots -->
            <div class="amenities-dots" id="amenitiesDots">
                <span class="amenity-dot active" data-index="0"></span>
                <span class="amenity-dot" data-index="1"></span>
                <span class="amenity-dot" data-index="2"></span>
                <span class="amenity-dot" data-index="3"></span>
                <span class="amenity-dot" data-index="4"></span>
                <span class="amenity-dot" data-index="5"></span>
                <span class="amenity-dot" data-index="6"></span>
                <span class="amenity-dot" data-index="7"></span>
            </div>
                <span class="amenity-dot" data-index="9"></span>
                <span class="amenity-dot" data-index="10"></span>
            </div>
        </div>
    </section>

    <!-- AMENITIES LIGHTBOX / DETAIL MODAL -->
    <div class="amenity-modal-backdrop" id="amenityModal" aria-hidden="true">
        <div class="amenity-modal-content">
            <button class="amenity-modal-close" id="modalCloseBtn" aria-label="Close modal">&times;</button>
            <div class="modal-grid">
                <div class="modal-image-col">
                    <img src="" alt="" id="modalImg" class="modal-img">
                </div>
                <div class="modal-info-col">
                    <span class="modal-badge" id="modalCategory">AMENITIES & WELLNESS</span>
                    <h3 class="modal-title" id="modalTitle">Lawn</h3>
                    <p class="modal-desc" id="modalDesc">Detailed description here.</p>
                    
                    <div class="modal-meta-grid">
                        <div class="modal-meta-item">
                            <span class="meta-label">SERVICE DURATION</span>
                            <span class="meta-value" id="modalDuration">Open Daily</span>
                        </div>
                        <div class="modal-meta-item">
                            <span class="meta-label">EXPERIENCE TYPE</span>
                            <span class="meta-value" id="modalLevel">Estate Grounds</span>
                        </div>
                    </div>

                    <div class="modal-actions">
                        <a href="#contact" class="modal-book-btn">Enquire About Amenities <span class="btn-arrow">→</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- EXCLUSIVE 6 LUXURIOUS DUPLEX APARTMENTS SECTION (Interactive Showcase with Image Gallery) -->
    <section class="investment-section" id="investment">
        <div class="investment-container">
            
            <!-- Section Header (Centered) -->
            <div class="investment-header" style="margin-top: -30px !important;">
                <span class="investment-tagline">BY INVITATION ONLY</span>
                <h2 class="investment-title">Exclusive Luxurious Duplex Apartments</h2>
                <div class="investment-header-line"></div>
                <p class="investment-subtitle">Escape to a world of indulgence and tranquility with our exclusive 3-bedroom duplex apartments, available by invitation only.</p>
            </div>

            <!-- Main Interactive Showcase Grid (2 Columns: Showcase Image + Interactive List) -->
            <div class="investment-grid">
                
                <!-- LEFT COLUMN: Featured Image Card, Dynamic Pill Badge, Thumbnails & Brochure CTA -->
                <div class="investment-showcase-column">
                    
                    <!-- Main Featured Photo Frame -->
                    <div class="investment-featured-card">
                        <img src="<?php echo e(asset('Website/assets/images/investment1.jpeg')); ?>" alt="Exclusive Plunge Pool Retreat" id="investmentFeaturedImg" class="investment-featured-img">
                        <div class="investment-card-overlay"></div>
                        
                        <!-- Floating Dynamic Category Pill Badge -->
                        <div class="investment-badge" id="investmentBadge">
                            <span class="badge-icon">✨</span>
                            <span id="investmentBadgeText">EXCLUSIVE PLUNGE POOL RETREAT</span>
                        </div>
                    </div>

                    <!-- Bottom Row: Thumbnail Selector Bar & Download Brochure CTA -->
                    <div class="investment-showcase-footer">
                        <!-- Thumbnail Previews -->
                        <div class="investment-thumbnails" id="investmentThumbnails">
                            <div class="investment-thumb active" data-img="<?php echo e(asset('Website/assets/images/investment1.jpeg')); ?>" data-badge="EXCLUSIVE PLUNGE POOL RETREAT" title="Plunge Pool Retreat">
                                <img src="<?php echo e(asset('Website/assets/images/investment1.jpeg')); ?>" alt="Plunge Pool Retreat">
                            </div>
                            <div class="investment-thumb" data-img="<?php echo e(asset('Website/assets/images/investment2.jpeg')); ?>" data-badge="VERSATILE DUAL-ENTRY LAYOUT" title="Versatile Layout">
                                <img src="<?php echo e(asset('Website/assets/images/investment2.jpeg')); ?>" alt="Versatile Layout">
                            </div>
                            <div class="investment-thumb" data-img="<?php echo e(asset('Website/assets/images/investment3.jpeg')); ?>" data-badge="SMART REVENUE-SHARING" title="Smart Investment">
                                <img src="<?php echo e(asset('Website/assets/images/investment3.jpeg')); ?>" alt="Smart Investment">
                            </div>
                            <div class="investment-thumb" data-img="<?php echo e(asset('Website/assets/images/investment4.jpeg')); ?>" data-badge="PREMIUM ELEGANCE & FLOORING" title="Unmatched Elegance">
                                <img src="<?php echo e(asset('Website/assets/images/investment4.jpeg')); ?>" alt="Unmatched Elegance">
                            </div>
                        </div>

                        <!-- Download Brochure Button -->
                        <a href="<?php echo e(asset('Website/assets/images/brochure.pdf')); ?>" download class="investment-brochure-btn" id="downloadBrochureBtn">
                            <span>Download Brochure</span>
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                        </a>
                    </div>
                </div>

                <!-- RIGHT COLUMN: Interactive Luxury Benefits List -->
                <div class="investment-list-column">
                    <div class="investment-benefits-list" id="investmentBenefitsList">
                        
                        <!-- Benefit Item 01: Exclusive plunge pool retreat -->
                        <div class="investment-item active" data-index="0" data-img="<?php echo e(asset('Website/assets/images/investment1.jpeg')); ?>" data-badge="EXCLUSIVE PLUNGE POOL RETREAT">
                            <div class="investment-item-content">
                                <div class="investment-item-header">
                                    <span class="investment-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M2 20c2 0 3-1.5 5-1.5s3 1.5 5 1.5 3-1.5 5-1.5 3 1.5 5 1.5"/>
                                            <path d="M2 16c2 0 3-1.5 5-1.5s3 1.5 5 1.5 3-1.5 5-1.5 3 1.5 5 1.5"/>
                                            <path d="M16 4v8M12 8h8"/>
                                            <circle cx="16" cy="4" r="2"/>
                                        </svg>
                                    </span>
                                    <h3 class="investment-item-title">Exclusive plunge pool retreat</h3>
                                    <div class="investment-arrow-circle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                                <div class="investment-item-body">
                                    <p class="investment-item-desc">Unwind in the privacy of your holiday home, featuring a master bedroom and two elegant guest rooms with a plunge pool.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Benefit Item 02: Versatile layout with separate entries -->
                        <div class="investment-item" data-index="1" data-img="<?php echo e(asset('Website/assets/images/investment2.jpeg')); ?>" data-badge="VERSATILE DUAL-ENTRY LAYOUT">
                            <div class="investment-item-content">
                                <div class="investment-item-header">
                                    <span class="investment-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <rect x="3" y="3" width="18" height="18" rx="2"/>
                                            <path d="M12 3v18M3 12h18"/>
                                            <path d="M8 8h.01M16 16h.01"/>
                                        </svg>
                                    </span>
                                    <h3 class="investment-item-title">Versatile layout with separate entries</h3>
                                    <div class="investment-arrow-circle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                                <div class="investment-item-body">
                                    <p class="investment-item-desc">Designed for your utmost convenience, this appartment offers separate entries for the two floors, providing flexibility and privacy.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Benefit Item 03: Smart investment opportunity -->
                        <div class="investment-item" data-index="2" data-img="<?php echo e(asset('Website/assets/images/investment3.jpeg')); ?>" data-badge="SMART REVENUE-SHARING">
                            <div class="investment-item-content">
                                <div class="investment-item-header">
                                    <span class="investment-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M4 19V5M4 19h16"/>
                                            <path d="m7 15 4-4 3 3 5-7"/>
                                            <path d="M16 7h3v3"/>
                                        </svg>
                                    </span>
                                    <h3 class="investment-item-title">Smart investment opportunity</h3>
                                    <div class="investment-arrow-circle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                                <div class="investment-item-body">
                                    <p class="investment-item-desc">Collaborate with The Ulhas Vilas to lease out your holiday home with plunge pool on a revenue-sharing basis, making it a savvy investment choice.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Benefit Item 04: Unmatched elegance and sophistication -->
                        <div class="investment-item" data-index="3" data-img="<?php echo e(asset('Website/assets/images/investment4.jpeg')); ?>" data-badge="PREMIUM ELEGANCE & FLOORING">
                            <div class="investment-item-content">
                                <div class="investment-item-header">
                                    <span class="investment-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="m12 3-8 9 8 9 8-9-8-9Z"/>
                                            <path d="M4 12h16"/>
                                            <path d="m8.5 7.5 3.5 4.5 3.5-4.5"/>
                                        </svg>
                                    </span>
                                    <h3 class="investment-item-title">Unmatched elegance and sophistication</h3>
                                    <div class="investment-arrow-circle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                                <div class="investment-item-body">
                                    <p class="investment-item-desc">Each bedroom is thoughtfully furnished with premium flooring, adding a touch of elegance to your living spaces.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Benefit Item 05: Enchanting wooden ceilings -->
                        <div class="investment-item" data-index="4" data-img="<?php echo e(asset('Website/assets/images/investment1.jpeg')); ?>" data-badge="ENCHANTING WOODEN CEILINGS">
                            <div class="investment-item-content">
                                <div class="investment-item-header">
                                    <span class="investment-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M3 10.5 12 3l9 7.5V21H3V10.5Z"/>
                                            <path d="M3 10.5h18M7 7l5-4 5 4M3 15h18M3 19h18"/>
                                        </svg>
                                    </span>
                                    <h3 class="investment-item-title">Enchanting wooden ceilings</h3>
                                    <div class="investment-arrow-circle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                                <div class="investment-item-body">
                                    <p class="investment-item-desc">Be captivated by the charming wooden ceilings that adorn every room, enhancing the villa's enchanting ambiance.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- TESTIMONIALS SECTION (Dark Premium Carousel + Visible Living Room Video) -->
    <section class="testimonials-section" id="testimonials">
        <div class="testimonials-video-wrapper">
            <video class="testimonials-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/mountain.jpeg')); ?>">
                <!--<source src="<?php echo e(asset('Website/assets/images/review-sectin.mp4')); ?>" type="video/mp4">-->
            </video>
            <div class="testimonials-video-overlay"></div>
        </div>

        <div class="testimonials-container" style="margin-bottom:-30px !important;">
            <div class="testimonials-header" style="margin-top:-30px !important;">
                <span class="testimonials-tagline">Resident Reflections</span>
                <h2 class="testimonials-title">Stories Of A Private Address</h2>
                <!--<p class="testimonials-subtitle">A refined collection of impressions from owners and guests who value quiet luxury, attentive service, and architecture with lasting presence.</p>-->
            </div>

            <div class="testimonials-carousel" aria-label="Client testimonials">
                <button class="testimonial-nav-btn testimonial-prev-btn" type="button" aria-label="Previous testimonial">
                    <span>&larr;</span>
                </button>

                <div class="swiper testimonialSwiper" style="margin-top:-20px !important">
                    <div class="swiper-wrapper">
                        <?php if(isset($reviews) && count($reviews) > 0): ?>
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $imgSrc = '';
                                    if (!empty($review->image)) {
                                        $cleanImg = ltrim($review->image, '/');
                                        if (file_exists(public_path($cleanImg))) {
                                            $imgSrc = asset($cleanImg);
                                        } elseif (str_starts_with($review->image, 'http')) {
                                            $imgSrc = $review->image;
                                        } elseif (file_exists(public_path('storage/Admin/review/' . basename($review->image)))) {
                                            $imgSrc = asset('storage/Admin/review/' . basename($review->image));
                                        }
                                    }
                                    if (empty($imgSrc)) {
                                        $fallbackNum = ($index % 5) + 1;
                                        $imgSrc = asset('Website/assets/images/client_' . $fallbackNum . '.jpg');
                                    }
                                ?>
                                <div class="swiper-slide">
                                    <article class="testimonial-card">
                                        <div class="testimonial-quote-mark">&ldquo;</div>
                                        <p class="testimonial-copy"><?php echo e($review->feedback); ?></p>
                                        <div class="testimonial-client">
                                            <img src="<?php echo e($imgSrc); ?>" alt="<?php echo e($review->name); ?>" class="testimonial-client-img">
                                            <div>
                                                <h3 class="testimonial-client-name"><?php echo e($review->name); ?></h3>
                                                <span class="testimonial-client-meta"><?php echo e($review->designation ?: ($review->city ?: 'Resident')); ?></span>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="swiper-slide">
                                <article class="testimonial-card">
                                    <div class="testimonial-quote-mark">&ldquo;</div>
                                    <p class="testimonial-copy">Ulhas Vilas feels composed from the first arrival. The interiors have that rare balance of warmth and restraint, and every detail seems considered without ever feeling loud.</p>
                                    <div class="testimonial-client">
                                        <img src="<?php echo e(asset('Website/assets/images/client_1.jpg')); ?>" alt="Aarav Mehta" class="testimonial-client-img">
                                        <div>
                                            <h3 class="testimonial-client-name">Aarav Mehta</h3>
                                            <span class="testimonial-client-meta">Villa Owner, Mumbai</span>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <button class="testimonial-nav-btn testimonial-next-btn" type="button" aria-label="Next testimonial">
                    <span>&rarr;</span>
                </button>
            </div>

            <div class="testimonial-dots" aria-label="Testimonial pagination"></div>
        </div>
    </section>

    <!-- GALLERY SECTION (Premium Living Image Mosaic) -->
    <section class="gallery-section" id="gallery">
        <div class="gallery-container">
            <div class="gallery-header-wrapper">
                <div class="gallery-header">
                    <span class="gallery-tagline">Curated Gallery</span>
                    <h2 class="gallery-title">Frames Of Refined Living</h2>
                    <p class="gallery-subtitle">A quiet visual journey through interiors, terraces, lounges, and private corners shaped for elevated mountain living.</p>
                </div>
                <div class="gallery-header-action">
                    <a href="<?php echo e(url('/gallery')); ?>" class="gallery-view-all-btn">
                        <span>VIEW ALL</span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>

            <?php
                $galleryList = (isset($galleries) && count($galleries) > 0) ? $galleries->values() : collect();
                $gallerySets = [];
                if ($galleryList->count() > 0) {
                    $totalItems = $galleryList->count();
                    $totalSets = (int) ceil($totalItems / 4);
                    for ($s = 0; $s < $totalSets; $s++) {
                        $set = [];
                        for ($t = 0; $t < 4; $t++) {
                            $idx = ($s * 4 + $t) % $totalItems;
                            $set[] = $galleryList->get($idx);
                        }
                        $gallerySets[] = $set;
                    }
                }
            ?>

            <?php if(count($gallerySets) > 0): ?>
                <div class="swiper gallerySwiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $gallerySets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setIndex => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="gallery-mosaic">
                                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tileIdx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $tileClass = '';
                                            if ($tileIdx === 0) {
                                                $tileClass = 'gallery-tile-large';
                                            } elseif ($tileIdx === 2) {
                                                $tileClass = 'gallery-tile-tall';
                                            }
                                            $imgSrc = '';
                                            if (!empty($item->image)) {
                                                if (str_starts_with($item->image, 'http') || str_starts_with($item->image, '/')) {
                                                    $imgSrc = $item->image;
                                                } else {
                                                    $imgSrc = asset($item->image);
                                                }
                                            }
                                            if (empty($imgSrc)) {
                                                $imgSrc = asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM (1).jpeg');
                                            }
                                        ?>
                                        <article class="gallery-tile <?php echo e($tileClass); ?>" data-gallery-id="<?php echo e($item->id ?? ''); ?>">
                                            <img src="<?php echo e($imgSrc); ?>" alt="<?php echo e($item->description ?: $item->title); ?>" class="gallery-img" loading="lazy">
                                            <div class="gallery-tile-overlay"></div>
                                            <div class="gallery-tile-caption">
                                                <h3><?php echo e($item->description ?: $item->title); ?></h3>
                                                <span><?php echo e($item->title ?: 'Ulhas Vilas'); ?></span>
                                            </div>
                                        </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="gallery-dots" aria-label="Gallery rotation"></div>
                </div>
            <?php else: ?>
                <div class="gallery-mosaic" id="galleryMosaic">
                    <article class="gallery-tile gallery-tile-large">
                        <img src="<?php echo e(asset('Website/assets/images/client_1.jpg')); ?>" alt="Luxury living room" class="gallery-img">
                        <div class="gallery-tile-overlay"></div>
                        <div class="gallery-tile-caption">
                            <h3>Wabi Residence</h3>
                            <span>Living Lounge</span>
                        </div>
                    </article>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- BLOG / ARCHITECTURAL JOURNAL SECTION (Dark Video Background) -->
    <!--<section class="blog-section" id="blogs">
        <div class="blog-video-wrapper">
            <video class="blog-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM (1).jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/smallhouses.mp4')); ?>" type="video/mp4">
            </video>
            <div class="blog-video-overlay"></div>
        </div>

        <div class="blog-container">
            <div class="blog-header">
                <span class="blog-tagline">CURATED ESSAYS &amp; INSIGHTS</span>
                <h2 class="blog-title">Chronicles Of Refined Living</h2>
                <p class="blog-subtitle">Explore thought leadership on biophilic architecture, high-yield luxury real estate, and high-altitude mountain wellness.</p>
            </div>

            <div class="blog-grid">
                <?php if(isset($blogs) && count($blogs) > 0): ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $bImg = '';
                            if (!empty($blog->image)) {
                                if (str_starts_with($blog->image, 'http') || str_starts_with($blog->image, '/')) {
                                    $bImg = $blog->image;
                                } else {
                                    $bImg = asset($blog->image);
                                }
                            }
                            if (empty($bImg)) {
                                $bImg = asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM (1).jpeg');
                            }
                            $blogDateStr = !empty($blog->blog_date) ? strtoupper(date('M d, Y', strtotime($blog->blog_date))) : strtoupper(date('M d, Y'));
                            $blogSlug = !empty($blog->slug) ? $blog->slug : $blog->id;
                            $blogUrl = url('/blog/' . $blogSlug);
                            $blogCat = $blog->category ?? $blog->category_name ?? 'Architecture & Design';
                            $blogExcerpt = Str::limit(strip_tags($blog->short_description ?: $blog->description), 135);
                        ?>
                        <article class="blog-card animate-fade-up">
                            <div class="blog-card-media">
                                <a href="<?php echo e($blogUrl); ?>" class="blog-card-link-img" style="display:block;width:100%;height:100%;">
                                    <img src="<?php echo e($bImg); ?>" alt="<?php echo e($blog->title); ?>" class="blog-card-img" loading="lazy">
                                    <span class="blog-card-category"><?php echo e($blogCat); ?></span>
                                    <div class="blog-card-media-overlay"></div>
                                </a>
                            </div>
                            <div class="blog-card-body">
                                <div class="blog-card-meta">
                                    <span class="blog-card-date"><?php echo e($blogDateStr); ?></span>
                                </div>
                                <h3 class="blog-card-title">
                                    <a href="<?php echo e($blogUrl); ?>" style="color:inherit;text-decoration:none;"><?php echo e($blog->title); ?></a>
                                </h3>
                                <p class="blog-card-excerpt"><?php echo e($blogExcerpt); ?></p>
                                <a href="<?php echo e($blogUrl); ?>" class="blog-card-readmore">
                                    <span>Read Article</span>
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="text-center text-muted col-12">No articles published yet.</p>
                <?php endif; ?>
            </div>

            <div class="blog-footer-cta">
                <a href="<?php echo e(url('/blogs')); ?>" class="blog-header-link">
                    <span>Explore All Articles</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </section>
   -->

    <!-- CURATED INQUIRIES & FAQ SECTION (Light Luxury 2-Column Layout) -->
    <section class="faq-section" id="faq">
        <!-- Preserved video markup is hidden in the light FAQ theme -->
        <div class="faq-video-wrapper">
            <video class="faq-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/client_1.jpg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/0_Home_Architecture_1920x1080.mp4')); ?>" type="video/mp4">
            </video>
            <div class="faq-video-overlay"></div>
        </div>

        <div class="faq-container">
            <div class="faq-main-grid">
                
                <!-- LEFT COLUMN: 50% Private Consultation / Enquiry Form -->
                <div class="faq-form-column">
                    <div class="faq-form-card" id="contact">
                        <div class="faq-form-header">
                            <span class="faq-form-tagline">PRIVATE ENQUIRY</span>
                            <h3 class="faq-form-title">Schedule A Consultation</h3>
                            <p class="faq-form-subtitle">Connect directly with our senior estate management team for exclusive previews and personalized guidance.</p>
                        </div>

                        <form id="faqConsultationForm" class="faq-contact-form" method="post" action="<?php echo e(url('/contact_submit')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="faq-form-group">
                                <label class="faq-form-label" for="faqName">Full Name *</label>
                                <input type="text" id="faqName" name="name" class="faq-form-input" placeholder="e.g. Alexander Wright" required minlength="2" maxlength="100">
                            </div>

                            <div class="faq-form-row">
                                <div class="faq-form-group">
                                    <label class="faq-form-label" for="faqPhone">Phone Number *</label>
                                    <input type="tel" id="faqPhone" name="mobile" class="faq-form-input" placeholder="10-digit Mobile Number" required minlength="10" maxlength="10" pattern="[0-9]{10}" inputmode="numeric">
                                    <span class="field-validation-error" id="faqPhoneError" style="display:none; color:#ef4444; font-size:12px; font-weight:600; margin-top:5px;">Please enter a valid 10-digit mobile number.</span>
                                </div>
                                <div class="faq-form-group">
                                    <label class="faq-form-label" for="faqEmail">Email Address *</label>
                                    <input type="email" id="faqEmail" name="email" class="faq-form-input" placeholder="alexander@example.com" required maxlength="150">
                                </div>
                            </div>

                            <div class="faq-form-row">
                                <div class="faq-form-group">
                                    <label class="faq-form-label" for="faqCity">City / Location</label>
                                    <input type="text" id="faqCity" name="city" class="faq-form-input" placeholder="e.g. Mumbai, Delhi, Chandigarh">
                                </div>
                                <div class="faq-form-group">
                                    <label class="faq-form-label" for="faqResidence">Residence Preference *</label>
                                    <select id="faqResidence" name="residence_id" class="faq-form-select" required>
                                        <option value="" disabled selected>Select Preferred Residence</option>
                                        <?php if(!empty($residences) && count($residences) > 0): ?>
                                            <?php $__currentLoopData = $residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($res->id); ?>"><?php echo e($res->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="faq-form-group">
                                <label class="faq-form-label" for="faqMessage">Message / Specific Preferences *</label>
                                <textarea id="faqMessage" name="message" class="faq-form-textarea" rows="3" placeholder="Tell us about your timeframe or specific requirements..." required minlength="3" maxlength="1000"></textarea>
                            </div>

                            <button type="submit" id="faqSubmitBtn" class="faq-form-submit-btn">
                                <span>SEND US A MESSAGE</span>
                                <span class="btn-arrow">→</span>
                            </button>
                        </form>

                        <div class="faq-reassurance-bar">
                            <div class="faq-reassurance-icon">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.12 6.12l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                            </div>
                            <span>24/7 Concierge Line: <strong>+91 98765 43210</strong></span>
                        </div>
                    </div>
                </div>

                <!-- RIGHT COLUMN: FAQ Header & Accordion List -->
                <div class="faq-content-column">
                    
                    <!-- Section Header -->
                    <div class="faq-header">
                        <span class="faq-tagline">CURATED INQUIRIES</span>
                        <h2 class="faq-title">Answers for the Discerning</h2>
                        <div class="faq-header-line"></div>
                        <p class="faq-subtitle">Explore comprehensive details regarding ownership, architectural customization, legal compliances, and concierge services.</p>
                    </div>

                    <!-- FAQ Accordion List (Dynamic FAQs from Database) -->
                    <div class="faq-accordion-list" id="faqAccordion">
                        <?php if(!empty($faqs) && count($faqs) > 0): ?>
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="faq-item <?php echo e($key === 0 ? 'active' : ''); ?>" onclick="toggleFaqCard(this)">
                                    <div class="faq-question-header">
                                        <h3 class="faq-question-title"><?php echo e($faq->question); ?></h3>
                                        <div class="faq-icon-toggle">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                        </div>
                                    </div>
                                    <div class="faq-answer-content">
                                        <p class="faq-answer-text"><?php echo nl2br(e($faq->answer)); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="faq-item active" onclick="toggleFaqCard(this)">
                                <div class="faq-question-header">
                                    <h3 class="faq-question-title">What architectural customization options are available for villas?</h3>
                                    <div class="faq-icon-toggle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </div>
                                </div>
                                <div class="faq-answer-content">
                                    <p class="faq-answer-text">Each villa at Ulhas Vilas offers bespoke structural personalization options. Buyers can collaborate with our master architects to select floorplans, private heated infinity pools, sky deck lounges, and imported Italian marble finishes.</p>
                                </div>
                            </div>

                            <div class="faq-item" onclick="toggleFaqCard(this)">
                                <div class="faq-question-header">
                                    <h3 class="faq-question-title">Is Ulhas Vilas fully RERA approved with clear freehold titles?</h3>
                                    <div class="faq-icon-toggle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </div>
                                </div>
                                <div class="faq-answer-content">
                                    <p class="faq-answer-text">Yes, Ulhas Vilas is 100% compliant with state housing regulatory standards and possesses complete RERA registration with verified freehold land titles.</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </section>

    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Real-time 10-digit mobile formatting and validation for FAQ Form
        const faqPhoneInput = document.getElementById('faqPhone');
        const faqPhoneError = document.getElementById('faqPhoneError');

        if (faqPhoneInput && faqPhoneError) {
            faqPhoneInput.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
                if (this.value.length === 10) {
                    faqPhoneError.style.display = 'none';
                    faqPhoneInput.style.borderColor = '';
                } else if (this.value.length > 0) {
                    faqPhoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                    faqPhoneError.style.display = 'block';
                    faqPhoneInput.style.borderColor = '#ef4444';
                } else {
                    faqPhoneError.style.display = 'none';
                    faqPhoneInput.style.borderColor = '';
                }
            });

            faqPhoneInput.addEventListener('blur', function() {
                if (this.value.length > 0 && this.value.length !== 10) {
                    faqPhoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                    faqPhoneError.style.display = 'block';
                    faqPhoneInput.style.borderColor = '#ef4444';
                }
            });
        }

        // AJAX submit for FAQ Consultation Form (With Lazy Loader Spinner & Redirect to Thank You)
        const faqForm = document.getElementById('faqConsultationForm');
        const faqSubmitBtn = document.getElementById('faqSubmitBtn');

        if (faqForm) {
            faqForm.addEventListener('submit', function (e) {
                e.preventDefault();

                if (faqPhoneInput && faqPhoneInput.value.trim().length !== 10) {
                    if (faqPhoneError) {
                        faqPhoneError.textContent = 'Mobile number must be exactly 10 digits.';
                        faqPhoneError.style.display = 'block';
                    }
                    faqPhoneInput.style.borderColor = '#ef4444';
                    faqPhoneInput.focus();
                    return;
                }

                const btnOriginal = faqSubmitBtn ? faqSubmitBtn.innerHTML : '';
                if (faqSubmitBtn) {
                    faqSubmitBtn.disabled = true;
                    faqSubmitBtn.innerHTML = '<span class="form-btn-spinner"></span><span>SUBMITTING...</span>';
                }

                const formData = new FormData(faqForm);

                fetch("<?php echo e(url('/contact_submit')); ?>", {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    },
                    body: formData
                })
                .then(function (res) {
                    return res.json().then(function (data) {
                        return { status: res.status, ok: res.ok, data: data };
                    }).catch(function () {
                        return { status: res.status, ok: res.ok, data: null };
                    });
                })
                .then(function (result) {
                    const data = result.data;
                    if (result.ok && data && data.success) {
                        try {
                            sessionStorage.setItem('allow_thankyou', 'true');
                        } catch(e) {}
                        if (faqSubmitBtn) {
                            faqSubmitBtn.innerHTML = '<span class="form-btn-spinner"></span><span>REDIRECTING...</span>';
                        }
                        window.location.href = data.redirect_url || "<?php echo e(url('/thank-you')); ?>";
                    } else {
                        if (faqSubmitBtn) {
                            faqSubmitBtn.disabled = false;
                            faqSubmitBtn.innerHTML = btnOriginal;
                        }
                        const errMsg = (data && (data.message || data.error)) ? (data.message || data.error) : 'Please check your input and try again.';
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Notice',
                                text: errMsg,
                                confirmButtonColor: '#CCA43B'
                            });
                        } else {
                            alert(errMsg);
                        }
                    }
                })
                .catch(function (err) {
                    if (faqSubmitBtn) {
                        faqSubmitBtn.disabled = false;
                        faqSubmitBtn.innerHTML = btnOriginal;
                    }
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'An error occurred while submitting. Please try again.',
                            confirmButtonColor: '#CCA43B'
                        });
                    } else {
                        alert('Submission error. Please try again.');
                    }
                });
            });
        }
    });
    </script>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/index.blade.php ENDPATH**/ ?>