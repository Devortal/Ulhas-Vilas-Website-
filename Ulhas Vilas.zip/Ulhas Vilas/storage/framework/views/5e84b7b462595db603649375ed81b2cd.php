<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- GLASS HEADER NAVIGATION -->
    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php
        $heroGallery = [];
        if (!empty($residence->image)) {
            if (str_starts_with(trim($residence->image), '[')) {
                $heroGallery = json_decode($residence->image, true) ?: [];
            } else {
                $heroGallery = array_filter(array_map('trim', explode(',', $residence->image)));
            }
        }
        if (empty($heroGallery)) {
            $heroGallery = [
                'Website/assets/images/WhatsApp Image 2026-08-18 at 5.00.20 PM.jpeg',
                'Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg',
                'Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM (1).jpeg',
                'Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.45 PM.jpeg'
            ];
        }
    ?>

    <style>
    /* Full Width Clean Luxury Styling for Residence Detail Page */
    .residence-detail-page {
        background: #FDFBF7;
        color: #1A202C;
    }

    .res-main-section {
        width: 100%;
        background: #FFFFFF;
        border-bottom: 1px solid #ECE7DC;
    }

    /* BHK Other Residences Multi-Image Slider */
    .bhk-card-img-box {
        position: relative;
        height: 230px;
        overflow: hidden;
        background: #0E1114;
    }

    .bhk-image-slider {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .bhk-slide-img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0;
        transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .bhk-slide-img.active,
    .bhk-slide-img:first-child {
        opacity: 1;
        z-index: 2;
    }

    .bhk-card:hover .bhk-slide-img.active,
    .bhk-card:hover .bhk-slide-img:first-child {
        transform: scale(1.08);
    }

    .bhk-slider-dots {
        position: absolute;
        bottom: 0.7rem;
        right: 0.8rem;
        z-index: 6;
        display: flex;
        gap: 0.35rem;
    }

    .bhk-slider-dots .bhk-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.55);
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .bhk-slider-dots .bhk-dot.active {
        width: 16px;
        border-radius: 4px;
        background-color: #DCB658;
    }

    /* FAQ Clean White UI */
    .res-faq-clean-section {
        background: #FFFFFF;
        padding: 5rem 1.5rem 6rem;
        border-top: 1px solid #ECE7DC;
    }

    .res-faq-clean-container {
        max-width: 960px;
        margin: 0 auto;
    }

    .res-faq-header {
        text-align: center;
        margin-bottom: 3rem;
    }

    .res-faq-eyebrow {
        font-size: 0.78rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.16em;
        color: #DCB658;
        display: block;
        margin-bottom: 0.45rem;
    }

    .res-faq-title {
        font-family: var(--font-heading, 'Marcellus', serif);
        font-size: clamp(2rem, 3.5vw, 2.6rem);
        color: #111827;
        font-weight: 400;
        margin: 0 0 0.5rem 0;
        letter-spacing: -0.01em;
    }

    .res-faq-subtitle {
        font-size: 0.95rem;
        color: #64748B;
        margin: 0;
        line-height: 1.6;
    }

    .res-faq-list {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .res-faq-card {
        background: #FFFFFF;
        border: 1px solid #E8E2D5;
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.3s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
    }

    .res-faq-card:hover {
        border-color: #DCB658;
        box-shadow: 0 6px 18px rgba(220, 182, 88, 0.08);
    }

    .res-faq-card.open {
        border-color: #DCB658;
        box-shadow: 0 8px 24px rgba(220, 182, 88, 0.12);
    }

    .res-faq-btn {
        width: 100%;
        padding: 1.35rem 1.65rem;
        background: transparent;
        border: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.25rem;
        text-align: left;
        cursor: pointer;
        outline: none;
    }

    .res-faq-question {
        font-family: var(--font-body, 'Manrope', system-ui, sans-serif);
        font-size: 1.02rem;
        font-weight: 600;
        color: #111827;
        text-transform: none !important;
        letter-spacing: normal;
        margin: 0;
        line-height: 1.45;
        transition: color 0.2s ease;
    }

    .res-faq-card.open .res-faq-question {
        color: #8C7335;
    }

    .res-faq-toggle-icon {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: #F8F5EE;
        border: 1px solid #E5DEC9;
        color: #8C7335;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        font-weight: 400;
        line-height: 1;
        flex-shrink: 0;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .res-faq-card.open .res-faq-toggle-icon {
        transform: rotate(45deg);
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        box-shadow: 0 2px 8px rgba(220, 182, 88, 0.35);
    }

    .res-faq-body {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.35s ease, padding 0.3s ease;
        padding: 0 1.65rem;
    }

    .res-faq-card.open .res-faq-body {
        max-height: 400px;
        padding: 0 1.65rem 1.5rem 1.65rem;
    }

    .res-faq-answer {
        font-size: 0.94rem;
        line-height: 1.75;
        color: #4A5568;
        border-top: 1px solid #F1ECE1;
        padding-top: 1rem;
        margin: 0;
    }

    /* Amenities Dynamic Icons Grid */
    .amenities-card-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
    }

    .amenity-item-card {
        background: #FDFBF7;
        border: 1px solid #EBE5D8;
        border-radius: 12px;
        padding: 1rem 1.15rem;
        display: flex;
        align-items: center;
        gap: 0.85rem;
        transition: all 0.25s ease;
    }

    .amenity-item-card:hover {
        border-color: #DCB658;
        background: #FFFFFF;
        transform: translateY(-2px);
        box-shadow: 0 4px 14px rgba(0,0,0,0.04);
    }

    .amenity-item-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #F4EFE6;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: #8C7335;
    }

    .amenity-item-icon img {
        width: 22px;
        height: 22px;
        object-fit: contain;
    }

    .amenity-item-title {
        font-size: 0.88rem;
        font-weight: 600;
        color: #2D3748;
        line-height: 1.35;
    }

    @media (max-width: 900px) {
        .amenities-card-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 600px) {
        .amenities-card-grid {
            grid-template-columns: 1fr;
        }
    }

    /* Residence Section Headings 42px on Desktop */
    .res-section-heading,
    .about-residence-box h2,
    .res-main-section h2,
    .res-faq-title {
        font-family: 'Marcellus', serif !important;
        font-size: 32px !important;
        line-height: 1.25 !important;
        letter-spacing: -0.01em !important;
        margin-bottom: 0.35rem;
    }

    @media (max-width: 991px) {
        .res-section-heading,
        .about-residence-box h2,
        .res-main-section h2,
        .res-faq-title {
            font-size: 32px !important;
        }
    }

    /* Full-Width Floor Plan Architectural Showcase Styling */
    .res-floorplans-fullwidth-section {
        background: #FDFBF7;
        border-top: 1px solid #EBE3D3;
        border-bottom: 1px solid #EBE3D3;
        padding: 2.5rem 1.5rem 2.5rem;
        width: 100%;
        position: relative;
    }

    .res-fp-fullwidth-container {
        max-width: 1400px;
        margin: 0 auto;
    }

    .res-fp-fullwidth-header {
        text-align: center;
        max-width: 860px;
        margin: 0 auto 3rem;
    }

    .res-fp-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.75rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.18em;
        color: #B88B2A;
        display: block;
        margin-bottom: 0.5rem;
    }

    .res-fp-filter-tabs {
        display: flex;
        justify-content: center;
        gap: 0.75rem;
        flex-wrap: wrap;
        margin-top: 1.75rem;
    }

    .res-fp-tab-btn {
        background: #FFFFFF;
        border: 1px solid #E2D8C6;
        padding: 0.65rem 1.35rem;
        border-radius: 999px;
        font-family: 'Manrope', sans-serif;
        font-size: 0.82rem;
        font-weight: 700;
        color: #4A5568;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 2px 6px rgba(0,0,0,0.02);
    }

    .res-fp-tab-btn:hover {
        border-color: #DCB658;
        color: #8C7335;
        transform: translateY(-1px);
    }

    .res-fp-tab-btn.active {
        background: #1A1510;
        border-color: #1A1510;
        color: #FFFFFF;
        box-shadow: 0 4px 14px rgba(26,21,16,0.25);
    }

    .res-fp-cards-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin-bottom: 3.5rem;
    }

    .res-fp-card {
        background: #FFFFFF;
        border: 1px solid #E5DDCF;
        border-radius: 16px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 6px 24px rgba(0, 0, 0, 0.04);
        cursor: pointer;
        position: relative;
    }

    .res-fp-card:hover {
        transform: translateY(-8px);
        border-color: #DCB658;
        box-shadow: 0 20px 45px rgba(220, 182, 88, 0.18), 0 0 0 1px rgba(220, 182, 88, 0.4);
    }

    .res-fp-card-imgbox {
        position: relative;
        height: 330px;
        background: #FFFFFF;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        padding: 1.25rem;
        border-bottom: 1px solid #ECE4D6;
    }

    .res-fp-card-img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        transition: transform 0.4s ease;
    }

    .res-fp-card:hover .res-fp-card-img {
        transform: scale(1.05);
    }

    .res-fp-card-zoom-overlay {
        position: absolute;
        inset: 0;
        background: rgba(10, 14, 12, 0.35);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .res-fp-card:hover .res-fp-card-zoom-overlay {
        opacity: 1;
    }

    .res-fp-card-zoom-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        background: #DCB658;
        color: #0E1114;
        font-family: 'Manrope', sans-serif;
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        padding: 0.55rem 1rem;
        border-radius: 999px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.3);
        transform: translateY(10px);
        transition: transform 0.3s ease;
    }

    .res-fp-card:hover .res-fp-card-zoom-btn {
        transform: translateY(0);
    }

    .res-fp-card-body {
        padding: 1.35rem 1.25rem 1.4rem;
        background: #FFFFFF;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 0.85rem;
        flex-grow: 1;
    }

    .res-fp-card-title {
        font-family: 'Marcellus', serif !important;
        font-size: 1rem !important;
        color: #111827 !important;
        margin: 0 !important;
        line-height: 1.35 !important;
        font-weight: 500 !important;
        text-align: center;
        transition: color 0.25s ease;
    }

    .res-fp-card:hover .res-fp-card-title {
        color: #8C7335 !important;
    }

    .res-fp-card-cta {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        padding: 0.85rem 1.25rem;
        background: linear-gradient(135deg, #1a1510, #2c2016);
        border: none;
        border-radius: 9999px;
        color: #FFFFFF;
        font-family: 'Marcellus', serif !important;
        font-size: 0.82rem;
        font-weight: 500;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        transition: all 0.3s ease;
        box-shadow: 0 4px 14px rgba(26, 21, 16, 0.2);
    }

    .res-fp-card:hover .res-fp-card-cta {
        background: #DCB658;
        color: #0E1114;
        box-shadow: 0 6px 20px rgba(220, 182, 88, 0.35);
        transform: translateY(-2px);
    }

    /* =========================================================
       SALIENT FEATURES STRAP SECTION (LUXURY VIDEO STRIP)
       ========================================================= */
    .res-salient-strap-section {
        position: relative;
        background: #080C10;
        border-top: 1px solid rgba(220, 182, 88, 0.35);
        border-bottom: 1px solid rgba(220, 182, 88, 0.35);
        padding: 3rem 1.5rem;
        width: 100%;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06), 0 12px 36px rgba(0, 0, 0, 0.45);
        overflow: hidden;
    }

    .res-salient-video-wrapper {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .res-salient-bg-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 0.68;
        filter: brightness(0.96) contrast(1.12) saturate(1.2);
        transform: scale(1.02);
    }

    .res-salient-video-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(8, 12, 16, 0.72) 0%, rgba(8, 12, 16, 0.48) 50%, rgba(8, 12, 16, 0.78) 100%),
                    radial-gradient(circle at 50% 50%, rgba(0, 0, 0, 0.0) 0%, rgba(8, 12, 16, 0.6) 100%);
        z-index: 2;
    }

    .res-salient-strap-container {
        max-width: 1360px;
        margin: 0 auto;
        position: relative;
        z-index: 5;
    }

    .res-salient-strap-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        align-items: stretch;
        gap: 0.5rem;
    }

    .res-salient-strap-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 1rem 0.75rem;
        border-right: 1px solid rgba(255, 255, 255, 0.08);
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        border-radius: 14px;
        position: relative;
    }

    .res-salient-strap-item:last-child {
        border-right: none;
    }

    .res-salient-strap-item:hover {
        transform: translateY(-4px);
        background: rgba(220, 182, 88, 0.06);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    }

    .res-salient-strap-icon {
        width: 54px;
        height: 54px;
        margin-bottom: 0.85rem;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at 35% 35%, rgba(220, 182, 88, 0.22) 0%, rgba(13, 18, 23, 0.85) 80%);
        border: 1px solid rgba(220, 182, 88, 0.45);
        border-radius: 14px;
        padding: 10px;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.12);
    }

    .res-salient-strap-item:hover .res-salient-strap-icon {
        transform: scale(1.12);
        border-color: #DCB658;
        background: radial-gradient(circle at 35% 35%, rgba(220, 182, 88, 0.35) 0%, rgba(13, 18, 23, 0.95) 80%);
        box-shadow: 0 8px 24px rgba(220, 182, 88, 0.35), inset 0 0 12px rgba(220, 182, 88, 0.2);
    }

    .res-salient-strap-icon svg {
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    .res-salient-strap-title {
        font-family: 'Marcellus', serif;
        font-size: 0.92rem;
        font-weight: 500;
        color: #F8F5EC;
        line-height: 1.35;
        max-width: 180px;
        margin: 0;
        letter-spacing: 0.02em;
        text-shadow: 0 2px 6px rgba(0, 0, 0, 0.5);
    }

    @media (max-width: 1100px) {
        .res-salient-strap-grid {
            grid-template-columns: repeat(3, 1fr);
            row-gap: 1.25rem;
        }
        .res-salient-strap-item:nth-child(3) {
            border-right: none;
        }
    }

    @media (max-width: 640px) {
        .res-salient-strap-grid {
            grid-template-columns: repeat(2, 1fr);
            row-gap: 1rem;
        }
        .res-salient-strap-item:nth-child(even) {
            border-right: none;
        }
        .res-salient-strap-item:nth-child(odd) {
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }
    }

    @media (max-width: 1200px) {
        .res-fp-cards-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.35rem;
        }
    }

    @media (max-width: 900px) {
        .res-floorplans-fullwidth-section {
            padding: 4rem 1.25rem 4.5rem;
        }
        .res-fp-metrics-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
        }
        .res-fp-metric-item {
            border-right: none;
            border-bottom: 1px solid #E6DEC9;
            padding-bottom: 0.75rem;
        }
        .res-fp-metric-item:nth-child(3),
        .res-fp-metric-item:nth-child(4) {
            border-bottom: none;
            padding-bottom: 0;
        }
        .res-fp-dim-columns {
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }
    }

    @media (max-width: 640px) {
        .res-fp-cards-grid {
            grid-template-columns: 1fr;
        }
        .res-fp-summary-box {
            padding: 1.5rem 1.25rem;
        }
        .res-fp-metrics-grid {
            grid-template-columns: 1fr;
        }
        .res-fp-metric-item {
            border-bottom: 1px solid #E6DEC9;
            padding-bottom: 0.6rem;
        }
        .res-fp-metric-item:last-child {
            border-bottom: none;
        }
    }

    /* Bottom-Aligned Gallery Card Overlay Matching Main Gallery */
    .res-gallery-item {
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        cursor: pointer;
    }

    .res-gallery-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.05) 0%, rgba(10, 12, 14, 0.9) 100%) !important;
        padding: 1.25rem !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: flex-end !important;
        opacity: 0.95 !important;
        transition: all 0.35s ease !important;
    }

    .res-gallery-item:hover .res-gallery-overlay {
        opacity: 1 !important;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.15) 0%, rgba(10, 12, 14, 0.96) 100%) !important;
    }

    .res-gallery-info {
        color: #ffffff !important;
        margin-top: auto !important;
    }

    .res-gallery-title {
        font-family: 'Marcellus', serif !important;
        font-size: 1.15rem !important;
        margin: 0 0 0.3rem 0 !important;
        line-height: 1.25 !important;
        font-weight: 400 !important;
        color: #ffffff !important;
        letter-spacing: 0.02em !important;
        text-shadow: 0 2px 8px rgba(0,0,0,0.6) !important;
    }

    .res-gallery-desc {
        font-size: 0.82rem !important;
        color: rgba(255, 255, 255, 0.85) !important;
        line-height: 1.45 !important;
        margin: 0 !important;
        text-shadow: 0 1px 4px rgba(0,0,0,0.5) !important;
    }

    /* =========================================================
       LUXURY LIGHTBOX STYLING WITH FULL NAVIGATION CONTROLS & CAPTIONS
       ========================================================= */
    .gallery-lightbox-modal {
        position: fixed;
        inset: 0;
        background: rgba(8, 10, 14, 0.94);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        user-select: none;
    }

    .gallery-lightbox-modal.active {
        opacity: 1;
        pointer-events: auto;
    }

    .lb-close-btn {
        position: absolute;
        top: 1.5rem;
        right: 2rem;
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.22);
        color: #ffffff;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        transition: all 0.25s ease;
    }

    .lb-close-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: rotate(90deg) scale(1.08);
        box-shadow: 0 4px 20px rgba(220, 182, 88, 0.4);
    }

    /* Navigation Arrows */
    .lb-nav-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(255, 255, 255, 0.12);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: #ffffff;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    }

    .lb-prev-btn {
        left: 2rem;
    }

    .lb-next-btn {
        right: 2rem;
    }

    .lb-nav-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: translateY(-50%) scale(1.12);
        box-shadow: 0 10px 30px rgba(220, 182, 88, 0.5);
    }

    .lb-nav-btn:active {
        transform: translateY(-50%) scale(0.95);
    }

    /* Lightbox Image Container & Content */
    .lb-content-wrap {
        position: relative;
        max-width: 90vw;
        max-height: 92vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10;
    }

    .lb-image-container {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        max-width: 86vw;
        max-height: 76vh;
    }

    .lb-main-image {
        max-width: 86vw;
        max-height: 76vh;
        border-radius: 12px;
        box-shadow: 0 25px 70px rgba(0, 0, 0, 0.7);
        object-fit: contain;
        border: 1px solid rgba(255, 255, 255, 0.14);
        transition: opacity 0.22s ease, transform 0.25s ease;
    }

    .lb-caption-bar {
        width: 100%;
        max-width: 86vw;
        margin-top: 0.85rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.5rem;
        padding: 0.75rem 1.4rem;
        background: rgba(18, 22, 28, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 12px;
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
    }

    .lb-caption-info {
        display: flex;
        flex-direction: column;
        gap: 0.2rem;
        text-align: left;
    }

    .lb-category-tag {
        font-size: 0.68rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.14em;
        color: #DCB658;
    }

    .lb-title-text {
        font-family: var(--font-heading, 'Marcellus', serif);
        font-size: 1.2rem;
        color: #ffffff;
        margin: 0;
        line-height: 1.25;
    }

    .lb-desc-text {
        font-size: 0.85rem;
        color: rgba(255, 255, 255, 0.75);
        margin: 0;
        line-height: 1.4;
    }

    .lb-counter {
        font-size: 0.85rem;
        font-weight: 700;
        color: #DCB658;
        background: rgba(220, 182, 88, 0.12);
        border: 1px solid rgba(220, 182, 88, 0.3);
        padding: 0.4rem 0.95rem;
        border-radius: 9999px;
        white-space: nowrap;
        letter-spacing: 0.05em;
    }

    @media (max-width: 768px) {
        .lb-prev-btn {
            left: 0.6rem;
            width: 44px;
            height: 44px;
        }
        .lb-next-btn {
            right: 0.6rem;
            width: 44px;
            height: 44px;
        }
        .lb-close-btn {
            top: 0.85rem;
            right: 0.85rem;
            width: 40px;
            height: 40px;
        }
        .lb-caption-bar {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
            padding: 0.65rem 1rem;
        }
        .lb-counter {
            align-self: flex-end;
        }
    }
    </style>

    <!-- =========================================================
         FULL-WIDTH DARK HERO GALLERY SLIDER
    ========================================================= -->
    <div class="residence-hero-fullwidth">

        <div class="residence-hero-slider-track" id="heroTrack">
            <?php $__currentLoopData = $heroGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $gImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="residence-hero-slide <?php echo e($idx === 0 ? 'active' : ''); ?>" data-title="<?php echo e($residence->name ?? 'Luxury Residence'); ?>" data-desc="Curated Exterior & Living Perspective" data-category="<?php echo e(strtoupper($residence->category_name ?? 'RESIDENCE')); ?>">
                    <img src="<?php echo e(Str::startsWith($gImg, ['http://', 'https://', '/']) ? $gImg : asset($gImg)); ?>" alt="<?php echo e($residence->name ?? 'Residence'); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Prev/Next Arrows -->
        <button class="hero-slider-arrow prev" onclick="heroSlide(-1)" aria-label="Previous">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <button class="hero-slider-arrow next" onclick="heroSlide(1)" aria-label="Next">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>
        </button>

        <!-- Bottom info bar: breadcrumbs + title + specs tabs -->
        <div class="hero-bottom-bar">
            <div class="hero-content-box">

                <!-- Breadcrumbs -->
                <div class="hero-breadcrumbs">
                    <a href="<?php echo e(url('/')); ?>" style="color: rgba(255,255,255,0.6); text-decoration: none;">Ulhas Vilas</a>
                    <span style="color: rgba(255,255,255,0.35);">›</span>
                    <a href="<?php echo e(url('/residences')); ?>" style="color: rgba(255,255,255,0.6); text-decoration: none;">Residences</a>
                    <span style="color: rgba(255,255,255,0.35);">›</span>
                    <span style="color: rgba(255,255,255,0.9);"><?php echo e($residence->name ?? 'Luxury Residence'); ?></span>
                </div>

                <!-- Title -->
                <div class="hero-info-title"><?php echo e($residence->name ?? 'Luxury Residence'); ?></div>

                <!-- Spec Tabs Row -->
                <div class="hero-spec-pills-row">
                    <?php if(!empty($residence->carpet_area)): ?>
                    <div class="hero-spec-pill">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="rgba(197,160,89,0.9)"><path d="M19 2H9c-1.1 0-2 .9-2 2v4H5c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM9 4h10v16H9V4zm-4 6h2v2H5v-2zm0 4h2v2H5v-2zm0 4h2v2H5v-2zm6-12h2v2h-2V6zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm4-12h2v2h-2V6zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2z"/></svg>
                        <?php echo e($residence->carpet_area); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(!empty($residence->rooms) || !empty($residence->suites)): ?>
                    <div class="hero-spec-pill">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="rgba(197,160,89,0.9)"><path d="M19 7h-8v8H3V5H1v15h2v-3h18v3h2v-9c0-2.21-1.79-4-4-4zm-9 6H3V9h7v4zm9 0h-7V9h7v4z"/></svg>
                        <?php echo e($residence->rooms ?? $residence->suites); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(!empty($residence->toilets) || !empty($residence->bathrooms)): ?>
                    <div class="hero-spec-pill">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="rgba(197,160,89,0.9)"><path d="M21 11H3c-.55 0-1 .45-1 1v3c0 2.76 2.24 5 5 5h10c2.76 0 5-2.24 5-5v-3c0-.55-.45-1-1-1zm-1 4c0 1.65-1.35 3-3 3H7c-1.65 0-3-1.35-3-3v-2h17v2zM7 9c.55 0 1-.45 1-1V5c0-1.1.9-2 2-2s2 .9 2 2v.5h-2V7h4V5c0-2.21-1.79-4-4-4S6 2.79 6 5v3c0 .55.45 1 1 1z"/></svg>
                        <?php echo e($residence->toilets ?? $residence->bathrooms); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(!empty($residence->price)): ?>
                    <div class="hero-spec-pill" style="background: rgba(197,160,89,0.18); border-color: rgba(197,160,89,0.5); color: #e8c96a;">
                        <?php echo e((!empty($residence->price_prefix) ? $residence->price_prefix . ' ' : '') . '₹ ' . $residence->price); ?>

                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <!-- Bottom Right: Dots + Photo count -->
        <div class="hero-slide-counter">
            <div class="hero-dots" id="heroDots">
                <?php $__currentLoopData = $heroGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dIdx => $dImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="hero-dot <?php echo e($dIdx === 0 ? 'active' : ''); ?>" onclick="heroGoTo(<?php echo e($dIdx); ?>)"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if(count($heroGallery) > 0): ?>
                <button class="hero-photo-count" onclick="openHeroItemLightbox(0)">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline;margin-right:4px;vertical-align:middle;"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                    View <?php echo e(count($heroGallery)); ?> photos
                </button>
            <?php endif; ?>
        </div>

    </div>

    <!-- =========================================================
         MAIN TWO-COLUMN CONTENT LAYOUT (FULL-WIDTH PURE WHITE BACKGROUND)
    ========================================================= -->
    <section class="res-main-section">
        <div class="res-main-grid" style="max-width:1340px; margin:0 auto; padding:3.5rem 1.5rem 4.5rem; display:grid; grid-template-columns:1fr 400px; gap:4rem; align-items:start; background:#fff;">

        <!-- LEFT COLUMN -->
        <div style="display: flex; flex-direction: column; gap: 2.5rem;">

            <!-- 1. RESIDENCE OVERVIEW -->
            <div class="about-residence-box" style="padding-top: 0.25rem;">
                <h2 class="res-section-heading">Residence Overview</h2>
                <span class="res-heading-line"></span>
                <div class="about-residence-text" style="font-size: 15px; line-height: 1.75; color: #374151; margin-top: 1rem;">
                    <?php if(!empty($residence->short_description)): ?>
                        <p style="font-size: 1.05rem; font-weight: 600; color: #1f2937; line-height: 1.6; margin-bottom: 0.95rem;">
                            <?php echo e($residence->short_description); ?>

                        </p>
                    <?php endif; ?>
                    <?php
                        $rawDesc = trim($residence->description ?? '');
                        if (!empty($rawDesc)) {
                            if (strip_tags($rawDesc) !== $rawDesc) {
                                $descHtml = $rawDesc;
                            } else {
                                $paragraphs = array_filter(array_map('trim', preg_split('/\r\n\r\n|\n\n|\r\r/', $rawDesc)));
                                $descHtml = '';
                                foreach ($paragraphs as $p) {
                                    $descHtml .= '<p style="margin-bottom: 0.85rem; line-height: 1.75; color: #4b5563;">' . nl2br(e($p)) . '</p>';
                                }
                            }
                        } else {
                            $descHtml = '<p style="margin-bottom: 0.85rem; line-height: 1.75; color: #4b5563;">Crafted with architectural finesse, this master-planned residence combines floor-to-ceiling panoramic glass walls, organic stone finishes, and expansive sun-drenched private balconies. Featuring 2 well-appointed rooms, a grand drawing and dining hall, 2 designer en-suite toilets, and a modular pantry kitchenette, every square inch is optimized for comfort, privacy, and picturesque mountain vistas.</p>';
                        }
                    ?>
                    <div class="res-overview-body" style="color: #4b5563;">
                        <?php echo $descHtml; ?>

                    </div>
                </div>
            </div>

            <hr class="res-section-divider">

            <!-- 2. DETAILS — INDIVIDUAL STAT CARDS -->
            <div id="details">
                <h2 class="res-section-heading">Key Specifications</h2>
                <span class="res-heading-line"></span>
                <p class="res-section-sub" style="margin-bottom: 1.75rem;">Key specifications of <?php echo e($residence->name ?? 'this luxury residence'); ?>.</p>

                <div class="details-stat-cards">

                    <!-- Property Size -->
                    <?php if(!empty($residence->carpet_area)): ?>
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24"><path d="M19 2H9c-1.1 0-2 .9-2 2v4H5c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM9 4h10v16H9V4zm-4 6h2v2H5v-2zm0 4h2v2H5v-2zm0 4h2v2H5v-2zm6-12h2v2h-2V6zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm4-12h2v2h-2V6zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2z"/></svg>
                            </div>
                            <span class="stat-card-badge">Carpet Area</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Property Size</div>
                            <div class="stat-card-value"><?php echo e($residence->carpet_area); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Rooms / Bedrooms -->
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24"><path d="M19 7h-8v8H3V5H1v15h2v-3h18v3h2v-9c0-2.21-1.79-4-4-4zm-9 6H3V9h7v4zm9 0h-7V9h7v4z"/></svg>
                            </div>
                            <span class="stat-card-badge">Private Suites</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Bedrooms / Suites</div>
                            <div class="stat-card-value"><?php echo e($residence->rooms ?? ($residence->suites ?? '2 Rooms')); ?></div>
                        </div>
                    </div>

                    <!-- 1 D Room (Drawing / Dining) -->
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 9V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v2"/><path d="M2 11v5a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/><path d="M4 18v2M20 18v2M8 11v3M16 11v3"/></svg>
                            </div>
                            <span class="stat-card-badge">Living Area</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Drawing / Dining</div>
                            <div class="stat-card-value"><?php echo e($residence->d_room ?? '1 D Room'); ?></div>
                        </div>
                    </div>

                    <!-- Balconies -->
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M5 21V10l7-5 7 5v11M9 21v-4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v4"/><line x1="3" y1="13" x2="21" y2="13"/></svg>
                            </div>
                            <span class="stat-card-badge">Balconies</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Balconies</div>
                            <div class="stat-card-value"><?php echo e($residence->balconies ?? '2 Balconies'); ?></div>
                        </div>
                    </div>

                    <!-- Toilets -->
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24"><path d="M21 11H3c-.55 0-1 .45-1 1v3c0 2.76 2.24 5 5 5h10c2.76 0 5-2.24 5-5v-3c0-.55-.45-1-1-1zm-1 4c0 1.65-1.35 3-3 3H7c-1.65 0-3-1.35-3-3v-2h17v2zM7 9c.55 0 1-.45 1-1V5c0-1.1.9-2 2-2s2 .9 2 2v.5h-2V7h4V5c0-2.21-1.79-4-4-4S6 2.79 6 5v3c0 .55.45 1 1 1z"/></svg>
                            </div>
                            <span class="stat-card-badge">Washrooms</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Toilets</div>
                            <div class="stat-card-value"><?php echo e($residence->toilets ?? ($residence->bathrooms ?? '2 Toilets')); ?></div>
                        </div>
                    </div>

                    <!-- Pantry -->
                    <div class="stat-card">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>
                            </div>
                            <span class="stat-card-badge">Pantry</span>
                        </div>
                        <div>
                            <div class="stat-card-label">Pantry</div>
                            <div class="stat-card-value"><?php echo e($residence->pantry ?? '1 Pantry'); ?></div>
                        </div>
                    </div>



                    <!-- Featured Starting Value -->
                    <?php if(!empty($residence->price)): ?>
                    <div class="stat-card accent">
                        <div class="stat-card-header-row">
                            <div class="stat-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
                            </div>
                            <span class="stat-card-badge" style="background:#fcebc7; border-color:#d4b060; color:#7a4f1a;"><?php echo e($residence->category_name ?? 'Signature Luxury'); ?></span>
                        </div>
                        <div>
                            <div class="stat-card-label" style="color:#a37d38;">Starting Value</div>
                            <div class="stat-card-value"><?php echo e((!empty($residence->price_prefix) ? $residence->price_prefix . ' ' : '') . '₹ ' . $residence->price); ?></div>
                            <div class="stat-card-pills-row">
                                <span class="stat-card-pill">Zero Brokerage</span>
                                <span class="stat-card-pill">RERA Registered</span>
                                <span class="stat-card-pill">Bank Pre-Approved</span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

            <hr class="res-section-divider">

            <!-- 3. INCLUDED COMFORTS (DYNAMIC FROM AMENITIES TABLE MATCHING amenity_id) -->
            <div id="amenities">
                <h2 class="res-section-heading">Included Comforts</h2>
                <span class="res-heading-line"></span>
                <p class="res-section-sub" style="margin-bottom: 1.5rem;">Everything you need for elevated daily living.</p>

                <div class="amenities-card-grid">
                    <?php if(!empty($residence_amenities) && count($residence_amenities) > 0): ?>
                        <?php $__currentLoopData = $residence_amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $am): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $iconUrl = !empty($am->image) ? (str_starts_with($am->image, 'http') || str_starts_with($am->image, '/') ? $am->image : asset($am->image)) : '';
                            ?>
                            <div class="amenity-item-card">
                                <div class="amenity-item-icon">
                                    <?php if($iconUrl): ?>
                                        <img src="<?php echo e($iconUrl); ?>" alt="<?php echo e($am->name); ?>" style="width: 22px; height: 22px; object-fit: contain;">
                                    <?php else: ?>
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                                    <?php endif; ?>
                                </div>
                                <div class="amenity-item-title"><?php echo e($am->name); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div style="grid-column: 1 / -1; padding: 1.5rem; background: #FAF8F5; border-radius: 12px; color: #718096; text-align: center;">
                            No specific amenities assigned for this residence.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- RIGHT STICKY ENQUIRY CARD -->
        <div style="position: relative; align-self: start;">
            <div style="position: sticky; top: 95px; background: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 8px 40px rgba(0,0,0,0.12); border: 1px solid #e5ddd0;">

                <!-- Dark luxury header -->
                <div style="background: linear-gradient(135deg, #1a1510 0%, #2a2018 100%); padding: 1.75rem 2rem;">
                    <div style="font-family: 'Marcellus', serif; font-size: 1.85rem; color: #ffffff;">
                        <?php echo e((!empty($residence->price_prefix) ? $residence->price_prefix . ' ' : '')); ?>&#8377; <?php echo e($residence->price ?? 'Price on Request'); ?>

                    </div>
                    <div style="font-size: 0.82rem; color: rgba(255,255,255,0.68); margin-top: 0.35rem;">
                        <?php echo e($residence->carpet_area ?? ''); ?> &middot; <?php echo e($residence->category_name ?? 'Signature Residence'); ?> &middot; Custom Fit-Outs Available
                    </div>
                    <div style="display: flex; gap: 0.5rem; margin-top: 1rem; flex-wrap: wrap;">
                        <span style="padding: 0.3rem 0.75rem; border: 1px solid rgba(197,160,89,0.5); border-radius: 999px; color: #e0bc6d; font-size: 0.73rem; font-weight: 700;">RERA Registered</span>
                        <span style="padding: 0.3rem 0.75rem; border: 1px solid rgba(197,160,89,0.5); border-radius: 999px; color: #e0bc6d; font-size: 0.73rem; font-weight: 700;">Bank Pre-Approved</span>
                    </div>
                </div>

                <!-- Form body (Single Clean Section Matching Contact Form) -->
                <div style="padding: 1.75rem 2rem 2rem;">
                    <form id="resBookingForm" method="post" action="<?php echo e(url('/contact_submit')); ?>">
                        <?php echo csrf_field(); ?>

                        <div style="display: flex; flex-direction: column; gap: 1rem; margin-bottom: 1.5rem;">
                            <!-- Row 1: Full Name & Mobile Number -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.85rem;">
                                <div>
                                    <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">Full Name *</label>
                                    <input type="text" name="name" placeholder="Full Name" required minlength="2" maxlength="100" style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;">
                                </div>
                                <div>
                                    <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">Mobile Number *</label>
                                    <input type="tel" id="resPhoneInput" name="mobile" placeholder="Mobile Number" maxlength="10" required pattern="[0-9]{10}" inputmode="numeric" style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;">
                                    <span id="resPhoneError" style="display:none; color:#dc2626; font-size:11px; font-weight:600; margin-top:3px;">Please enter 10 digits.</span>
                                </div>
                            </div>

                            <!-- Row 2: Email Address & City -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.85rem;">
                                <div>
                                    <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">Email Address *</label>
                                    <input type="email" name="email" placeholder="Email Address" required maxlength="150" style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;">
                                </div>
                                <div>
                                    <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">City *</label>
                                    <input type="text" name="city" placeholder="City" required maxlength="100" style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;box-sizing:border-box;transition:border-color 0.2s;">
                                </div>
                            </div>

                            <!-- Row 3: Preferred Configuration (Dynamic Dropdown with Current Residence selected) -->
                            <div>
                                <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">Preferred Configuration *</label>
                                <select name="residence_id" id="residenceSelect" required style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;cursor:pointer;box-sizing:border-box;transition:border-color 0.2s;">
                                    <option value="" disabled>Select Preferred Configuration</option>
                                    <?php if(!empty($residences) && count($residences) > 0): ?>
                                        <?php $__currentLoopData = $residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>" <?php echo e((!empty($residence) && $residence->id == $r->id) ? 'selected' : ''); ?>>
                                                <?php echo e($r->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="<?php echo e($residence->id ?? 1); ?>" selected><?php echo e($residence->name ?? 'Residence'); ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- Row 4: Message -->
                            <div>
                                <label style="display:block;font-size:0.75rem;font-weight:700;color:#1e293b;margin-bottom:0.35rem;">Message</label>
                                <textarea name="message" rows="3" placeholder="Message" style="width:100%;background:#FDFBF7;border:1px solid #E2D9C8;border-radius:10px;padding:0.75rem 0.9rem;font-size:0.88rem;color:#1A202C;outline:none;font-family:inherit;box-sizing:border-box;resize:vertical;min-height:75px;transition:border-color 0.2s;"></textarea>
                            </div>
                        </div>

                        <button type="submit" id="resSubmitBtn" class="send-msg-btn" style="width:100%;padding:1rem;background:linear-gradient(135deg,#1a1510,#2c2016);border:none;border-radius:12px;color:#fff;font-size:0.95rem;font-weight:700;letter-spacing:0.07em;text-transform:uppercase;cursor:pointer;font-family:inherit;transition:all 0.25s;"
                            onmouseover="this.style.opacity='0.9'"
                            onmouseout="this.style.opacity='1'">SEND US A MESSAGE</button>
                        <div style="text-align:center;font-size:0.78rem;color:#9a9283;margin-top:0.6rem;margin-bottom:1.25rem;">No obligation &middot; Response within 2 hours</div>
                    </form>

                    <!-- Residence Ownership Highlights -->
                    <div style="padding: 1.15rem; background: #faf8f5; border-radius: 12px; border: 1px solid #eee8dd;">
                        <div style="font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: #8a7a66; margin-bottom: 0.65rem;">Key Ownership Benefits</div>
                        <div style="display: flex; flex-direction: column; gap: 0.6rem; font-size: 0.82rem; color: #444444;">
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#c5a059" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                                <span><strong>Clear Title</strong> · 100% Freehold Land Ownership</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#c5a059" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                                <span><strong>High Rental Yield</strong> · Professional Villa Pool Management</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#c5a059" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                                <span><strong>Zero Hidden Fees</strong> · Transparent Possession Schedule</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
    </section>

    <!-- =========================================================
         4. FULL-WIDTH ARCHITECTURAL MASTER PLANS (DYNAMIC PER RESIDENCE)
    ========================================================= -->
    <?php
        $layoutPlans = [];
        if (!empty($residence->layout_plans)) {
            if (is_string($residence->layout_plans)) {
                $layoutPlans = json_decode($residence->layout_plans, true) ?: [];
            } elseif (is_array($residence->layout_plans)) {
                $layoutPlans = $residence->layout_plans;
            }
        }
        if (is_array($layoutPlans)) {
            $layoutPlans = array_values(array_filter($layoutPlans, function($p) {
                return !empty(trim($p['title'] ?? '')) || !empty(trim($p['image'] ?? ''));
            }));
        } else {
            $layoutPlans = [];
        }
    ?>
    <?php if(!empty($layoutPlans) && count($layoutPlans) > 0): ?>
    <section class="res-floorplans-fullwidth-section" id="architectural-master-plans">
        <div class="res-fp-fullwidth-container">
            <div class="res-fp-fullwidth-header">
                <span class="res-fp-eyebrow">ARCHITECTURAL BLUEPRINTS</span>
                <h2 class="res-section-heading">Architectural Master Plans & 3D Layouts</h2>
                <span class="res-heading-line center"></span>
                <p class="res-section-sub" style="font-size: 0.95rem; max-width: 820px; margin: 0 auto;">
                    Explore detailed floor-by-floor 3D layouts, carpet area breakdowns, and spatial configurations for <?php echo e($residence->name ?? 'the Residences'); ?>.
                </p>
            </div>

            <!-- Dynamic Layout Plans Grid -->
            <div class="res-fp-cards-grid">
                <?php $__currentLoopData = $layoutPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rawPlanImg = $plan['image'] ?? '';
                        if (str_starts_with($rawPlanImg, 'http://') || str_starts_with($rawPlanImg, 'https://')) {
                            $planImgSrc = $rawPlanImg;
                        } elseif (!empty($rawPlanImg)) {
                            $planImgSrc = asset($rawPlanImg);
                        } else {
                            $planImgSrc = asset('Website/assets/images/Layout plan type 4 - First Floor (3 BR).png');
                        }
                        $planTitle = $plan['title'] ?? 'Layout Plan';
                    ?>
                    <div class="res-fp-card" data-title="<?php echo e(strip_tags($planTitle)); ?>" data-desc="Architectural Master Plan & 3D Layout" data-category="FLOOR PLAN">
                        <div class="res-fp-card-imgbox" style="cursor: pointer;" onclick="openPlanItemLightbox(this)" title="Click to zoom plan">
                            <img src="<?php echo e($planImgSrc); ?>" alt="<?php echo e(strip_tags($planTitle)); ?>" class="res-fp-card-img" loading="lazy">
                            <div class="res-fp-card-zoom-overlay">
                                <span class="res-fp-card-zoom-btn">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
                                    Zoom Image
                                </span>
                            </div>
                        </div>
                        <div class="res-fp-card-body">
                            <h4 class="res-fp-card-title"><?php echo nl2br(e($planTitle)); ?></h4>
                            <button type="button" class="res-fp-card-cta" onclick="openQuoteModal('<?php echo e($residence->id ?? ''); ?>', '<?php echo e(addslashes($residence->name ?? 'Residence')); ?>', '<?php echo e(addslashes($residence->category_name ?? '')); ?>')">
                                <span>VIEW PLAN</span>
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section>
    <?php endif; ?>

    <!-- =========================================================
         5. STATIC SALIENT FEATURES STRAP SECTION (SINGLE CONTINUOUS ROW)
    ========================================================= -->
    <section class="res-salient-strap-section" id="salient-features">
        <!-- Ambient Background Video Player -->
        <div class="res-salient-video-wrapper">
            <video class="res-salient-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/0_Coastal_Green_1920x1080.mp4')); ?>" type="video/mp4">
                <source src="<?php echo e(asset('Website/assets/images/2333673_Aerial_Mountainside_1920x1080.mp4')); ?>" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="res-salient-video-overlay"></div>
        </div>

        <div class="res-salient-strap-container">
            <div class="res-salient-strap-grid">
                <!-- Feature 1: 100% Power Back-up -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="8" y="16" width="48" height="34" rx="4" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                            <circle cx="16" cy="24" r="2.5" fill="#DCB658"/>
                            <line x1="13" y1="32" x2="23" y2="32" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="13" y1="38" x2="23" y2="38" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="13" y1="44" x2="23" y2="44" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <rect x="29" y="22" width="21" height="22" rx="3" stroke="#DCB658" stroke-width="2"/>
                            <path d="M40 26L36 33H41L38 40" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M26 16V11H38V16" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <line x1="14" y1="50" x2="14" y2="55" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                            <line x1="50" y1="50" x2="50" y2="55" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">100% Power Back-up</span>
                </div>

                <!-- Feature 2: Round the Year Security -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 28L34 16C37 14 42 16 44 19L47 24C49 27 48 32 45 34L23 46C20 48 15 46 13 43L10 38C8 35 9 30 12 28Z" stroke="#DCB658" stroke-width="2.5" stroke-linejoin="round"/>
                            <path d="M10 29L6 33C5 34 5 36 6 37L9 41C10 42 12 42 13 41L17 37" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <circle cx="28" cy="30" r="3.5" stroke="#DCB658" stroke-width="2"/>
                            <path d="M40 33L48 42V52H54" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <line x1="54" y1="46" x2="54" y2="56" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">Round the Year Security</span>
                </div>

                <!-- Feature 3: Paved Internal Paths with Lighting -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M26 19L28 11H36L38 19L32 24L26 19Z" stroke="#DCB658" stroke-width="2.2" stroke-linejoin="round"/>
                            <line x1="32" y1="7" x2="32" y2="11" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <line x1="20" y1="13" x2="23" y2="15" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="44" y1="13" x2="41" y2="15" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="18" y1="20" x2="22" y2="20" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="46" y1="20" x2="42" y2="20" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <line x1="32" y1="24" x2="32" y2="48" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                            <rect x="28" y="48" width="8" height="3" rx="1" fill="#DCB658"/>
                            <line x1="12" y1="55" x2="52" y2="55" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <path d="M14 55L17 50L20 55M22 55L25 50L28 55M36 55L39 50L42 55M44 55L47 50L50 55" stroke="#DCB658" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">Paved Internal Paths with Lighting</span>
                </div>

                <!-- Feature 4: Landscaped Courts & Lawns -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 14L14 26H18L12 36H20L15 45H29L24 36H32L26 26H30L22 14Z" stroke="#DCB658" stroke-width="2.2" stroke-linejoin="round"/>
                            <line x1="22" y1="45" x2="22" y2="52" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                            <path d="M43 18C40 18 38 20 37 23C34 23 32 26 33 29C31 31 31 35 33 37C33 41 37 44 42 44C47 44 51 40 51 36C54 34 54 29 52 26C52 21 48 18 43 18Z" stroke="#DCB658" stroke-width="2.2" stroke-linejoin="round"/>
                            <line x1="43" y1="44" x2="43" y2="52" stroke="#DCB658" stroke-width="2.5" stroke-linecap="round"/>
                            <path d="M10 52C16 50 24 54 32 51C40 48 48 53 54 51" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <path d="M14 57C22 55 30 58 38 56C44 54 50 57 52 56" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">Landscaped Courts & Lawns</span>
                </div>

                <!-- Feature 5: Free Parking -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="27" y="10" width="10" height="13" rx="2" stroke="#DCB658" stroke-width="2"/>
                            <path d="M30 14H33C34.5 14 35 15 35 16.5C35 18 34.5 19 33 19H30V21" stroke="#DCB658" stroke-width="1.8" stroke-linecap="round"/>
                            <path d="M10 26V52H14" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <path d="M54 26V52H50" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <line x1="32" y1="23" x2="32" y2="28" stroke="#DCB658" stroke-width="2"/>
                            <path d="M22 34C22 30 25 28 32 28C39 28 42 30 42 34L45 40V49H42V46H22V49H19V40L22 34Z" stroke="#DCB658" stroke-width="2.2" stroke-linejoin="round"/>
                            <path d="M23 35L25 31H39L41 35H23Z" stroke="#DCB658" stroke-width="1.8" stroke-linejoin="round"/>
                            <circle cx="23" cy="40" r="1.5" fill="#DCB658"/>
                            <circle cx="41" cy="40" r="1.5" fill="#DCB658"/>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">Free Parking</span>
                </div>

                <!-- Feature 6: 24-hours Water Supply -->
                <div class="res-salient-strap-item">
                    <div class="res-salient-strap-icon">
                        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M32 10C42 10 50 17 52 26" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <path d="M54 22L52 26L47 24" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 32C12 21 21 12 32 10" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round"/>
                            <path d="M32 18C32 18 24 28 24 33C24 37.4 27.6 41 32 41C36.4 41 40 37.4 40 33C40 28 32 18 32 18Z" stroke="#DCB658" stroke-width="2.2" stroke-linejoin="round"/>
                            <path d="M18 43C22 41 28 45 34 43C40 41 46 44 48 43" stroke="#DCB658" stroke-width="2" stroke-linecap="round"/>
                            <path d="M22 48C26 46 32 50 38 48" stroke="#DCB658" stroke-width="1.8" stroke-linecap="round"/>
                            <text x="39" y="56" font-family="'Manrope', sans-serif" font-size="13" font-weight="800" fill="#DCB658">24</text>
                        </svg>
                    </div>
                    <span class="res-salient-strap-title">24-hours Water Supply</span>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         4. FULL-WIDTH RESIDENCE GALLERY SHOWCASE (BHK-WISE GALLERY)
    ========================================================= -->
    <section class="res-gallery-section" id="residence-gallery">
        <div class="res-gallery-container">
            <div class="res-gallery-header">
                <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.14em; color: #a37d38; margin-bottom: 0.4rem; display: block;">Curated Visuals</span>
                <h2 class="res-section-heading" style="margin-bottom: 0.2rem;"><?php echo e($residence->name ?? 'Residence'); ?> Visual Showcase</h2>
                <span class="res-heading-line center"></span>
                <p class="res-section-sub" style="font-size: 0.95rem;">Explore high-definition indoor spatial layouts, luxury sundeck balconies, architectural details, and finishes for <?php echo e($residence->name ?? 'this residence'); ?>.</p>
            </div>

            <!-- Gallery Grid (BHK Specific) -->
            <div class="res-gallery-grid" id="galleryGrid">
                <?php if(!empty($galleries) && count($galleries) > 0): ?>
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $imgUrl = !empty($gItem->image) ? (str_starts_with($gItem->image, 'http') || str_starts_with($gItem->image, '/') ? $gItem->image : asset($gItem->image)) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg');
                            $photoTitle = !empty($gItem->title) && $gItem->title !== '-' ? $gItem->title : ($residence->name ?? 'The Ulhas Vilas');
                            $photoDesc = !empty($gItem->description) ? $gItem->description : '';
                            $catTag = !empty($residence->category_name) ? strtoupper($residence->category_name) : 'RESIDENCE';
                        ?>
                        <div class="res-gallery-item" data-title="<?php echo e($photoTitle); ?>" data-desc="<?php echo e($photoDesc); ?>" data-category="<?php echo e($catTag); ?>" onclick="openGalleryItemLightbox(this)">
                            <img src="<?php echo e($imgUrl); ?>" alt="<?php echo e($photoTitle); ?>" loading="lazy">
                            <div class="res-gallery-overlay">
                                <div class="res-gallery-info">
                                    <h4 class="res-gallery-title"><?php echo e($photoTitle); ?></h4>
                                    <?php if(!empty($gItem->description)): ?>
                                        <p class="res-gallery-desc" style="font-size: 0.8rem; color: rgba(255,255,255,0.85); margin: 0.2rem 0 0;"><?php echo e($gItem->description); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: #8a7a58;">
                        <p>No gallery photographs uploaded yet for this residence.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- =========================================================
         5. FULL-WIDTH BHK PLANS CAROUSEL SECTION (ALL OTHER RESIDENCES FROM DB)
    ========================================================= -->
    <section class="bhk-carousel-section" id="other-residences">
        <!-- Background Ambient Video -->
        <video class="bhk-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.45 PM.jpeg')); ?>">
            <source src="<?php echo e(asset('Website/assets/images/Real Estate video for villa promotion. Interior Videographer in Dubai, UAE - OG Videography (1080p, h264).mp4')); ?>" type="video/mp4">
            <source src="<?php echo e(asset('Website/assets/images/2333673_Aerial_Mountainside_1920x1080.mp4')); ?>" type="video/mp4">
        </video>
        <div class="bhk-bg-overlay"></div>

        <div class="bhk-carousel-container">
            <div class="bhk-carousel-header">
                <div>
                    <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.14em; color: #e0bc6d; margin-bottom: 0.4rem; display: block;">Residence Portfolio</span>
                    <h2 class="res-section-heading" style="color: #ffffff; margin: 0 0 0.2rem 0;">Explore More Residence Plans</h2>
                    <span class="res-heading-line"></span>
                    <p style="font-size: 0.95rem; color: rgba(255,255,255,0.85); margin: 0;">Discover our curated suite of luxury 2 BHK, 3 BHK, 4 BHK, and Royal Penthouse typologies.</p>
                </div>
                <div class="bhk-carousel-nav-btns">
                    <button type="button" class="bhk-nav-btn" onclick="moveBhkCarousel(-1)" aria-label="Previous Residence">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                    </button>
                    <button type="button" class="bhk-nav-btn" onclick="moveBhkCarousel(1)" aria-label="Next Residence">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                    </button>
                </div>
            </div>

            <div class="bhk-carousel-track-wrapper">
                <div class="bhk-carousel-track" id="bhkTrack">

                    <?php if(!empty($all_residences) && count($all_residences) > 0): ?>
                        <?php $__currentLoopData = $all_residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $otherSlideImages = [];
                                if (!empty($other->image)) {
                                    if (str_starts_with(trim($other->image), '[')) {
                                        $rawImgs = json_decode($other->image, true) ?: [];
                                    } else {
                                        $rawImgs = explode(',', $other->image);
                                    }
                                    foreach ($rawImgs as $rImg) {
                                        $rImg = trim($rImg);
                                        if (!empty($rImg)) {
                                            $otherSlideImages[] = \Illuminate\Support\Str::startsWith($rImg, ['http://', 'https://', '/']) ? $rImg : asset($rImg);
                                        }
                                    }
                                }
                                if (empty($otherSlideImages)) {
                                    $otherSlideImages[] = asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.45 PM.jpeg');
                                }
                                $otherSlug = !empty($other->slug) ? $other->slug : $other->id;
                                $otherDetailUrl = url('/residence/' . $otherSlug);
                                
                                $otherPricePrefix = !empty($other->price_prefix) ? $other->price_prefix : 'From';
                                $otherPriceText = '';
                                if (!empty($other->price)) {
                                    $otherPriceText = $otherPricePrefix . ' ₹ ' . $other->price;
                                    if (!str_contains(strtolower($other->price), 'lac') && !str_contains(strtolower($other->price), 'cr')) {
                                        $otherPriceText .= ' Lacs*';
                                    } else {
                                        $otherPriceText .= '*';
                                    }
                                } else {
                                    $otherPriceText = 'Price on Request';
                                }
                            ?>
                            <div class="bhk-card" onclick="window.location.href='<?php echo e($otherDetailUrl); ?>'" style="cursor: pointer;">
                                <div class="bhk-card-img-box">
                                    <div class="bhk-image-slider">
                                        <?php $__currentLoopData = $otherSlideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e($sImg); ?>" alt="<?php echo e($other->name); ?>" class="bhk-slide-img <?php echo e($imgIdx === 0 ? 'active' : ''); ?>" loading="lazy">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <span class="bhk-card-badge"><?php echo e(strtoupper($other->category_name ?? 'RESIDENCE')); ?></span>
                                    <?php if(count($otherSlideImages) > 1): ?>
                                        <div class="bhk-slider-dots">
                                            <?php $__currentLoopData = $otherSlideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="bhk-dot <?php echo e($imgIdx === 0 ? 'active' : ''); ?>"></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="bhk-card-body">
                                    <div>
                                        <div class="bhk-card-header-row">
                                            <h3 class="bhk-card-title"><?php echo e($other->name); ?></h3>
                                            <span class="bhk-card-price"><?php echo e($otherPriceText); ?></span>
                                        </div>
                                        <div class="bhk-card-specs-row">
                                            <?php if(!empty($other->carpet_area)): ?>
                                                <span class="bhk-card-spec-tag"><?php echo e($other->carpet_area); ?></span>
                                            <?php endif; ?>
                                            <?php if(!empty($other->rooms) || !empty($other->suites)): ?>
                                                <span class="bhk-card-spec-tag"><?php echo e($other->rooms ?? $other->suites); ?></span>
                                            <?php endif; ?>
                                            <span class="bhk-card-spec-tag"><?php echo e($other->d_room ?? '1 D Room'); ?></span>
                                        </div>
                                        <p class="bhk-card-desc"><?php echo e(!empty($other->short_description) ? $other->short_description : Str::limit(strip_tags($other->description ?? ''), 95)); ?></p>
                                    </div>
                                    <a href="<?php echo e($otherDetailUrl); ?>" class="bhk-card-cta-btn" onclick="event.stopPropagation();">EXPLORE <?php echo e(strtoupper($other->name)); ?></a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div style="padding: 2rem; color: #fff; text-align: center;">
                            <p>No other residences available.</p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         6. COMMON INQUIRIES / RESIDENCE FAQS SECTION (CLEAN LUXURY WHITE UI)
    ========================================================= -->
    <section class="res-faq-clean-section" id="faq">
        <div class="res-faq-clean-container">
            <div class="res-faq-header">
                <span class="res-faq-eyebrow">COMMON INQUIRIES</span>
                <h2 class="res-faq-title">Residence FAQs</h2>
                <span class="res-heading-line center"></span>
                <p class="res-faq-subtitle">Everything you need to know before booking your luxury residence.</p>
            </div>

            <div class="res-faq-list">
                <?php if(!empty($faqs) && count($faqs) > 0): ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="res-faq-card <?php echo e($key === 0 ? 'open' : ''); ?>" id="resFaq-<?php echo e($faq->id); ?>">
                            <button type="button" class="res-faq-btn" onclick="toggleResFaq('resFaq-<?php echo e($faq->id); ?>')">
                                <span class="res-faq-question"><?php echo e($faq->question); ?></span>
                                <div class="res-faq-toggle-icon">+</div>
                            </button>
                            <div class="res-faq-body">
                                <p class="res-faq-answer"><?php echo nl2br(e($faq->answer)); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="res-faq-card open" id="resFaq-1">
                        <button type="button" class="res-faq-btn" onclick="toggleResFaq('resFaq-1')">
                            <span class="res-faq-question">What is the carpet area and layout of this residence?</span>
                            <div class="res-faq-toggle-icon">+</div>
                        </button>
                        <div class="res-faq-body">
                            <p class="res-faq-answer">The residence features an optimized carpet area engineered without wasted corridor space, including high-ceiling living zones, en-suite bathrooms, private sundecks, and bespoke designer finishes.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Lightbox Modal for Fullscreen Preview with Navigation & Captions -->
    <div id="lbModal" onclick="closeLb(event)" class="gallery-lightbox-modal">
        <!-- Close Button -->
        <button type="button" class="lb-close-btn" onclick="closeLb(event)" aria-label="Close Lightbox">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <!-- Previous Arrow Navigation Button -->
        <button type="button" class="lb-nav-btn lb-prev-btn" onclick="event.stopPropagation(); navigateLightbox(-1);" aria-label="Previous Image">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>

        <!-- Next Arrow Navigation Button -->
        <button type="button" class="lb-nav-btn lb-next-btn" onclick="event.stopPropagation(); navigateLightbox(1);" aria-label="Next Image">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>

        <!-- Center Image Container with Caption Ribbon -->
        <div class="lb-content-wrap" onclick="event.stopPropagation()">
            <div class="lb-image-container">
                <img id="lbImg" src="" alt="Full view" class="lb-main-image">
            </div>
            <!-- Bottom Details Ribbon -->
            <div class="lb-caption-bar">
                <div class="lb-caption-info">
                    <span id="lbCategory" class="lb-category-tag">RESIDENCE</span>
                    <h4 id="lbTitle" class="lb-title-text">The Ulhas Vilas</h4>
                    <p id="lbDesc" class="lb-desc-text"></p>
                </div>
                <div class="lb-counter" id="lbCounter">1 / 1</div>
            </div>
        </div>
    </div>

    <!-- =========================================================
         PAGE SCRIPTS
    ========================================================= -->
    <script>
        // ---- HERO SLIDER ----
        let heroIdx = 0;
        const heroSlides = document.querySelectorAll('.residence-hero-slide');
        const heroDots   = document.querySelectorAll('.hero-dot');
        const heroMax    = heroSlides.length - 1;

        function heroGoTo(n) {
            if (!heroSlides.length) return;
            heroSlides[heroIdx].classList.remove('active');
            if (heroDots[heroIdx]) heroDots[heroIdx].classList.remove('active');
            heroIdx = Math.max(0, Math.min(n, heroMax));
            heroSlides[heroIdx].classList.add('active');
            if (heroDots[heroIdx]) heroDots[heroIdx].classList.add('active');
            var track = document.getElementById('heroTrack');
            if (track) track.style.transform = `translateX(-${heroIdx * 100}%)`;
        }

        function heroSlide(dir) { heroGoTo(heroIdx + dir); }

        if (heroMax > 0) {
            setInterval(() => heroGoTo(heroIdx < heroMax ? heroIdx + 1 : 0), 5000);
        }

        // Touch swipe for hero slider
        (function() {
            let sx = 0;
            const t = document.getElementById('heroTrack');
            if (t) {
                t.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
                t.addEventListener('touchend', e => {
                    const dx = sx - e.changedTouches[0].clientX;
                    if (Math.abs(dx) > 40) heroSlide(dx > 0 ? 1 : -1);
                }, { passive: true });
            }
        })();

        // Click hero slides to open lightbox
        document.querySelectorAll('.residence-hero-slide').forEach((s, i) => {
            s.style.cursor = 'pointer';
            s.addEventListener('click', () => {
                openHeroItemLightbox(i);
            });
        });

        // ---- ARCHITECTURAL FLOOR PLANS FILTER ----
        function filterFloorPlans(type, btn) {
            document.querySelectorAll('.res-fp-tab-btn').forEach(b => b.classList.remove('active'));
            if (btn) btn.classList.add('active');
            
            document.querySelectorAll('.res-fp-card').forEach(card => {
                if (type === 'all' || card.getAttribute('data-fptype') === type) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // ---- UNIFIED RESIDENCE LIGHTBOX SYSTEM WITH FULL NAVIGATION & CAPTIONS ----
        var residenceLbList = [];
        var currentLbIndex = 0;

        function renderLightbox() {
            if (!residenceLbList.length) return;
            var item = residenceLbList[currentLbIndex];
            var img = document.getElementById('lbImg');
            var titleEl = document.getElementById('lbTitle');
            var descEl = document.getElementById('lbDesc');
            var catEl = document.getElementById('lbCategory');
            var counterEl = document.getElementById('lbCounter');
            var prevBtn = document.querySelector('.lb-prev-btn');
            var nextBtn = document.querySelector('.lb-next-btn');

            if (img) {
                img.style.opacity = '0.3';
                img.style.transform = 'scale(0.97)';
                
                var newImg = new Image();
                newImg.onload = function() {
                    img.src = item.src;
                    img.style.opacity = '1';
                    img.style.transform = 'scale(1)';
                };
                newImg.src = item.src;
            }

            if (titleEl) {
                titleEl.textContent = item.title || 'The Ulhas Vilas';
                titleEl.style.display = item.title ? 'block' : 'none';
            }
            if (descEl) {
                descEl.textContent = item.desc || '';
                descEl.style.display = item.desc ? 'block' : 'none';
            }
            if (catEl) {
                catEl.textContent = item.category || 'RESIDENCE';
                catEl.style.display = item.category ? 'inline-block' : 'none';
            }
            if (counterEl) {
                counterEl.textContent = (currentLbIndex + 1) + ' / ' + residenceLbList.length;
                counterEl.style.display = residenceLbList.length > 1 ? 'block' : 'none';
            }

            if (prevBtn) prevBtn.style.display = residenceLbList.length > 1 ? 'flex' : 'none';
            if (nextBtn) nextBtn.style.display = residenceLbList.length > 1 ? 'flex' : 'none';
        }

        function showLightboxModal() {
            var modal = document.getElementById('lbModal');
            if (modal) {
                modal.classList.add('active');
                modal.style.opacity = '1';
                modal.style.pointerEvents = 'auto';
                document.body.style.overflow = 'hidden';
            }
        }

        // 1. Open when clicking gallery showcase items
        window.openGalleryItemLightbox = function(itemEl) {
            var galleryItems = document.querySelectorAll('.res-gallery-item');
            residenceLbList = [];
            galleryItems.forEach(function(el) {
                if (el.style.display !== 'none') {
                    var img = el.querySelector('img');
                    if (img && img.src) {
                        residenceLbList.push({
                            src: img.src,
                            title: el.getAttribute('data-title') || (el.querySelector('.res-gallery-title') ? el.querySelector('.res-gallery-title').textContent.trim() : 'The Ulhas Vilas'),
                            desc: el.getAttribute('data-desc') || (el.querySelector('.res-gallery-desc') ? el.querySelector('.res-gallery-desc').textContent.trim() : ''),
                            category: el.getAttribute('data-category') || 'RESIDENCE',
                            el: el
                        });
                    }
                }
            });

            var foundIndex = residenceLbList.findIndex(function(it) {
                return it.el === itemEl;
            });

            currentLbIndex = foundIndex !== -1 ? foundIndex : 0;
            renderLightbox();
            showLightboxModal();
        };

        // 2. Open when clicking floor plan zoom
        window.openPlanItemLightbox = function(planImgBox) {
            var planCards = document.querySelectorAll('.res-fp-card');
            residenceLbList = [];
            planCards.forEach(function(card) {
                if (card.style.display !== 'none') {
                    var img = card.querySelector('img');
                    var titleEl = card.querySelector('.res-fp-card-title');
                    if (img && img.src) {
                        residenceLbList.push({
                            src: img.src,
                            title: card.getAttribute('data-title') || (titleEl ? titleEl.textContent.trim() : 'Layout Plan'),
                            desc: card.getAttribute('data-desc') || 'Architectural Master Plan & 3D Layout',
                            category: card.getAttribute('data-category') || 'FLOOR PLAN',
                            el: card
                        });
                    }
                }
            });

            var parentCard = planImgBox.closest ? planImgBox.closest('.res-fp-card') : planImgBox;
            var foundIndex = residenceLbList.findIndex(function(it) {
                return it.el === parentCard;
            });

            currentLbIndex = foundIndex !== -1 ? foundIndex : 0;
            renderLightbox();
            showLightboxModal();
        };

        // 3. Open when clicking hero slides or photo count button
        window.openHeroItemLightbox = function(slideIndex) {
            var slides = document.querySelectorAll('.residence-hero-slide');
            residenceLbList = [];
            slides.forEach(function(slide) {
                var img = slide.querySelector('img');
                if (img && img.src) {
                    residenceLbList.push({
                        src: img.src,
                        title: slide.getAttribute('data-title') || '<?php echo e(addslashes($residence->name ?? 'Luxury Residence')); ?>',
                        desc: slide.getAttribute('data-desc') || 'Curated Exterior & Living Perspective',
                        category: slide.getAttribute('data-category') || '<?php echo e(strtoupper($residence->category_name ?? 'RESIDENCE')); ?>',
                        el: slide
                    });
                }
            });

            currentLbIndex = (typeof slideIndex === 'number' && slideIndex >= 0 && slideIndex < residenceLbList.length) ? slideIndex : 0;
            renderLightbox();
            showLightboxModal();
        };

        // 4. Fallback openLightbox by src or element
        window.openLightbox = function(src) {
            // Check if matches a gallery item
            var galleryItems = document.querySelectorAll('.res-gallery-item');
            var matched = false;
            galleryItems.forEach(function(el) {
                var img = el.querySelector('img');
                if (img && (img.src === src || img.getAttribute('src') === src)) {
                    openGalleryItemLightbox(el);
                    matched = true;
                }
            });
            if (matched) return;

            // Check if matches a floor plan
            var planCards = document.querySelectorAll('.res-fp-card');
            planCards.forEach(function(card) {
                var img = card.querySelector('img');
                if (img && (img.src === src || img.getAttribute('src') === src)) {
                    openPlanItemLightbox(card);
                    matched = true;
                }
            });
            if (matched) return;

            // Check hero slides
            var heroSlides = document.querySelectorAll('.residence-hero-slide');
            heroSlides.forEach(function(slide, sIdx) {
                var img = slide.querySelector('img');
                if (img && (img.src === src || img.getAttribute('src') === src)) {
                    openHeroItemLightbox(sIdx);
                    matched = true;
                }
            });
            if (matched) return;

            // Single item fallback
            residenceLbList = [{
                src: src,
                title: '<?php echo e(addslashes($residence->name ?? 'The Ulhas Vilas')); ?>',
                desc: '',
                category: '<?php echo e(strtoupper($residence->category_name ?? 'RESIDENCE')); ?>'
            }];
            currentLbIndex = 0;
            renderLightbox();
            showLightboxModal();
        };

        window.navigateLightbox = function(direction) {
            if (!residenceLbList.length) return;
            currentLbIndex = (currentLbIndex + direction + residenceLbList.length) % residenceLbList.length;
            renderLightbox();
        };
        window.navigateLb = window.navigateLightbox;

        window.closeLb = function(e) {
            var modal = document.getElementById('lbModal');
            if (!modal) return;
            modal.classList.remove('active');
            modal.style.opacity = '0';
            modal.style.pointerEvents = 'none';
            document.body.style.overflow = '';
        };

        // Keyboard Navigation (Escape, ArrowLeft, ArrowRight)
        document.addEventListener('keydown', function(e) {
            const m = document.getElementById('lbModal');
            if (!m || (m.style.opacity !== '1' && !m.classList.contains('active'))) return;
            if (e.key === 'Escape') closeLb();
            else if (e.key === 'ArrowLeft') navigateLightbox(-1);
            else if (e.key === 'ArrowRight') navigateLightbox(1);
        });

        // Touch swipe gestures for lightbox modal
        (function() {
            var touchStartX = 0;
            var touchEndX = 0;
            var modal = document.getElementById('lbModal');
            if (modal) {
                modal.addEventListener('touchstart', function(e) {
                    touchStartX = e.changedTouches[0].screenX;
                }, { passive: true });
                modal.addEventListener('touchend', function(e) {
                    touchEndX = e.changedTouches[0].screenX;
                    if (touchStartX - touchEndX > 50) {
                        navigateLightbox(1); // Swipe left -> Next
                    } else if (touchEndX - touchStartX > 50) {
                        navigateLightbox(-1); // Swipe right -> Prev
                    }
                }, { passive: true });
            }
        })();



        // ---- OTHER BHK CAROUSEL & MULTI-IMAGE AUTO-SLIDER ----
        let bhkIdx = 0;
        function moveBhkCarousel(dir) {
            const track = document.getElementById('bhkTrack');
            const cards = document.querySelectorAll('.bhk-card');
            if (!track || !cards.length) return;
            const cardWidth = cards[0].offsetWidth + 24;
            const visibleCards = window.innerWidth <= 640 ? 1 : (window.innerWidth <= 1024 ? 2 : 3);
            const maxIdx = Math.max(0, cards.length - visibleCards);
            bhkIdx = Math.max(0, Math.min(bhkIdx + dir, maxIdx));
            track.style.transform = `translateX(-${bhkIdx * cardWidth}px)`;
        }

        document.addEventListener('DOMContentLoaded', function() {
            // BHK Cards Multi-Image Auto-Slider Loop
            const bhkCards = document.querySelectorAll('.bhk-card');
            bhkCards.forEach(card => {
                const slides = card.querySelectorAll('.bhk-slide-img');
                const dots = card.querySelectorAll('.bhk-slider-dots .bhk-dot');
                if (slides.length <= 1) return;

                let curIdx = 0;
                let sliderTimer = null;

                function changeBhkSlide(toIdx) {
                    slides.forEach((s, i) => {
                        s.classList.toggle('active', i === toIdx);
                    });
                    dots.forEach((d, i) => {
                        d.classList.toggle('active', i === toIdx);
                    });
                    curIdx = toIdx;
                }

                function nextSlide() {
                    const next = (curIdx + 1) % slides.length;
                    changeBhkSlide(next);
                }

                sliderTimer = setInterval(nextSlide, 3500);

                dots.forEach((dot, dotIdx) => {
                    dot.addEventListener('click', function(e) {
                        e.stopPropagation();
                        clearInterval(sliderTimer);
                        changeBhkSlide(dotIdx);
                        sliderTimer = setInterval(nextSlide, 3500);
                    });
                });
            });
        });

        // ---- RESIDENCE FAQS ACCORDION ----
        function toggleResFaq(id) {
            const card = document.getElementById(id);
            if (card) {
                const isOpen = card.classList.contains('open');
                document.querySelectorAll('.res-faq-card').forEach(c => c.classList.remove('open'));
                if (!isOpen) card.classList.add('open');
            }
        }

        // ---- SIDEBAR ENQUIRY FORM SUBMISSION (WITH 10-DIGIT VALIDATION & AJAX) ----
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('resBookingForm');
            const phoneInput = document.getElementById('resPhoneInput');
            const phoneError = document.getElementById('resPhoneError');
            const submitBtn = document.getElementById('resSubmitBtn');

            if (phoneInput && phoneError) {
                phoneInput.addEventListener('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
                    if (this.value.length === 10) {
                        phoneError.style.display = 'none';
                        this.style.borderColor = '';
                    } else if (this.value.length > 0) {
                        phoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                        phoneError.style.display = 'block';
                    } else {
                        phoneError.style.display = 'none';
                    }
                });

                phoneInput.addEventListener('blur', function() {
                    if (this.value.length > 0 && this.value.length !== 10) {
                        phoneError.textContent = 'Mobile number must be exactly 10 digits.';
                        phoneError.style.display = 'block';
                    }
                });
            }

            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();

                    if (phoneInput && phoneInput.value.trim().length !== 10) {
                        if (phoneError) {
                            phoneError.textContent = 'Mobile number must be exactly 10 digits.';
                            phoneError.style.display = 'block';
                        }
                        phoneInput.focus();
                        return;
                    }

                    const origBtnText = submitBtn ? submitBtn.innerHTML : '';
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.innerHTML = '<span class="form-btn-spinner"></span> SUBMITTING...';
                    }

                    const formData = new FormData(form);

                    fetch("<?php echo e(url('/contact_submit')); ?>", {
                        method: 'POST',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest',
                            'Accept': 'application/json'
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            try {
                                sessionStorage.setItem('allow_thankyou', 'true');
                            } catch(e) {}
                            if (submitBtn) submitBtn.innerHTML = 'REDIRECTING...';
                            window.location.href = data.redirect_url || "<?php echo e(url('/thank-you')); ?>";
                        } else {
                            alert(data.message || 'An error occurred. Please try again.');
                            if (submitBtn) {
                                submitBtn.disabled = false;
                                submitBtn.innerHTML = origBtnText;
                            }
                        }
                    })
                    .catch(err => {
                        console.error('Error:', err);
                        alert('Submission failed. Please check your network and try again.');
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.innerHTML = origBtnText;
                        }
                    });
                });
            }
        });

        // Ensure all ambient background videos autoplay properly
        document.addEventListener('DOMContentLoaded', function() {
            var bgVideos = document.querySelectorAll('.res-salient-bg-video, .bhk-bg-video');
            bgVideos.forEach(function(v) {
                v.muted = true;
                var promise = v.play();
                if (promise !== undefined) {
                    promise.catch(function() {
                        document.body.addEventListener('touchstart', function() { v.play(); }, { once: true });
                        document.body.addEventListener('click', function() { v.play(); }, { once: true });
                    });
                }
            });
        });
    </script>

    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\DOWNLOADS\ulhas-vilas\ulhas-vilas.partnersindia.com\resources\views/Website/residence_detail.blade.php ENDPATH**/ ?>