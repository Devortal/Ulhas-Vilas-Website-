<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Site Icon / Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('Website/assets/images/ulhas-logo.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('Website/assets/images/ulhas-logo.png')); ?>">

   

<?php
    // 🔄 Auto-Detect SEO if not passed by controller
    if (empty($seo) || !is_array($seo)) {
        $curPath = trim(request()->path(), '/');
        $resolvedKey = empty($curPath) || $curPath === '/' ? 'home' : explode('/', $curPath)[0];
        $possibleKeys = [$resolvedKey];
        if (str_starts_with($resolvedKey, 'residence')) $possibleKeys = ['residences', 'residence'];
        if (str_starts_with($resolvedKey, 'about')) $possibleKeys = ['about', 'about_us'];
        if (str_starts_with($resolvedKey, 'amenit')) $possibleKeys = ['amenities', 'amenity'];
        if (str_starts_with($resolvedKey, 'gallery')) $possibleKeys = ['gallery', 'galleries'];
        if (str_starts_with($resolvedKey, 'blog')) $possibleKeys = ['blogs', 'blog'];
        if (str_starts_with($resolvedKey, 'faq')) $possibleKeys = ['faqs', 'faq'];
        if (str_starts_with($resolvedKey, 'contact')) $possibleKeys = ['contact', 'contact_us'];

        $dbSeo = DB::table('page_seos')->whereIn('page_key', $possibleKeys)->first();
        $seo = [
            'meta_title' => (!empty($dbSeo) && !empty($dbSeo->meta_title)) ? $dbSeo->meta_title : 'The Ulhas Vilas — Architectural Refinement & Luxury Estates',
            'meta_description' => (!empty($dbSeo) && !empty($dbSeo->meta_description)) ? $dbSeo->meta_description : 'Discover The Ulhas Vilas in Himachal Pradesh. Luxury architectural estates, 1-4 BHK bespoke villas, private suites, and world-class wellness.',
            'meta_keywords' => (!empty($dbSeo) && !empty($dbSeo->meta_keywords)) ? $dbSeo->meta_keywords : 'The Ulhas Vilas, luxury villas, Himachal Pradesh real estate, luxury estates, mountain villas, holiday homes',
            'og_image' => (!empty($dbSeo) && !empty($dbSeo->og_image)) ? (filter_var($dbSeo->og_image, FILTER_VALIDATE_URL) ? $dbSeo->og_image : asset($dbSeo->og_image)) : asset('Admin/assets/images/ulhas_logo.png'),
            'custom_script' => (!empty($dbSeo) && !empty($dbSeo->custom_script)) ? $dbSeo->custom_script : '',
        ];
    }
?>

    <!-- 1️⃣ Meta Title -->
    <title><?php echo e($seo['meta_title']); ?></title>

    <!-- 2️⃣ Meta Description -->
    <meta name="description" content="<?php echo e($seo['meta_description']); ?>">

    <!-- 3️⃣ Meta Keywords -->
    <?php if(!empty($seo['meta_keywords'])): ?>
    <meta name="keywords" content="<?php echo e($seo['meta_keywords']); ?>">
    <?php endif; ?>

     <!-- 5️⃣ Custom Script / Google Tag / Meta Pixel / Schema Markup -->
    <?php if(!empty($seo['custom_script'])): ?>
        <?php echo $seo['custom_script']; ?>

    <?php endif; ?>

    <!-- 4️⃣ Open Graph / WhatsApp / Facebook / Twitter Share Preview Image -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo e($seo['meta_title']); ?>">
    <meta property="og:description" content="<?php echo e($seo['meta_description']); ?>">
    <meta property="og:image" content="<?php echo e($seo['og_image']); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($seo['meta_title']); ?>">
    <meta name="twitter:description" content="<?php echo e($seo['meta_description']); ?>">
    <meta name="twitter:image" content="<?php echo e($seo['og_image']); ?>">


<!-- Preconnect to CDNs for Fast Asset Resolution -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700&family=Marcellus&display=swap" rel="stylesheet">

<!-- Leaflet CSS for Luxury Interactive Map -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- External Assets -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<!-- All Website Custom CSS Styles -->
<style>

:root {
  --font-heading: 'Marcellus', serif;
  --font-body: 'Manrope', sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  --color-bg-dark: #0a0c0e;
  --color-bg-section: #ffffff;
  --color-text-main: #ffffff;
  --color-text-dark: #0a0c0e;
  --color-text-muted: rgba(255, 255, 255, 0.85);
  --color-text-subtle: rgba(255, 255, 255, 0.65);
  --glass-bg: rgba(18, 22, 26, 0.35);
  --glass-border: rgba(255, 255, 255, 0.2);
  --glass-hover: rgba(255, 255, 255, 0.18);
  --color-accent-amber: #DCB658;
}

/* Universal Smooth Video Optimization for Safari/Chrome/Firefox */
video {
  background-color: transparent !important;
  content-visibility: auto;
}

.form-btn-spinner {
  display: inline-block;
  width: 14px;
  height: 14px;
  border: 2.2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: btnSpin 0.7s linear infinite;
  vertical-align: middle;
  margin-right: 8px;
}

@keyframes btnSpin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.field-validation-error {
  display: block;
  color: #ef4444 !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  margin-top: 5px !important;
  line-height: 1.4 !important;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
  font-size: 16px;
  background-color: #050607;
}

body {
  font-family: var(--font-body);
  background-color: #050607;
  color: var(--color-text-main);
  line-height: 1.6;
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* =========================================
   GLOBAL BUTTON STYLES (MARCELLUS FONT & 32PX BORDER RADIUS & NO UNDERLINE)
   ========================================= */
button,
a.nav-btn,
.nav-btn,
.send-msg-btn,
.gallery-cta-btn,
.gallery-tab-btn,
.villa-tab-btn,
.amenity-tab-btn,
.res-gallery-tab-btn,
.enquire-btn,
.contact-btn,
.hero-btn,
.cta-btn,
.blog-read-btn,
.blog-card-btn,
.blog-author-btn,
.footer-newsletter-btn,
input[type="submit"],
button[type="submit"] {
  font-family: 'Marcellus', serif !important;
  border-radius: 32px !important;
  text-decoration: none !important;
}

/* =========================================
   HERO SECTION STYLES
   ========================================= */
.hero-section {
  position: relative;
  width: 100%;
  height: 100vh;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  overflow: hidden;
  background-color: #050607;
}

/* Background Video Player & Fallback Image */
.hero-video-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  overflow: hidden;
  background-color: #080a0d;
}

.hero-bg-fallback-img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center center;
  z-index: 1;
  transform: scale(1.02);
  transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 1.2s ease;
  pointer-events: none;
}

.hero-video {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  min-width: 100%;
  min-height: 100%;
  object-fit: cover;
  z-index: 2;
  transform: scale(1.02);
  opacity: 1;
  filter: brightness(1.08) contrast(1.05) saturate(1.04);
  transition: opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 1.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.hero-video.video-loaded,
.hero-video.video-playing {
  opacity: 1;
}

/* Dark Gradient Overlay for Text Readability & High Video Opacity */
.hero-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 3;
  background: linear-gradient(
    90deg,
    rgba(6, 9, 13, 0.65) 0%,
    rgba(6, 9, 13, 0.38) 45%,
    rgba(6, 9, 13, 0.10) 80%,
    rgba(6, 9, 13, 0.05) 100%
  ),
  linear-gradient(
    180deg,
    rgba(6, 9, 13, 0.40) 0%,
    rgba(6, 9, 13, 0.0) 35%,
    rgba(6, 9, 13, 0.15) 70%,
    rgba(6, 9, 13, 0.65) 100%
  );
  pointer-events: none;
}

/* Glass Header / Navigation - STATIC TOP STATE (Default at Top of Page) */
.hero-header {
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  max-width: 100%;
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1.25rem;
  padding: 1.15rem 4rem;
  margin: 0;
  box-sizing: border-box;
  border-radius: 0;
  background: linear-gradient(180deg, rgba(7, 12, 18, 0.75) 0%, rgba(7, 12, 18, 0) 100%) !important;
  border: none !important;
  border-bottom: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  box-shadow: none !important;
  transition: width 0.45s cubic-bezier(0.16, 1, 0.3, 1),
              top 0.45s cubic-bezier(0.16, 1, 0.3, 1),
              padding 0.45s cubic-bezier(0.16, 1, 0.3, 1),
              border-radius 0.45s cubic-bezier(0.16, 1, 0.3, 1),
              background 0.45s ease,
              border 0.45s ease,
              box-shadow 0.45s ease,
              backdrop-filter 0.45s ease;
  will-change: width, top, padding, border-radius, background, box-shadow;
}

/* Scrolled Floating Pill Bar State with High Clarity Glass Effect */
.hero-header.scrolled {
  top: 0.75rem;
  left: 50%;
  right: auto;
  transform: translateX(-50%);
  width: min(1340px, 94%);
  max-width: 1340px;
  padding: 0.55rem 1.8rem;
  border-radius: 9999px;
  background: rgba(10, 13, 18, 0.95) !important;
  border: 1px solid rgba(255, 255, 255, 0.22) !important;
  backdrop-filter: blur(24px) saturate(190%) !important;
  -webkit-backdrop-filter: blur(24px) saturate(190%) !important;
  box-shadow: 0 20px 48px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.25) !important;
}

.hero-header .brand-mark {
  width: 52px;
  height: 52px;
  transition: width 0.4s ease, height 0.4s ease;
}

.hero-header.scrolled .brand-mark {
  width: 44px;
  height: 44px;
}

.hero-header .brand-title {
  font-size: 1.45rem;
  transition: font-size 0.4s ease;
}

.hero-header.scrolled .brand-title {
  font-size: 1.3rem;
}

.hero-header .brand-subtitle {
  font-size: 0.58rem;
  margin-top: 4px;
  opacity: 0.9;
  transition: font-size 0.4s ease, opacity 0.4s ease, margin 0.4s ease;
}

.hero-header.scrolled .brand-subtitle {
  font-size: 0.52rem;
  margin-top: 1px;
  opacity: 0.85;
}

.hero-header .nav-link {
  transition: all 0.3s ease;
}

.hero-header.scrolled .nav-link {
  font-size: 0.7rem;
}

.hero-header.scrolled .nav-btn {
  padding: 0.6rem 1.4rem;
  font-size: 0.76rem;
}

.brand-logo {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-shrink: 0;
  text-decoration: none;
  color: var(--color-text-main);
  text-shadow: none;
  margin: 0;
  padding: 0;
}

.brand-mark {
  width: 52px;
  height: 52px;
  object-fit: contain;
  display: block;
}

.brand-copy {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.brand-title {
  font-family: var(--font-heading);
  font-size: 1.45rem;
  letter-spacing: 0;
  text-transform: none;
  font-weight: 400;
  line-height: 1.1;
  white-space: nowrap;
}

.brand-subtitle {
  font-family: var(--font-body);
  font-size: 0.58rem;
  letter-spacing: 0.02em;
  text-transform: none;
  color: rgba(255, 255, 255, 0.9);
  margin-top: 2px;
  font-weight: 700;
  white-space: nowrap;
}

.nav-container {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0;
  padding: 0;
}

.nav-links {
  display: flex;
  gap: 0.45rem 1.7rem;
  align-items: center;
  justify-content: center;
  list-style: none;
  background: transparent;
  backdrop-filter: none;
  -webkit-backdrop-filter: none;
  padding: 0 !important;
  margin: 0 !important;
  border-radius: 0;
  border: 0;
  max-width: 940px;
}

.nav-links li {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin: 0 !important;
  padding: 0 !important;
}

.nav-link {
  color: var(--color-text-muted);
  text-decoration: none;
  font-family: var(--font-heading);
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  transition: color 0.3s ease, text-shadow 0.3s ease;
  letter-spacing: 0.09em;
  white-space: nowrap;
  position: relative;
  padding: 0.3rem 0;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.nav-link:hover,
.nav-link.active {
  color: #DCB658;
  text-shadow: 0 0 14px rgba(220, 182, 88, 0.32);
  transform: none;
}

.nav-link::before {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 0;
  height: 2px;
  border-radius: 2px;
  background: #DCB658;
  transition: width 0.3s ease;
}

.nav-link:hover::before,
.nav-link.active::before {
  width: 100%;
}

.nav-dropdown {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin: 0 !important;
  padding: 0 !important;
}

.nav-dropdown-toggle {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.35rem;
  border: 0;
  cursor: pointer;
  background: transparent !important;
  box-shadow: none !important;
  min-width: 0 !important;
  min-height: 0 !important;
  padding: 0.3rem 0 !important;
  border-radius: 0 !important;
  color: var(--color-text-muted) !important;
  font-family: var(--font-heading) !important;
  font-size: 0.72rem !important;
  font-weight: 700 !important;
  letter-spacing: 0.09em !important;
  text-transform: uppercase !important;
  line-height: 1 !important;
  text-decoration: none;
}

.nav-dropdown-toggle:hover,
.nav-dropdown-toggle.active {
  color: #DCB658 !important;
  text-shadow: 0 0 14px rgba(220, 182, 88, 0.32);
}

.header-cta {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin: 0;
  padding: 0;
}

.header-cta .nav-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
}

.nav-dropdown-toggle::after {
  content: '';
  display: inline-block;
  width: 5px;
  height: 5px;
  border-right: 1.5px solid currentColor;
  border-bottom: 1.5px solid currentColor;
  transform: rotate(45deg);
  margin-left: 2px;
  margin-bottom: 2px;
  transition: transform 0.3s ease;
}

.nav-dropdown:hover .nav-dropdown-toggle::after,
.nav-dropdown:focus-within .nav-dropdown-toggle::after {
  transform: rotate(225deg);
  margin-bottom: -2px;
}

.nav-dropdown-menu {
  position: absolute;
  top: calc(100% + 0.8rem);
  left: 50%;
  z-index: 9999;
  min-width: 250px;
  width: max-content;
  max-width: 340px;
  padding: 0.6rem;
  margin: 0;
  list-style: none;
  border-radius: 12px;
  background: #11141a !important; /* Solid non-transparent luxury dark background */
  border: 1px solid rgba(220, 182, 88, 0.35) !important;
  box-shadow: 0 18px 45px rgba(0, 0, 0, 0.9) !important;
  opacity: 0;
  visibility: hidden;
  transform: translate(-50%, 8px);
  transition: opacity 0.28s ease, visibility 0.28s ease, transform 0.28s ease;
}

.nav-dropdown-menu li {
  width: 100%;
  display: block;
}

.nav-dropdown:hover .nav-dropdown-menu,
.nav-dropdown:focus-within .nav-dropdown-menu {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, 0);
}

.nav-dropdown-link {
  display: block;
  width: 100%;
  box-sizing: border-box;
  padding: 0.65rem 0.9rem;
  border-radius: 8px;
  color: #f1f5f9 !important;
  text-decoration: none;
  font-family: var(--font-heading);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  line-height: 1.35;
  text-transform: uppercase;
  transition: all 0.22s ease;
  white-space: nowrap;
}

.nav-dropdown-link:hover,
.nav-dropdown-link:focus {
  color: #07090b !important;
  background: #DCB658 !important;
  outline: none;
}

.header-cta {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.nav-btn {
  font-family: var(--font-body);
  font-size: 0.82rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  padding: 0.7rem 1.6rem;
  border-radius: 9999px;
  text-decoration: none;
  color: var(--color-text-main);
  background: rgba(129, 204, 202, 0.25);
  border: 1px solid rgba(129, 204, 202, 0.5);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 4px 16px rgba(129, 204, 202, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.2);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.nav-btn:hover {
  background: rgba(129, 204, 202, 0.45);
  border-color: rgba(129, 204, 202, 0.8);
  transform: translateY(-2px);
  box-shadow: 0 10px 28px rgba(129, 204, 202, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.25);
}

/* Sound Control Widget */
.sound-toggle-btn {
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
  backdrop-filter: blur(10px);
  color: var(--color-text-main);
  width: 42px;
  height: 42px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.sound-toggle-btn:hover {
  background: rgba(255, 255, 255, 0.25);
  transform: scale(1.08);
}

.sound-toggle-btn svg {
  width: 18px;
  height: 18px;
  fill: currentColor;
}

/* Main Hero Body Content */
.hero-body {
  position: relative;
  z-index: 10;
  padding: 6rem 0 2rem 0;
  max-width: 1340px;
  width: 100%;
  margin: auto auto 0 auto;
  transform: translateY(-3rem);
  box-sizing: border-box;
}

/* Title Slider Container */
.title-slider-container {
  min-height: 200px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  position: relative;
}

.title-slide {
  opacity: 0;
  transform: translateY(35px) scale(0.97);
  filter: blur(10px);
  transition: opacity 0.85s cubic-bezier(0.16, 1, 0.3, 1),
    transform 0.85s cubic-bezier(0.16, 1, 0.3, 1),
    filter 0.85s cubic-bezier(0.16, 1, 0.3, 1);
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  pointer-events: none;
}

.title-slide.active {
  opacity: 1;
  transform: translateY(0) scale(1);
  filter: blur(0px);
  position: relative;
  pointer-events: auto;
}

.title-slide.exit {
  opacity: 0;
  transform: translateY(-30px) scale(0.97);
  filter: blur(10px);
}

/* Marcellus Regular Font for Titles */
.hero-title {
  font-family: var(--font-heading);
  font-size: 54px;
  font-weight: 500;
  line-height: 1.18;
  letter-spacing: -0.01em;
  color: var(--color-text-main);
  margin-bottom: 1.2rem;
  max-width: 820px;
  text-shadow: 0 4px 24px rgba(0, 0, 0, 0.6);
  text-transform: capitalize;
}

@media (min-width: 769px) {
  .hero-title {
    font-size: 54px !important;
  }
}

.hero-highlight {
  color: #DCB658;
}

/* Manrope Font for Body Copy */
.hero-subtitle {
  font-family: var(--font-body);
  font-size: clamp(0.95rem, 1.15vw, 1.1rem);
  font-weight: 400;
  line-height: 1.6;
  color: var(--color-text-muted);
  max-width: 580px;
  margin-bottom: 2rem;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
}

/* Action Buttons Container */
.hero-actions {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  margin-top: 0.5rem;
}

/* Primary Button (White Pill) */
.btn-primary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  min-width: 174px;
  min-height: 48px;
  background-color: #DCB658;
  color: #0c0e10;
  font-family: var(--font-heading);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-size: 0.88rem;
  padding: 0.75rem 1.8rem;
  border-radius: 9999px;
  text-decoration: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  border: 1px solid #DCB658;
}

.btn-primary:hover {
  background-color: #ffffff;
  border-color: #ffffff;
  transform: translateY(-3px);
  box-shadow: 0 15px 35px rgba(220, 182, 88, 0.3);
}

.btn-primary .btn-arrow {
  display: inline-block;
  transition: transform 0.3s ease;
  font-size: 1.1rem;
}

.btn-primary:hover .btn-arrow {
  transform: translateX(4px);
}

/* Secondary Button (Glass Pill) */
.btn-secondary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 174px;
  min-height: 48px;
  background: rgba(18, 22, 26, 0.5);
  color: #ffffff;
  font-family: var(--font-heading);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  font-size: 0.88rem;
  padding: 0.75rem 1.8rem;
  border-radius: 9999px;
  text-decoration: none;
  border: 1px solid rgba(255, 255, 255, 0.3);
  backdrop-filter: blur(12px);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.22);
  border-color: rgba(255, 255, 255, 0.5);
  transform: translateY(-3px);
}

/* Ultra-Luxury Architectural Specs Bar Below Buttons */
.hero-specs-bar {
  display: inline-flex;
  align-items: center;
  gap: 1.8rem;
  margin-top: 2rem;
  padding: 0.8rem 1.8rem;
  background: rgba(18, 22, 26, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.18);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-radius: 12px;
}

.hero-specs-bar--mobile {
  display: none;
}

.spec-item {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
}

.spec-value {
  font-family: var(--font-heading);
  font-size: 1.45rem;
  font-weight: 400;
  color: #ffffff;
  letter-spacing: 0.02em;
  line-height: 1.1;
}

.spec-label {
  font-family: var(--font-body);
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.14em;
  color: rgba(255, 255, 255, 0.75);
  margin-top: 0.15rem;
}

.spec-divider {
  width: 1px;
  height: 24px;
  background: rgba(255, 255, 255, 0.2);
}

/* Title Carousel Progress Bar & Timer */
.carousel-controls {
  display: flex;
  align-items: center;
  gap: 1.2rem;
  margin-top: 2rem;
}

.progress-bar-container {
  width: 160px;
  height: 2px;
  background: rgba(255, 255, 255, 0.25);
  border-radius: 2px;
  overflow: hidden;
  position: relative;
}

.progress-bar-fill {
  height: 100%;
  width: 0%;
  background-color: #ffffff;
  border-radius: 2px;
  transition: width 0.1s linear;
}

.title-counter {
  font-family: var(--font-body);
  font-size: 0.85rem;
  font-weight: 500;
  letter-spacing: 0.1em;
  color: var(--color-text-muted);
}

/* Right Side Floating Navigation Arrows */
.hero-floating-arrows {
  position: absolute;
  right: 5%;
  bottom: 18%;
  z-index: 20;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.hero-floating-arrows .nav-arrow-btn {
  background: #ffffff;
  border: 1px solid rgba(129, 204, 202, 0.75);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: #0a0c0e;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.8);
}

.hero-floating-arrows .nav-arrow-btn span {
  font-size: 1.2rem;
  line-height: 1;
  transition: transform 0.3s ease;
}

.hero-floating-arrows .nav-arrow-btn:hover {
  background: #81CCCA;
  border-color: #81CCCA;
  transform: scale(1.1);
  box-shadow: 0 12px 30px rgba(129, 204, 202, 0.45);
}

.hero-floating-arrows .prev-title-btn:hover span {
  transform: translateX(-3px);
}

.hero-floating-arrows .next-title-btn:hover span {
  transform: translateX(3px);
}

/* Bottom Bar Section */
.hero-footer {
  position: relative;
  z-index: 10;
  width: 100%;
  border-top: 1px solid rgba(255, 255, 255, 0.15);
  background: linear-gradient(180deg, rgba(10, 12, 14, 0) 0%, rgba(10, 12, 14, 0.75) 100%);
}

.hero-footer-inner {
  max-width: 1340px;
  width: 100%;
  margin: 0 auto;
  padding: 2rem 0 2.5rem 0;
  display: grid;
  grid-template-columns: 1.2fr 2fr;
  gap: 3rem;
  align-items: flex-end;
  box-sizing: border-box;
}

.footer-description {
  font-family: var(--font-body);
  font-size: 0.95rem;
  line-height: 1.6;
  color: var(--color-text-muted);
  max-width: 480px;
  font-weight: 400;
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

/* Clean Editorial Stats Container (Matching Image 2 Style) */
.stats-grid {
  display: flex;
  justify-content: flex-end;
  gap: 2.2rem;
}

.stat-item {
  display: flex;
  flex-direction: column;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.stat-item:hover {
  transform: translateY(-3px);
}

.stat-number {
  font-family: var(--font-heading);
  font-size: clamp(1.45rem, 2vw, 1.9rem);
  font-weight: 400;
  line-height: 1.15;
  color: #ffffff;
  margin-bottom: 0.2rem;
  letter-spacing: 0.03em;
  text-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
  text-transform: none;
}

.stat-item:hover .stat-number {
  color: var(--color-accent-amber);
  text-shadow: 0 0 15px rgba(220, 182, 88, 0.5);
}

.stat-label {
  font-family: var(--font-body);
  font-size: 0.6rem;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.65);
  letter-spacing: 0.12em;
  text-transform: uppercase;
}

/* =========================================
   ABOUT US SECTION STYLES (Luxury Architectural Living & Ojas Gram Vision)
   ========================================= */
.about-section {
  position: relative;
  width: 100%;
  padding: 90px 5% 85px;
  background-color: #ffffff;
  overflow: hidden;
  display: block;
}

.about-grid {
  display: grid;
  grid-template-columns: 1fr 1.15fr;
  gap: 4.5rem;
  align-items: center;
  max-width: 1340px;
  margin: 0 auto;
}

/* Left Overlapping Video Collage Container */
.about-collage-container {
  position: relative;
  width: 100%;
  height: 560px;
}

.about-video-card {
  position: absolute;
  overflow: hidden;
  background-color: #0f172a;
  border-radius: 20px;
}

/* Main Top-Right Video Card */
.about-video-main {
  width: 84%;
  height: 400px;
  top: 0;
  right: 0;
  box-shadow: 0 20px 45px rgba(0, 0, 0, 0.12);
  z-index: 2;
  border: none;
}

/* Overlapping Bottom-Left Video Card */
.about-video-sub {
  width: 66%;
  height: 300px;
  bottom: 0;
  left: 0;
  box-shadow: 0 25px 55px rgba(0, 0, 0, 0.18);
  border: 6px solid #ffffff;
  z-index: 5;
}

.about-video,
.about-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transform: scale(1.02);
  transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}

.about-video-card:hover .about-video,
.about-video-card:hover .about-img {
  transform: scale(1.08);
}

/* Floating Heritage & Vision Badge */
.about-floating-badge {
  position: absolute;
  bottom: 25px;
  right: -10px;
  z-index: 10;
  background: #14181c;
  color: #ffffff;
  padding: 0.85rem 1.4rem;
  border-radius: 16px;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  border: 1px solid rgba(220, 182, 88, 0.4);
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  transition: transform 0.35s ease;
}

.about-floating-badge:hover {
  transform: translateY(-3px) scale(1.03);
  border-color: #DCB658;
}

.badge-accent-icon {
  font-size: 1.35rem;
  line-height: 1;
}

.badge-text-group {
  display: flex;
  flex-direction: column;
}

.badge-main-label {
  font-family: var(--font-heading, 'Cinzel', serif);
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: #DCB658;
  text-transform: uppercase;
  line-height: 1.2;
}

.badge-sub-label {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.65rem;
  color: rgba(255, 255, 255, 0.75);
  letter-spacing: 0.04em;
  margin-top: 2px;
}

/* Right Content Styling */
.about-info-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  text-align: left;
}

.about-tagline {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.68rem;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: #DCB658;
  font-weight: 700;
  margin-bottom: 0.6rem;
  display: block;
}

.about-title {
  font-family: var(--font-heading, 'Cinzel', 'Playfair Display', serif);
  font-size: clamp(2rem, 3vw, 2.75rem);
  letter-spacing: 0.02em;
  color: #0a0c0e;
  line-height: 1.2;
  margin-bottom: 1.2rem;
  font-weight: 500;
}

.about-lead-paragraph {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.98rem;
  line-height: 1.72;
  color: #1e293b;
  margin-bottom: 0.85rem;
  font-weight: 400;
}

.about-secondary-paragraph {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.92rem;
  line-height: 1.68;
  color: #475569;
  margin-bottom: 1.35rem;
  font-weight: 400;
}

/* Developer Vision & Leadership Showcase Card */
.about-vision-card {
  background: linear-gradient(135deg, #FAF8F5 0%, #F4EFE6 100%);
  border-left: 4px solid #DCB658;
  border-top: 1px solid rgba(220, 182, 88, 0.25);
  border-right: 1px solid rgba(220, 182, 88, 0.2);
  border-bottom: 1px solid rgba(220, 182, 88, 0.2);
  border-radius: 0 16px 16px 0;
  padding: 1.35rem 1.6rem;
  margin-bottom: 1.6rem;
  width: 100%;
  box-sizing: border-box;
  box-shadow: 0 6px 20px rgba(220, 182, 88, 0.06);
}

.vision-card-header {
  display: flex;
  align-items: flex-start;
  gap: 0.65rem;
  margin-bottom: 0.6rem;
}

.vision-quote-icon {
  font-family: var(--font-heading, serif);
  font-size: 2.2rem;
  line-height: 0.9;
  color: #DCB658;
  font-weight: 700;
  flex-shrink: 0;
}

.vision-leadership-text {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.88rem;
  line-height: 1.6;
  color: #1a221e;
  margin: 0;
}

.vision-leadership-text strong {
  color: #0f172a;
  font-weight: 600;
}

.vision-core-text {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.85rem;
  line-height: 1.65;
  color: #475569;
  margin: 0;
  padding-left: 1.6rem;
}

/* Editorial Architectural Numbered Grid */
.about-pillars-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.35rem 1.75rem;
  margin-bottom: 1.5rem;
  width: 100%;
}

.pillar-item {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
  padding-top: 0.75rem;
  border-top: 1px solid rgba(15, 23, 42, 0.1);
  transition: all 0.3s ease;
  position: relative;
}

.pillar-item::before {
  content: '';
  position: absolute;
  top: -1px;
  left: 0;
  width: 0%;
  height: 2px;
  background-color: #DCB658;
  transition: width 0.4s ease;
}

.pillar-item:hover::before {
  width: 100%;
}

.pillar-header {
  display: flex;
  align-items: baseline;
  gap: 0.55rem;
}

.pillar-num {
  font-family: var(--font-heading, 'Cinzel', serif);
  font-size: 1.05rem;
  font-weight: 600;
  color: #DCB658;
  line-height: 1;
}

.pillar-title {
  font-family: var(--font-heading, 'Cinzel', 'Playfair Display', serif);
  font-size: 0.95rem;
  font-weight: 600;
  color: #0a0c0e;
  letter-spacing: 0.01em;
  margin: 0;
}

.pillar-desc {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.8rem;
  color: #64748b;
  font-weight: 400;
  line-height: 1.5;
  margin: 0;
  padding-left: 1.6rem;
}

/* Closing Invitation Quote */
.about-closing-quote {
  font-family: var(--font-heading, 'Playfair Display', Georgia, serif);
  font-size: 0.95rem;
  line-height: 1.68;
  color: #1e293b;
  margin-bottom: 1.75rem;
  padding: 0.85rem 1.2rem;
  border-left: 2px solid rgba(220, 182, 88, 0.5);
  background: rgba(248, 245, 238, 0.5);
  border-radius: 0 10px 10px 0;
}

.about-closing-quote em {
  font-style: italic;
}

/* CTA Group */
.about-cta-group {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.about-cta-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.65rem;
  background-color: #DCB658;
  color: #0a0c0e;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-weight: 700;
  font-size: 0.82rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 0.85rem 2rem;
  border-radius: 9999px;
  text-decoration: none;
  box-shadow: 0 8px 22px rgba(220, 182, 88, 0.3);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  border: 1px solid #DCB658;
}

.about-cta-btn:hover {
  background-color: #000000;
  color: #ffffff;
  border-color: #000000;
  transform: translateY(-2px);
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.3);
}

.about-cta-btn .btn-arrow {
  display: inline-block;
  transition: transform 0.3s ease;
}

.about-cta-btn:hover .btn-arrow {
  transform: translateX(4px);
}

.about-secondary-cta-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: transparent;
  color: #14181c;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-weight: 700;
  font-size: 0.82rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 0.85rem 1.8rem;
  border-radius: 9999px;
  text-decoration: none;
  border: 1px solid rgba(20, 24, 28, 0.25);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.about-secondary-cta-btn:hover {
  background: #14181c;
  color: #ffffff;
  border-color: #14181c;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(20, 24, 28, 0.15);
}

/* Responsive Styles for About Section */
@media (max-width: 1024px) {
  .about-grid {
    grid-template-columns: 1fr;
    gap: 3.5rem;
  }

  .about-collage-container {
    max-width: 580px;
    margin: 0 auto;
    height: 480px;
  }
}

@media (max-width: 640px) {
  .about-section {
    padding: 60px 4% 50px;
  }

  .about-collage-container {
    height: 360px;
  }

  .about-video-main {
    height: 260px;
  }

  .about-video-sub {
    height: 200px;
  }

  .about-floating-badge {
    bottom: -15px;
    right: 10px;
    padding: 0.65rem 1rem;
  }

  .about-pillars-grid {
    grid-template-columns: 1fr;
    gap: 1.25rem;
  }

  .about-cta-group {
    flex-direction: column;
    width: 100%;
  }

  .about-cta-btn,
  .about-secondary-cta-btn {
    width: 100%;
    justify-content: center;
  }
}

/* =========================================
   RESPONSIVE LAYOUT
   ========================================= */
@media (max-width: 1400px) {
  .hero-header,
  .hero-body,
  .hero-footer-inner {
    padding-left: 5%;
    padding-right: 5%;
  }
}

@media (max-width: 1100px) {
  .about-grid {
    grid-template-columns: 1fr;
    gap: 4rem;
  }

  .about-collage-container {
    height: 440px;
    max-width: 600px;
    margin: 0 auto;
  }

  .about-info-content {
    align-items: center;
    text-align: center;
  }

  .about-pillars-grid {
    text-align: left;
  }
}

@media (max-width: 640px) {
  .hero-header {
    align-items: flex-start;
    padding: 1rem 4%;
    gap: 0.8rem;
  }

  .brand-mark {
    width: 42px;
    height: 42px;
  }

  .brand-title {
    font-size: 1.08rem;
  }

  .brand-subtitle {
    font-size: 0.5rem;
  }

  .nav-links {
    max-width: none;
    padding: 0;
    gap: 0.55rem 1rem;
    justify-content: flex-start;
  }

  .nav-link {
    font-size: 0.62rem;
  }

  .nav-dropdown-menu {
    left: 0;
    min-width: 210px;
    transform: translate(0, 8px);
  }

  .nav-dropdown:hover .nav-dropdown-menu,
  .nav-dropdown:focus-within .nav-dropdown-menu {
    transform: translate(0, 0);
  }

  .hero-body {
    padding: 2rem 5%;
  }

  .hero-title {
    font-size: 2.2rem;
  }

  .about-section {
    padding: 4.5rem 5%;
  }

  .about-title {
    font-size: 2.2rem;
  }

  .about-collage-container {
    height: 360px;
  }

  .about-pillars-grid {
    grid-template-columns: 1fr;
  }

  .hero-actions {
    flex-direction: column;
    align-items: stretch;
  }

  .btn-primary,
  .btn-secondary {
    justify-content: center;
    width: 100%;
  }

  .hero-specs-bar {
    flex-wrap: wrap;
    gap: 1rem;
    width: 100%;
    justify-content: space-between;
  }

  .spec-divider {
    display: none;
  }

  .hero-floating-arrows {
    position: relative;
    right: auto;
    bottom: auto;
    flex-direction: row;
    margin-top: 1.5rem;
  }

  .stats-grid {
    flex-wrap: wrap;
    gap: 1.5rem;
  }

  .stat-item {
    min-width: 45%;
  }
}

/* =========================================
   NEARBY ESCAPES & LOCATION SECTION (Pure White Background + Luxury Interactive Leaflet Map)
   ========================================= */
.location-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background-color: #ffffff;
  color: #0a0c0e;
  overflow: hidden;
}

.location-container {
  max-width: 1340px;
  margin: 0 auto;
}

.location-grid {
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 4rem;
  align-items: center;
}

/* Left Column: Editorial Narrative & Places Navigation Menu */
.location-info-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.location-tagline {
  font-family: var(--font-body);
  font-size: 0.65rem;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--color-accent-amber);
  font-weight: 700;
  margin-bottom: 0.7rem;
  display: block;
}

.location-title {
  font-family: var(--font-heading);
  font-size: 42px;
  letter-spacing: 0.02em;
  text-transform: capitalize;
  color: #0a0c0e;
  line-height: 1.2;
  margin-bottom: 1.1rem;
  font-weight: 400;
}

.location-narrative {
  font-family: var(--font-body);
  font-size: 0.92rem;
  line-height: 1.7;
  color: #475569;
  margin-bottom: 1.5rem;
}

/* Luxury Climate & Elevation Highlights Strip */
.location-climate-strip {
  display: flex;
  align-items: stretch;
  gap: 1.25rem;
  background: linear-gradient(135deg, rgba(220, 182, 88, 0.08) 0%, rgba(248, 250, 252, 0.95) 100%);
  border: 1px solid rgba(220, 182, 88, 0.35);
  border-radius: 16px;
  padding: 1.1rem 1.35rem;
  margin-bottom: 1.75rem;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.03);
}

.climate-badge {
  display: flex;
  align-items: center;
  gap: 0.9rem;
  flex: 1;
}

.climate-badge:not(:last-child) {
  border-right: 1px solid rgba(220, 182, 88, 0.3);
  padding-right: 1.25rem;
}

.climate-icon-wrap {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: linear-gradient(135deg, #DCB658 0%, #B88E28 100%);
  color: #0A0C0E;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(220, 182, 88, 0.35);
}

.climate-icon-wrap svg {
  width: 22px;
  height: 22px;
  stroke: currentColor;
}

.climate-content {
  display: flex;
  flex-direction: column;
}

.climate-label {
  font-family: var(--font-body);
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: #8C6D1F;
  margin-bottom: 0.15rem;
}

.climate-value {
  font-family: var(--font-heading);
  font-size: 1.15rem;
  font-weight: 700;
  color: #0A0C0E;
  line-height: 1.2;
}

.climate-sub {
  font-family: var(--font-body);
  font-size: 0.8rem;
  font-weight: 600;
  color: #64748B;
}

@media (max-width: 768px) {
  .location-climate-strip {
    flex-direction: column;
    gap: 0.9rem;
    padding: 1rem;
  }
  .climate-badge:not(:last-child) {
    border-right: none;
    border-bottom: 1px solid rgba(220, 182, 88, 0.25);
    padding-right: 0;
    padding-bottom: 0.85rem;
  }
}

/* Interactive Compact Light Theme 2-Column Places Navigation Grid */
.location-places-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.9rem;
  width: 100%;
  margin-bottom: 2.2rem;
}

.place-grid-card {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  padding: 0.95rem 1.1rem;
  background-color: #ffffff;
  border: 1px solid #E2E8F0;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  position: relative;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.03);
}

.place-grid-card:hover {
  background-color: #ffffff;
  border-color: rgba(220, 182, 88, 0.7);
  box-shadow: 0 10px 24px rgba(220, 182, 88, 0.14);
  transform: translateY(-3px);
}

.place-grid-card.active {
  background-color: #ffffff;
  border: 2px solid #DCB658;
  box-shadow: 0 12px 28px rgba(220, 182, 88, 0.24), 0 0 0 1px rgba(220, 182, 88, 0.3);
  transform: translateY(-3px);
}

.card-icon-box {
  width: 42px;
  height: 42px;
  border-radius: 11px;
  background-color: #F8FAFC;
  border: 1px solid #E2E8F0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #1E293B;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.card-icon-box svg {
  width: 19px;
  height: 19px;
  stroke: currentColor;
}

.place-grid-card:hover .card-icon-box {
  background-color: rgba(220, 182, 88, 0.12);
  color: #B88E28;
  border-color: rgba(220, 182, 88, 0.4);
  transform: scale(1.08);
}

.place-grid-card.active .card-icon-box {
  background: linear-gradient(135deg, #DCB658 0%, #B88E28 100%);
  color: #0A0C0E;
  border-color: #DCB658;
  transform: scale(1.08);
  box-shadow: 0 4px 14px rgba(220, 182, 88, 0.45);
}

.card-meta {
  display: flex;
  flex-direction: column;
}

.place-name {
  font-family: var(--font-body);
  font-size: 0.9rem;
  font-weight: 700;
  color: #0A0C0E;
  line-height: 1.25;
  letter-spacing: -0.01em;
}

.place-grid-card.active .place-name {
  color: #0A0C0E;
}

.place-time {
  font-family: var(--font-body);
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.09em;
  text-transform: uppercase;
  color: #64748B;
  margin-top: 0.25rem;
}

.place-grid-card.active .place-time {
  color: #B88E28;
  font-weight: 800;
}

/* Location CTA Button (#DCB658 with Black Hover) */
.location-cta-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.75rem;
  background-color: var(--color-accent-amber);
  color: #0a0c0e;
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 0.85rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 1.05rem 2.6rem;
  border-radius: 9999px;
  text-decoration: none;
  box-shadow: 0 10px 25px rgba(220, 182, 88, 0.35);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  border: 1px solid var(--color-accent-amber);
}

.location-cta-btn:hover {
  background-color: #000000;
  color: #ffffff;
  border-color: #000000;
  transform: translateY(-3px);
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.35);
}

.location-cta-btn .btn-arrow {
  display: inline-block;
  transition: transform 0.3s ease;
}

.location-cta-btn:hover .btn-arrow {
  transform: translateX(4px);
}

/* Right Column: Luxury Interactive Leaflet Map Card */
/* Right Column: Luxury Interactive Leaflet Map Card */
.luxury-map-card {
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.25);
  border-top: 4px solid #DCB658;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 30px 60px -12px rgba(10, 12, 14, 0.16), 0 12px 24px -8px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: column;
  position: relative;
}

.map-control-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  background: linear-gradient(135deg, #0A0C0E 0%, #151A21 100%);
  border-bottom: 1px solid rgba(220, 182, 88, 0.2);
}

.map-status {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.status-pulse {
  width: 9px;
  height: 9px;
  background-color: #DCB658;
  border-radius: 50%;
  box-shadow: 0 0 12px #DCB658, 0 0 0 3px rgba(220, 182, 88, 0.25);
  animation: mapStatusPulse 1.8s infinite ease-in-out;
}

@keyframes mapStatusPulse {
  0% {
    transform: scale(0.9);
    opacity: 0.7;
    box-shadow: 0 0 8px #DCB658, 0 0 0 2px rgba(220, 182, 88, 0.2);
  }

  50% {
    transform: scale(1.35);
    opacity: 1;
    box-shadow: 0 0 16px #DCB658, 0 0 0 6px rgba(220, 182, 88, 0.4);
  }

  100% {
    transform: scale(0.9);
    opacity: 0.7;
    box-shadow: 0 0 8px #DCB658, 0 0 0 2px rgba(220, 182, 88, 0.2);
  }
}

.status-text {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: #FFFFFF;
  text-transform: uppercase;
}

.map-hint {
  font-family: var(--font-body);
  font-size: 0.74rem;
  color: rgba(220, 182, 88, 0.9);
  font-weight: 500;
  letter-spacing: 0.02em;
}

.map-canvas-wrapper {
  position: relative;
  width: 100%;
  height: 560px;
  background-color: #f1f5f9;
  overflow: hidden;
}

.leaflet-map-element {
  width: 100%;
  height: 100%;
  z-index: 1;
}

/* Custom Leaflet Pins & Waypoints matching schematic map */
.leaflet-custom-marker-wrapper {
  background: transparent !important;
  border: none !important;
  overflow: visible !important;
}

.map-node-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  cursor: pointer;
  transform-origin: center center;
  transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
  user-select: none;
}

.map-node-circle {
  width: 20px;
  height: 20px;
  background: #ffffff;
  border: 3.5px solid #C89D48;
  border-radius: 50%;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.28), 0 0 0 2px rgba(255, 255, 255, 0.7);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  flex-shrink: 0;
}

.map-node-wrapper:hover .map-node-circle,
.map-node-wrapper.active-node .map-node-circle,
.map-node-wrapper.gold-pin .map-node-circle {
  background: #7E5420;
  border-color: #FFFFFF;
  box-shadow: 0 0 0 4px rgba(200, 157, 72, 0.6), 0 8px 20px rgba(126, 84, 32, 0.5);
  transform: scale(1.35);
}

.map-node-label {
  position: absolute;
  left: 26px;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  color: #1e293b;
  font-family: 'Outfit', sans-serif;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.02em;
  padding: 3px 8px;
  border-radius: 6px;
  border: 1px solid rgba(200, 157, 72, 0.5);
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.12);
  white-space: nowrap;
  pointer-events: none;
  transition: all 0.25s ease;
  z-index: 10;
}

.map-node-wrapper:hover .map-node-label,
.map-node-wrapper.active-node .map-node-label,
.map-node-wrapper.gold-pin .map-node-label {
  background: #111827;
  color: #F8E3B6;
  border-color: #C89D48;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.3);
}

/* Origin Node (Chandigarh / Delhi) */
.map-node-wrapper.origin-node .map-node-circle {
  background: #C89D48;
  border-color: #FFFFFF;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3), 0 0 0 3px rgba(200, 157, 72, 0.5);
}

/* The Ulhas Vilas Destination Highlight Pin */
.ulhas-estate-pin-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  user-select: none;
  overflow: visible !important;
  z-index: 1000 !important;
}

.ulhas-radar-pulse {
  position: absolute;
  top: 38px;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: 2px solid #C89D48;
  background: rgba(200, 157, 72, 0.25);
  animation: ulhasPulse 2.4s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
  pointer-events: none;
  z-index: 1;
}

.ulhas-radar-pulse.pulse-delayed {
  animation-delay: 1.2s;
}

@keyframes ulhasPulse {
  0% {
    transform: translate(-50%, -50%) scale(0.6);
    opacity: 1;
  }
  70% {
    transform: translate(-50%, -50%) scale(2.2);
    opacity: 0.35;
  }
  100% {
    transform: translate(-50%, -50%) scale(2.8);
    opacity: 0;
  }
}

.ulhas-estate-badge-top {
  display: flex;
  align-items: center;
  gap: 6px;
  background: linear-gradient(135deg, #FFFDF8 0%, #FAF0DE 100%);
  border: 1.5px solid #C89D48;
  padding: 4px 10px;
  border-radius: 20px;
  box-shadow: 0 6px 18px rgba(126, 84, 32, 0.25), 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 6px;
  white-space: nowrap;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  z-index: 10;
}

.ulhas-estate-badge-top:hover {
  transform: translateY(-2px) scale(1.05);
  box-shadow: 0 8px 22px rgba(126, 84, 32, 0.35);
}

.ulhas-estate-badge-top svg {
  flex-shrink: 0;
}

.ulhas-estate-badge-top .estate-name {
  font-family: 'Cinzel', 'Marcellus', serif;
  font-size: 12px;
  font-weight: 700;
  color: #5B3B10;
  letter-spacing: 0.05em;
}

.ulhas-estate-disc {
  position: relative;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #F5DE98 0%, #C89D48 60%, #8A5F1C 100%);
  border: 3px solid #FFFFFF;
  box-shadow: 0 4px 14px rgba(126, 84, 32, 0.4), 0 0 0 3px rgba(200, 157, 72, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 5;
  transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.ulhas-estate-disc:hover {
  transform: scale(1.18);
}

.ulhas-estate-disc svg {
  color: #FFFFFF;
  filter: drop-shadow(0 1px 2px rgba(0,0,0,0.3));
}

/* Floating Climate & Elevation Overlay Card on Map */
.map-floating-climate-card {
  position: absolute;
  top: 1.25rem;
  left: 1.25rem;
  z-index: 25;
  display: flex;
  align-items: center;
  gap: 0.85rem;
  background: rgba(255, 255, 255, 0.94);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(220, 182, 88, 0.4);
  border-radius: 14px;
  padding: 0.65rem 1rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12), 0 1px 3px rgba(0, 0, 0, 0.05);
  pointer-events: auto;
  transition: all 0.3s ease;
}

.map-floating-climate-card:hover {
  background: #ffffff;
  box-shadow: 0 14px 36px rgba(220, 182, 88, 0.2);
  transform: translateY(-2px);
}

.floating-climate-item {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.floating-climate-divider {
  width: 1px;
  height: 28px;
  background-color: rgba(220, 182, 88, 0.35);
}

.floating-climate-icon {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: linear-gradient(135deg, #DCB658 0%, #B88E28 100%);
  color: #0A0C0E;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(220, 182, 88, 0.3);
}

.floating-climate-meta {
  display: flex;
  flex-direction: column;
}

.floating-climate-lbl {
  font-family: var(--font-body);
  font-size: 0.58rem;
  font-weight: 800;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: #8C6D1F;
  line-height: 1.1;
  margin-bottom: 0.1rem;
}

.floating-climate-val {
  font-family: var(--font-heading);
  font-size: 0.88rem;
  font-weight: 700;
  color: #0A0C0E;
  line-height: 1.15;
  white-space: nowrap;
}

.floating-climate-sub {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 600;
  color: #64748B;
}

@media (max-width: 640px) {
  .map-floating-climate-card {
    top: 0.75rem;
    left: 0.75rem;
    right: 0.75rem;
    justify-content: space-around;
    padding: 0.55rem 0.75rem;
  }
  .floating-climate-val {
    font-size: 0.78rem;
  }
}

/* Floating Luxury Photo / Destination Card Overlay */
.featured-photo-card {
  position: absolute;
  bottom: 1.5rem;
  right: 1.5rem;
  width: 320px;
  background: #ffffff;
  border-top: 4px solid #DCB658;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 22px 45px rgba(10, 12, 14, 0.22), 0 0 0 1px rgba(220, 182, 88, 0.18);
  z-index: 15;
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

.photo-card-top-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  margin-bottom: 0.65rem;
}

.photo-dist-pill {
  position: static;
  background: rgba(10, 12, 14, 0.9);
  border: 1px solid rgba(220, 182, 88, 0.4);
  color: #DCB658;
  font-family: var(--font-body);
  font-size: 0.62rem;
  font-weight: 800;
  letter-spacing: 0.09em;
  padding: 0.35rem 0.75rem;
  border-radius: 9999px;
  text-transform: uppercase;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  display: inline-flex;
  align-items: center;
}

.photo-card-body {
  padding: 1.25rem 1.35rem;
}

.photo-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5rem;
  gap: 0.5rem;
}

.photo-card-title {
  font-family: var(--font-heading);
  font-size: 1.12rem;
  color: #0A0C0E;
  font-weight: 600;
  letter-spacing: -0.01em;
}

.photo-card-time {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  color: #B88E28;
  background: rgba(220, 182, 88, 0.14);
  padding: 0.3rem 0.65rem;
  border-radius: 6px;
  border: 1px solid rgba(220, 182, 88, 0.28);
  white-space: nowrap;
}

.photo-card-desc {
  font-family: var(--font-body);
  font-size: 0.8rem;
  color: #475569;
  line-height: 1.55;
  margin-bottom: 0.95rem;
}

/* Progress Dots */
.photo-progress-dots {
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.photo-progress-dots .dot {
  width: 7px;
  height: 7px;
  background: #CBD5E1;
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.photo-progress-dots .dot:hover {
  background: #94A3B8;
  transform: scale(1.2);
}

.photo-progress-dots .dot.active {
  width: 22px;
  height: 7px;
  background: linear-gradient(90deg, #DCB658 0%, #B88E28 100%);
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(220, 182, 88, 0.45);
}

/* Responsive Layout */
@media (max-width: 1100px) {
  .location-grid {
    grid-template-columns: 1fr;
    gap: 3.5rem;
  }
}

@media (max-width: 640px) {
  .featured-photo-card {
    width: 250px;
    bottom: 1rem;
    right: 1rem;
  }

  .photo-card-img-wrapper {
    height: 130px;
  }
}

/* =========================================
   VILLAS / RESIDENCES SHOWCASE SECTION (Dark Ambient Video Single-Line Grid)
   ========================================= */
.villas-section {
  position: relative;
  width: 100%;
  padding: 80px 4%;
  background-color: #06080a;
  color: #ffffff;
  overflow: hidden;
}

/* Background Ambient Video Player */
.villas-video-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  overflow: hidden;
}

.villas-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.03);
  opacity: 1;
  filter: brightness(1.05) contrast(1.04);
}

.villas-video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: radial-gradient(circle at 50% 50%, rgba(6, 8, 10, 0.22) 0%, rgba(6, 8, 10, 0.5) 100%),
    linear-gradient(180deg, rgba(6, 8, 10, 0.42) 0%, rgba(6, 8, 10, 0.18) 50%, rgba(6, 8, 10, 0.58) 100%);
  pointer-events: none;
}

.villas-container {
  position: relative;
  z-index: 10;
  max-width: 1340px;
  margin: 0 auto;
}

/* Section Header */
.villas-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  margin-bottom: 3.5rem;
}

.villas-tagline {
  font-family: var(--font-body);
  font-size: 0.65rem;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--color-accent-amber);
  font-weight: 700;
  margin-bottom: 0.7rem;
}

.villas-title {
  font-family: var(--font-heading);
  font-size: 42px;
  letter-spacing: 0.03em;
  text-transform: capitalize;
  color: #ffffff;
  margin-bottom: 0.8rem;
  font-weight: 400;
}

.villas-subtitle {
  font-family: var(--font-body);
  font-size: 0.92rem;
  color: rgba(255, 255, 255, 0.72);
  max-width: 580px;
  line-height: 1.6;
  margin-bottom: 2rem;
}

/* Filter Tabs */
.villa-filter-tabs {
  display: inline-flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 0.65rem;
  background: transparent !important;
  border: none !important;
  box-shadow: none !important;
  padding: 0 !important;
  border-radius: 0 !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

.villa-tab-btn {
  font-family: var(--font-heading);
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: rgba(255, 255, 255, 0.88);
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.22);
  padding: 0.55rem 1.25rem;
  border-radius: 9999px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.villa-tab-btn:hover {
  color: #ffffff;
  background: rgba(129, 204, 202, 0.25);
}

.villa-tab-btn.active {
  background-color: #DCB658;
  color: #0a0c0e;
  border-color: #DCB658;
  box-shadow: 0 4px 15px rgba(220, 182, 88, 0.35);
}

/* Villa Grid (3 Cards Side-by-Side) */
.villas-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.75rem;
  width: 100%;
}

.villa-card {
  position: relative;
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.35);
  border-top: 4px solid #DCB658;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 14px 35px rgba(0, 0, 0, 0.14);
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  display: flex;
  flex-direction: column;
}

.villa-card:hover {
  background: #ffffff;
  transform: translateY(-6px);
  border-color: #DCB658;
  border-top: 4px solid #DCB658;
  box-shadow: 0 22px 50px rgba(0, 0, 0, 0.22), 0 0 25px rgba(220, 182, 88, 0.3);
}

/* Image Wrapper & Slider */
.villa-image-wrapper {
  position: relative;
  width: 100%;
  height: 225px;
  overflow: hidden;
}

.villa-image-slider {
  position: relative;
  width: 100%;
  height: 100%;
}

.villa-slide-img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0;
  transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
}

.villa-slide-img.active,
.villa-slide-img:first-child {
  opacity: 1;
  z-index: 2;
}

.villa-card:hover .villa-slide-img.active,
.villa-card:hover .villa-slide-img:first-child {
  transform: scale(1.08);
}

.villa-type-badge {
  position: absolute;
  top: 0.8rem;
  left: 0.8rem;
  z-index: 5;
  font-family: var(--font-body);
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #0a0c0e;
  background-color: #DCB658;
  padding: 0.3rem 0.7rem;
  border-radius: 9999px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.35);
}

.villa-slider-dots {
  position: absolute;
  bottom: 0.7rem;
  right: 0.8rem;
  z-index: 6;
  display: flex;
  gap: 0.3rem;
}

.villa-slider-dots .dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.45);
  transition: all 0.3s ease;
  cursor: pointer;
}

.villa-slider-dots .dot.active {
  width: 14px;
  border-radius: 4px;
  background-color: #DCB658;
}

.villa-img-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 40%, rgba(0, 0, 0, 0.25) 100%);
  pointer-events: none;
}

/* Card Content */
.villa-card-content {
  padding: 1.35rem;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
}

.villa-card-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
}

.villa-name {
  font-family: var(--font-heading);
  font-size: 1.1rem;
  font-weight: 500;
  color: #14181c;
  letter-spacing: 0.01em;
  line-height: 1.2;
}

.villa-price {
  font-family: var(--font-body);
  font-size: 0.76rem;
  font-weight: 700;
  color: #9e7b23;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  white-space: nowrap;
}

.villa-short-desc {
  font-family: var(--font-body);
  font-size: 0.78rem;
  color: rgba(20, 24, 28, 0.72);
  line-height: 1.5;
  margin-bottom: 1.15rem;
}

.villa-specs-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.4rem;
  padding: 0.75rem 1.35rem;
  margin-left: -1.35rem;
  margin-right: -1.35rem;
  background: #fffdf5;
  border-top: 1px solid rgba(220, 182, 88, 0.35);
  border-bottom: 1px solid rgba(220, 182, 88, 0.35);
  margin-bottom: 1.25rem;
}

.villa-spec {
  font-family: var(--font-body);
  font-size: 0.7rem;
  font-weight: 600;
  color: rgba(20, 24, 28, 0.82);
  display: flex;
  align-items: center;
  gap: 0.35rem;
}

.spec-icon-svg {
  display: inline-block;
  vertical-align: middle;
  flex-shrink: 0;
}

/* Action Buttons in Same Row (Send Quote & View Details) */
.villa-card-actions {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 0.65rem;
  margin-top: auto;
}

/* Send Quote Button (#DCB658 with Black Hover) */
.villa-btn-quote {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background-color: #DCB658;
  color: #0a0c0e;
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 0.75rem;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  padding: 0.75rem 0.6rem;
  border-radius: 9999px;
  text-decoration: none;
  border: 1px solid #DCB658;
  box-shadow: 0 4px 15px rgba(220, 182, 88, 0.25);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  white-space: nowrap;
}

.villa-btn-quote:hover {
  background-color: #000000;
  color: #ffffff;
  border-color: #000000;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.45);
}

/* View Details Button (Glass Pill) */
.villa-btn-details {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: #14181c;
  color: #ffffff;
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 0.75rem;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  padding: 0.75rem 0.6rem;
  border-radius: 9999px;
  text-decoration: none;
  border: 1px solid #14181c;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  white-space: nowrap;
}

.villa-btn-details:hover {
  background: #DCB658;
  color: #0a0c0e;
  border-color: #DCB658;
  transform: translateY(-2px);
}

/* Responsive Villas Grid */
@media (max-width: 1024px) {
  .villas-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
  }
}

@media (max-width: 680px) {
  .villas-grid {
    grid-template-columns: 1fr;
    gap: 1.25rem;
  }
}

/* =========================================
   AMENITIES & WELLNESS SECTION STYLES
   ========================================= */
.amenities-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background-color: #07090b;
  color: var(--color-text-main);
  overflow: hidden;
}

/* Background Ambient Video Wrapper */
.amenities-video-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  overflow: hidden;
}

.amenities-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.05);
  filter: brightness(1.05) contrast(1.04);
  opacity: 0.86;
}

.amenities-video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 2;
  background:
    radial-gradient(circle at 50% 40%, rgba(10, 12, 14, 0.18) 0%, rgba(5, 7, 9, 0.48) 100%),
    linear-gradient(180deg, rgba(7, 9, 11, 0.34) 0%, rgba(7, 9, 11, 0.12) 50%, rgba(7, 9, 11, 0.52) 100%);
  pointer-events: none;
}

/* Section Main Container */
.amenities-container {
  position: relative;
  z-index: 5;
  max-width: 1340px;
  margin: 0 auto;
}

/* Header Styles */
.amenities-header {
  text-align: center;
  margin-bottom: 4rem;
}

.amenities-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.8rem;
  font-weight: 700;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--color-accent-amber);
  margin-bottom: 0.8rem;
}

.amenities-title {
  font-family: var(--font-heading);
  font-size: clamp(2.2rem, 4vw, 3.2rem);
  font-weight: 400;
  color: #ffffff;
  margin-bottom: 1.2rem;
  letter-spacing: -0.02em;
}

.amenities-subtitle {
  max-width: 720px;
  margin: 0 auto 2.5rem auto;
  font-size: 1.05rem;
  line-height: 1.7;
  color: rgba(255, 255, 255, 0.78);
  font-weight: 300;
}

/* Filter Tabs */
.amenities-filter-tabs {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.8rem;
  flex-wrap: wrap;
}

.amenity-tab-btn {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: rgba(255, 255, 255, 0.8);
  padding: 0.65rem 1.4rem;
  border-radius: 9999px;
  font-family: var(--font-body);
  font-size: 0.85rem;
  font-weight: 600;
  cursor: pointer;
  backdrop-filter: blur(12px);
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.amenity-tab-btn:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
  border-color: rgba(255, 255, 255, 0.35);
}

.amenity-tab-btn.active {
  background: var(--color-accent-amber);
  color: #0a0c0e;
  border-color: var(--color-accent-amber);
  box-shadow: 0 4px 20px rgba(220, 182, 88, 0.3);
}

/* Carousel & Grid Track Wrapper */
.amenities-carousel-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
}

.amenities-slider-track {
  display: flex;
  flex-flow: row nowrap;
  gap: 1.5rem;
  width: 100%;
  overflow-x: auto;
  padding: 1.5rem 0.5rem 2.5rem 0.5rem;
  scroll-behavior: smooth;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.amenities-slider-track::-webkit-scrollbar {
  display: none;
}

/* Amenities Pagination Dots */
.amenities-dots {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.6rem;
  margin-top: 1.8rem;
}

.amenity-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid rgba(255, 255, 255, 0.35);
  cursor: pointer;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.amenity-dot:hover {
  background: rgba(220, 182, 88, 0.6);
  border-color: var(--color-accent-amber);
}

.amenity-dot.active {
  width: 30px;
  border-radius: 10px;
  background: var(--color-accent-amber);
  border-color: var(--color-accent-amber);
  box-shadow: 0 0 14px rgba(220, 182, 88, 0.6);
}

/* Navigation Arrow Buttons */
.amenities-nav-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  z-index: 10;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: rgba(15, 18, 22, 0.92);
  border: 1px solid rgba(220, 182, 88, 0.35);
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  backdrop-filter: blur(10px);
  transition: all 0.3s ease;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
}

.amenities-nav-btn:hover {
  background: var(--color-accent-amber);
  color: #0a0c0e;
  border-color: var(--color-accent-amber);
  transform: translateY(-50%) scale(1.1);
  box-shadow: 0 0 25px rgba(220, 182, 88, 0.5);
}

.prev-amenity-btn {
  left: -60px;
}

.next-amenity-btn {
  right: -60px;
}

@media (max-width: 1480px) {
  .amenities-carousel-wrapper {
    padding: 0 54px;
  }
  .prev-amenity-btn {
    left: 0;
  }
  .next-amenity-btn {
    right: 0;
  }
}

/* Amenity Card (Inspired by User's Reference Image) */
.amenity-card {
  flex: 0 0 calc(20% - 1.2rem);
  min-width: 250px;
  flex-shrink: 0;
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.28);
  border-radius: 20px;
  overflow: visible;
  display: flex;
  flex-direction: column;
  box-shadow: 0 14px 35px rgba(0, 0, 0, 0.18);
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  opacity: 1;
  transform: scale(1);
}

.amenity-card.hidden {
  display: none;
}

.amenity-card:hover {
  background: #ffffff;
  transform: translateY(-8px);
  border-color: #DCB658;
  box-shadow: 0 22px 45px rgba(0, 0, 0, 0.28), 0 0 25px rgba(220, 182, 88, 0.25);
}

/* Card Top Image & Overlapping Badge */
.amenity-image-wrapper {
  position: relative;
  width: 100%;
  height: 200px;
  overflow: visible;
}

.amenity-img-box {
  width: 100%;
  height: 100%;
  border-radius: 18px 18px 0 0;
  overflow: hidden;
  position: relative;
}

.amenity-card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 18px 18px 0 0;
  transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.amenity-card:hover .amenity-card-img {
  transform: scale(1.06);
}

/* Circular Overlapping Icon Badge (Key Reference Feature) */
.amenity-icon-badge {
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translate(-50%, 50%);
  z-index: 5;
  width: 46px;
  height: 46px;
  border-radius: 50%;
  background: linear-gradient(145deg, #181D22 0%, #080A0D 100%);
  border: 2px solid #DCB658;
  color: #DCB658;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.45), 0 0 14px rgba(220, 182, 88, 0.25);
  backdrop-filter: blur(8px);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.amenity-icon-badge svg {
  width: 21px;
  height: 21px;
  stroke: #DCB658;
  transition: stroke 0.35s ease;
}

.amenity-card:hover .amenity-icon-badge {
  background: linear-gradient(135deg, #DCB658 0%, #C49838 100%);
  color: #0A0C0E;
  transform: translate(-50%, 50%) scale(1.1);
  box-shadow: 0 8px 24px rgba(220, 182, 88, 0.55);
}

.amenity-card:hover .amenity-icon-badge svg {
  stroke: #0A0C0E;
}

/* Card Body Content */
.amenity-card-body {
  padding: 1.55rem 1.2rem 1.25rem 1.2rem;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-grow: 1;
  justify-content: flex-start;
}

.amenity-card-title {
  font-family: var(--font-heading);
  font-size: 1.18rem;
  font-weight: 500;
  color: #14181c;
  margin-bottom: 0.4rem;
  letter-spacing: 0.02em;
}

.amenity-card-desc {
  font-family: var(--font-body);
  font-size: 0.82rem;
  line-height: 1.45;
  color: rgba(20, 24, 28, 0.72);
  margin-bottom: 1rem;
  font-weight: 400;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* View Details Action Link */
.amenity-view-btn {
  background: transparent;
  border: none;
  color: #9e7b23;
  font-family: var(--font-body);
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.25rem 0;
  transition: all 0.3s ease;
  outline: none;
}

.amenity-view-btn .btn-arrow {
  display: inline-block;
  transition: transform 0.3s ease, color 0.3s ease;
}

.amenity-view-btn:hover,
.amenity-view-btn:focus {
  color: #071524 !important;
  text-decoration: none;
}

.amenity-view-btn:hover .btn-arrow,
.amenity-view-btn:focus .btn-arrow {
  transform: translateX(6px);
  color: #b38b29 !important;
}

/* Modal Lightbox */
.amenity-modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(5, 7, 9, 0.85);
  backdrop-filter: blur(16px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.4s ease;
}

.amenity-modal-backdrop.active {
  opacity: 1;
  pointer-events: auto;
}

.amenity-modal-content {
  position: relative;
  width: 100%;
  max-width: 850px;
  background: rgba(18, 22, 26, 0.95);
  border: 1px solid rgba(220, 182, 88, 0.3);
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.8), 0 0 40px rgba(220, 182, 88, 0.15);
  transform: scale(0.9);
  transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

.amenity-modal-backdrop.active .amenity-modal-content {
  transform: scale(1);
}

.amenity-modal-close {
  position: absolute;
  top: 1.2rem;
  right: 1.5rem;
  z-index: 10;
  background: rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: #ffffff;
  font-size: 1.8rem;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.amenity-modal-close:hover {
  background: var(--color-accent-amber);
  color: #0a0c0e;
  border-color: var(--color-accent-amber);
}

.modal-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
}

.modal-image-col {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 340px;
}

.modal-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.modal-info-col {
  padding: 3rem 2.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.modal-badge {
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.2em;
  color: var(--color-accent-amber);
  text-transform: uppercase;
  margin-bottom: 0.8rem;
}

.modal-title {
  font-family: var(--font-heading);
  font-size: 2rem;
  color: #ffffff;
  margin-bottom: 1rem;
}

.modal-desc {
  font-size: 0.95rem;
  line-height: 1.7;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 1.8rem;
  font-weight: 300;
}

.modal-meta-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 2rem;
  padding: 1rem 0;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.modal-meta-item {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
}

.meta-label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  color: rgba(255, 255, 255, 0.5);
  text-transform: uppercase;
}

.meta-value {
  font-size: 0.95rem;
  font-weight: 600;
  color: #ffffff;
}

.modal-book-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.6rem;
  background: var(--color-accent-amber);
  color: #0a0c0e;
  font-family: var(--font-heading);
  font-size: 0.88rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 0.9rem 1.8rem;
  border-radius: 9999px;
  text-decoration: none;
  box-shadow: 0 6px 20px rgba(220, 182, 88, 0.3);
  transition: all 0.3s ease;
}

.modal-book-btn:hover {
  background: #ffffff;
  box-shadow: 0 8px 25px rgba(255, 255, 255, 0.4);
  transform: translateY(-2px);
}

/* Responsive Styles for Amenities */
@media (max-width: 1366px) {
  .amenity-card {
    flex: 0 0 calc(25% - 1.2rem);
  }
}

@media (max-width: 1024px) {
  .amenity-card {
    flex: 0 0 calc(33.333% - 1rem);
  }

  .modal-grid {
    grid-template-columns: 1fr;
  }

  .modal-image-col {
    min-height: 220px;
  }

  .modal-info-col {
    padding: 2rem 1.8rem;
  }
}

@media (max-width: 768px) {
  .amenities-section {
    padding: 80px 4%;
  }

  .amenity-card {
    flex: 0 0 calc(50% - 0.8rem);
  }

  .prev-amenity-btn {
    left: -10px;
  }

  .next-amenity-btn {
    right: -10px;
  }
}

@media (max-width: 520px) {
  .amenity-card {
    flex: 0 0 85%;
  }
}



/* =========================================
   EXCLUSIVE 6 LUXURIOUS DUPLEX APARTMENTS (Interactive Showcase Layout)
   ========================================= */
.investment-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background-color: #ffffff;
  color: #14181c;
  overflow: hidden;
  box-sizing: border-box;
}

.investment-container {
  max-width: 1340px;
  margin: 0 auto;
  position: relative;
  z-index: 5;
}

/* Centered Header */
.investment-header {
  text-align: center;
  margin-bottom: 3.25rem;
}

.investment-tagline {
  display: inline-block;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: #DCB658;
  margin-bottom: 0.6rem;
}

.investment-title {
  font-family: var(--font-heading, 'Cinzel', 'Playfair Display', serif);
  font-size: clamp(1.85rem, 2.8vw, 2.6rem);
  font-weight: 500;
  color: #14181c;
  margin-bottom: 0.6rem;
  letter-spacing: 0.01em;
}

.investment-header-line {
  width: 44px;
  height: 2px;
  background: #DCB658;
  margin: 0 auto 0.9rem auto;
  border-radius: 2px;
}

.investment-subtitle {
  max-width: 660px;
  margin: 0 auto;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.92rem;
  line-height: 1.65;
  color: rgba(20, 24, 28, 0.7);
  font-weight: 400;
}

/* 2-Column Main Layout */
.investment-grid {
  display: grid;
  grid-template-columns: 480px 1fr;
  gap: 3.5rem;
  align-items: center;
}

/* LEFT COLUMN: Main Showcase Image Card & Thumbnails & Brochure CTA */
.investment-showcase-column {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

/* Large Featured Image Frame */
.investment-featured-card {
  position: relative;
  width: 100%;
  height: 440px;
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 16px 40px rgba(20, 24, 28, 0.08);
  background: #f4f2ed;
  border: 1px solid rgba(220, 182, 88, 0.3);
}

.investment-featured-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: opacity 0.35s ease, transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.investment-featured-card:hover .investment-featured-img {
  transform: scale(1.04);
}

.investment-card-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 45%, rgba(20, 24, 28, 0.75) 100%);
  pointer-events: none;
}

.investment-badge {
  position: absolute;
  top: 1.2rem;
  left: 1.2rem;
  z-index: 5;
  background: rgba(20, 24, 28, 0.88);
  border: 1px solid rgba(220, 182, 88, 0.5);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  padding: 0.45rem 1rem;
  border-radius: 9999px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.64rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  color: #DCB658;
  text-transform: uppercase;
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.25);
  transition: all 0.3s ease;
}

/* Bottom Showcase Row: Thumbnails + Pill CTA Button */
.investment-showcase-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.85rem;
}

.investment-thumbnails {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.investment-thumb {
  width: 54px;
  height: 54px;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid transparent;
  opacity: 0.65;
  transition: all 0.35s ease;
  background: #ffffff;
  box-shadow: 0 4px 12px rgba(20, 24, 28, 0.06);
}

.investment-thumb:hover {
  opacity: 1;
  transform: translateY(-2px);
  border-color: rgba(220, 182, 88, 0.6);
}

.investment-thumb.active {
  opacity: 1;
  border-color: #DCB658;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(220, 182, 88, 0.35);
}

.investment-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* Download Brochure Button */
.investment-brochure-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.55rem;
  background: #14181c;
  color: #ffffff;
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.76rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 0.75rem 1.4rem;
  border-radius: 9999px;
  text-decoration: none;
  border: 1px solid #14181c;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 4px 16px rgba(20, 24, 28, 0.15);
  white-space: nowrap;
}

.investment-brochure-btn:hover {
  background: #DCB658;
  color: #14181c;
  border-color: #DCB658;
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(220, 182, 88, 0.35);
}

/* RIGHT COLUMN: Minimalist Luxury Benefits List */
.investment-list-column {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.investment-benefits-list {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

.investment-item {
  padding: 1.15rem 1.35rem;
  border: 1px solid rgba(20, 24, 28, 0.08);
  border-left: 4px solid transparent;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  cursor: pointer;
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 4px 16px rgba(20, 24, 28, 0.03);
}

.investment-item-header {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.investment-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: #DCB658 !important;
  background: rgba(220, 182, 88, 0.12) !important;
  border: 1px solid rgba(220, 182, 88, 0.35) !important;
  box-shadow: 0 4px 12px rgba(220, 182, 88, 0.1);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.investment-icon svg {
  width: 22px;
  height: 22px;
  stroke: #DCB658 !important;
  transition: all 0.3s ease;
}

.investment-item-title {
  font-family: var(--font-heading, 'Cinzel', 'Playfair Display', serif);
  font-size: clamp(0.98rem, 1.15vw, 1.12rem);
  font-weight: 600;
  color: #14181c;
  letter-spacing: 0.01em;
  line-height: 1.35;
  transition: all 0.3s ease;
  margin: 0;
  flex: 1;
}

.investment-arrow-circle {
  display: flex !important;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: rgba(220, 182, 88, 0.1);
  border: 1px solid rgba(220, 182, 88, 0.25);
  color: #9e7b23;
  margin-left: auto;
  flex-shrink: 0;
  transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), background 0.35s ease, color 0.35s ease, border-color 0.35s ease;
}

.investment-arrow-circle svg {
  width: 14px;
  height: 14px;
  stroke: currentColor;
}

.investment-item:hover {
  background: #ffffff;
  border-color: rgba(220, 182, 88, 0.45);
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(220, 182, 88, 0.1);
}

.investment-item:hover .investment-icon {
  background: #DCB658 !important;
  border-color: #DCB658 !important;
  color: #0a0c0e !important;
  transform: scale(1.05);
  box-shadow: 0 6px 18px rgba(220, 182, 88, 0.35);
}

.investment-item:hover .investment-icon svg {
  stroke: #0a0c0e !important;
}

.investment-item.active {
  background: #ffffff;
  border-color: rgba(220, 182, 88, 0.5);
  border-left: 4px solid #DCB658;
  box-shadow: 0 14px 35px rgba(220, 182, 88, 0.12), 0 4px 18px rgba(20, 24, 28, 0.04);
}

.investment-item.active .investment-item-title {
  color: #14181c;
  font-weight: 700;
}

.investment-item.active .investment-icon {
  background: #DCB658 !important;
  border-color: #DCB658 !important;
  color: #0a0c0e !important;
  transform: scale(1.05);
  box-shadow: 0 6px 18px rgba(220, 182, 88, 0.35);
}

.investment-item.active .investment-icon svg {
  stroke: #0a0c0e !important;
}

.investment-item.active .investment-arrow-circle {
  background: #DCB658;
  color: #0a0c0e;
  border-color: #DCB658;
  transform: rotate(90deg);
}

.investment-item-body {
  max-height: 0;
  opacity: 0;
  overflow: hidden;
  transition: max-height 0.4s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s ease, margin-top 0.3s ease;
  margin-top: 0;
  padding-left: 3.75rem;
  padding-right: 1.5rem;
  display: block;
}

.investment-item.active .investment-item-body {
  max-height: 140px;
  opacity: 1;
  margin-top: 0.65rem;
}

.investment-item-desc {
  font-family: var(--font-body, 'Montserrat', sans-serif);
  font-size: 0.88rem;
  line-height: 1.62;
  color: rgba(20, 24, 28, 0.72);
  margin: 0;
}

/* Responsive Styles */
@media (max-width: 1080px) {
  .investment-grid {
    grid-template-columns: 1fr;
    gap: 2.5rem;
  }

  .investment-showcase-column {
    max-width: 580px;
    margin: 0 auto;
    width: 100%;
  }

  .investment-featured-card {
    height: 380px;
  }
}

@media (max-width: 640px) {
  .investment-section {
    padding: 4rem 4%;
  }

  .investment-featured-card {
    height: 280px;
    border-radius: 20px;
  }

  .investment-showcase-footer {
    flex-direction: column;
    align-items: stretch;
  }

  .investment-thumbnails {
    justify-content: center;
  }

  .investment-brochure-btn {
    justify-content: center;
    width: 100%;
  }

  .investment-item-body {
    padding-left: 0;
  }
}

/* =========================================
   TESTIMONIALS SECTION (Dark Premium Video Carousel)
   ========================================= */
.testimonials-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background: #050607;
  color: #ffffff;
  overflow: hidden;
}

.testimonials-video-wrapper {
  position: absolute;
  inset: 0;
  z-index: 1;
  overflow: hidden;
  pointer-events: none;
}

.testimonials-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.86;
  filter: brightness(1.04) contrast(1.06) saturate(1.05);
  transform: scale(1.02);
}

.testimonials-video-overlay {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(circle at 50% 40%, rgba(220, 182, 88, 0.08) 0%, rgba(5, 6, 7, 0.08) 36%, rgba(5, 6, 7, 0.32) 76%),
    linear-gradient(180deg, rgba(5, 6, 7, 0.42) 0%, rgba(5, 6, 7, 0.16) 48%, rgba(5, 6, 7, 0.54) 100%);
}

.testimonials-container {
  position: relative;
  z-index: 5;
  max-width: 1340px;
  margin: 0 auto;
}

.testimonials-header {
  max-width: 760px;
  margin: 0 auto 3rem auto;
  text-align: center;
}

.testimonials-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--color-accent-amber);
  margin-bottom: 0.4rem;
}

.testimonials-title {
  font-family: var(--font-heading);
  font-size: clamp(2rem, 3.2vw, 2.7rem);
  font-weight: 400;
  line-height: 1.2;
  color: #ffffff;
  margin-bottom: 0.5rem;
  letter-spacing: 0.02em;
  text-shadow: 0 10px 35px rgba(0, 0, 0, 0.55);
}

.testimonials-title::after {
  content: '';
  display: block;
  width: 45px;
  height: 2px;
  background: var(--color-accent-amber);
  border-radius: 2px;
  margin: 0.75rem auto 0.85rem auto;
}

.testimonials-subtitle {
  max-width: 620px;
  margin: 0 auto;
  font-family: var(--font-body);
  font-size: 0.9rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.72);
  font-weight: 400;
}

.testimonials-carousel {
  position: relative;
  display: flex;
  align-items: center;
  gap: 1.25rem;
  width: 100%;
}

.testimonialSwiper {
  width: 100%;
  overflow: hidden;
  padding: 12px 6px 18px 6px;
}

.testimonialSwiper .swiper-slide {
  height: auto;
  display: flex;
}

.testimonial-card {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 1.5rem;
  min-height: 315px;
  padding: 1.75rem;
  border: 1px solid rgba(220, 182, 88, 0.35);
  border-top: 2px solid #DCB658;
  background: #ffffff;
  box-shadow: 0 14px 35px rgba(0, 0, 0, 0.18);
  transition: border-color 0.35s ease, background 0.35s ease, transform 0.35s ease, box-shadow 0.35s ease;
  border-radius: 16px;
  box-sizing: border-box;
}

.testimonial-card:hover {
  transform: translateY(-4px);
  background: #ffffff;
  border-color: #DCB658;
  box-shadow: 0 20px 45px rgba(0, 0, 0, 0.25), 0 0 25px rgba(220, 182, 88, 0.25);
}

.testimonial-quote-mark {
  font-family: Georgia, serif;
  font-size: 3.4rem;
  line-height: 0.72;
  color: #DCB658;
  height: 2.1rem;
}

.testimonial-copy {
  font-family: var(--font-heading);
  font-size: 15px;
  line-height: 1.6;
  color: rgba(20, 24, 28, 0.82);
  font-weight: 400;
}

.testimonial-client {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(20, 24, 28, 0.1);
}

.testimonial-client-img {
  width: 54px;
  height: 54px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #DCB658;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
  flex-shrink: 0;
}

.testimonial-client-name {
  font-family: var(--font-heading);
  font-size: 1rem;
  font-weight: 500;
  color: #14181c;
  margin-bottom: 0.25rem;
}

.testimonial-client-meta {
  display: block;
  font-size: 0.62rem;
  font-weight: 700;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: rgba(20, 24, 28, 0.62);
}

.testimonial-nav-btn {
  flex-shrink: 0;
  width: 54px;
  height: 54px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.24);
  background: rgba(8, 10, 12, 0.6);
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  transition: all 0.32s ease;
  z-index: 10;
}

.testimonial-nav-btn span {
  font-size: 1.2rem;
  line-height: 1;
}

.testimonial-nav-btn:hover {
  background: var(--color-accent-amber);
  border-color: var(--color-accent-amber);
  color: #0a0c0e;
  transform: translateY(-2px);
  box-shadow: 0 12px 28px rgba(220, 182, 88, 0.35);
}

.testimonial-dots {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.65rem;
  margin-top: 1.8rem;
}

.testimonial-dot {
  width: 34px;
  height: 4px;
  border: 0;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.28);
  cursor: pointer;
  transition: all 0.3s ease;
  padding: 0;
}

.testimonial-dot.active,
.testimonial-dot:hover {
  width: 54px;
  background: var(--color-accent-amber);
}

@media (max-width: 900px) {
  .testimonials-section {
    padding: 80px 4%;
  }

  .testimonial-nav-btn {
    width: 44px;
    height: 44px;
  }
}

@media (max-width: 640px) {
  .testimonials-section {
    padding: 4rem 4%;
  }

  .testimonials-header {
    margin-bottom: 2rem;
  }

  .testimonials-carousel {
    flex-direction: column;
    gap: 1rem;
  }

  .testimonial-nav-btn {
    display: none;
  }

  .testimonial-card {
    min-height: 320px;
    padding: 1.5rem;
  }
}

/* =========================================
   GALLERY SECTION (Premium Living Image Mosaic)
   ========================================= */
.gallery-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background: #ffffff;
  color: #14181c;
  overflow: hidden;
}

.gallery-container {
  max-width: 1340px;
  margin: 0 auto;
}

.gallery-header-wrapper {
  position: relative;
  margin-bottom: 2.8rem;
  width: 100%;
}

.gallery-header {
  max-width: 720px;
  margin: 0 auto;
  text-align: center;
}

.gallery-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--color-accent-amber);
  margin-bottom: 0.4rem;
}

.gallery-title {
  font-family: var(--font-heading);
  font-size: clamp(2rem, 3.2vw, 2.7rem);
  font-weight: 400;
  line-height: 1.2;
  color: #14181c;
  margin-bottom: 0.5rem;
  letter-spacing: 0.02em;
  text-align: center;
}

.gallery-title::after {
  content: '';
  display: block;
  width: 45px;
  height: 2px;
  background: var(--color-accent-amber);
  border-radius: 2px;
  margin: 0.75rem auto 0.85rem auto;
}

.gallery-subtitle {
  max-width: 620px;
  margin: 0 auto;
  font-family: var(--font-body);
  font-size: 0.9rem;
  line-height: 1.6;
  color: rgba(20, 24, 28, 0.68);
  text-align: center;
}

.gallery-header-action {
  position: absolute;
  right: 0;
  bottom: 0.5rem;
  z-index: 5;
}

.gallery-view-all-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.65rem 1.4rem;
  font-family: var(--font-body);
  font-size: 0.82rem;
  font-weight: 700;
  letter-spacing: 0.8px;
  text-transform: uppercase;
  color: #14181c;
  background: #ffffff;
  border: 1.5px solid #DCB658;
  border-radius: 50px;
  text-decoration: none;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 4px 15px rgba(220, 182, 88, 0.12);
  white-space: nowrap;
}

.gallery-view-all-btn:hover {
  background: #DCB658;
  border-color: #DCB658;
  color: #07090b;
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(220, 182, 88, 0.3);
}

.gallery-view-all-btn svg {
  transition: transform 0.3s ease;
}

.gallery-view-all-btn:hover svg {
  transform: translateX(4px);
}

@media (max-width: 991px) {
  .gallery-header-action {
    position: static;
    margin-top: 1.5rem;
    text-align: center;
    display: flex;
    justify-content: center;
  }
}

.gallerySwiper {
  width: 100%;
  position: relative;
  overflow: hidden;
}

.gallerySwiper .swiper-slide {
  width: 100%;
  height: auto;
}

.gallery-mosaic {
  display: grid;
  grid-template-columns: 1.1fr 0.9fr 1.05fr;
  grid-template-rows: 185px 185px;
  gap: 0.85rem;
  width: 100%;
}

.gallery-tile {
  position: relative;
  overflow: hidden;
  border-radius: 8px;
  background: #e9e3d7;
  border: 1px solid rgba(220, 182, 88, 0.24);
  box-shadow: 0 14px 34px rgba(20, 24, 28, 0.08);
  cursor: pointer;
  isolation: isolate;
  width: 100%;
  height: 100%;
}

/* Tile 1: Left Column (Full Height) */
.gallery-tile:nth-child(1),
.gallery-tile.gallery-tile-large {
  grid-column: 1;
  grid-row: 1 / span 2;
}

/* Tile 2: Middle Column (Top) */
.gallery-tile:nth-child(2) {
  grid-column: 2;
  grid-row: 1;
}

/* Tile 3: Right Column (Full Height) */
.gallery-tile:nth-child(3),
.gallery-tile.gallery-tile-tall {
  grid-column: 3;
  grid-row: 1 / span 2;
}

/* Tile 4: Middle Column (Bottom) */
.gallery-tile:nth-child(4) {
  grid-column: 2;
  grid-row: 2;
}

.gallery-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transform: scale(1.02);
  transition: opacity 0.45s ease, transform 0.75s cubic-bezier(0.16, 1, 0.3, 1);
}

.gallery-tile:hover .gallery-img {
  transform: scale(1.08);
}

.gallery-img.changing {
  opacity: 0;
}

.gallery-tile-overlay {
  position: absolute;
  inset: 0;
  z-index: 1;
  background:
    linear-gradient(180deg, rgba(0, 0, 0, 0) 35%, rgba(0, 0, 0, 0.62) 100%),
    linear-gradient(90deg, rgba(0, 0, 0, 0.24), rgba(0, 0, 0, 0));
  pointer-events: none;
}

.gallery-tile-caption {
  position: absolute;
  left: 1rem;
  right: 1rem;
  bottom: 1rem;
  z-index: 2;
  color: #ffffff;
  text-shadow: 0 2px 12px rgba(0, 0, 0, 0.45);
}

.gallery-tile-caption h3 {
  font-family: var(--font-heading);
  font-size: clamp(1rem, 1.2vw, 1.18rem);
  font-weight: 400;
  line-height: 1.2;
  margin-bottom: 0.25rem;
}

.gallery-tile-caption span {
  display: block;
  font-size: 0.58rem;
  font-weight: 700;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.82);
}

.gallery-dots {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.65rem;
  margin-top: 1.75rem;
  position: relative;
  z-index: 10;
}

.gallery-dot {
  width: 36px;
  height: 3.5px;
  border: 0;
  border-radius: 4px;
  background: #d1d5db;
  opacity: 1 !important;
  cursor: pointer;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  display: inline-block;
  padding: 0;
  outline: none;
}

.gallery-dot.active,
.gallery-dot.swiper-pagination-bullet-active {
  width: 58px;
  background: #cca43b !important;
  opacity: 1 !important;
}

.gallery-dot:hover {
  background: #cca43b;
}

@media (max-width: 900px) {
  .gallery-section {
    padding: 80px 4%;
  }

  .gallery-mosaic {
    grid-template-columns: 1fr 1fr;
    grid-auto-rows: 180px;
  }

  .gallery-tile:nth-child(4) {
    grid-column: auto;
    grid-row: auto;
  }

  .gallery-tile-tall {
    grid-row: span 1;
  }
}

@media (max-width: 640px) {
  .gallery-section {
    padding: 4rem 4%;
  }

  .gallery-header {
    margin-bottom: 2rem;
  }

  .gallery-mosaic {
    grid-template-columns: 1fr;
    grid-auto-rows: 230px;
  }

  .gallery-tile-large,
  .gallery-tile-tall {
    grid-row: span 1;
  }
}

/* =========================================
   FAQ SECTION STYLES (Light Luxury 2-Column Layout)
   ========================================= */
.faq-section {
  position: relative;
  width: 100%;
  padding: 80px 5%;
  background: #f8f7f4;
  color: #14181c;
  overflow: hidden;
  box-sizing: border-box;
}

.faq-video-wrapper {
  display: none;
}

.faq-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.02);
  opacity: 1;
  filter: brightness(1.05) contrast(1.04);
}

.faq-video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: radial-gradient(circle at 50% 50%, rgba(6, 8, 10, 0.22) 0%, rgba(6, 8, 10, 0.55) 100%),
    linear-gradient(180deg, rgba(6, 8, 10, 0.42) 0%, rgba(6, 8, 10, 0.18) 50%, rgba(6, 8, 10, 0.58) 100%);
  pointer-events: none;
}

.faq-container {
  position: relative;
  z-index: 2;
  max-width: 1340px;
  margin: 0 auto;
  width: 100%;
}

/* 2-Column Main Grid (50:50 Ratio) */
.faq-main-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3.5rem;
  align-items: start;
}

/* LEFT COLUMN: 50% Private Consultation / Enquiry Form Card */
.faq-form-column {
  position: relative;
  width: 100%;
}

.faq-form-card {
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.35);
  border-radius: 20px;
  padding: 2.2rem 2.2rem 1.8rem 2.2rem;
  box-shadow: 0 16px 42px rgba(20, 24, 28, 0.06);
  box-sizing: border-box;
}

.faq-form-header {
  margin-bottom: 1.4rem;
}

.faq-form-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: #DCB658;
  margin-bottom: 0.35rem;
}

.faq-form-title {
  font-family: var(--font-heading);
  font-size: clamp(1.4rem, 2vw, 1.75rem);
  font-weight: 400;
  color: #14181c;
  margin-bottom: 0.4rem;
  letter-spacing: 0.01em;
}

.faq-form-subtitle {
  font-family: var(--font-body);
  font-size: 0.84rem;
  line-height: 1.55;
  color: rgba(20, 24, 28, 0.65);
}

.faq-contact-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.faq-form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.faq-form-group {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.faq-form-label {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #14181c;
}

.faq-form-input,
.faq-form-select,
.faq-form-textarea {
  width: 100%;
  padding: 0.75rem 1rem;
  font-family: var(--font-body);
  font-size: 0.86rem;
  color: #14181c;
  background: #faf9f6;
  border: 1px solid rgba(20, 24, 28, 0.14);
  border-radius: 10px;
  outline: none;
  transition: all 0.3s ease;
  box-sizing: border-box;
}

.faq-form-input:focus,
.faq-form-select:focus,
.faq-form-textarea:focus {
  background: #ffffff;
  border-color: #DCB658;
  box-shadow: 0 0 0 3px rgba(220, 182, 88, 0.15);
}

.faq-form-submit-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.6rem;
  background: #DCB658;
  color: #07090b;
  font-family: var(--font-heading);
  font-size: 0.76rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  padding: 0.85rem 1.8rem;
  border-radius: 9999px;
  border: none;
  cursor: pointer;
  transition: all 0.35s ease;
  box-shadow: 0 8px 22px rgba(220, 182, 88, 0.3);
  margin-top: 0.4rem;
  width: 100%;
}

.faq-form-submit-btn:hover {
  background: #e8c76a;
  transform: translateY(-2px);
  box-shadow: 0 12px 28px rgba(220, 182, 88, 0.45);
}

.faq-reassurance-bar {
  display: flex;
  align-items: center;
  gap: 0.65rem;
  margin-top: 1.25rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(20, 24, 28, 0.08);
  font-family: var(--font-body);
  font-size: 0.78rem;
  color: rgba(20, 24, 28, 0.7);
}

.faq-reassurance-icon {
  color: #DCB658;
  display: flex;
  align-items: center;
}

/* RIGHT COLUMN: Content & Accordion */
.faq-content-column {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* Section Header Aligned Left */
.faq-header {
  text-align: left;
  margin-bottom: 2rem;
}

.faq-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--color-accent-amber, #DCB658);
  margin-bottom: 0.4rem;
}

.faq-title {
  font-family: var(--font-heading);
  font-size: clamp(2rem, 3.2vw, 2.7rem);
  font-weight: 400;
  color: #14181c;
  margin-bottom: 0.5rem;
  letter-spacing: 0.02em;
}

.faq-header-line {
  width: 45px;
  height: 2px;
  background: var(--color-accent-amber, #DCB658);
  margin: 0 0 0.8rem 0;
  border-radius: 2px;
}

.faq-subtitle {
  max-width: 580px;
  font-family: var(--font-body);
  font-size: 0.9rem;
  line-height: 1.6;
  color: rgba(20, 24, 28, 0.68);
  font-weight: 400;
}

/* FAQ Accordion List (4 Items) */
.faq-accordion-list {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 2rem;
}

.faq-item {
  background: rgba(255, 255, 255, 0.82);
  border: 1px solid rgba(20, 24, 28, 0.08);
  border-left: 3px solid transparent;
  border-radius: 14px;
  padding: 1.25rem 1.6rem;
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  cursor: pointer;
  overflow: hidden;
  box-shadow: 0 10px 28px rgba(20, 24, 28, 0.05);
}

.faq-item:hover {
  background: #ffffff;
  border-color: rgba(220, 182, 88, 0.35);
  box-shadow: 0 14px 34px rgba(20, 24, 28, 0.08);
  transform: translateY(-2px);
}

.faq-item.active {
  background: #ffffff;
  border-color: rgba(220, 182, 88, 0.55);
  border-left: 3px solid var(--color-accent-amber, #DCB658);
  box-shadow: 0 16px 42px rgba(20, 24, 28, 0.1);
}

.faq-question-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  user-select: none;
}

.faq-question-title {
  font-family: var(--font-body, 'Manrope', system-ui, sans-serif);
  font-size: 1.05rem;
  font-weight: 600;
  color: #14181c;
  text-transform: none !important;
  letter-spacing: normal;
  line-height: 1.45;
  transition: color 0.3s ease;
}

.faq-item.active .faq-question-title {
  color: #14181c;
}

.faq-icon-toggle {
  width: 32px;
  height: 32px;
  flex-shrink: 0;
  border-radius: 50%;
  background: #f0ebe1;
  border: 1px solid rgba(20, 24, 28, 0.08);
  color: #14181c;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.35s ease;
}

.faq-item:hover .faq-icon-toggle {
  border-color: var(--color-accent-amber, #DCB658);
  color: var(--color-accent-amber, #DCB658);
}

.faq-item.active .faq-icon-toggle {
  background: var(--color-accent-amber, #DCB658);
  border-color: var(--color-accent-amber, #DCB658);
  color: #0a0c0e;
  transform: rotate(180deg);
}

/* FAQ Answer Animation */
.faq-answer-content {
  max-height: 0;
  opacity: 0;
  overflow: hidden;
  transition: max-height 0.45s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.35s ease, margin-top 0.35s ease;
  margin-top: 0;
}

.faq-item.active .faq-answer-content {
  max-height: 260px;
  opacity: 1;
  margin-top: 0.85rem;
}

.faq-answer-text {
  font-family: var(--font-body);
  font-size: 0.92rem;
  line-height: 1.6;
  color: rgba(20, 24, 28, 0.72);
  font-weight: 400;
  padding-top: 0;
  margin: 0;
}

/* Bottom CTA Contact Box (Shifted to Left Column) */
.faq-footer-box {
  width: 100%;
  margin-top: 2.2rem;
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.32);
  border-radius: 16px;
  padding: 1.25rem 1.6rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1.2rem;
  box-shadow: 0 14px 35px rgba(20, 24, 28, 0.08);
  flex-wrap: wrap;
}

.faq-footer-info h4 {
  font-family: var(--font-heading);
  font-size: 1.12rem;
  font-weight: 400;
  color: #14181c;
  margin-bottom: 0.2rem;
}

.faq-footer-info p {
  font-family: var(--font-body);
  font-size: 0.82rem;
  color: rgba(20, 24, 28, 0.62);
}

.faq-contact-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  background: var(--color-accent-amber, #DCB658);
  color: #0a0c0e;
  font-family: var(--font-body);
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 0.75rem 1.5rem;
  border-radius: 9999px;
  text-decoration: none;
  transition: all 0.3s ease;
  box-shadow: 0 6px 20px rgba(220, 182, 88, 0.3);
}

.faq-contact-btn:hover {
  background: #14181c;
  color: #ffffff;
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(20, 24, 28, 0.22);
}

/* Unified Premium Button Typography */
:is(button,
  .nav-btn,
  .btn-primary,
  .btn-secondary,
  .about-cta-btn,
  .location-cta-btn,
  .villa-tab-btn,
  .villa-btn,
  .amenity-tab-btn,
  .amenity-view-btn,
  .modal-book-btn,
  .investment-brochure-btn,
  .faq-contact-btn) {
  font-family: var(--font-heading) !important;
  font-size: 0.72rem !important;
  font-weight: 700 !important;
  letter-spacing: 0.12em !important;
  text-transform: uppercase !important;
}

:is(.sound-toggle-btn, .nav-arrow-btn, .amenities-nav-btn, .testimonial-nav-btn) {
  font-size: 0 !important;
}

/* Unified Section Heading Size */
:is(.about-title,
  .location-title,
  .villas-title,
  .amenities-title,
  .investment-title,
  .testimonials-title,
  .gallery-title,
  .faq-title) {
  font-size: 42px !important;
  font-weight: 500 !important;
}

/* Unified Section Heading Underline */
:is(.about-title,
  .location-title,
  .villas-title,
  .amenities-title,
  .investment-title,
  .testimonials-title,
  .gallery-title,
  .faq-title)::after {
  content: '';
  display: block;
  width: 32px;
  height: 2px;
  background: var(--color-accent-amber);
  border-radius: 2px;
  margin: 0.75rem auto 0.85rem auto;
}

.investment-header-line,
.faq-header-line {
  display: none;
}

:is(.about-info-content .about-title,
  .location-info-content .location-title,
  .faq-header .faq-title)::after {
  margin-left: 0;
  margin-right: auto;
}

.about-title::after {
  background: #DCB658 !important;
}

.villas-title::after {
  background: #DCB658 !important;
}

/* Unified Section Heading Description Size */
:is(.about-paragraph,
  .location-narrative,
  .villas-subtitle,
  .amenities-subtitle,
  .investment-subtitle,
  .testimonials-subtitle,
  .gallery-subtitle,
  .faq-subtitle) {
  font-size: 14px !important;
}

/* =========================================
   COMPREHENSIVE MOBILE & TABLET RESPONSIVE STYLES
   ========================================= */

/* Mobile Hamburger Menu Toggle Button */
.mobile-menu-toggle {
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 40px;
  height: 36px;
  padding: 8px 6px;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 8px;
  cursor: pointer;
  z-index: 10002;
  transition: all 0.3s ease;
}

.mobile-menu-toggle span {
  display: block;
  width: 100%;
  height: 2px;
  background-color: #ffffff;
  border-radius: 2px;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  transform-origin: center;
}

.mobile-menu-toggle.active {
  display: none !important;
  opacity: 0 !important;
  visibility: hidden !important;
  pointer-events: none !important;
}

.mobile-cta-wrapper {
  display: none;
}

/* =========================================
   COMPREHENSIVE MOBILE & TABLET RESPONSIVE STYLES
   ========================================= */

/* Sleek Circular Glass Mobile Hamburger Toggle Button */
.mobile-menu-toggle {
  display: none;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 5px;
  width: 38px;
  height: 38px;
  padding: 0;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 50%;
  cursor: pointer;
  z-index: 10002;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.mobile-menu-toggle span {
  display: block;
  width: 18px;
  height: 1.5px;
  background-color: #ffffff;
  border-radius: 1px;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.mobile-menu-toggle.active {
  display: none !important;
  opacity: 0 !important;
  visibility: hidden !important;
  pointer-events: none !important;
}

.mobile-cta-wrapper {
  display: none;
}

/* Tablet Breakpoint (max-width: 1024px) */
@media (max-width: 1024px) {
  .hero-header {
    padding: 1rem 1.5rem;
  }

  .about-grid,
  .location-grid,
  .investment-grid,
  .faq-main-grid {
    grid-template-columns: 1fr !important;
    gap: 3rem !important;
  }

  .luxury-map-card {
    border-radius: 16px;
  }

  .map-canvas-wrapper {
    height: 340px !important;
  }

  .featured-photo-card {
    position: relative !important;
    bottom: auto !important;
    right: auto !important;
    left: auto !important;
    width: 100% !important;
    border-radius: 0 0 16px 16px !important;
    box-shadow: none !important;
    border-top: 1px solid #e2e8f0 !important;
  }

  .consultation-form-card {
    padding: 2.2rem 1.8rem;
  }
}

/* Mobile & Small Tablet Breakpoint (max-width: 992px) */
@media (max-width: 992px) {
  .mobile-menu-toggle {
    display: flex;
  }

  .header-cta {
    display: none !important;
  }

  .nav-container {
    position: fixed;
    top: 0;
    right: 0;
    width: min(340px, 86vw);
    height: 100vh;
    background: #ffffff;
    backdrop-filter: none;
    -webkit-backdrop-filter: none;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 0;
    box-sizing: border-box;
    opacity: 1;
    visibility: hidden;
    transform: translateX(100%);
    transition: transform 0.38s cubic-bezier(0.16, 1, 0.3, 1);
    z-index: 99999;
    border-left: 1px solid #efe8da;
    box-shadow: -6px 0 25px rgba(0, 0, 0, 0.08);
    overflow-y: auto;
  }

  .nav-container.active {
    visibility: visible;
    transform: translateX(0);
  }

  .nav-links {
    flex-direction: column;
    gap: 0;
    align-items: stretch;
    text-align: center;
    width: 100%;
    max-width: 340px;
  }

  .nav-links li {
    width: 100%;
    display: flex;
    justify-content: center;
  }

  .nav-link {
    width: 100%;
    justify-content: center;
    padding: 1rem 0.5rem !important;
    border-radius: 0;
    border: 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    background: transparent;
    color: rgba(255, 255, 255, 0.88) !important;
    font-size: 0.86rem !important;
    letter-spacing: 0.16em;
    box-shadow: none;
  }

  .nav-link.active {
    color: #DCB658 !important;
    background: transparent;
    border-color: rgba(220, 182, 88, 0.4);
    text-shadow: 0 0 14px rgba(220, 182, 88, 0.28);
  }

  .nav-link::before {
    display: none;
  }

  .nav-dropdown {
    flex-direction: column;
    width: 100%;
  }

  .nav-dropdown-toggle::after {
    margin-left: 0.45rem;
  }

  .nav-dropdown-menu {
    position: static;
    width: 100%;
    min-width: 0;
    margin: 0;
    padding: 0.35rem 0 0.55rem 0;
    border-radius: 0;
    background: transparent;
    border: 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    opacity: 1;
    visibility: visible;
    transform: none;
    box-shadow: none;
  }

  .nav-dropdown-menu li {
    display: block;
  }

  .nav-dropdown-link {
    padding: 0.42rem 0.85rem;
    border-radius: 0;
    font-family: var(--font-body);
    font-size: 0.62rem;
    letter-spacing: 0.12em;
    color: rgba(255, 255, 255, 0.6);
  }

  .mobile-cta-wrapper {
    display: block;
    margin-top: 1.2rem;
    width: 100%;
    max-width: 360px;
    text-align: center;
  }

  .mobile-cta-wrapper .nav-btn {
    display: block;
    width: 100%;
    padding: 0.9rem 1.8rem;
    font-size: 0.78rem !important;
    text-align: center;
    background: rgba(84, 130, 132, 0.38);
    border-color: rgba(129, 204, 202, 0.52);
    border-radius: 9999px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.28);
  }

  .hero-header {
    padding: 0.85rem 1.25rem !important;
  }

  /* Scrolled floating header on mobile */
  .hero-header.scrolled {
    width: 94% !important;
    top: 0.6rem !important;
    padding: 0.5rem 1.25rem !important;
  }

  .hero-header.scrolled .brand-title {
    font-size: 1.1rem !important;
  }

  .hero-header.scrolled .brand-subtitle {
    display: block !important;
    font-size: 0.48rem !important;
    opacity: 0.85 !important;
  }

  /* Hide Hero Bottom Bar on Mobile */
  .hero-footer {
    display: none !important;
  }

  /* Force Center Alignment for All Section Headers, Titles, Subtitles, Paragraphs */
  :is(.hero-body,
    .title-slider-container,
    .title-slide,
    .about-info-content,
    .location-info-content,
    .villas-header,
    .amenities-header,
    .investment-header,
    .testimonials-header,
    .gallery-header,
    .faq-header,
    .footer-col,
    .footer-col--brand) {
    text-align: center !important;
    align-items: center !important;
    justify-content: center !important;
  }

  :is(.hero-title,
    .hero-subtitle,
    .about-title,
    .about-paragraph,
    .location-title,
    .location-narrative,
    .villas-title,
    .villas-subtitle,
    .amenities-title,
    .amenities-subtitle,
    .investment-title,
    .investment-subtitle,
    .testimonials-title,
    .testimonials-subtitle,
    .gallery-title,
    .gallery-subtitle,
    .faq-title,
    .faq-subtitle,
    .footer-col-heading,
    .footer-brand-desc,
    .footer-newsletter-heading,
    .footer-newsletter-sub) {
    text-align: center !important;
    margin-left: auto !important;
    margin-right: auto !important;
  }

  /* Center All Gold Underline Bars */
  :is(.about-title,
    .location-title,
    .villas-title,
    .amenities-title,
    .investment-title,
    .testimonials-title,
    .gallery-title,
    .faq-title,
    .footer-newsletter-heading)::after {
    margin-left: auto !important;
    margin-right: auto !important;
  }

  /* Center All Buttons & CTAs */
  :is(.hero-actions,
    .about-cta-wrapper,
    .location-cta-wrapper,
    .villas-cta-row,
    .faq-footer-box) {
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    width: 100% !important;
    margin-left: auto !important;
    margin-right: auto !important;
    gap: 0.85rem !important;
  }

  :is(.btn-primary,
    .btn-secondary,
    .about-cta-btn,
    .location-cta-btn,
    .villa-btn,
    .consultation-submit-btn,
    .faq-contact-btn,
    .footer-enquire-btn,
    .footer-newsletter-btn) {
    margin-left: auto !important;
    margin-right: auto !important;
    align-self: center !important;
    text-align: center !important;
    justify-content: center !important;
  }

  /* Hero Specs Bar - Force Single Row in Mobile View */
  .hero-specs-bar {
    display: flex !important;
    flex-direction: row !important;
    flex-wrap: nowrap !important;
    justify-content: space-around !important;
    align-items: center !important;
    margin: 1.5rem auto 0 auto !important;
    width: 100% !important;
    max-width: 100% !important;
    padding: 0.6rem 0.3rem !important;
    text-align: center !important;
    box-sizing: border-box !important;
    gap: 0.15rem !important;
  }

  .hero-specs-bar .spec-item {
    flex: 1 1 0px !important;
    min-width: 0 !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    justify-content: center !important;
    text-align: center !important;
  }

  .hero-specs-bar .spec-value {
    font-size: 1.1rem !important;
    line-height: 1.1 !important;
    white-space: nowrap !important;
  }

  .hero-specs-bar .spec-label {
    font-size: 0.48rem !important;
    letter-spacing: 0.02em !important;
    line-height: 1.2 !important;
    margin-top: 0.15rem !important;
    white-space: nowrap !important;
    opacity: 0.9 !important;
  }

  .hero-specs-bar .spec-divider {
    display: block !important;
    width: 1px !important;
    height: 22px !important;
    background: rgba(255, 255, 255, 0.2) !important;
    margin: 0 0.1rem !important;
    flex-shrink: 0 !important;
  }

  .hero-footer-inner {
    display: block !important;
    align-items: center !important;
    text-align: center !important;
    padding: 1.1rem 1rem 0.9rem 1rem !important;
  }

  .footer-description {
    display: none !important;
  }

  .stats-grid {
    display: flex !important;
    flex-direction: row !important;
    flex-wrap: nowrap !important;
    justify-content: space-between !important;
    align-items: center !important;
    gap: 0.45rem !important;
    width: 100% !important;
    max-width: 430px !important;
    margin: 0 auto !important;
    border-top: 0 !important;
    padding-top: 0 !important;
  }

  .stat-item {
    flex: 1 1 0 !important;
    text-align: center !important;
    align-items: center !important;
    min-width: 0 !important;
  }

  .stat-number {
    font-size: 1.35rem !important;
    line-height: 1 !important;
    margin-bottom: 0.35rem !important;
  }

  .stat-label {
    font-size: 0.56rem !important;
    line-height: 1.1 !important;
    letter-spacing: 0.08em !important;
    white-space: nowrap !important;
  }

  /* About Image Stack Collage Fix */
  .about-image-stack {
    position: relative !important;
    width: 100% !important;
    max-width: 520px !important;
    margin: 0 auto !important;
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
  }

  .about-main-card,
  .about-main-img {
    width: 100% !important;
    border-radius: 18px !important;
  }

  .about-secondary-card {
    position: relative !important;
    width: 88% !important;
    margin: -45px auto 0 auto !important;
    top: auto !important;
    bottom: auto !important;
    left: auto !important;
    right: auto !important;
    z-index: 10 !important;
    border-radius: 16px !important;
    box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35) !important;
  }

  /* Villa Showcase Filter Tabs Fix (Screenshot 3 Fix) */
  .villa-filter-tabs {
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
    padding: 0 !important;
    display: flex !important;
    flex-wrap: wrap !important;
    justify-content: center !important;
    gap: 0.6rem !important;
    width: 100% !important;
    margin: 1.5rem auto 0 auto !important;
    border-radius: 0 !important;
  }

  .villa-tab-btn {
    background: rgba(255, 255, 255, 0.08) !important;
    border: 1px solid rgba(255, 255, 255, 0.18) !important;
    border-radius: 9999px !important;
    padding: 0.55rem 1.25rem !important;
    font-size: 0.72rem !important;
    letter-spacing: 0.08em !important;
    text-transform: uppercase !important;
    color: #ffffff !important;
    transition: all 0.3s ease !important;
    flex-shrink: 0 !important;
  }

  .villa-tab-btn.active {
    background: #DCB658 !important;
    color: #07090b !important;
    border-color: #DCB658 !important;
    box-shadow: 0 6px 20px rgba(220, 182, 88, 0.3) !important;
  }

  /* Footer Layout Centering */
  .footer-main-inner {
    grid-template-columns: 1fr !important;
    text-align: center !important;
    justify-items: center !important;
    gap: 2.5rem !important;
  }

  .footer-logo-link {
    justify-content: center !important;
    text-align: center !important;
    margin: 0 auto 1.25rem auto !important;
  }

  .footer-brand-copy {
    align-items: center !important;
    text-align: center !important;
  }

  .footer-brand-desc {
    text-align: center !important;
    margin: 0 auto 1.5rem auto !important;
    max-width: 380px !important;
  }

  .footer-social-row {
    justify-content: center !important;
    margin: 0 auto !important;
  }

  .footer-col {
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-nav-list {
    align-items: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-rera-badge {
    align-items: center !important;
    text-align: center !important;
    margin: 1.5rem auto 0 auto !important;
    width: fit-content !important;
  }

  /* Section Padding & Unified Widths */
  :is(.about-section,
    .location-section,
    .villas-section,
    .amenities-section,
    .investment-section,
    .testimonials-section,
    .gallery-section,
    .faq-section) {
    padding: 50px 5% !important;
    width: 100% !important;
    max-width: 100% !important;
  }

  :is(.about-title,
    .location-title,
    .villas-title,
    .amenities-title,
    .investment-title,
    .testimonials-title,
    .gallery-title,
    .faq-title) {
    font-size: 28px !important;
  }
}

/* Phone Breakpoint (max-width: 768px) */
@media (max-width: 768px) {
  .hero-body {
    margin: auto !important;
    padding: 6.5rem 5% 2rem 5% !important;
    transform: none !important;
  }

  .title-slider-container {
    min-height: 165px !important;
  }

  .hero-title {
    font-size: 2.2rem !important;
    font-weight: 500 !important;
    line-height: 1.2 !important;
  }

  .hero-subtitle {
    font-size: 0.9rem !important;
  }

  .hero-stats-bar {
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 1.25rem !important;
  }

  .villas-grid {
    grid-template-columns: 1fr !important;
    gap: 2rem !important;
  }

  .location-places-grid {
    grid-template-columns: 1fr !important;
    gap: 0.75rem !important;
  }

  .place-grid-card {
    padding: 0.85rem 1.1rem !important;
    width: 100% !important;
  }

  .amenities-filter-tabs,
  .amenity-tabs,
  .faq-tabs {
    overflow-x: auto !important;
    flex-wrap: wrap !important;
    justify-content: center !important;
    gap: 0.75rem !important;
    padding-bottom: 0.5rem !important;
    -webkit-overflow-scrolling: touch;
    width: 100% !important;
  }

  .amenity-tab-btn,
  .faq-tab-btn {
    flex-shrink: 0 !important;
    white-space: nowrap !important;
  }

  .investment-item {
    padding: 1rem 1rem !important;
  }

  .investment-item-header {
    align-items: center !important;
    gap: 0.85rem !important;
  }

  .investment-item-body {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }

  .investment-item.active .investment-item-body {
    margin-top: 0.75rem !important;
    max-height: 180px !important;
  }

  .investment-item-desc {
    padding-left: calc(42px + 0.85rem) !important;
    padding-right: 0 !important;
    text-align: left !important;
  }

  .amenity-card {
    min-width: 60vw !important;
  }

  .amenity-card-body {
    justify-content: flex-start !important;
    padding: 1.55rem 1.2rem 1.15rem 1.2rem !important;
  }

  .amenity-card-title {
    margin-bottom: 0.35rem !important;
  }

  .amenity-card-desc {
    margin-bottom: 0.9rem !important;
    line-height: 1.45 !important;
  }

  .amenity-view-btn {
    padding: 0.25rem 0 !important;
  }

  .consultation-form-card {
    padding: 1.8rem 1.25rem !important;
  }

  .consultation-input,
  .consultation-select,
  .consultation-textarea {
    font-size: 16px !important; /* Prevents auto zoom on iOS */
    padding: 0.85rem 1rem !important;
  }
}

/* Extra Small Phones (max-width: 480px) */
@media (max-width: 480px) {
  .hero-body {
    margin: auto !important;
    padding-top: 6rem !important;
    padding-bottom: 1.5rem !important;
  }

  .title-slider-container {
    min-height: 150px !important;
  }

  .hero-title {
    font-size: 1.85rem !important;
    font-weight: 500 !important;
  }

  .amenities-filter-tabs {
    gap: 0.65rem !important;
    padding-bottom: 0 !important;
  }

  .amenities-header {
    margin-bottom: 1.5rem !important;
  }

  .amenities-slider-track {
    padding-top: 2.5rem !important;
  }

  .amenity-tab-btn {
    padding: 0.65rem 1.35rem !important;
  }

  .amenity-card-body {
    padding-top: 1.45rem !important;
    padding-bottom: 1rem !important;
  }

  .investment-item {
    padding: 0.95rem 0.95rem !important;
  }

  .investment-item-title {
    font-size: 1rem !important;
  }

  .investment-item-desc {
    font-size: 0.82rem !important;
    line-height: 1.55 !important;
  }

  .hero-stats-bar {
    grid-template-columns: 1fr !important;
  }

  .brand-title {
    font-size: 1.15rem !important;
  }

  .brand-subtitle {
    display: block !important;
    font-size: 0.5rem !important;
    color: var(--color-gold-light, #d4af37) !important;
    margin-top: 1px !important;
  }

  .map-canvas-wrapper {
    height: 300px !important;
  }

  .amenity-modal-content {
    padding: 1.5rem 1.2rem !important;
    width: 95vw !important;
  }

  :is(.about-title,
    .location-title,
    .villas-title,
    .amenities-title,
    .investment-title,
    .testimonials-title,
    .gallery-title,
    .faq-title) {
    font-size: 28px !important;
  }
}


/* =========================================
   BLOG / ARCHITECTURAL JOURNAL SECTION
   ========================================= */
.blog-section {
  position: relative;
  width: 100%;
  padding: 4.5rem 5vw;
  background-color: #07090b;
  overflow: hidden;
  color: #ffffff;
}

.blog-video-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
  overflow: hidden;
}

.blog-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.95;
  filter: brightness(1) contrast(1.05);
  transform: scale(1.05);
  transition: transform 10s ease;
}

.blog-section:hover .blog-video {
  transform: scale(1);
}

.blog-video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: radial-gradient(circle at center, rgba(7, 9, 11, 0.15) 0%, rgba(7, 9, 11, 0.45) 80%, rgba(7, 9, 11, 0.7) 100%),
              linear-gradient(180deg, rgba(7, 9, 11, 0.45) 0%, rgba(7, 9, 11, 0.25) 50%, rgba(7, 9, 11, 0.6) 100%);
  z-index: 2;
}

.blog-container {
  position: relative;
  z-index: 3;
  max-width: 1380px;
  margin: 0 auto;
}

/* Header Centered Layout */
.blog-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  max-width: 720px;
  margin: 0 auto 2.8rem auto;
}

.blog-tagline {
  display: inline-block;
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: #DCB658;
  margin-bottom: 0.5rem;
}

.blog-title {
  font-family: var(--font-heading);
  font-size: clamp(2rem, 3.5vw, 2.7rem);
  font-weight: 400;
  line-height: 1.2;
  color: #ffffff;
  letter-spacing: -0.5px;
  margin-bottom: 0.5rem;
  text-align: center;
}

.blog-title::after {
  content: '';
  display: block;
  width: 32px;
  height: 2px;
  background: var(--color-accent-amber, #DCB658);
  border-radius: 2px;
  margin: 0.75rem auto 0.85rem auto;
}

.blog-subtitle {
  font-family: var(--font-body);
  font-size: 0.92rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.75);
  text-align: center;
  margin-bottom: 1.25rem;
  max-width: 620px;
}

.blog-header-cta,
.blog-footer-cta {
  display: flex;
  justify-content: center;
  margin-top: 2.5rem;
}

.blog-header-link {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.65rem 1.4rem;
  font-family: var(--font-body);
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 0.5px;
  color: #ffffff;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 40px;
  text-decoration: none;
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}

.blog-header-link:hover {
  background: #DCB658;
  border-color: #DCB658;
  color: #07090b;
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(220, 182, 88, 0.28);
}

.blog-header-link svg {
  transition: transform 0.3s ease;
}

.blog-header-link:hover svg {
  transform: translateX(4px);
}

/* Grid & Compact Cards */
.blog-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
}

.blog-card {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1px solid rgba(220, 182, 88, 0.28);
  border-radius: 18px;
  overflow: hidden;
  transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 14px 35px rgba(0, 0, 0, 0.18);
}

.blog-card:hover {
  transform: translateY(-6px);
  border-color: #DCB658;
  box-shadow: 0 22px 45px rgba(0, 0, 0, 0.28), 0 0 25px rgba(220, 182, 88, 0.25);
  background: #ffffff;
}

.blog-card-media {
  position: relative;
  width: 100%;
  height: 200px;
  overflow: hidden;
}

.blog-card-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.blog-card:hover .blog-card-img {
  transform: scale(1.08);
}

.blog-card-category {
  position: absolute;
  top: 1rem;
  left: 1rem;
  z-index: 3;
  font-family: var(--font-body);
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 1.2px;
  text-transform: uppercase;
  color: #ffffff;
  background: rgba(10, 12, 14, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.2);
  padding: 4px 10px;
  border-radius: 20px;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
}

.blog-card-media-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0.05) 0%, rgba(255, 255, 255, 0.15) 100%);
  z-index: 2;
}

.blog-card-body {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  padding: 1.4rem 1.5rem 1.6rem 1.5rem;
}

.blog-card-meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 1px;
  color: #9e7b23;
  margin-bottom: 0.65rem;
}

.blog-meta-divider {
  color: rgba(20, 24, 28, 0.3);
}

.blog-card-title {
  font-family: var(--font-heading);
  font-size: 1.2rem;
  font-weight: 500;
  line-height: 1.35;
  color: #14181c;
  margin-bottom: 0.65rem;
  transition: color 0.3s ease;
}

.blog-card:hover .blog-card-title {
  color: #9e7b23;
}

.blog-card-excerpt {
  font-family: var(--font-body);
  font-size: 0.86rem;
  line-height: 1.55;
  color: rgba(20, 24, 28, 0.72);
  margin-bottom: 1.2rem;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.blog-card-readmore {
  margin-top: auto;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  font-family: var(--font-body);
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: #14181c;
  text-decoration: none;
  transition: all 0.3s ease;
}

.blog-card-readmore svg {
  transition: transform 0.3s ease;
}

.blog-card:hover .blog-card-readmore {
  color: #9e7b23;
}

.blog-card:hover .blog-card-readmore svg {
  transform: translateX(4px);
}

/* Responsive */
@media (max-width: 1200px) {
  .blog-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
  }
}

@media (max-width: 768px) {
  .blog-section {
    padding: 3.5rem 5%;
  }
  .blog-grid {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
  .blog-header {
    margin-bottom: 2rem;
  }
}


/* ==========================================================================
   FOOTER STYLES
   ========================================================================== */

/* â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
   SITE FOOTER â€” Pure White Text Update
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• */

/* Global Footer Base Text Settings */
.site-footer {
  color: #ffffff !important;
}

.site-footer a {
  color: #ffffff !important;
  text-decoration: none;
}

/* â”€â”€ Newsletter Banner â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-newsletter-banner {
  position: relative;
  overflow: hidden;
  min-height: 240px;
  display: flex;
  align-items: center;
  background: #080A0C;
}

/* Background video */
.footer-newsletter-video {
  position: absolute;
  top: 50%;
  left: 50%;
  min-width: 100%;
  min-height: 100%;
  width: auto;
  height: auto;
  object-fit: cover;
  transform: translate(-50%, -50%);
  opacity: 0.78;
  filter: brightness(0.92) contrast(1.06);
  z-index: 1;
}

/* Dark overlay on video */
.footer-newsletter-overlay {
  position: absolute;
  inset: 0;
  z-index: 2;
  background: linear-gradient(135deg, rgba(4, 5, 6, 0.6) 0%, rgba(7, 9, 11, 0.38) 50%, rgba(4, 5, 6, 0.65) 100%);
  pointer-events: none;
}

.footer-newsletter-inner {
  position: relative;
  z-index: 3;
  max-width: 1340px;
  width: 100%;
  margin: 0 auto;
  padding: 45px 1.5rem;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 3rem;
}

.footer-newsletter-text {
  flex: 1;
}

.footer-newsletter-eyebrow {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.14em;
  color: #81CCCA !important;
  margin-bottom: 0.5rem;
}

.footer-newsletter-heading {
  font-family: var(--font-heading);
  font-size: clamp(1.6rem, 2.5vw, 2.4rem);
  font-weight: 400;
  color: #ffffff !important;
  letter-spacing: 0.02em;
  margin-bottom: 0.5rem;
  line-height: 1.2;
}

.footer-newsletter-heading::after {
  content: '';
  display: block;
  width: 32px;
  height: 2px;
  background: #DCB658;
  border-radius: 2px;
  margin-top: 0.5rem;
  margin-bottom: 0.5rem;
}

.footer-newsletter-sub {
  font-family: var(--font-body);
  font-size: 0.88rem;
  color: #ffffff !important;
  opacity: 0.9;
  line-height: 1.6;
}

.footer-newsletter-form {
  display: flex;
  gap: 0;
  flex-shrink: 0;
  width: min(480px, 100%);
  border-radius: 9999px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.footer-newsletter-form:focus-within {
  border-color: rgba(129, 204, 202, 0.6);
  box-shadow: 0 0 0 3px rgba(129, 204, 202, 0.12);
}

.footer-newsletter-input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  padding: 0.9rem 1.4rem;
  font-family: var(--font-body);
  font-size: 0.88rem;
  color: #ffffff !important;
  min-width: 0;
}

.footer-newsletter-input::placeholder {
  color: rgba(255, 255, 255, 0.6) !important;
}

.footer-newsletter-btn {
  flex-shrink: 0;
  background: #DCB658;
  border: none;
  color: #07090b !important;
  font-family: var(--font-body);
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  padding: 0.9rem 1.6rem;
  cursor: pointer;
  transition: background 0.3s ease;
  white-space: nowrap;
}

.footer-newsletter-btn:hover {
  background: #e8c76a;
}

/* â”€â”€ Main Footer Body â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-main {
  background: #07090b;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
}

.footer-main-inner {
  max-width: 1340px;
  width: 100%;
  margin: 0 auto;
  padding: 40px 0 2.5rem 0;
  box-sizing: border-box;
  display: grid;
  grid-template-columns: 1.6fr 1fr 1.2fr 1fr;
  gap: 3rem;
  align-items: start;
}

/* â”€â”€ Brand Column â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-logo-link {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  text-decoration: none;
  margin-bottom: 1.25rem;
}

.footer-logo-img {
  width: 52px;
  height: 52px;
  object-fit: contain;
  display: block;
  filter: drop-shadow(0 2px 8px rgba(220, 182, 88, 0.25));
}

.footer-brand-copy {
  display: flex;
  flex-direction: column;
}

.footer-brand-name {
  font-family: var(--font-heading);
  font-size: 1.45rem;
  font-weight: 400;
  color: #ffffff !important;
  letter-spacing: 0;
  line-height: 1.05;
  white-space: nowrap;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
}

.footer-brand-subtitle {
  font-family: var(--font-body);
  font-size: 0.58rem;
  letter-spacing: 0.02em;
  text-transform: none;
  color: #ffffff !important;
  opacity: 0.95;
  margin-top: 4px;
  font-weight: 700;
  white-space: nowrap;
}

.footer-brand-desc {
  font-family: var(--font-body);
  font-size: 0.86rem;
  line-height: 1.75;
  color: #ffffff !important;
  opacity: 0.9;
  margin-bottom: 1.75rem;
  max-width: 280px;
}

.footer-social-row {
  display: flex;
  gap: 0.6rem;
}

.footer-social-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: #ffffff !important;
  text-decoration: none;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.footer-social-btn svg {
  color: #ffffff !important;
}

.footer-social-btn:hover {
  background: rgba(129, 204, 202, 0.2);
  border-color: rgba(129, 204, 202, 0.6);
  color: #81CCCA !important;
  transform: translateY(-3px);
}

.footer-social-btn:hover svg {
  color: #81CCCA !important;
}

/* â”€â”€ Nav Columns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-col-heading {
  font-family: var(--font-body);
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.14em;
  color: #DCB658 !important;
  margin-bottom: 1.4rem;
  position: relative;
  padding-bottom: 0.75rem;
}

.footer-col-heading::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 28px;
  height: 1px;
  background: #DCB658;
  opacity: 0.45;
}

.footer-nav-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 0.65rem;
}

.footer-nav-link {
  font-family: var(--font-body);
  font-size: 0.875rem;
  color: #ffffff !important;
  text-decoration: none;
  transition: color 0.25s ease, padding-left 0.25s ease;
  display: inline-block;
}

.footer-nav-link:hover {
  color: #81CCCA !important;
  padding-left: 6px;
}

/* â”€â”€ Contact Column â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-contact-list {
  list-style: none;
  padding: 0;
  margin: 0 0 1.5rem 0;
  display: flex;
  flex-direction: column;
  gap: 0.9rem;
}

.footer-contact-item {
  display: flex;
  align-items: flex-start;
  gap: 0.65rem;
  font-family: var(--font-body);
  font-size: 0.855rem;
  color: #ffffff !important;
  line-height: 1.55;
}

.footer-contact-item a {
  color: #ffffff !important;
  text-decoration: none;
  transition: color 0.25s ease;
}

.footer-contact-item a:hover {
  color: #81CCCA !important;
}

.footer-contact-item svg {
  flex-shrink: 0;
  margin-top: 2px;
  color: #81CCCA !important;
}

.footer-enquire-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  font-family: var(--font-body);
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: #07090b !important;
  background: #DCB658;
  border: none;
  padding: 0.7rem 1.4rem;
  border-radius: 9999px;
  text-decoration: none;
  transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  margin-top: 0.5rem;
}

.footer-enquire-btn:hover {
  background: #e8c76a;
  color: #07090b !important;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(220, 182, 88, 0.3);
}

.footer-enquire-btn svg {
  transition: transform 0.3s ease;
  color: #07090b !important;
}

.footer-enquire-btn:hover svg {
  transform: translateX(4px);
}

/* â”€â”€ RERA Badge â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-rera-badge {
  margin-top: 1.5rem;
  padding: 0.75rem 1rem;
  background: rgba(220, 182, 88, 0.07);
  border: 1px solid rgba(220, 182, 88, 0.2);
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.footer-rera-label {
  font-family: var(--font-body);
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  color: #DCB658 !important;
}

.footer-rera-number {
  font-family: var(--font-body);
  font-size: 0.82rem;
  color: #ffffff !important;
  letter-spacing: 0.04em;
}

/* â”€â”€ Bottom Bar â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
.footer-bottom {
  background: #040506;
  border-top: 1px solid rgba(255, 255, 255, 0.06);
}

.footer-bottom-inner {
  max-width: 1340px;
  width: 100%;
  margin: 0 auto;
  padding: 1.25rem 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}

.footer-copyright,
.footer-crafted {
  font-family: var(--font-body);
  font-size: 0.78rem;
  color: #ffffff !important;
  opacity: 0.8;
}

/* â”€â”€ Footer Responsive â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
@media (max-width: 1400px) {
  .footer-newsletter-inner,
  .footer-main-inner,
  .footer-bottom-inner {
    padding-left: 5%;
    padding-right: 5%;
  }
}

@media (max-width: 992px) {
  .footer-newsletter-inner {
    flex-direction: column !important;
    text-align: center !important;
    align-items: center !important;
    gap: 1.8rem !important;
    padding: 40px 5% !important;
  }

  .footer-newsletter-text {
    text-align: center !important;
    align-items: center !important;
  }

  .footer-newsletter-heading {
    text-align: center !important;
  }

  .footer-newsletter-heading::after {
    margin-left: auto !important;
    margin-right: auto !important;
  }

  .footer-newsletter-sub {
    text-align: center !important;
    margin-left: auto !important;
    margin-right: auto !important;
  }

  .footer-newsletter-form {
    width: 100% !important;
    max-width: 480px !important;
    margin: 0 auto !important;
  }

  .footer-main-inner {
    grid-template-columns: 1fr !important;
    gap: 2.5rem !important;
    text-align: center !important;
    justify-items: center !important;
    padding: 40px 5% 2.5rem 5% !important;
  }

  .footer-logo-link {
    justify-content: center !important;
    margin-left: auto !important;
    margin-right: auto !important;
  }

  .footer-brand-copy {
    align-items: center !important;
    text-align: center !important;
  }

  .footer-brand-desc {
    text-align: center !important;
    margin-left: auto !important;
    margin-right: auto !important;
    max-width: 380px !important;
  }

  .footer-social-row {
    justify-content: center !important;
    margin-left: auto !important;
    margin-right: auto !important;
  }

  .footer-col {
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-col-heading {
    text-align: center !important;
    width: 100% !important;
  }

  .footer-col-heading::after {
    left: 50% !important;
    transform: translateX(-50%) !important;
  }

  .footer-nav-list {
    align-items: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-nav-link {
    text-align: center !important;
  }

  .footer-contact-list {
    align-items: center !important;
    justify-content: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-contact-item {
    justify-content: center !important;
    text-align: center !important;
    width: 100% !important;
  }

  .footer-rera-badge {
    align-items: center !important;
    text-align: center !important;
    margin: 1.5rem auto 0 auto !important;
  }

  .footer-bottom-inner {
    flex-direction: column !important;
    text-align: center !important;
    gap: 0.5rem !important;
  }
}

@media (max-width: 480px) {
  .footer-newsletter-form {
    flex-direction: column !important;
    border-radius: 16px !important;
    background: transparent !important;
    border: none !important;
    gap: 0.75rem !important;
  }

  .footer-newsletter-input {
    width: 100% !important;
    background: rgba(255, 255, 255, 0.08) !important;
    border: 1px solid rgba(255, 255, 255, 0.2) !important;
    border-radius: 9999px !important;
    text-align: center !important;
    box-sizing: border-box !important;
  }

  .footer-newsletter-btn {
    width: 100% !important;
    border-radius: 9999px !important;
    text-align: center !important;
    justify-content: center !important;
  }
}



/* =========================================
   1 BHK RESIDENCE HERO SLIDER & REDESIGNED SECTIONS
   ========================================= */
.residence-plum-page {
  background-color: #ffffff;
  color: #1a1a1a;
  font-family: var(--font-body);
}

/* 1. Hero Gallery Slider Container */
.hero-slider-container {
  position: relative;
  max-width: 1320px;
  margin: 85px auto 0 auto;
  padding: 0 1rem;
  overflow: hidden;
}

.hero-slider-track {
  display: flex;
  transition: transform 0.5s cubic-bezier(0.25, 1, 0.5, 1);
  gap: 12px;
}

.hero-slide-item {
  min-width: 50%;
  height: 460px;
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  flex-shrink: 0;
}

@media (max-width: 768px) {
  .hero-slide-item {
    min-width: 100%;
    height: 320px;
  }
}

.hero-slide-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.6s ease;
}

.hero-slide-item:hover .hero-photo-img,
.hero-slide-item:hover .hero-slide-img {
  transform: scale(1.04);
}

/* Slider Arrow Controls */
.slider-arrow-btn {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  z-index: 10;
  width: 46px;
  height: 46px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(0, 0, 0, 0.12);
  color: #1a1a1a;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
  transition: all 0.25 ease;
}

.slider-arrow-btn:hover {
  background: #ffffff;
  transform: translateY(-50%) scale(1.08);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.22);
}

.slider-arrow-prev {
  left: 2rem;
}

.slider-arrow-next {
  right: 2rem;
}

/* Slide Dots Indicator */
.slider-dots-box {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-top: 1rem;
}

.slider-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #e0e0e0;
  cursor: pointer;
  transition: all 0.3s ease;
}

.slider-dot.active {
  background: #c5a059;
  width: 28px;
  border-radius: 9999px;
}

/* Floating View All Photos Button */
.view-photos-btn {
  position: absolute;
  bottom: 1.25rem;
  right: 2rem;
  z-index: 5;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(0, 0, 0, 0.12);
  border-radius: 8px;
  padding: 0.65rem 1.3rem;
  font-size: 0.85rem;
  font-weight: 800;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: #1a1a1a;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.12);
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.view-photos-btn:hover {
  background: #ffffff;
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.18);
}

/* Two Column Layout Container */
.plum-layout-container {
  max-width: 1320px;
  margin: 2.5rem auto 4rem auto;
  padding: 0 1.5rem;
  display: grid;
  grid-template-columns: 1fr 380px;
  gap: 4rem;
}

@media (max-width: 1024px) {
  .plum-layout-container {
    grid-template-columns: 1fr;
    gap: 2.5rem;
  }
}

/* Left Main Content Column */
.plum-main-col {
  display: flex;
  flex-direction: column;
  gap: 3rem;
}

/* Breadcrumbs */
.plum-breadcrumbs {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  color: #767676;
}

.plum-breadcrumbs a {
  color: #767676;
  text-decoration: none;
}

.plum-breadcrumbs a:hover {
  color: #1a1a1a;
  text-decoration: underline;
}

/* Title & Specs Header */
.plum-title {
  font-family: 'Marcellus', serif;
  font-size: clamp(2.4rem, 4vw, 3.4rem);
  font-weight: 400;
  color: #111111;
  letter-spacing: -0.02em;
  margin: 0.5rem 0 1rem 0;
  line-height: 1.15;
}

.plum-specs-bar {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  flex-wrap: wrap;
  font-size: 0.98rem;
  color: #484848;
  font-weight: 500;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid #ebebeb;
}

.plum-spec-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.plum-spec-item svg {
  width: 18px;
  height: 18px;
  fill: #c29f68;
}

/* REDESIGNED DETAILS SECTION (LUXURY CARD MATCHING SCREENSHOT STRICTLY) */
.plum-details-card-redesigned {
  background: #ffffff;
  border: 1px solid #e8e4db;
  border-left: 4px solid #c5a059;
  border-radius: 16px;
  padding: 2.25rem 2.5rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
}

.plum-details-heading {
  font-family: var(--font-body);
  font-size: 2rem;
  font-weight: 700;
  color: #000000;
  margin-bottom: 1.75rem;
  letter-spacing: -0.02em;
}

.plum-details-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem 2.5rem;
}

@media (max-width: 640px) {
  .plum-details-grid {
    grid-template-columns: 1fr;
  }
}

.plum-details-row {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  font-size: 1.12rem;
  color: #222222;
  font-weight: 600;
}

.plum-details-icon {
  width: 44px;
  height: 44px;
  flex-shrink: 0;
  border-radius: 10px;
  background: #fbf7ef;
  border: 1px solid #efe6d3;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c29f68;
}

.plum-details-icon svg {
  width: 30px;
  height: 30px;
  fill: currentColor;
}

.plum-details-lbl {
  color: #2b2b2b;
  font-weight: 700;
}

.plum-details-val {
  color: #7a633a;
  font-weight: 700;
}

/* REDESIGNED AMENITIES SECTION */
.amenities-redesigned-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem;
  margin-top: 1.5rem;
}

@media (max-width: 640px) {
  .amenities-redesigned-grid {
    grid-template-columns: 1fr;
  }
}

.amenity-redesigned-card {
  background: #fdfcf9;
  border: 1px solid #eae5db;
  border-radius: 12px;
  padding: 1.4rem 1.6rem;
  display: flex;
  align-items: flex-start;
  gap: 1.25rem;
  transition: all 0.3s ease;
}

.amenity-redesigned-card:hover {
  background: #ffffff;
  border-color: #c5a059;
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(197, 160, 89, 0.12);
}

.amenity-redesigned-icon {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  background: #f8f3e6;
  border: 1px solid #e7d8b8;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #a37d38;
  flex-shrink: 0;
}

.amenity-redesigned-icon svg {
  width: 22px;
  height: 22px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.amenity-redesigned-title {
  font-size: 1.05rem;
  font-weight: 700;
  color: #111111;
  margin-bottom: 0.25rem;
}

.amenity-redesigned-desc {
  font-size: 0.88rem;
  color: #666666;
  line-height: 1.5;
}

/* REDESIGNED POLISHED FAQ ACCORDION */
.faq-redesigned-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1.5rem;
}

.faq-redesigned-card {
  background: #ffffff;
  border: 1px solid #e5e0d5;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.02);
  transition: all 0.3s ease;
}

.faq-redesigned-card.active {
  border-color: #c5a059;
  box-shadow: 0 8px 25px rgba(197, 160, 89, 0.14);
}

.faq-redesigned-btn {
  width: 100%;
  padding: 1.35rem 1.75rem;
  background: none;
  border: none;
  display: flex;
  align-items: center;
  justify-content: space-between;
  text-align: left;
  font-family: var(--font-body);
  font-size: 1.1rem;
  font-weight: 700;
  color: #111111;
  cursor: pointer;
  transition: color 0.3s ease;
}

.faq-redesigned-btn:hover {
  color: #a37d38;
}

.faq-redesigned-toggle-icon {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #f7f3e8;
  border: 1px solid #e4d8bc;
  color: #a37d38;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  font-weight: bold;
  transition: transform 0.3s ease, background-color 0.3s ease;
  flex-shrink: 0;
}

.faq-redesigned-card.active .faq-redesigned-toggle-icon {
  transform: rotate(45deg);
  background: #c5a059;
  color: #ffffff;
  border-color: #c5a059;
}

.faq-redesigned-content {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s cubic-bezier(0.25, 1, 0.5, 1), padding 0.4s ease;
  padding: 0 1.75rem;
}

.faq-redesigned-card.active .faq-redesigned-content {
  max-height: 400px;
  padding: 0 1.75rem 1.5rem 1.75rem;
}

.faq-redesigned-content p {
  font-size: 0.98rem;
  line-height: 1.75;
  color: #4a5056;
}

/* Sticky Sidebar Widget */
.plum-sidebar-col {
  position: relative;
}

.sticky-booking-widget {
  position: sticky;
  top: 100px;
  background: #ffffff;
  border: 1px solid #e2e2e2;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 12px 35px rgba(0, 0, 0, 0.08);
}

.booking-widget-header {
  margin-bottom: 1.5rem;
}

.booking-widget-price {
  font-size: 1.8rem;
  font-weight: 700;
  color: #111111;
}

.booking-widget-sub {
  font-size: 0.88rem;
  color: #717171;
}

.booking-inputs-box {
  border: 1px solid #b0b0b0;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 1.25rem;
}

.booking-input-row {
  padding: 0.85rem 1rem;
  background: #ffffff;
}

.booking-input-row:not(:last-child) {
  border-bottom: 1px solid #e2e2e2;
}

.booking-input-label {
  font-size: 0.72rem;
  font-weight: 800;
  text-transform: uppercase;
  color: #222222;
  letter-spacing: 0.04em;
  display: block;
}

.booking-input-field {
  width: 100%;
  border: none;
  background: transparent;
  font-size: 0.95rem;
  color: #222222;
  font-weight: 600;
  outline: none;
  font-family: inherit;
}

.booking-submit-btn-gold {
  width: 100%;
  padding: 1.1rem;
  background: linear-gradient(135deg, #ffc736 0%, #f5ab00 100%);
  border: none;
  border-radius: 12px;
  color: #111111;
  font-size: 1.05rem;
  font-weight: 800;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 6px 20px rgba(245, 171, 0, 0.35);
  margin-bottom: 1.5rem;
}

.booking-submit-btn-gold:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(245, 171, 0, 0.45);
  filter: brightness(1.05);
}

.ask-anything-box {
  border: 1px solid #e8e8e8;
  border-radius: 12px;
  padding: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fafafa;
  margin-top: 1.25rem;
}

.ask-anything-text p {
  font-size: 0.88rem;
  font-weight: 700;
  color: #222222;
}

.ask-anything-text span {
  font-size: 0.82rem;
  color: #717171;
}

.ask-chat-icon {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  background: #ffffff;
  border: 1px solid #e2e2e2;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #111111;
  flex-shrink: 0;
}
</style>



<style>

  /* =============================================
       FULL-WIDTH DARK HERO GALLERY SLIDER
    ============================================= */
    .residence-hero-fullwidth {
        position: relative;
        width: 100%;
        background: #0a0c0e;
        overflow: hidden;
        margin-top: 0;
    }

    .residence-hero-slider-track {
        display: flex;
        transition: transform 0.55s cubic-bezier(0.25, 1, 0.5, 1);
        width: 100%;
    }

    .residence-hero-slide {
        min-width: 100%;
        height: 100vh;
        min-height: 500px;
        max-height: 680px;
        position: relative;
        flex-shrink: 0;
        overflow: hidden;
    }

    @media (max-width: 768px) {
        .residence-hero-slide { height: 65vh; min-height: 380px; max-height: 500px; }
    }

    .residence-hero-slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.75;
        transition: transform 0.8s ease;
    }

    .residence-hero-slide.active img {
        transform: scale(1.04);
    }

    /* Dark overlay covering full hero for readability */
    .residence-hero-fullwidth::before {
        content: '';
        position: absolute;
        inset: 0;
        background: rgba(5, 7, 9, 0.42);
        z-index: 2;
        pointer-events: none;
    }

    /* Stronger bottom gradient so title text pops */
    .residence-hero-fullwidth::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 260px;
        background: linear-gradient(to top, rgba(5,7,9,0.95) 0%, rgba(5,7,9,0.3) 60%, transparent 100%);
        z-index: 3;
        pointer-events: none;
    }

    /* Hero bottom bar overlay (Desktop) */
    .hero-bottom-bar {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 6;
        padding: 2.5rem 3rem 2rem 3rem;
        background: linear-gradient(to top, rgba(5,7,9,0.95) 0%, rgba(5,7,9,0.4) 65%, transparent 100%);
        pointer-events: auto;
    }

    .hero-content-box {
        max-width: 1340px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 0.65rem;
    }

    .hero-breadcrumbs {
        display: flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.85rem;
        margin-bottom: 0.35rem;
    }

    .hero-info-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.4rem 1rem;
        background: rgba(197, 160, 89, 0.2);
        border: 1px solid rgba(197, 160, 89, 0.5);
        border-radius: 999px;
        color: #e0bc6d;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        margin-bottom: 0.45rem;
    }

    .hero-info-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(2rem, 3.5vw, 3.2rem);
        color: #ffffff;
        line-height: 1.2;
        text-shadow: 0 2px 12px rgba(0,0,0,0.4);
        margin: 0.35rem 0 0.75rem 0;
    }

    .hero-spec-pills-row {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 0.65rem;
    }

    /* Prev/Next Arrows */
    .hero-slider-arrow {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        z-index: 7;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(8px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.25s ease;
    }

    .hero-slider-arrow:hover {
        background: rgba(255, 255, 255, 0.28);
        transform: translateY(-50%) scale(1.08);
    }

    .hero-slider-arrow.prev { left: 1.5rem; }
    .hero-slider-arrow.next { right: 1.5rem; }

    /* Slide count & dots bottom-right */
    .hero-slide-counter {
        position: absolute;
        bottom: 2.25rem;
        right: 3rem;
        z-index: 7;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .hero-dots {
        display: flex;
        gap: 0.45rem;
    }

    .hero-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.4);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .hero-dot.active {
        background: #c5a059;
        width: 22px;
        border-radius: 999px;
    }

    .hero-photo-count {
        font-size: 0.82rem;
        font-weight: 600;
        color: rgba(255, 255, 255, 0.8);
        background: rgba(0, 0, 0, 0.45);
        padding: 0.35rem 0.85rem;
        border-radius: 999px;
        border: 1px solid rgba(255,255,255,0.2);
        cursor: pointer;
        transition: background 0.2s;
    }

    .hero-photo-count:hover {
        background: rgba(0, 0, 0, 0.65);
    }

    /* =============================================
       PAGE LAYOUT
    ============================================= */
    .res-page-wrapper {
        background: #ffffff;
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
        display: grid;
        grid-template-columns: 1fr 400px;
        gap: 4rem;
        padding-top: 3rem;
        padding-bottom: 4rem;
    }

    @media (max-width: 1100px) {
        .res-page-wrapper {
            grid-template-columns: 1fr;
        }
    }

    /* =============================================
       BREADCRUMB, TITLE, SPECS
    ============================================= */
    .res-breadcrumbs {
        display: flex;
        align-items: center;
        gap: 0.45rem;
        font-size: 0.82rem;
        color: #9a9a9a;
        margin-bottom: 0.75rem;
    }

    .res-breadcrumbs a { color: #9a9a9a; text-decoration: none; }
    .res-breadcrumbs a:hover { color: #333; text-decoration: underline; }

    .res-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(2rem, 3.5vw, 3rem);
        color: #111111;
        letter-spacing: -0.02em;
        margin: 0.25rem 0 1rem 0;
        line-height: 1.15;
    }

    .res-specs-bar {
        display: flex;
        align-items: center;
        gap: 1.25rem;
        flex-wrap: wrap;
        font-size: 0.95rem;
        color: #484848;
        font-weight: 500;
        padding-bottom: 1.75rem;
        border-bottom: 1px solid #ebebeb;
    }

    .res-spec {
        display: flex;
        align-items: center;
        gap: 0.45rem;
    }

    .res-spec svg {
        width: 17px;
        height: 17px;
        fill: #c29f68;
    }

    /* =============================================
       DETAILS — INDIVIDUAL STAT CARDS (REDESIGNED)
    ============================================= */
    .details-stat-cards {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
        margin-top: 0;
    }

    @media (max-width: 768px) {
        .details-stat-cards { grid-template-columns: repeat(2, 1fr); }
    }

    @media (max-width: 520px) {
        .details-stat-cards { grid-template-columns: 1fr; }
    }

    .stat-card {
        background: #fdfcf9;
        border: 1px solid #e8e3d8;
        border-radius: 16px;
        padding: 1.5rem 1.6rem;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 1rem;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.02);
        text-align: left !important;
    }

    .stat-card:hover {
        border-color: #c5a059;
        background: #ffffff;
        transform: translateY(-5px);
        box-shadow: 0 14px 32px rgba(197, 160, 89, 0.16);
    }

    .stat-card-header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .stat-card-icon {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        background: #f7f5f0;
        border: 1px solid #e8e2d6;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #8c734b;
        transition: all 0.3s ease;
        flex-shrink: 0;
    }

    .stat-card:hover .stat-card-icon {
        background: #c5a059;
        color: #ffffff;
        border-color: #c5a059;
        transform: scale(1.05);
    }

    .stat-card-icon svg {
        width: 22px;
        height: 22px;
        fill: currentColor;
    }

    .stat-card-badge {
        font-size: 0.7rem;
        font-weight: 500;
        color: #7a6850;
        background: #f4f0e8;
        padding: 0.25rem 0.65rem;
        border-radius: 999px;
        border: 1px solid #e6dfd3;
        letter-spacing: 0.03em;
    }

    .stat-card-label {
        font-size: 0.73rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #8c8273;
        margin-bottom: 0.2rem;
    }

    .stat-card-value {
        font-size: 1.35rem;
        font-weight: 500;
        color: #111111;
        line-height: 1.15;
        font-family: 'Marcellus', serif;
    }

    .stat-card-value span {
        font-family: var(--font-body);
        font-size: 0.88rem;
        color: #6b5b44;
        font-weight: 500;
    }

    .stat-card-subtag {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        font-size: 0.78rem;
        color: #6b6355;
        font-weight: 400;
        margin-top: 0.2rem;
    }

    /* Value card (pricing) accent */
    .stat-card.accent {
        background: #faf8f4;
        border: 1px solid #dccbb0;
        grid-column: span 2;
    }

    @media (max-width: 768px) {
        .stat-card.accent { grid-column: span 1; }
    }

    .stat-card.accent .stat-card-icon {
        background: #f0e6d2;
        border-color: #d6c39e;
        color: #7a5a23;
    }

    .stat-card.accent:hover .stat-card-icon {
        background: #a37d38;
        color: #ffffff;
    }

    .stat-card.accent .stat-card-value {
        color: #7a4f1a;
        font-size: 1.65rem;
        font-weight: 500;
    }

    .stat-card-pills-row {
        display: flex;
        gap: 0.4rem;
        flex-wrap: wrap;
        margin-top: 0.35rem;
    }

    .stat-card-pill {
        font-size: 0.72rem;
        font-weight: 500;
        color: #7a5a23;
        background: #f4ece0;
        padding: 0.2rem 0.6rem;
        border-radius: 6px;
        border: 1px solid #e6d8c3;
    }

    /* =============================================
       AMENITIES — SLEEK COMPACT CARDS (NO DESC)
    ============================================= */
    .amenities-card-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
        margin-top: 1.5rem;
    }

    @media (max-width: 992px) {
        .amenities-card-grid { grid-template-columns: repeat(2, 1fr); }
    }

    @media (max-width: 540px) {
        .amenities-card-grid { grid-template-columns: 1fr; }
    }

    .amenity-item-card {
        background: #ffffff;
        border: 1px solid #e8e4dc;
        border-radius: 14px;
        padding: 1.1rem 1.35rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        position: relative;
        overflow: hidden;
    }

    .amenity-item-card:hover {
        background: #ffffff;
        border-color: #c5a059;
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(197, 160, 89, 0.12);
    }

    .amenity-item-icon {
        width: 42px;
        height: 42px;
        border-radius: 10px;
        background: #f7f5f0;
        border: 1px solid #e8e2d6;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #8c734b;
        flex-shrink: 0;
        transition: all 0.3s ease;
    }

    .amenity-item-card:hover .amenity-item-icon {
        background: #c5a059;
        color: #ffffff;
        border-color: #c5a059;
    }

    .amenity-item-icon svg {
        width: 20px;
        height: 20px;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .amenity-item-title {
        font-size: 0.92rem;
        font-weight: 600;
        color: #1a1a1a;
        line-height: 1.3;
        margin: 0;
    }

    /* =============================================
       FAQ REDESIGNED
    ============================================= */
    .faq-list-new {
        display: flex;
        flex-direction: column;
        gap: 0.85rem;
        margin-top: 1.5rem;
    }

    .faq-card-new {
        background: #ffffff;
        border: 1px solid #e5e0d5;
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .faq-card-new.open {
        border-color: #c5a059;
        box-shadow: 0 6px 22px rgba(197, 160, 89, 0.13);
    }

    .faq-btn-new,
    .faq-btn-new *,
    .faq-card-new button,
    .faq-card-new button span {
        font-family: 'Manrope', var(--font-body), sans-serif !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        font-size: 15px !important;
        font-weight: 500 !important;
    }

    .faq-btn-new {
        width: 100%;
        padding: 1.15rem 1.5rem;
        background: none;
        border: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        text-align: left;
        font-family: 'Manrope', var(--font-body), sans-serif !important;
        font-size: 15px !important;
        font-weight: 500 !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        color: #111111;
        cursor: pointer;
        transition: color 0.2s;
    }

    .faq-btn-new:hover { color: #a37d38; }

    .faq-toggle {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: #f5efe0;
        border: 1px solid #e4d8be;
        color: #a37d38;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        font-weight: 300;
        line-height: 1;
        flex-shrink: 0;
        transition: transform 0.3s ease, background 0.3s ease, color 0.3s ease;
    }

    .faq-card-new.open .faq-toggle {
        transform: rotate(45deg);
        background: #c5a059;
        color: #ffffff;
        border-color: #c5a059;
    }

    .faq-body-new {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.4s cubic-bezier(0.25, 1, 0.5, 1), padding 0.35s ease;
        padding: 0 1.5rem;
    }

    .faq-card-new.open .faq-body-new {
        max-height: 350px;
        padding: 0 1.5rem 1.35rem 1.5rem;
    }

    .faq-body-new p {
        font-size: 0.96rem;
        line-height: 1.75;
        color: #555;
        border-top: 1px solid #f0ebe0;
        padding-top: 1rem;
    }

    /* =============================================
       STICKY SIDEBAR — REDESIGNED PREMIUM FORM
    ============================================= */
    .res-sidebar {
        position: relative;
    }

    .sticky-enquiry-card {
        position: sticky;
        top: 95px;
        background: #ffffff;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 8px 40px rgba(0, 0, 0, 0.1), 0 2px 8px rgba(0, 0, 0, 0.05);
        border: 1px solid #ece7dc;
    }

    /* Gold accent header strip */
    .sticky-card-top {
        background: linear-gradient(135deg, #1a1510 0%, #2a2018 100%);
        padding: 1.75rem 2rem;
        position: relative;
        overflow: hidden;
    }

    .sticky-card-top::after {
        content: '';
        position: absolute;
        inset: 0;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c5a059' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E") repeat;
        opacity: 0.4;
        pointer-events: none;
    }

    .sticky-price-tag {
        font-family: 'Marcellus', serif;
        font-size: 2rem;
        color: #ffffff;
        position: relative;
        z-index: 1;
    }

    .sticky-price-tag span {
        font-family: var(--font-body);
        font-size: 1rem;
        color: rgba(255,255,255,0.65);
        font-weight: 400;
    }

    .sticky-price-sub {
        font-size: 0.82rem;
        color: rgba(255, 255, 255, 0.65);
        margin-top: 0.25rem;
        position: relative;
        z-index: 1;
    }

    .sticky-badge-row {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
        position: relative;
        z-index: 1;
        flex-wrap: wrap;
    }

    .sticky-badge {
        padding: 0.3rem 0.75rem;
        border: 1px solid rgba(197, 160, 89, 0.4);
        border-radius: 999px;
        color: #e0bc6d;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.04em;
    }

    /* Form Body */
    .sticky-card-body {
        padding: 1.75rem 2rem 2rem 2rem;
    }

    .form-section-label {
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #9a9283;
        margin-bottom: 0.85rem;
        display: block;
    }

    .form-fields-box {
        border: 1px solid #e0dbd0;
        border-radius: 12px;
        overflow: hidden;
        margin-bottom: 1.25rem;
    }

    .form-row-field {
        display: flex;
        flex-direction: column;
        padding: 0.85rem 1.1rem;
        background: #ffffff;
        transition: background 0.2s;
    }

    .form-row-field:not(:last-child) {
        border-bottom: 1px solid #f0ebe0;
    }

    .form-row-field:focus-within {
        background: #fdfbf5;
    }

    .form-row-label {
        font-size: 0.68rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #7a6a56;
        margin-bottom: 0.3rem;
    }

    .form-row-input,
    .form-row-select {
        border: none;
        background: transparent;
        font-size: 0.95rem;
        color: #1a1a1a;
        font-weight: 600;
        outline: none;
        font-family: var(--font-body);
        width: 100%;
    }

    .form-row-select {
        cursor: pointer;
        appearance: none;
        -webkit-appearance: none;
    }

    .form-cta-btn {
        width: 100%;
        padding: 1.1rem;
        background: linear-gradient(135deg, #1a1510 0%, #2c2016 100%);
        border: none;
        border-radius: 12px;
        color: #ffffff;
        font-size: 1rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.25s ease;
        position: relative;
        overflow: hidden;
        margin-bottom: 1rem;
    }

    .form-cta-btn::after {
        content: '';
        position: absolute;
        inset: 1px;
        border-radius: 11px;
        border: 1px solid rgba(197, 160, 89, 0.3);
        pointer-events: none;
    }

    .form-cta-btn:hover {
        background: linear-gradient(135deg, #2c2016 0%, #3d2d1e 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.25);
    }

    .form-cta-btn-sub {
        text-align: center;
        font-size: 0.8rem;
        color: #9a9283;
        margin-bottom: 1.25rem;
    }

    .form-divider {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 1rem 0;
    }

    .form-divider-line { flex: 1; height: 1px; background: #f0ebe0; }
    .form-divider-text { font-size: 0.75rem; color: #b0a898; font-weight: 600; }

    .ask-box-new {
        background: #fdfcf9;
        border: 1px solid #eae5db;
        border-radius: 12px;
        padding: 1.1rem 1.25rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
    }

    .ask-box-text strong { font-size: 0.9rem; color: #111111; display: block; }
    .ask-box-text span { font-size: 0.8rem; color: #717171; }

    .ask-box-icon {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        background: #ffffff;
        border: 1px solid #e0dbd0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #5a4a38;
        flex-shrink: 0;
    }

    /* section dividers */
    .res-section-divider {
        border: none;
        border-top: 1px solid #ebebeb;
        margin: 0;
    }

    .res-section-heading {
        font-family: 'Marcellus', serif;
        font-size: 42px;
        line-height: 1.25;
        letter-spacing: -0.01em;
        color: #111111;
        margin-bottom: 0.35rem;
    }

    .res-section-sub {
        font-size: 0.92rem;
        color: #9a9283;
        margin-bottom: 0;
    }
    
    .res-page-wrapper {
        max-width: 1340px;
        margin: 0 auto;
    }

    /* Sidebar column */
    .res-sidebar {
        position: relative;
        align-self: start;
    }

    .sticky-enquiry-card {
        position: sticky;
        top: 95px;
        background: #ffffff;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 8px 40px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.05);
        border: 1px solid #ece7dc;
    }

    .sticky-card-top {
        background: linear-gradient(135deg, #1a1510 0%, #2a2018 100%);
        padding: 1.75rem 2rem;
        position: relative;
        overflow: hidden;
    }

    .sticky-price-tag {
        font-family: 'Marcellus', serif;
        font-size: 2rem;
        color: #ffffff;
        position: relative;
        z-index: 1;
    }

    .sticky-price-tag span {
        font-family: var(--font-body, sans-serif);
        font-size: 1rem;
        color: rgba(255,255,255,0.65);
        font-weight: 400;
    }

    .sticky-price-sub {
        font-size: 0.82rem;
        color: rgba(255,255,255,0.65);
        margin-top: 0.25rem;
        position: relative;
        z-index: 1;
    }

    .sticky-badge-row {
        display: flex;
        gap: 0.5rem;
        margin-top: 1rem;
        position: relative;
        z-index: 1;
        flex-wrap: wrap;
    }

    .sticky-badge {
        padding: 0.3rem 0.75rem;
        border: 1px solid rgba(197,160,89,0.4);
        border-radius: 999px;
        color: #e0bc6d;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.04em;
    }

    .sticky-card-body {
        padding: 1.75rem 2rem 2rem 2rem;
    }

    .form-section-label {
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #9a9283;
        margin-bottom: 0.85rem;
        display: block;
    }

    .form-fields-box {
        border: 1px solid #e0dbd0;
        border-radius: 12px;
        overflow: hidden;
        margin-bottom: 1.25rem;
    }

    .form-row-field {
        display: flex;
        flex-direction: column;
        padding: 0.85rem 1.1rem;
        background: #ffffff;
        transition: background 0.2s;
    }

    .form-row-field:not(:last-child) { border-bottom: 1px solid #f0ebe0; }
    .form-row-field:focus-within { background: #fdfbf5; }

    .form-row-label {
        font-size: 0.68rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #7a6a56;
        margin-bottom: 0.3rem;
    }

    .form-row-input,
    .form-row-select {
        border: none;
        background: transparent;
        font-size: 0.95rem;
        color: #1a1a1a;
        font-weight: 600;
        outline: none;
        width: 100%;
    }

    .form-row-select { cursor: pointer; appearance: none; }

    .form-cta-btn {
        width: 100%;
        padding: 1.1rem;
        background: linear-gradient(135deg, #1a1510 0%, #2c2016 100%);
        border: none;
        border-radius: 12px;
        color: #ffffff;
        font-size: 1rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.25s ease;
        margin-bottom: 1rem;
    }

    .form-cta-btn:hover {
        background: linear-gradient(135deg, #2c2016 0%, #3d2d1e 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 28px rgba(0,0,0,0.25);
    }

    .form-cta-btn-sub {
        text-align: center;
        font-size: 0.8rem;
        color: #9a9283;
        margin-bottom: 1.25rem;
    }

    .res-heading-line {
        display: block;
        width: 48px;
        height: 3px;
        background: linear-gradient(90deg, #c5a059 0%, #e0bc6d 100%);
        border-radius: 999px;
        margin-top: 0.5rem;
        margin-bottom: 1.1rem;
    }

    .res-heading-line.center {
        margin-left: auto;
        margin-right: auto;
    }

    /* =============================================
       FULL-WIDTH BHK PLANS CAROUSEL & FAQ SECTIONS
    ============================================= */
    .bhk-carousel-section {
        position: relative;
        overflow: hidden;
        background: #14100c;
        border-top: 1px solid #2d241b;
        border-bottom: 1px solid #2d241b;
        padding: 5rem 0;
    }

    .bhk-bg-video {
        position: absolute;
        top: 50%;
        left: 50%;
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
        transform: translate(-50%, -50%);
        object-fit: cover;
        z-index: 1;
        opacity: 0.85;
        filter: brightness(0.9) contrast(1.05);
    }

    .bhk-bg-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(180deg, rgba(14, 10, 8, 0.45) 0%, rgba(14, 10, 8, 0.65) 100%);
        z-index: 2;
    }

    .bhk-carousel-container {
        position: relative;
        z-index: 3;
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    .bhk-carousel-header {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        margin-bottom: 2.5rem;
        flex-wrap: wrap;
        gap: 1.5rem;
    }

    .bhk-carousel-nav-btns {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .bhk-nav-btn {
        width: 46px;
        height: 46px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(224, 188, 109, 0.6);
        color: #e0bc6d;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 18px rgba(0,0,0,0.3);
    }

    .bhk-nav-btn:hover {
        background: #c5a059;
        color: #ffffff;
        transform: scale(1.06);
    }

    .bhk-carousel-track-wrapper {
        overflow: hidden;
        width: 100%;
        margin: 0 -0.5rem;
        padding: 0.5rem;
    }

    .bhk-carousel-track {
        display: flex;
        gap: 1.5rem;
        transition: transform 0.5s cubic-bezier(0.25, 1, 0.5, 1);
    }

    .bhk-card {
        flex: 0 0 calc(33.333% - 1rem);
        min-width: 320px;
        background: #ffffff;
        border: 1px solid #eae5db;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 8px 30px rgba(0,0,0,0.04);
        transition: all 0.35s ease;
        display: flex;
        flex-direction: column;
    }

    .bhk-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 16px 40px rgba(197, 160, 89, 0.18);
        border-color: #c5a059;
    }

    .bhk-card-img-box {
        position: relative;
        height: 230px;
        overflow: hidden;
    }

    .bhk-card-img-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }

    .bhk-card:hover .bhk-card-img-box img {
        transform: scale(1.06);
    }

    .bhk-card-badge {
        position: absolute;
        top: 1.1rem;
        left: 1.1rem;
        background: rgba(26, 21, 16, 0.82);
        backdrop-filter: blur(8px);
        color: #e0bc6d;
        border: 1px solid rgba(197, 160, 89, 0.4);
        padding: 0.35rem 0.85rem;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.05em;
    }

    .bhk-card-body {
        padding: 1.6rem;
        display: flex;
        flex-direction: column;
        flex: 1;
        justify-content: space-between;
    }

    .bhk-card-header-row {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        gap: 0.5rem;
        margin-bottom: 0.75rem;
    }

    .bhk-card-title {
        font-family: 'Marcellus', serif;
        font-size: 1.25rem;
        color: #111111;
        margin: 0;
        line-height: 1.25;
    }

    .bhk-card-price {
        font-size: 0.92rem;
        font-weight: 700;
        color: #7a5a23;
        white-space: nowrap;
        flex-shrink: 0;
    }

    .bhk-card-specs-row {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #f0ebe0;
    }

    .bhk-card-spec-tag {
        font-size: 0.76rem;
        font-weight: 600;
        color: #665b48;
        background: #f7f3ea;
        padding: 0.25rem 0.65rem;
        border-radius: 6px;
    }

    .bhk-card-desc {
        font-size: 0.88rem;
        color: #666666;
        line-height: 1.6;
        margin-bottom: 1.4rem;
    }

    .bhk-card-cta-btn {
        width: 100%;
        padding: 0.9rem 1.5rem;
        background: linear-gradient(135deg, #c5a059 0%, #a37d38 100%);
        color: #ffffff;
        font-size: 0.85rem;
        font-weight: 600;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        border: none;
        border-radius: 32px;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        display: block;
        transition: all 0.25s ease;
        box-shadow: 0 4px 16px rgba(197, 160, 89, 0.25);
    }

    .bhk-card-cta-btn:hover {
        background: linear-gradient(135deg, #b58f48 0%, #8f6a27 100%);
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(197, 160, 89, 0.35);
    }

    .faq-fullwidth-section {
        max-width: 1340px;
        margin: 0 auto;
        padding: 4.5rem 1.5rem 2rem 1.5rem;
    }

    /* =============================================
       FULL-WIDTH SHOWCASE GALLERY SECTION
    ============================================= */
    .res-gallery-section {
        background: #fdfbf7;
        border-top: 1px solid #ede7dc;
        border-bottom: 1px solid #ede7dc;
        padding: 5rem 0;
        position: relative;
    }

    .res-gallery-container {
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    .res-gallery-header {
        text-align: center;
        max-width: 720px;
        margin: 0 auto 2.5rem;
    }

    .res-gallery-filter-tabs {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.65rem;
        flex-wrap: wrap;
        margin-bottom: 2.5rem;
    }

    .res-gallery-tab-btn {
        padding: 0.6rem 1.35rem;
        border-radius: 999px;
        background: #ffffff;
        border: 1px solid #e2dacd;
        color: #665b48;
        font-family: 'Manrope', var(--font-body), sans-serif;
        font-size: 0.88rem;
        font-weight: 600;
        text-transform: none;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 2px 8px rgba(0,0,0,0.02);
    }

    .res-gallery-tab-btn:hover {
        border-color: #c5a059;
        color: #7a5a23;
    }

    .res-gallery-tab-btn.active {
        background: linear-gradient(135deg, #1a1510 0%, #2c2016 100%);
        border-color: #1a1510;
        color: #ffffff;
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    }

    .res-gallery-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0.75rem;
    }

    @media (max-width: 1024px) {
        .res-gallery-grid { grid-template-columns: repeat(3, 1fr); gap: 0.65rem; }
    }

    @media (max-width: 768px) {
        .res-gallery-grid { grid-template-columns: repeat(2, 1fr); gap: 0.5rem; }
    }

    @media (max-width: 480px) {
        .res-gallery-grid { grid-template-columns: 1fr; gap: 0.5rem; }
    }

    .res-gallery-item {
        position: relative;
        border-radius: 4px;
        overflow: hidden;
        height: 260px;
        cursor: pointer;
        background: #f4f0e8;
        border: 1px solid #eae5db;
        box-shadow: 0 4px 14px rgba(0,0,0,0.04);
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .res-gallery-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 14px 35px rgba(0,0,0,0.12);
        border-color: #c5a059;
    }

    .res-gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .res-gallery-item:hover img {
        transform: scale(1.08);
    }

    .res-gallery-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.05) 0%, rgba(10, 12, 14, 0.88) 100%);
        padding: 1.25rem;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        opacity: 0.95;
        transition: all 0.35s ease;
    }

    .res-gallery-item:hover .res-gallery-overlay {
        opacity: 1;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.15) 0%, rgba(10, 12, 14, 0.95) 100%);
    }

    .res-gallery-info {
        color: #ffffff;
        margin-top: auto;
    }

    .res-gallery-title {
        font-family: 'Marcellus', serif;
        font-size: 1.15rem;
        margin: 0 0 0.35rem 0;
        line-height: 1.25;
        font-weight: 400;
        color: #ffffff;
        letter-spacing: 0.02em;
    }

    .res-gallery-desc {
        font-size: 0.82rem;
        color: rgba(255, 255, 255, 0.82);
        line-height: 1.45;
        margin: 0;
    }

    @media (max-width: 768px) {
        .res-gallery-title {
            font-size: 1.35rem !important;
            line-height: 1.2 !important;
        }

        .res-gallery-overlay {
            padding: 0.9rem !important;
        }

        .res-gallery-sub {
            font-size: 0.7rem !important;
        }
    }

    /* Global overflow fix */
    html, body {
        overflow-x: hidden;
        max-width: 100%;
    }

    .hero-spec-pill {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.18);
        border-radius: 10px;
        padding: 0.65rem 1.1rem;
        color: #ffffff;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .faq-body-new, .faq-body-new p {
        font-family: 'Manrope', var(--font-body), sans-serif;
    }

    /* =============================================
       MOBILE RESPONSIVENESS OVERHAUL
    ============================================= */
    @media (max-width: 1024px) {
        .res-main-grid {
            grid-template-columns: 1fr !important;
            gap: 2.5rem !important;
            padding: 2rem 1.25rem 3rem !important;
        }

        .sticky-enquiry-card {
            position: static !important;
            max-width: 100% !important;
        }

        .bhk-card {
            flex: 0 0 calc(50% - 0.75rem);
        }
    }

    @media (max-width: 768px) {
        body, p, .res-section-sub, div p, .res-intro-paragraph, #moreText p {
            font-family: 'Manrope', var(--font-body), sans-serif !important;
            font-size: 14px !important;
            line-height: 1.7 !important;
        }

        .faq-body-new, .faq-body-new p {
            font-family: 'Manrope', var(--font-body), sans-serif !important;
            font-size: 14px !important;
            line-height: 1.75 !important;
        }

        /* Hero Section Mobile Overlay Fix */
        .residence-hero-fullwidth {
            position: relative !important;
            overflow: hidden !important;
        }

        .residence-hero-slide {
            height: 70vh !important;
            min-height: 480px !important;
            max-height: 560px !important;
        }

        .hero-slider-arrow {
            display: none !important;
        }

        .hero-bottom-bar {
            position: absolute !important;
            top: auto !important;
            bottom: 0 !important;
            left: 0 !important;
            right: 0 !important;
            padding: 1.75rem 1.25rem 1.5rem 1.25rem !important;
            background: linear-gradient(to top, rgba(5,7,9,0.96) 0%, rgba(5,7,9,0.6) 70%, transparent 100%) !important;
            display: flex !important;
            justify-content: center !important;
            align-items: flex-end !important;
        }

        .hero-content-box {
            padding: 0 !important;
            text-align: center !important;
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            justify-content: center !important;
            width: 100% !important;
            gap: 0.45rem !important;
        }

        .hero-breadcrumbs {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            text-align: center !important;
            width: 100% !important;
            font-size: 0.76rem !important;
            margin: 0 0 0.2rem 0 !important;
            flex-wrap: wrap !important;
        }

        .hero-breadcrumbs a, .hero-breadcrumbs span {
            display: inline-block !important;
        }

        .hero-info-badge {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin: 0.25rem auto 0.35rem auto !important;
            padding: 0.35rem 0.85rem !important;
            font-size: 0.74rem !important;
        }

        .hero-info-title {
            font-size: 32px !important;
            line-height: 1.2 !important;
            text-align: center !important;
            width: 100% !important;
            margin: 0.25rem 0 0.45rem 0 !important;
            font-family: 'Marcellus', serif !important;
        }

        .hero-spec-pills-row {
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            width: 100% !important;
            gap: 0.45rem !important;
            margin: 0.25rem 0 0.35rem 0 !important;
            flex-wrap: wrap !important;
        }

        .hero-spec-pill {
            padding: 0.4rem 0.75rem !important;
            font-size: 0.75rem !important;
            gap: 0.4rem !important;
            background: rgba(0, 0, 0, 0.45) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }

        .hero-slide-counter {
            position: static !important;
            margin-top: 0.4rem !important;
            justify-content: center !important;
            width: 100% !important;
        }

        .hero-photo-count {
            padding: 0.25rem 0.65rem !important;
            font-size: 0.73rem !important;
        }

        .res-section-heading,
        .bhk-carousel-header h2,
        .res-gallery-header h2 {
            font-size: 1.5rem !important;
            line-height: 1.25 !important;
            text-align: center !important;
        }

        .bhk-carousel-header p,
        .res-gallery-header p {
            font-size: 0.88rem !important;
            text-align: center !important;
        }

        .res-heading-line {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        .res-section-sub {
            text-align: center !important;
        }

        .bhk-carousel-header {
            flex-direction: column !important;
            align-items: center !important;
            text-align: center !important;
        }

        .bhk-carousel-nav-btns {
            justify-content: center !important;
            margin-top: 0.5rem !important;
        }

        .details-stat-cards {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 0.85rem !important;
        }

        .amenities-card-grid {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 0.85rem !important;
        }

        .bhk-carousel-section {
            padding: 3.5rem 0 !important;
        }

        .bhk-card {
            flex: 0 0 calc(85% - 0.5rem) !important;
            min-width: 270px !important;
        }

        .faq-fullwidth-section {
            padding: 3rem 1.25rem !important;
        }

        .faq-btn-new,
        .faq-btn-new span {
            font-size: 15px !important;
            font-weight: 500 !important;
            padding: 1rem 1.25rem !important;
        }
    }

    @media (max-width: 480px) {
        .hero-info-title {
            font-size: 28px !important;
        }

        .details-stat-cards {
            grid-template-columns: 1fr !important;
        }

        .amenities-card-grid {
            grid-template-columns: 1fr !important;
        }

        .bhk-card {
            flex: 0 0 100% !important;
            min-width: 250px !important;
        }
    }

    /* =============================================
       CONTACT PAGE LIGHT THEME STYLES
    ============================================= */
    .contact-page-body {
        background-color: #ffffff !important;
        color: #1a1a1a !important;
        font-family: var(--font-body) !important;
    }

    .contact-hero-light {
        position: relative;
        width: 100%;
        height: 380px;
        background: #111518;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        overflow: hidden;
        margin-top: 0;
    }

    .contact-hero-slider-track {
        display: flex;
        width: 100%;
        height: 100%;
        position: absolute;
        inset: 0;
        transition: transform 0.85s cubic-bezier(0.25, 1, 0.5, 1);
        z-index: 1;
    }

    .contact-hero-slide {
        min-width: 100%;
        height: 100%;
        position: relative;
        flex-shrink: 0;
        overflow: hidden;
    }

    .contact-hero-slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.55;
        filter: brightness(0.85) contrast(1.05);
        transition: transform 1s ease;
    }

    .contact-hero-slide.active img {
        transform: scale(1.04);
    }

    .contact-hero-light-bg {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.52;
        filter: brightness(0.85) contrast(1.05);
    }

    .contact-hero-light-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.4) 0%, rgba(10, 12, 14, 0.65) 100%);
        z-index: 2;
    }

    .contact-hero-light-content {
        position: relative;
        z-index: 3;
        max-width: 800px;
        padding: 0 1.5rem;
        margin-top: 2rem;
    }

    .contact-hero-light-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(2.4rem, 4.8vw, 3.6rem);
        font-weight: 300;
        color: #ffffff;
        margin-bottom: 0.85rem;
        line-height: 1.15;
        letter-spacing: 0.01em;
        text-shadow: 0 4px 18px rgba(0,0,0,0.5);
    }

    .contact-hero-light-title span {
        color: #D1AC62;
        font-weight: 300;
    }

    .blog-detail-page-body .contact-hero-light-title {
        font-size: clamp(2rem, 3.4vw, 2.85rem);
        max-width: 680px;
    }

    .contact-hero-light-sub {
        font-size: 1.02rem;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.88);
        line-height: 1.6;
        margin: 0 auto;
        max-width: 640px;
    }

    .contact-main-wrapper {
        background: #ffffff;
        padding: 5.5rem 0 4.5rem 0;
    }

    .contact-main-container {
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
        display: grid;
        grid-template-columns: 1fr 540px;
        gap: 4.5rem;
        align-items: start;
    }

    @media (max-width: 1080px) {
        .contact-main-container {
            grid-template-columns: 1fr;
            gap: 3.5rem;
        }
    }

    .contact-left-col {
        padding-top: 0.5rem;
    }

    .contact-eyebrow {
        font-size: 0.78rem;
        font-weight: 800;
        color: #D1AC62;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        margin-bottom: 0.75rem;
        display: block;
    }

    .contact-heading {
        font-family: 'Marcellus', serif;
        font-size: clamp(2.1rem, 3.5vw, 2.8rem);
        font-weight: 400;
        color: #111111;
        line-height: 1.2;
        margin-bottom: 1.25rem;
        letter-spacing: -0.01em;
    }

    .contact-heading span {
        color: #D1AC62;
        font-weight: 400;
    }

    .contact-desc-text {
        font-size: 0.95rem;
        color: #666666;
        line-height: 1.7;
        margin-bottom: 2.75rem;
        max-width: 600px;
    }

    .contact-info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 2.25rem 1.75rem;
        margin-bottom: 3.25rem;
    }

    @media (max-width: 580px) {
        .contact-info-grid {
            grid-template-columns: 1fr;
            gap: 1.75rem;
        }
    }

    .contact-info-item {
        display: flex;
        align-items: flex-start;
        gap: 1.1rem;
    }

    .contact-info-icon-box {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: #faf5ea;
        border: 1px solid #eee0c5;
        color: #D1AC62;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        transition: all 0.3s ease;
    }

    .contact-info-item:hover .contact-info-icon-box {
        background: #D1AC62;
        color: #ffffff;
        border-color: #D1AC62;
        transform: scale(1.05);
    }

    .contact-info-icon-box svg {
        width: 22px;
        height: 22px;
    }

    .contact-info-label {
        font-size: 0.96rem;
        font-weight: 700;
        color: #111111;
        margin-bottom: 0.35rem;
        line-height: 1.2;
    }

    .contact-info-detail {
        font-size: 0.86rem;
        color: #666666;
        line-height: 1.55;
    }

    .contact-info-detail a {
        color: #666666;
        text-decoration: none;
        transition: color 0.2s;
    }

    .contact-info-detail a:hover {
        color: #D1AC62;
    }

    .contact-social-section {
        padding-top: 1rem;
        border-top: 1px solid #f0ebe0;
    }

    .contact-social-title {
        font-size: 0.92rem;
        font-weight: 700;
        color: #111111;
        margin-bottom: 1.1rem;
    }

    .contact-social-btns-row {
        display: flex;
        align-items: center;
        gap: 0.65rem;
        flex-wrap: wrap;
    }

    .contact-social-circle {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #D1AC62;
        color: #ffffff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.25s ease;
        box-shadow: 0 4px 12px rgba(209, 172, 98, 0.25);
    }

    .contact-social-circle:hover {
        background: #111111;
        color: #D1AC62;
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .contact-social-circle svg {
        width: 18px;
        height: 18px;
    }

    .contact-form-card {
        background: #ffffff;
        border: 1.5px solid #d6c8ae;
        border-radius: 18px;
        padding: 3rem 2.5rem;
        box-shadow: 0 16px 45px rgba(0, 0, 0, 0.07);
    }

    @media (max-width: 580px) {
        .contact-form-card {
            padding: 2rem 1.35rem;
        }
    }

    .contact-form-card-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(1.65rem, 2.2vw, 2.15rem);
        font-weight: 400;
        color: #111111;
        line-height: 1.15;
        letter-spacing: 0;
        margin-bottom: 0.8rem;
    }

    .contact-form-card-title span {
        color: #D1AC62;
        font-weight: 400;
    }

    .contact-form-card-sub {
        font-size: 0.88rem;
        color: #777777;
        line-height: 1.6;
        margin-bottom: 2rem;
    }

    .form-row-2col {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.1rem;
        margin-bottom: 1.1rem;
    }

    @media (max-width: 580px) {
        .form-row-2col {
            grid-template-columns: 1fr;
            gap: 1.1rem;
        }
    }

    .form-field-group {
        display: flex;
        flex-direction: column;
        gap: 0.35rem;
        margin-bottom: 1.1rem;
    }

    .form-field-label {
        font-size: 0.78rem;
        font-weight: 700;
        color: #333333;
    }

    .form-field-input,
    .form-field-select,
    .form-field-textarea {
        width: 100%;
        padding: 0.85rem 1rem;
        background: #f7f6f3;
        border: 1.25px solid #d9d0c1;
        border-radius: 8px;
        font-family: var(--font-body);
        font-size: 0.9rem;
        color: #111111;
        outline: none;
        transition: all 0.25s ease;
    }

    .form-field-select {
        appearance: none;
        -webkit-appearance: none;
        cursor: pointer;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23777777' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 1rem center;
        padding-right: 2.5rem;
    }

    .form-field-input:focus,
    .form-field-select:focus,
    .form-field-textarea:focus {
        border-color: #D1AC62;
        background: #ffffff;
        box-shadow: 0 0 0 3px rgba(209, 172, 98, 0.15);
    }

    .form-field-textarea {
        resize: vertical;
        min-height: 110px;
    }

    .send-msg-btn {
        width: 100%;
        padding: 1.1rem;
        background: #D1AC62;
        color: #ffffff;
        border: none;
        border-radius: 32px;
        font-family: var(--font-body);
        font-size: 0.88rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.25s ease;
        box-shadow: 0 6px 20px rgba(209, 172, 98, 0.3);
        margin-top: 0.5rem;
    }

    .send-msg-btn:hover {
        background: #c29c54;
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(209, 172, 98, 0.4);
    }

    .contact-map-fullwidth {
        width: 100%;
        height: 480px;
        background: #e5e3df;
        border-top: 1px solid #e0dad0;
    }

    .contact-map-fullwidth iframe {
        width: 100%;
        height: 100%;
        border: 0;
    }

    /* =========================================================
       GALLERY PAGE LIGHT THEME STYLES
    ========================================================= */
    .gallery-page-body {
        background-color: #ffffff;
        color: #111111;
    }

    .gallery-main-wrapper {
        background: #ffffff;
        padding: 5.5rem 0 5rem 0;
    }

    .gallery-main-container {
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    .gallery-header-center {
        text-align: center;
        max-width: 780px;
        margin: 0 auto 3rem auto;
    }

    .gallery-intro-desc {
        font-size: 0.96rem;
        color: #666666;
        line-height: 1.7;
        margin-top: 0.5rem;
    }

    .gallery-filter-tabs {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        flex-wrap: wrap;
        margin-bottom: 3.25rem;
    }

    .gallery-tab-btn {
        background: #f7f5f0;
        border: 1px solid #e7e2d7;
        color: #444444;
        padding: 0.75rem 1.4rem;
        border-radius: 9999px;
        font-family: var(--font-body);
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.25s ease;
        outline: none;
    }

    .gallery-tab-btn:hover,
    .gallery-tab-btn.active {
        background: #D1AC62;
        color: #ffffff;
        border-color: #D1AC62;
        box-shadow: 0 6px 18px rgba(209, 172, 98, 0.28);
        transform: translateY(-1px);
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0.75rem;
    }

    @media (max-width: 1100px) {
        .gallery-grid {
            grid-template-columns: repeat(3, 1fr);
            gap: 0.65rem;
        }
    }

    @media (max-width: 768px) {
        .gallery-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.5rem;
        }
    }

    @media (max-width: 480px) {
        .gallery-grid {
            grid-template-columns: 1fr;
            gap: 0.5rem;
        }
    }

    .gallery-card-item {
        position: relative;
        border-radius: 4px;
        overflow: hidden;
        cursor: pointer;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);
        background: #000000;
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .gallery-card-item:hover {
        transform: translateY(-6px);
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.16);
    }

    .gallery-img-wrapper {
        position: relative;
        width: 100%;
        height: 290px;
        overflow: hidden;
    }

    .gallery-img-wrapper img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }

    .gallery-card-item:hover .gallery-img-wrapper img {
        transform: scale(1.08);
    }

    .gallery-card-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(10, 12, 14, 0.05) 0%, rgba(10, 12, 14, 0.88) 100%);
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        opacity: 0.95;
        transition: all 0.35s ease;
    }

    .gallery-card-tag {
        font-size: 0.68rem;
        font-weight: 800;
        letter-spacing: 0.12em;
        color: #D1AC62;
        margin-bottom: 0.35rem;
        text-transform: uppercase;
        display: block;
    }

    .gallery-card-title {
        font-family: 'Marcellus', serif;
        font-size: 1.22rem;
        font-weight: 400;
        color: #ffffff;
        margin-bottom: 0.35rem;
        line-height: 1.2;
    }

    .gallery-card-desc {
        font-size: 0.82rem;
        color: rgba(255, 255, 255, 0.8);
        line-height: 1.45;
        margin-bottom: 0;
    }

    .gallery-cta-section {
        background: #faf8f3;
        padding: 5rem 1.5rem;
        border-top: 1px solid #efe8da;
    }

    .gallery-cta-card {
        max-width: 820px;
        margin: 0 auto;
        text-align: center;
    }

    .gallery-cta-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(2rem, 3.5vw, 2.6rem);
        font-weight: 400;
        color: #111111;
        margin: 0.5rem 0 1rem 0;
    }

    .gallery-cta-title span {
        color: #D1AC62;
        font-weight: 400;
    }

    .gallery-cta-desc {
        font-size: 0.96rem;
        color: #666666;
        line-height: 1.7;
        margin-bottom: 2rem;
    }

    .gallery-cta-btn {
        display: inline-block;
        width: auto;
        padding: 1.1rem 2.8rem;
        text-decoration: none;
    }

    /* =========================================================
       MOBILE OPTIMIZATION & STANDARDIZED MOBILE HEADING TYPOGRAPHY
    ========================================================= */
    @media (max-width: 768px) {
        /* Main section titles in mobile view. Hero titles are intentionally excluded. */
        .about-title,
        .location-title,
        .villas-title,
        .amenities-title,
        .investment-title,
        .testimonials-title,
        .gallery-title,
        .faq-title,
        .contact-heading,
        .gallery-cta-title,
        .res-section-heading {
            font-size: 28px !important;
            line-height: 1.2 !important;
        }

        /* Card titles & Consultation headers (Proportioned for mobile) */
        .contact-form-card-title,
        .blog-consultation-title {
            font-size: 1.45rem !important;
            line-height: 1.25 !important;
            margin-bottom: 0.5rem !important;
        }

        /* Contact Us Mobile Optimizations */
        .contact-hero-light {
            min-height: 380px;
            padding: 6.5rem 1rem 3.5rem 1rem;
        }

        .contact-hero-light-content {
            padding: 0 0.5rem;
        }

        .contact-hero-light-sub {
            font-size: 0.92rem;
            line-height: 1.55;
        }

        .contact-main-wrapper {
            padding: 3.5rem 0 3rem 0;
        }

        .contact-main-container {
            padding: 0 1.15rem;
            gap: 2.75rem;
        }

        /* Contact Us Mobile Center Alignment */
        .contact-left-col {
            text-align: center;
        }

        .contact-eyebrow,
        .contact-heading,
        .contact-desc-text {
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }

        .contact-info-grid {
            justify-items: center;
        }

        .contact-info-item {
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .contact-social-section {
            text-align: center;
        }

        .contact-social-btns-row {
            justify-content: center;
        }

        .contact-form-card-title,
        .contact-form-card-sub {
            text-align: center;
        }

        .contact-form-card-title {
            font-size: 1.6rem !important;
            line-height: 1.15 !important;
        }

        .contact-map-fullwidth {
            height: 320px;
        }

        /* Gallery Mobile Optimizations */
        .gallery-main-wrapper {
            padding: 3.5rem 0 3rem 0;
        }

        .gallery-main-container {
            padding: 0 1.15rem;
        }

        .gallery-header-center {
            margin-bottom: 2rem;
        }

        .gallery-intro-desc {
            font-size: 0.9rem;
            line-height: 1.6;
        }

        .gallery-filter-tabs {
            gap: 0.5rem;
            margin-bottom: 2.25rem;
            justify-content: center;
        }

        .gallery-tab-btn {
            padding: 0.6rem 1.15rem;
            font-size: 0.8rem;
        }

        .gallery-grid {
            grid-template-columns: 1fr;
            gap: 1.25rem;
        }

        .gallery-img-wrapper {
            height: 250px;
        }

        .gallery-card-overlay {
            padding: 1.15rem;
        }

        .gallery-cta-section {
            padding: 3.5rem 1.15rem;
        }

        .gallery-cta-desc {
            font-size: 0.9rem;
            line-height: 1.6;
            margin-bottom: 1.5rem;
        }

        .gallery-cta-btn {
            padding: 0.95rem 2rem;
            width: 100%;
        }

        /* Blog Mobile Optimizations */
        .blog-featured-card {
            display: flex !important;
            flex-direction: column !important;
            gap: 0 !important;
            border-radius: 16px !important;
            overflow: hidden !important;
        }

        .blog-featured-img-wrapper {
            width: 100% !important;
            height: 220px !important;
            flex-shrink: 0 !important;
        }

        .blog-featured-img-wrapper img {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
        }

        .blog-featured-content {
            width: 100% !important;
            padding: 0.85rem 1.15rem 1.5rem !important;
            text-align: center !important;
            box-sizing: border-box !important;
        }

        .blog-featured-title {
            font-size: 1.35rem !important;
            line-height: 1.25 !important;
            margin-bottom: 0.6rem !important;
        }

        .blog-featured-excerpt {
            font-size: 0.88rem;
            line-height: 1.55;
            margin-bottom: 1.25rem;
        }

        .blog-meta-row {
            justify-content: center;
        }

        .blog-grid {
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }

        .blog-card-body {
            padding: 1.25rem;
            text-align: center;
        }

        .blog-card-title {
            font-size: 1.25rem !important;
            line-height: 1.3 !important;
        }

        .blog-read-btn,
        .blog-card-btn {
            width: 100%;
        }
    }

    /* =========================================================
       BLOG PAGE LIGHT THEME STYLES
    ========================================================= */
    .blog-page-body {
        background-color: #ffffff;
        color: #111111;
    }

    .blog-main-wrapper {
        background: #ffffff;
        padding: 5.5rem 0 5rem 0;
    }

    @media (max-width: 768px) {
        .blog-main-wrapper {
            padding-top: 2.25rem;
        }
    }

    .blog-main-container {
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    .blog-featured-card {
        display: grid;
        grid-template-columns: 1.1fr 1fr;
        gap: 2.5rem;
        background: #faf8f3;
        border: 1px solid #efe8da;
        border-radius: 20px;
        overflow: hidden;
        align-items: center;
        box-shadow: 0 12px 36px rgba(0,0,0,0.04);
        transition: all 0.35s ease;
    }

    .blog-featured-card:hover {
        box-shadow: 0 20px 48px rgba(0,0,0,0.08);
        border-color: #e2d7c3;
    }

    .blog-featured-img-wrapper {
        position: relative;
        width: 100%;
        height: 390px;
        overflow: hidden;
    }

    .blog-featured-img-wrapper img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }

    .blog-featured-card:hover .blog-featured-img-wrapper img {
        transform: scale(1.05);
    }

    .blog-tag-badge {
        position: absolute;
        top: 1.25rem;
        left: 1.25rem;
        background: #D1AC62;
        color: #ffffff;
        font-size: 0.68rem;
        font-weight: 800;
        letter-spacing: 0.1em;
        padding: 0.4rem 0.9rem;
        border-radius: 9999px;
        box-shadow: 0 4px 12px rgba(209, 172, 98, 0.3);
    }

    .blog-featured-content {
        padding: 1rem 2.5rem 2rem 1rem;
    }

    .blog-meta-row {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        font-size: 0.82rem;
        color: #888888;
        margin-bottom: 0.75rem;
    }

    .blog-date, .blog-read-time {
        font-weight: 500;
    }

    .blog-dot-sep {
        color: #D1AC62;
        font-weight: 700;
    }

    .blog-featured-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(1.6rem, 2.5vw, 2.1rem);
        font-weight: 400;
        color: #111111;
        line-height: 1.25;
        margin-bottom: 0.85rem;
    }

    .blog-featured-excerpt {
        font-size: 0.94rem;
        color: #666666;
        line-height: 1.65;
        margin-bottom: 1.5rem;
    }

    .blog-read-btn {
        display: inline-block;
        width: auto;
        padding: 0.9rem 2.2rem;
        text-decoration: none;
    }

    .blog-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin-top: 3.25rem;
    }

    @media (max-width: 1024px) {
        .blog-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }
    }

    @media (max-width: 640px) {
        .blog-grid {
            grid-template-columns: 1fr;
        }
    }

    .blog-card-item {
        background: #ffffff;
        border: 1.5px solid #d8cdbd;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 8px 24px rgba(0,0,0,0.06);
        transition: all 0.35s ease;
        display: flex;
        flex-direction: column;
    }

    .blog-card-item:hover {
        transform: translateY(-6px);
        box-shadow: 0 18px 38px rgba(0,0,0,0.09);
        border-color: #D1AC62;
    }

    .blog-card-img-box {
        position: relative;
        width: 100%;
        height: 220px;
        overflow: hidden;
    }

    .blog-card-img-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .blog-card-item:hover .blog-card-img-box img {
        transform: scale(1.06);
    }

    .blog-card-category {
        position: absolute;
        top: 1rem;
        left: 1rem;
        background: rgba(10, 12, 14, 0.78);
        color: #D1AC62;
        font-size: 0.65rem;
        font-weight: 800;
        letter-spacing: 0.1em;
        padding: 0.35rem 0.8rem;
        border-radius: 9999px;
        backdrop-filter: blur(8px);
    }

    .blog-card-body {
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    }

    .blog-card-title {
        font-family: 'Marcellus', serif;
        font-size: 1.25rem;
        font-weight: 400;
        color: #111111;
        line-height: 1.3;
        margin-bottom: 0.65rem;
    }

    .blog-card-excerpt {
        font-size: 0.86rem;
        color: #666666;
        line-height: 1.6;
        margin-bottom: 1.35rem;
        flex-grow: 1;
    }

    .blog-card-btn {
        display: inline-block;
        width: 100%;
        padding: 0.85rem;
        text-align: center;
        text-decoration: none;
    }

    /* =========================================================
       BLOG DETAIL SINGLE ARTICLE STYLES
    ========================================================= */
    .blog-detail-page-body {
        background-color: #ffffff;
        color: #111111;
    }

    .blog-detail-main-wrapper {
        background: #ffffff;
        padding: 5rem 0 5rem 0;
    }

    .blog-detail-container {
        max-width: 1340px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    .blog-detail-meta-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.5rem;
        padding-bottom: 2rem;
        border-bottom: 1px solid #efe8da;
        margin-bottom: 2.5rem;
        flex-wrap: wrap;
    }

    .blog-meta-info-line {
        display: flex;
        align-items: center;
        gap: 0.65rem;
        font-size: 0.88rem;
        color: #666666;
        margin-top: 0.35rem;
        flex-wrap: wrap;
    }

    .blog-author-name {
        font-weight: 700;
        color: #111111;
    }

    .blog-share-actions {
        display: flex;
        align-items: center;
        gap: 0.65rem;
    }

    .blog-share-label {
        font-size: 0.82rem;
        font-weight: 700;
        color: #777777;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-right: 0.25rem;
    }

    .blog-detail-featured-hero {
        position: relative;
        border-radius: 18px;
        overflow: hidden;
        margin-bottom: 3rem;
        box-shadow: 0 12px 36px rgba(0,0,0,0.06);
    }

    .blog-detail-featured-hero img {
        width: 100%;
        max-height: 560px;
        object-fit: cover;
        display: block;
    }

    .blog-image-caption {
        font-size: 0.84rem;
        color: #777777;
        font-style: italic;
        text-align: center;
        padding: 0.85rem 1rem;
        background: #faf8f3;
        border-top: 1px solid #efe8da;
    }

    .blog-article-body {
        font-family: var(--font-body);
        font-size: 1.05rem;
        line-height: 1.85;
        color: #222222;
    }

    .blog-article-body p {
        margin-bottom: 1.6rem;
    }

    .blog-article-body h1,
    .blog-article-body h2,
    .blog-article-body h3,
    .blog-article-body h4,
    .blog-article-body h5,
    .blog-article-body h6 {
        font-family: 'Marcellus', serif;
        font-weight: 400;
        color: #111111;
        margin: 2.5rem 0 1rem 0;
        line-height: 1.35;
    }
    .blog-article-body h1 { font-size: 2.2rem; }
    .blog-article-body h2 { font-size: 1.85rem; }
    .blog-article-body h3 { font-size: 1.55rem; }
    .blog-article-body h4 { font-size: 1.35rem; }

    .blog-article-body img {
        max-width: 100%;
        height: auto;
        border-radius: 12px;
        margin: 1.5rem 0;
    }

    .blog-article-body ul, .blog-article-body ol {
        margin: 1.2rem 0 1.8rem 1.8rem;
        padding-left: 0.5rem;
    }

    .blog-article-body li {
        margin-bottom: 0.6rem;
    }

    .blog-article-body blockquote {
        margin: 2.5rem 0;
        padding: 1.8rem 2.25rem;
        background: #faf8f3;
        border-left: 4px solid #D1AC62;
        border-radius: 0 16px 16px 0;
        font-family: 'Marcellus', serif;
        font-size: 1.25rem;
        font-style: italic;
        color: #111111;
        line-height: 1.6;
    }

    .blog-drop-cap,
    .blog-article-body > p:first-of-type::first-letter,
    .blog-article-body p:first-of-type::first-letter {
        font-family: 'Marcellus', 'Playfair Display', serif;
        float: left;
        font-size: 3.8rem;
        line-height: 0.8;
        padding-top: 6px;
        padding-right: 14px;
        padding-bottom: 2px;
        color: #CCA43B;
        font-weight: 500;
    }

    .blog-lead-paragraph {
        font-size: 1.15rem;
        line-height: 1.8;
        color: #111111;
    }

    .blog-subheading {
        font-family: 'Marcellus', serif;
        font-size: 1.7rem;
        font-weight: 400;
        color: #111111;
        margin: 2.5rem 0 1rem 0;
        line-height: 1.3;
    }

    .blog-pull-quote {
        margin: 2.5rem 0;
        padding: 2rem 2.25rem;
        background: #faf8f3;
        border-left: 4px solid #D1AC62;
        border-radius: 0 16px 16px 0;
        font-family: 'Marcellus', serif;
        font-size: 1.3rem;
        font-style: italic;
        color: #111111;
        line-height: 1.6;
    }

    .blog-inline-images {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
        margin: 2.5rem 0;
    }

    @media (max-width: 640px) {
        .blog-inline-images {
            grid-template-columns: 1fr;
            gap: 1.25rem;
        }
    }

    .blog-inline-img-card {
        border-radius: 14px;
        overflow: hidden;
        background: #faf8f3;
        border: 1px solid #efe8da;
    }

    .blog-inline-img-card img {
        width: 100%;
        height: 220px;
        object-fit: cover;
        display: block;
    }

    .blog-img-subcap {
        display: block;
        font-size: 0.8rem;
        color: #666666;
        padding: 0.65rem 0.85rem;
        text-align: center;
    }

    .blog-bullet-list {
        margin: 1.5rem 0 2rem 1.5rem;
        line-height: 1.8;
    }

    .blog-bullet-list li {
        margin-bottom: 0.65rem;
        color: #333333;
    }

    .blog-consultation-card {
        background: #faf8f3;
        border: 1px solid #efe8da;
        border-radius: 20px;
        padding: 3rem 2.5rem;
        margin: 3.5rem 0 3rem 0;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.03);
    }

    .blog-consultation-title {
        font-family: 'Marcellus', serif;
        font-size: clamp(1.6rem, 2.5vw, 2.1rem);
        font-weight: 400;
        color: #111111;
        margin: 0.5rem 0 0.85rem 0;
    }

    .blog-consultation-title span {
        color: #D1AC62;
    }

    .blog-consultation-desc {
        font-size: 0.95rem;
        color: #666666;
        line-height: 1.65;
        max-width: 720px;
        margin: 0 auto 2rem auto;
    }

    .blog-consultation-actions {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .blog-consultation-actions .send-msg-btn {
        width: auto;
        padding: 0.9rem 2.2rem;
        text-decoration: none !important;
        line-height: 1.3;
        display: inline-block;
    }

    @media (max-width: 640px) {
        .blog-consultation-card {
            padding: 2rem 1.25rem !important;
        }
        .blog-consultation-actions .send-msg-btn,
        .blog-consultation-actions .gallery-tab-btn {
            width: 100% !important;
            padding: 0.95rem 1.25rem !important;
            text-align: center !important;
            box-sizing: border-box !important;
            display: block !important;
        }
    }

    .blog-back-wrapper {
        text-align: center;
        margin-bottom: 4rem;
    }

    .blog-related-section {
        padding-top: 3.5rem;
        border-top: 1px solid #efe8da;
    }

    /* =========================================================
       FAQ PAGE LIGHT THEME STYLES
    ========================================================= */
    .faq-page-body {
        background-color: #ffffff;
        color: #111111;
    }

    .faq-page-section {
        background: #ffffff;
        padding-bottom: 2.25rem;
    }

    .faq-page-header {
        margin-bottom: 3rem;
    }

    .faq-page-grid {
        position: relative;
        display: grid;
        grid-template-columns: minmax(0, 1.25fr) minmax(320px, 0.75fr);
        gap: 2.5rem;
        align-items: start;
    }

    .faq-page-grid .faq-accordion-list {
        width: 100%;
    }

    .faq-page-card {
        position: sticky;
        top: 6rem;
        background:
            linear-gradient(135deg, rgba(255, 255, 255, 0.96), rgba(250, 247, 241, 0.98)),
            radial-gradient(circle at top right, rgba(209, 172, 98, 0.18), transparent 42%);
        border-color: #d8bd80;
    }

    .faq-page-grid::after {
        content: '';
        position: absolute;
        right: 0;
        bottom: -3rem;
        width: min(380px, 46vw);
        height: 220px;
        background: linear-gradient(135deg, rgba(209, 172, 98, 0.16), rgba(129, 204, 202, 0.12));
        border-radius: 18px;
        z-index: -1;
    }

    .faq-page-card .gallery-cta-btn,
    .faq-page-secondary-link {
        width: 100%;
        text-align: center;
        text-decoration: none;
        display: block;
        box-sizing: border-box;
    }

    .faq-page-secondary-link {
        margin-top: 0.85rem;
    }

    .faq-support-strip {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
        margin-top: 2rem;
    }

    .faq-support-item {
        background: #faf8f3;
        border: 1px solid #e4d7c3;
        border-radius: 14px;
        padding: 1.25rem;
    }

    .faq-support-item span {
        display: block;
        color: #D1AC62;
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.12em;
        margin-bottom: 0.5rem;
    }

    .faq-support-item h3 {
        font-family: 'Marcellus', serif;
        font-size: 1.2rem;
        color: #111111;
        font-weight: 400;
        margin-bottom: 0.45rem;
    }

    .faq-support-item p {
        color: #666666;
        font-size: 0.86rem;
        line-height: 1.6;
        margin: 0;
    }

    @media (max-width: 900px) {
        .faq-page-grid {
            grid-template-columns: 1fr;
        }

        .faq-page-card {
            position: static;
        }

        .faq-support-strip {
            grid-template-columns: 1fr;
        }
    }

    .faq-page-body .gallery-cta-section {
        padding-top: 2.25rem;
    }

    /* =========================================================
       LUXURY LIGHT THEME MOBILE SIDEBAR DRAWER & MENU STYLES
    ========================================================= */
    .mobile-drawer-header,
    .mobile-drawer-social-section,
    .mobile-cta-wrapper {
        display: none !important;
    }

    .mobile-nav-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.12) !important;
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
        filter: none !important;
        z-index: 99998;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.35s ease;
    }

    .mobile-nav-backdrop.active {
        opacity: 1;
        pointer-events: auto;
    }

    .mobile-menu-toggle {
        display: none;
    }

    @media (max-width: 1024px) {
        .mobile-menu-toggle {
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            width: 34px;
            height: 34px;
            padding: 8px 7px;
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            cursor: pointer;
            z-index: 10001;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        .mobile-menu-toggle span {
            width: 18px;
            height: 1.5px;
            background-color: #ffffff;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .hero-header.scrolled .mobile-menu-toggle span {
            background-color: #ffffff;
        }

        .mobile-menu-toggle.active {
            display: none !important;
            opacity: 0 !important;
            visibility: hidden !important;
            pointer-events: none !important;
            transform: scale(0.8) !important;
        }

        /* Mobile Slide-Out Drawer (Light Theme Panel - Sharp & Crisp Rendering) */
        .nav-container {
            position: fixed !important;
            top: 0 !important;
            right: 0 !important;
            width: min(340px, 86vw) !important;
            height: 100vh !important;
            background: #ffffff !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
            filter: none !important;
            box-shadow: -6px 0 25px rgba(0, 0, 0, 0.08) !important;
            z-index: 99999 !important;
            display: flex !important;
            flex-direction: column !important;
            justify-content: space-between !important;
            padding: 0 !important;
            transform: translateX(100%) !important;
            transition: transform 0.38s cubic-bezier(0.16, 1, 0.3, 1) !important;
            overflow-y: auto !important;
            border-left: 1px solid #efe8da !important;
            box-sizing: border-box !important;
            will-change: transform;
            -webkit-font-smoothing: antialiased;
        }

        .nav-container.active {
            transform: translateX(0) !important;
        }

        /* Mobile Drawer Header */
        .mobile-drawer-header {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 1.1rem 1.25rem !important;
            border-bottom: 1px solid #efe8da !important;
            background: #ffffff !important;
            position: sticky !important;
            top: 0 !important;
            z-index: 10 !important;
            width: 100% !important;
            box-sizing: border-box !important;
        }

        .mobile-drawer-close {
            width: 38px !important;
            height: 38px !important;
            min-width: 38px !important;
            min-height: 38px !important;
            border-radius: 50% !important;
            background: #f7f4ec !important;
            border: 1px solid #e5dfcb !important;
            color: #1a202c !important;
            cursor: pointer !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            transition: all 0.28s cubic-bezier(0.16, 1, 0.3, 1) !important;
            outline: none !important;
            flex-shrink: 0 !important;
            position: relative !important;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04) !important;
            padding: 0 !important;
        }

        .mobile-drawer-close svg {
            width: 18px !important;
            height: 18px !important;
            stroke: #1a202c !important;
            stroke-width: 2.2 !important;
            transition: all 0.28s cubic-bezier(0.16, 1, 0.3, 1) !important;
            display: block !important;
        }

        .mobile-drawer-close:hover {
            background: #DCB658 !important;
            border-color: #DCB658 !important;
            transform: rotate(90deg) scale(1.08) !important;
            box-shadow: 0 4px 14px rgba(220, 182, 88, 0.35) !important;
        }

        .mobile-drawer-close:hover svg {
            stroke: #0e1114 !important;
        }

        /* Drawer Nav Links List */
        .nav-links {
            display: flex !important;
            flex-direction: column !important;
            align-items: flex-start !important;
            text-align: left !important;
            gap: 0.35rem !important;
            padding: 1.25rem 1.25rem !important;
            width: 100% !important;
            margin: 0 !important;
            list-style: none !important;
            box-sizing: border-box !important;
        }

        .nav-links li {
            width: 100% !important;
            display: block !important;
            margin: 0 !important;
            text-align: left !important;
        }

        .nav-link {
            font-family: 'Marcellus', serif !important;
            font-size: 1.05rem !important;
            font-weight: 500 !important;
            text-transform: capitalize !important;
            color: #111111 !important;
            padding: 0.8rem 1rem !important;
            border-radius: 12px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            transition: all 0.25s ease !important;
            width: 100% !important;
            text-decoration: none !important;
            box-sizing: border-box !important;
            letter-spacing: 0.01em !important;
            text-align: left !important;
            border: 0 !important;
            background: transparent !important;
            cursor: pointer !important;
            appearance: none !important;
            -webkit-appearance: none !important;
            position: relative !important;
            z-index: 2 !important;
            pointer-events: auto !important;
        }

        .nav-link::before {
            display: none !important;
        }

        .nav-link:hover,
        .nav-link.active {
            background: #faf6ee !important;
            color: #D1AC62 !important;
            font-weight: 600 !important;
            text-shadow: none !important;
        }

        /* Mobile Dropdown Sub-menu */
        .nav-dropdown {
            display: block !important;
            width: 100% !important;
        }

        .nav-dropdown-menu {
            position: relative !important;
            top: 0 !important;
            left: 0 !important;
            transform: none !important;
            width: 100% !important;
            min-width: 100% !important;
            display: none !important;
            opacity: 0 !important;
            visibility: hidden !important;
            background: #faf7f2 !important;
            border: 1px solid #efe8da !important;
            border-radius: 12px !important;
            margin: 0.4rem 0 0.6rem 0 !important;
            padding: 0.4rem 0.5rem !important;
            box-shadow: none !important;
            text-align: left !important;
            box-sizing: border-box !important;
        }

        .nav-dropdown.open .nav-dropdown-menu {
            display: block !important;
            opacity: 1 !important;
            visibility: visible !important;
        }

        .nav-dropdown.open .nav-dropdown-toggle::after {
            transform: rotate(225deg) !important;
            margin-bottom: -2px !important;
        }

        .mobile-drawer-header .brand-logo {
            display: flex !important;
            align-items: center !important;
            gap: 0.75rem !important;
            text-decoration: none !important;
        }

        .mobile-drawer-header .brand-title {
            color: #111827 !important;
            font-family: 'Marcellus', serif !important;
            font-size: 1.25rem !important;
            font-weight: 600 !important;
            line-height: 1.15 !important;
            text-shadow: none !important;
            display: block !important;
        }

        .mobile-drawer-header .brand-subtitle {
            color: #927538 !important;
            font-size: 0.52rem !important;
            margin-top: 2px !important;
            letter-spacing: 0.04em !important;
            text-shadow: none !important;
            display: block !important;
        }

        .mobile-drawer-header .brand-mark {
            width: 44px !important;
            height: 44px !important;
            object-fit: contain !important;
            box-shadow: none !important;
            filter: none !important;
        }

        /* Mobile Drawer Social Links Section */
        .mobile-drawer-social-section {
            display: block !important;
            padding: 1.1rem 1.25rem 0.6rem !important;
            width: 100% !important;
            box-sizing: border-box !important;
            border-top: 1px solid #efe8da !important;
            margin-top: 0.5rem !important;
        }

        .mobile-drawer-social-label {
            display: block !important;
            font-size: 0.72rem !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            letter-spacing: 0.12em !important;
            color: #8C7335 !important;
            margin-bottom: 0.65rem !important;
            text-align: left !important;
        }

        .mobile-drawer-social-row {
            display: flex !important;
            align-items: center !important;
            gap: 0.65rem !important;
            flex-wrap: wrap !important;
        }

        .mobile-drawer-social-btn {
            width: 38px !important;
            height: 38px !important;
            border-radius: 50% !important;
            background: #faf7f0 !important;
            border: 1px solid #e7dfcc !important;
            color: #111827 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            text-decoration: none !important;
            transition: all 0.25s ease !important;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04) !important;
        }

        .mobile-drawer-social-btn:hover {
            background: #DCB658 !important;
            color: #0E1114 !important;
            border-color: #DCB658 !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 12px rgba(220, 182, 88, 0.3) !important;
        }

        .nav-dropdown-menu li {
            text-align: left !important;
            width: 100% !important;
        }

        .nav-dropdown-link {
            color: #444444 !important;
            font-family: 'Manrope', var(--font-body), sans-serif !important;
            font-size: 0.85rem !important;
            font-weight: 600 !important;
            padding: 0.6rem 0.85rem !important;
            text-transform: none !important;
            border-radius: 8px !important;
            display: block !important;
            width: 100% !important;
            text-decoration: none !important;
            transition: all 0.2s ease !important;
            text-align: left !important;
            box-sizing: border-box !important;
            position: relative !important;
            z-index: 3 !important;
            pointer-events: auto !important;
        }

        .nav-dropdown-link:hover,
        .nav-dropdown-link.active {
            color: #D1AC62 !important;
            background: #ffffff !important;
        }

        /* Pinned Drawer Bottom CTA Wrapper */
        .mobile-cta-wrapper {
            padding: 1.25rem 1.25rem !important;
            border-top: 1px solid #efe8da !important;
            background: #faf8f3 !important;
            margin-top: auto !important;
            box-sizing: border-box !important;
        }

        .mobile-cta-wrapper .nav-btn {
            width: 100% !important;
            padding: 0.95rem !important;
            text-align: center !important;
            font-family: 'Marcellus', serif !important;
            border-radius: 32px !important;
            background: #D1AC62 !important;
            color: #ffffff !important;
            text-decoration: none !important;
            display: block !important;
            box-shadow: 0 6px 20px rgba(209, 172, 98, 0.3) !important;
            font-size: 0.88rem !important;
            font-weight: 700 !important;
            letter-spacing: 0.08em !important;
            text-transform: uppercase !important;
            border: none !important;
        }

        .header-cta {
            display: none !important;
        }
    }

    @media (max-width: 768px) {
        .about-section,
        .villas-section,
        .location-section,
        .amenities-section,
        .investment-section,
        .testimonials-section,
        .gallery-section,
        .blog-section,
        .faq-section,
        .contact-main-wrapper,
        .gallery-main-wrapper,
        .blog-main-wrapper,
        .blog-detail-main-wrapper,
        .gallery-cta-section,
        .res-gallery-section,
        .bhk-carousel-section {
            padding-top: 3rem !important;
            padding-bottom: 3rem !important;
        }

        .contact-hero-light {
            min-height: 340px !important;
            padding-top: 5.75rem !important;
            padding-bottom: 2.5rem !important;
        }

        .about-residence-box {
            text-align: center !important;
        }

        .about-residence-box .res-heading-line {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        .about-header,
        .villas-header,
        .amenities-header,
        .investment-header,
        .testimonials-header,
        .gallery-header,
        .faq-header,
        .gallery-header-center,
        .blog-header,
        .blog-detail-meta-bar {
            margin-bottom: 1.5rem !important;
        }

        .contact-heading,
        .gallery-cta-title,
        .blog-featured-title,
        .blog-detail-page-body .contact-hero-light-title {
            margin-bottom: 0.65rem !important;
        }

        .contact-main-container,
        .gallery-grid,
        .blog-grid,
        .investment-content-wrapper,
        .location-content-wrapper,
        .faq-content-wrapper,
        .res-details-wrapper,
        .plum-details-layout {
            gap: 1.5rem !important;
        }

        .blog-grid,
        .gallery-grid,
        .res-gallery-grid {
            margin-top: 1.75rem !important;
        }

        .faq-page-section {
            padding-bottom: 1.25rem !important;
        }

        .faq-page-body .gallery-cta-section {
            padding-top: 1.5rem !important;
        }

        .btn-primary,
        .btn-secondary,
        .send-msg-btn,
        .gallery-cta-btn,
        .about-cta-btn,
        .location-cta-btn,
        .villa-btn,
        .villa-btn-quote,
        .villa-btn-details,
        .amenity-view-btn,
        .investment-brochure-btn,
        .faq-contact-btn,
        .footer-enquire-btn,
        .footer-newsletter-btn,
        .blog-read-btn,
        .blog-card-btn {
            min-width: 0 !important;
            min-height: 40px !important;
            width: auto !important;
            max-width: 100% !important;
            padding: 0.62rem 1.25rem !important;
            font-size: 0.78rem !important;
            line-height: 1.1 !important;
            letter-spacing: 0.05em !important;
        }

        .hero-actions .btn-primary,
        .hero-actions .btn-secondary {
            width: 100% !important;
        }

        .mobile-cta-wrapper .nav-btn {
            padding: 0.7rem 1rem !important;
            font-size: 0.78rem !important;
            min-height: 40px !important;
        }

        .hero-header {
            z-index: 100000 !important;
        }

        .mobile-nav-backdrop {
            z-index: 99998 !important;
        }

        .mobile-menu-toggle {
            position: relative !important;
            z-index: 100001 !important;
            pointer-events: auto !important;
        }

        .nav-container {
            visibility: hidden !important;
            opacity: 1 !important;
            pointer-events: none !important;
            transform: translateX(100%) !important;
            z-index: 100000 !important;
        }

        .nav-container.active {
            visibility: visible !important;
            pointer-events: auto !important;
            transform: translateX(0) !important;
        }
    }
  </style>

</head>

<body><?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/includes/CssLink.blade.php ENDPATH**/ ?>