<?php if(Session::get('admin_login')): ?>

<?php $__env->startSection('main-content'); ?>
    <style>
        .table-responsive-athlo {
            width: 100%;
            overflow-x: auto !important;
            -webkit-overflow-scrolling: touch;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
        }
        .table-athlo {
            margin-bottom: 0 !important;
            white-space: nowrap;
            width: 100%;
        }
        .table-athlo th {
            background-color: #f8fafc;
            color: #475569;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            padding: 12px 16px;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }
        .table-athlo td {
            padding: 12px 16px;
            vertical-align: middle;
            color: #334155;
            font-size: 13px;
            white-space: nowrap;
        }

        .th-nowrap th {
            white-space: nowrap;
        }

        .gallery-img-thumb {
            height: 55px;
            width: 75px;
            object-fit: cover;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.25s ease;
            border: 2px solid #eef2f7;
        }

        .gallery-img-thumb:hover {
            transform: scale(1.08);
            box-shadow: 0 4px 14px rgba(204, 164, 59, 0.4);
            border-color: #CCA43B !important;
        }

        /* 🖼️ Fullscreen Image Lightbox Overlay */
        #imgLightbox {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(15, 23, 42, 0.95);
            z-index: 999999;
            display: none;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            backdrop-filter: blur(8px);
        }
        #imgLightbox.active {
            display: flex !important;
        }
        #imgLightbox img {
            max-width: 85vw;
            max-height: 75vh;
            border-radius: 12px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.8);
            object-fit: contain;
            border: 2px solid rgba(255,255,255,0.15);
        }
        .lb-close {
            position: absolute;
            top: 24px;
            right: 32px;
            color: #ffffff;
            font-size: 36px;
            cursor: pointer;
            line-height: 1;
            transition: all 0.2s ease;
            z-index: 10;
        }
        .lb-close:hover {
            color: #CCA43B;
            transform: scale(1.15);
        }
        .lb-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            color: #ffffff;
            font-size: 26px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.12);
            width: 52px;
            height: 52px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            z-index: 10;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .lb-nav:hover {
            background: #CCA43B;
            color: #ffffff;
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 0 15px rgba(204,164,59,0.6);
        }
        .lb-prev { left: 32px; }
        .lb-next { right: 32px; }
        .lb-label {
            margin-top: 18px;
            color: #e2e8f0;
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.5px;
            background: rgba(0,0,0,0.4);
            padding: 6px 18px;
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
    </style>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                    <!-- Filter Bar -->
                    <div class="filter-card-container mb-4">
                        <div class="row align-items-end g-3">
                            <div class="col-xl-4 col-lg-4 col-md-5">
                                <label class="filter-section-title">SEARCH GALLERY</label>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="search-input-pill flex-grow-1">
                                        <i class="bi bi-search"></i>
                                        <input type="text" class="search_gallery" placeholder="Search title, category, description..." />
                                    </div>
                                    <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                        <i class="bi bi-file-earmark-excel-fill"></i>
                                    </a>
                                </div>
                            </div>

                            <div class="col-xl-3 col-lg-3 col-md-4">
                                <label class="filter-section-title">FILTER BY CATEGORY</label>
                                <select id="filter_category" class="form-select form-control-3d">
                                    <option value="">All Categories</option>
                                    <?php if(!empty($categories)): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-xl-auto col-lg-auto col-md-auto">
                                <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                    <i class="bi bi-arrow-counterclockwise"></i> Reset
                                </button>
                            </div>

                            <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                                <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddGalleryModal">
                                    <i class="bi bi-plus-lg me-1"></i> Add Gallery Photo
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Gallery Table -->
                    <div class="table-responsive-athlo mb-3">
                        <table id="galleryTable" class="table table-hover table-athlo align-middle">
                            <thead class="th-nowrap">
                                <tr>
                                    <th>#</th>
                                    <th>Action</th>
                                    <th>Status</th>
                                    <th>Image</th>
                                    <th>Category</th>
                                    <th style="min-width: 180px;">Title</th>
                                    <th style="min-width: 250px;">Description</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <nav class="mt-2">
                        <ul id="pagination" class="pagination justify-content-center"></ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Gallery Modal -->
    <div class="modal fade" id="AddGalleryModal" tabindex="-1" aria-labelledby="addGalleryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content modal-content-3d">
                <div class="modal-header modal-header-3d">
                    <h5 class="modal-title" id="addGalleryModalLabel"><i class="bi bi-images me-2"></i>Add Gallery Photo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body modal-body-3d p-4">
                    <form id="add_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label form-label-3d">Category <span class="text-danger">*</span></label>
                                <select name="category_id" class="form-select form-control-3d" required>
                                    <option value="" selected disabled>Select Gallery Category</option>
                                    <?php if(!empty($categories)): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label form-label-3d">Photo Title <span class="text-danger">*</span></label>
                                <input type="text" name="title" class="form-control form-control-3d" placeholder="e.g. Master Bedroom Suite" required>
                            </div>

                            <div class="col-12">
                                <label class="form-label form-label-3d">Gallery Image <span class="text-danger">*</span></label>
                                <input type="file" name="image" class="form-control form-control-3d" accept="image/*" required>
                            </div>

                            <div class="col-12">
                                <label class="form-label form-label-3d">Description</label>
                                <textarea name="description" class="form-control form-control-3d" rows="3" placeholder="Brief description of the space or view..."></textarea>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4">
                            <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Save Photo</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Gallery Modal -->
    <div class="modal fade" id="EditGalleryModal" tabindex="-1" aria-labelledby="editGalleryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content modal-content-3d">
                <div class="modal-header modal-header-3d">
                    <h5 class="modal-title" id="editGalleryModalLabel"><i class="bi bi-pencil-square me-2"></i>Edit Gallery Photo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body modal-body-3d p-4">
                    <form id="edit_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="edit_gallery_id">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label form-label-3d">Category <span class="text-danger">*</span></label>
                                <select name="category_id" id="edit_gallery_category_id" class="form-select form-control-3d" required>
                                    <option value="" disabled>Select Gallery Category</option>
                                    <?php if(!empty($categories)): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label form-label-3d">Photo Title <span class="text-danger">*</span></label>
                                <input type="text" name="title" id="edit_gallery_title" class="form-control form-control-3d" required>
                            </div>

                            <div class="col-12">
                                <label class="form-label form-label-3d">Change Image (Optional)</label>
                                <div class="d-flex align-items-center gap-3">
                                    <input type="file" name="image" class="form-control form-control-3d flex-grow-1" accept="image/*">
                                    <div id="edit_gallery_img_preview"></div>
                                </div>
                            </div>

                            <div class="col-12">
                                <label class="form-label form-label-3d">Description</label>
                                <textarea name="description" id="edit_gallery_description" class="form-control form-control-3d" rows="3"></textarea>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 mt-4">
                            <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Update Photo</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Lightbox HTML -->
    <div id="imgLightbox">
        <span class="lb-close" id="lbClose">&times;</span>
        <span class="lb-nav lb-prev" id="lbPrev" onclick="navigateGalleryLightbox(-1)"><i class="bi bi-chevron-left"></i></span>
        <img src="" id="lbImg">
        <span class="lb-nav lb-next" id="lbNext" onclick="navigateGalleryLightbox(1)"><i class="bi bi-chevron-right"></i></span>
        <div class="lb-label" id="lbLabel"></div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
            <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
                <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                    <div style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                        <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                    </div>
                    <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
                </div>
                <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                    <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this gallery photo? This action <strong>cannot be undone.</strong></p>
                </div>
                <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                    <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="delete_id" value="">
                        <button type="button" class="btn" data-bs-dismiss="modal" style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                        <button type="submit" class="btn btn_delete" style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes, Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var currentPage = 1;

            // Search
            $('.search_gallery').on('keyup', function() {
                currentPage = 1;
                showdata(1);
            });

            // Filter category
            $('#filter_category').on('change', function() {
                currentPage = 1;
                showdata(1);
            });

            // Reset
            $('#reset_filter').click(function() {
                $('.search_gallery').val('');
                $('#filter_category').val('');
                currentPage = 1;
                showdata(1);
            });

            // Initial load
            showdata(1);

            function showdata(page = 1) {
                var search = $('.search_gallery').val();
                var category_id = $('#filter_category').val();

                $.ajax({
                    url: "<?php echo e(url('/show_gallery')); ?>",
                    type: 'POST',
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        search: search,
                        category_id: category_id,
                        page: page
                    },
                    success: function (response) {
                        var tbody = $('#galleryTable tbody');
                        var pagination = $('#pagination');
                        var result = response.data;

                        tbody.empty();
                        pagination.empty();

                        if (response.data && response.data.length > 0) {
                            currentPage = response.current_page;
                        } else {
                            if (page > 1) {
                                showdata(page - 1);
                                return;
                            }
                            currentPage = 1;
                        }

                        window.galleryList = [];
                        if (!result || result.length === 0) {
                            tbody.append('<tr><td colspan="9" class="text-center py-5 text-muted"><i class="bi bi-images text-muted d-block mb-2" style="font-size:36px;"></i>No gallery photos found. Click <strong>+ Add Gallery Photo</strong> to upload.</td></tr>');
                        } else {
                            result.forEach(function (data, index) {
                                var globalIndex = index + 1 + (response.current_page - 1) * response.per_page;
                                var createdAtVal = formatDateTime(data.created_at);
                                var updatedAtVal = formatDateTime(data.updated_at);
                                var cleanJson = JSON.stringify(data).replace(/'/g, "&apos;");

                                window.galleryList.push({
                                    src: data.image,
                                    label: (data.title && data.title !== '-') ? data.title : ('Gallery Image #' + globalIndex)
                                });

                                var catBadge = `<span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-tag-fill me-1 text-warning"></i>${data.category_name || '-'}</span>`;

                                tbody.append(`
                                    <tr>
                                        <td>${globalIndex}</td>
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="javascript:void(0);" class="btn-act-edit edit_gallery_btn" title="Edit" data-json='${cleanJson}'><i class="bi bi-pencil-fill"></i></a>
                                                <a class="btn-act-del delete_gallery_btn" title="Delete" href="javascript:void(0);" data-id="${data.id}"><i class="bi bi-trash3-fill"></i></a>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="custom-switch">
                                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input StatusSwitch" value="${data.id}" ${data.status == 1 ? 'checked' : ''}>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </td>
                                        <td><img src="${data.image}" class="gallery-img-thumb" onclick="viewFullImage('${data.image}', '${(data.title && data.title !== '-') ? data.title.replace(/'/g, "\\'") : 'Gallery Image #' + globalIndex}', ${index})" title="Click to view full screen" /></td>
                                        <td>${catBadge}</td>
                                        <td class="fw-bold text-dark" style="min-width:180px;max-width:260px;white-space:normal;line-height:1.4;">${data.title || '-'}</td>
                                        <td style="min-width:250px;max-width:350px;font-size:13px;color:#64748b;white-space:normal;line-height:1.45;">${data.description || '-'}</td>
                                        <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-calendar-plus me-1 text-primary"></i>${createdAtVal}</span></td>
                                        <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock-history me-1 text-success"></i>${updatedAtVal}</span></td>
                                    </tr>
                                `);
                            });
                        }

                        // Pagination
                        if (response.last_page > 1) {
                            for (var p = 1; p <= response.last_page; p++) {
                                var activeClass = p === response.current_page ? 'active' : '';
                                pagination.append(`
                                    <li class="page-item ${activeClass}">
                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(${p})">${p}</a>
                                    </li>
                                `);
                            }
                        }

                        }
                    });
            }
            window.showdata = showdata;

            // Add Form Submit
            $('#add_form').submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                $('.btn_submit').prop('disabled', true);

                $.ajax({
                    url: "<?php echo e(url('/add_gallery')); ?>",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        $('.btn_submit').prop('disabled', false);
                        if (res.success === 'success') {
                            $('#AddGalleryModal').modal('hide');
                            $('#add_form')[0].reset();
                            showToast(res.message || 'Gallery photo added successfully!', 'success');
                            showdata(currentPage);
                        } else {
                            showToast(res.message || 'Failed to add gallery photo', 'error');
                        }
                    },
                    error: function(err) {
                        $('.btn_submit').prop('disabled', false);
                        showToast('Something went wrong. Please check your inputs.', 'error');
                    }
                });
            });

            // Edit Open
            $(document).on('click', '.edit_gallery_btn', function() {
                var item = $(this).data('json');
                $('#edit_gallery_id').val(item.id);
                $('#edit_gallery_category_id').val(item.category_id || '');
                $('#edit_gallery_title').val(item.title !== '-' ? item.title : '');
                $('#edit_gallery_description').val(item.description || '');

                if (item.image) {
                    $('#edit_gallery_img_preview').html('<img src="' + item.image + '" class="rounded-3 border" style="width:70px;height:50px;object-fit:cover;">');
                } else {
                    $('#edit_gallery_img_preview').empty();
                }

                $('#EditGalleryModal').modal('show');
            });

            // Edit Form Submit
            $('#edit_form').submit(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                $('.btn_submit').prop('disabled', true);

                $.ajax({
                    url: "<?php echo e(url('/update_gallery')); ?>",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        $('.btn_submit').prop('disabled', false);
                        if (res.success === 'success') {
                            $('#EditGalleryModal').modal('hide');
                            showToast(res.message || 'Gallery photo updated successfully!', 'success');
                            showdata(currentPage);
                        } else {
                            showToast(res.message || 'Failed to update gallery photo', 'error');
                        }
                    },
                    error: function() {
                        $('.btn_submit').prop('disabled', false);
                        showToast('Something went wrong while updating.', 'error');
                    }
                });
            });

            // Delete Open
            $(document).on('click', '.delete_gallery_btn', function () {
                var id = $(this).data("id");
                $("#delete_id").val(id);
                $("#deletemodal").modal("show");
            });

            // Delete Form Submit
            $("#delete_form").submit(function (e) {
                $(".btn_delete").prop('disabled', true);
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('/delete_gallery')); ?>",
                    data: formData,
                    dataType: "json",
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        $(".btn_delete").prop('disabled', false);
                        $("#deletemodal").modal("hide");
                        if (response.success === 'success') {
                            showToast('Gallery photo deleted successfully!', 'success');
                            showdata(currentPage);
                        } else {
                            showToast(response.message || 'Failed to delete photo', 'error');
                        }
                    },
                    error: function () {
                        $(".btn_delete").prop('disabled', false);
                        showToast('Something went wrong while deleting', 'error');
                    }
                });
            });

            // Lightbox functionality
            var currentLightboxIndex = 0;
            window.viewFullImage = function(src, label, index) {
                currentLightboxIndex = index !== undefined ? index : 0;
                $('#lbImg').attr('src', src);
                $('#lbLabel').text(label || '');
                $('#imgLightbox').addClass('active');
            };

            $('#lbClose').click(function() {
                $('#imgLightbox').removeClass('active');
            });

            $('#imgLightbox').click(function(e) {
                if (e.target.id === 'imgLightbox') {
                    $(this).removeClass('active');
                }
            });

            window.navigateGalleryLightbox = function(step) {
                if (!window.galleryList || window.galleryList.length === 0) return;
                currentLightboxIndex = (currentLightboxIndex + step + window.galleryList.length) % window.galleryList.length;
                var current = window.galleryList[currentLightboxIndex];
                $('#lbImg').attr('src', current.src);
                $('#lbLabel').text(current.label);
            };
        });
    </script>

<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DOWNLOADS\ulhas-vilas\ulhas-vilas.partnersindia.com\resources\views/Admin/pages/gallery.blade.php ENDPATH**/ ?>