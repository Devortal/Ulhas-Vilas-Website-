<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- GLASS HEADER NAVIGATION -->
    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php
        $info = DB::table('information')->first();
        $reraNo = (!empty($info) && !empty($info->rera_number)) ? $info->rera_number : 'HP/RERA/2024/001';
    ?>

    <!-- =========================================================
         HERO BANNER
    ========================================================= -->
    <section class="contact-hero-light">
        <div class="contact-hero-slider-track" id="disclaimerHeroTrack">
            <div class="contact-hero-slide active">
                <img src="<?php echo e(asset('Website/assets/images/mountain.jpeg')); ?>" alt="The Ulhas Vilas Disclaimer & RERA Compliance">
            </div>
        </div>
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">Disclaimer & <span>RERA Compliance</span></h1>
            <p class="contact-hero-light-sub">Statutory project approvals, artistic representation disclaimers, and official RERA registration details.</p>
        </div>
    </section>

    <style>
    .policy-page-wrapper {
        background: #FDFBF7;
        padding: 4.5rem 1.5rem 6rem;
        color: #1A202C;
    }
    .policy-container {
        max-width: 1040px;
        margin: 0 auto;
    }
    .policy-meta-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.85rem;
        padding: 1.15rem 1.6rem;
        background: #FFFFFF;
        border: 1px solid #ECE7DC;
        border-radius: 14px;
        margin-bottom: 2.25rem;
        box-shadow: 0 4px 16px rgba(0,0,0,0.03);
    }
    .policy-meta-left {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.75rem;
    }
    .policy-meta-badge {
        font-size: 0.72rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.14em;
        color: #DCB658;
        background: rgba(220, 182, 88, 0.12);
        padding: 0.35rem 0.8rem;
        border-radius: 9999px;
        border: 1px solid rgba(220, 182, 88, 0.3);
        display: inline-block;
        white-space: nowrap;
    }
    .policy-meta-right {
        font-size: 0.82rem;
        color: #64748B;
    }
    .policy-rera-highlight {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        padding: 1.1rem 1.4rem;
        background: rgba(220, 182, 88, 0.08);
        border: 1px solid rgba(220, 182, 88, 0.35);
        border-radius: 14px;
        margin-bottom: 2rem;
    }
    .policy-rera-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #DCB658;
        color: #0E1114;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .policy-card {
        background: #FFFFFF;
        border: 1px solid #ECE7DC;
        border-radius: 18px;
        padding: 3rem 3.5rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
        line-height: 1.85;
    }
    .policy-content {
        font-family: var(--font-body, system-ui, sans-serif);
        font-size: 0.98rem;
        color: #374151;
        word-break: break-word;
        overflow-wrap: break-word;
    }
    .policy-content h2, .policy-content h3 {
        font-family: 'Marcellus', serif;
        color: #111827;
        font-weight: 400;
        margin-top: 2.25rem;
        margin-bottom: 0.85rem;
        line-height: 1.35;
        letter-spacing: -0.01em;
    }
    .policy-content h2 {
        font-size: 1.65rem;
        border-bottom: 1px solid #ECE7DC;
        padding-bottom: 0.5rem;
    }
    .policy-content h3 {
        font-size: 1.3rem;
        color: #1a1f2c;
    }
    .policy-content p {
        margin-bottom: 1.25rem;
        color: #4B5563;
    }
    .policy-content ul, .policy-content ol {
        margin-bottom: 1.5rem;
        padding-left: 1.5rem;
        color: #4B5563;
    }
    .policy-content li {
        margin-bottom: 0.6rem;
    }
    .policy-content strong {
        color: #111827;
    }
    .policy-content a {
        color: #A37D38;
        text-decoration: underline;
        text-underline-offset: 3px;
        transition: color 0.2s ease;
    }
    .policy-content a:hover {
        color: #DCB658;
    }
    .policy-contact-box {
        margin-top: 3rem;
        padding: 2rem 2.25rem;
        background: linear-gradient(135deg, #12161c 0%, #1c222b 100%);
        border-radius: 14px;
        color: #FFFFFF;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 1.5rem;
        border: 1px solid rgba(220, 182, 88, 0.3);
    }
    .policy-contact-text h4 {
        font-family: 'Marcellus', serif;
        font-size: 1.3rem;
        color: #DCB658;
        margin: 0 0 0.35rem 0;
    }
    .policy-contact-text p {
        margin: 0;
        color: rgba(255,255,255,0.78);
        font-size: 0.92rem;
    }
    .policy-contact-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.75rem 1.6rem;
        background: #DCB658;
        color: #0E1114;
        font-size: 0.85rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        border-radius: 9999px;
        text-decoration: none;
        transition: all 0.3s ease;
        white-space: nowrap;
    }
    .policy-contact-btn:hover {
        background: #e8c670;
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(220,182,88,0.35);
        color: #0E1114;
    }

    /* 📱 RESPONSIVE MOBILE OPTIMIZATIONS */
    @media (max-width: 768px) {
        .policy-page-wrapper {
            padding: 3rem 1.25rem 4.5rem;
        }
        .policy-card {
            padding: 2.25rem 1.75rem;
            border-radius: 16px;
        }
    }
    @media (max-width: 640px) {
        .contact-hero-light {
            height: 270px !important;
            padding: 1.5rem 1rem !important;
        }
        .contact-hero-light-title {
            font-size: 1.75rem !important;
        }
        .contact-hero-light-sub {
            font-size: 0.86rem !important;
            line-height: 1.5 !important;
        }
        .policy-page-wrapper {
            padding: 2rem 0.85rem 3.5rem !important;
        }
        .policy-meta-bar {
            flex-direction: column;
            align-items: flex-start;
            padding: 1rem 1.15rem;
            gap: 0.65rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
        }
        .policy-meta-left {
            width: 100%;
            justify-content: space-between;
            align-items: center;
        }
        .policy-meta-right {
            width: 100%;
            font-size: 0.78rem;
            padding-top: 0.45rem;
            border-top: 1px dashed #ECE7DC;
        }
        .policy-rera-highlight {
            flex-direction: column;
            align-items: flex-start;
            padding: 1rem 1.15rem !important;
            gap: 0.75rem !important;
            border-radius: 12px;
        }
        .policy-card {
            padding: 1.5rem 1.15rem !important;
            border-radius: 14px !important;
        }
        .policy-content h2 {
            font-size: 1.32rem !important;
            margin-top: 1.6rem !important;
            margin-bottom: 0.65rem !important;
        }
        .policy-content h3 {
            font-size: 1.12rem !important;
            margin-top: 1.4rem !important;
            margin-bottom: 0.55rem !important;
        }
        .policy-content p, .policy-content li {
            font-size: 0.92rem !important;
            line-height: 1.68 !important;
            margin-bottom: 1rem !important;
        }
        .policy-content ul, .policy-content ol {
            padding-left: 1.15rem !important;
            margin-bottom: 1.15rem !important;
        }
        .policy-contact-box {
            flex-direction: column;
            align-items: stretch;
            padding: 1.35rem 1.15rem !important;
            gap: 1.15rem !important;
            margin-top: 2.25rem !important;
            border-radius: 12px;
        }
        .policy-contact-text h4 {
            font-size: 1.15rem !important;
        }
        .policy-contact-text p {
            font-size: 0.86rem !important;
            line-height: 1.5 !important;
        }
        .policy-contact-btn {
            width: 100%;
            padding: 0.75rem 1rem;
            font-size: 0.82rem;
        }
    }
    </style>

    <!-- =========================================================
         MAIN POLICY CONTENT SECTION
    ========================================================= -->
    <section class="policy-page-wrapper">
        <div class="policy-container">
            
            <div class="policy-meta-bar">
                <div class="policy-meta-left">
                    <span class="policy-meta-badge">Statutory Compliance</span>
                    <p style="margin:0; font-size:0.88rem; color:#64748B;">RERA No: <strong><?php echo e($reraNo); ?></strong></p>
                </div>
                <div class="policy-meta-right">
                    <span>Himachal Pradesh Real Estate Regulatory Authority</span>
                </div>
            </div>

            <div class="policy-card">
                
                <!-- RERA Callout Strip -->
                <div class="policy-rera-highlight">
                    <div class="policy-rera-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>
                    </div>
                    <div>
                        <div style="font-size: 0.95rem; font-weight: 700; color: #111827;">Himachal Pradesh RERA Registered Project</div>
                        <div style="font-size: 0.84rem; color: #64748B;">Registration Certificate No: <strong style="color: #A37D38;"><?php echo e($reraNo); ?></strong> | Available for verification at HP RERA official portal.</div>
                    </div>
                </div>

                <div class="policy-content">
                    <?php if(!empty($content)): ?>
                        <?php echo $content; ?>

                    <?php elseif(!empty($info->return_policy)): ?>
                        <?php echo $info->return_policy; ?>

                    <?php else: ?>
                        <h3>1. Official RERA Compliance</h3>
                        <p>The project <strong>The Ulhas Vilas</strong> is developed in compliance with the Real Estate (Regulation and Development) Act, 2016 (RERA). The project is duly registered with the Himachal Pradesh Real Estate Regulatory Authority under Registration Certificate Number: <strong><?php echo e($reraNo); ?></strong>.</p>

                        <h3>2. Artistic Impressions & Visual Representations</h3>
                        <p>All visual representations, 3D renderings, computer-generated walkthroughs, landscape illustrations, floor layout plans, interior designs, furniture placements, decor fixtures, and scenic views depicted on this website are <strong>artistic impressions and conceptual representations</strong>.</p>

                        <h3>3. No Binding Offer or Warranty</h3>
                        <p>The contents of this website and marketing materials are for promotional and informational guidance only and do not constitute an offer, warranty, or binding legal contract.</p>

                        <h3>4. Agreement for Sale Governs All Allotments</h3>
                        <p>The actual layout, carpet areas, structural specifications, fixtures, fittings, completion timelines, and payment obligations shall be strictly governed by the registered <strong>Agreement for Sale</strong> executed between the buyer and the promoter.</p>
                    <?php endif; ?>
                </div>

                <div class="policy-contact-box">
                    <div class="policy-contact-text">
                        <h4>Need verification or compliance assistance?</h4>
                        <p>Our project compliance desk can provide sanctioned blueprint documentation.</p>
                    </div>
                    <a href="<?php echo e(url('/contact')); ?>" class="policy-contact-btn">Contact Compliance Desk</a>
                </div>
            </div>

        </div>
    </section>

    <!-- FOOTER & SCRIPTS -->
    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/disclaimer.blade.php ENDPATH**/ ?>