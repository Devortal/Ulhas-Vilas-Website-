<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- GLASS HEADER NAVIGATION -->
    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- =========================================================
         HERO BANNER (WITH STATIC BACKGROUND IMAGE)
    ========================================================= -->
    <section class="contact-hero-light">
        <img src="<?php echo e(asset('Website/assets/images/contact2.jpeg')); ?>" alt="Contact The Ulhas Vilas" class="contact-hero-light-bg">
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">Contact <span>us</span></h1>
            <p class="contact-hero-light-sub">Start the conversation to establish a good relationship and private estate inquiries.</p>
        </div>
    </section>

    <!-- =========================================================
         MAIN CONTENT SECTION (MATCHING UI LAYOUT)
    ========================================================= -->
    <section class="contact-main-wrapper">
        <div class="contact-main-container">
            
            <!-- LEFT COLUMN: Contact Details & Social Links -->
            <div class="contact-left-col">
                <span class="contact-eyebrow">GET IN TOUCH</span>
                <h2 class="contact-heading">Seamless <span>Communication</span>,<br>Global Impact.</h2>
                <p class="contact-desc-text">
                    <?php echo e((!empty($info) && !empty($info->footer_about)) ? $info->footer_about : 'Whether you wish to schedule an exclusive private estate visit, enquire about our bespoke 1, 2, 3 & 4 BHK residences, or connect with our relationship management team, we are at your service.'); ?>

                </p>

                <!-- 2x2 Info Grid -->
                <div class="contact-info-grid">
                    
                    <!-- 1. Head Office -->
                    <div class="contact-info-item">
                        <div class="contact-info-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <div>
                            <h4 class="contact-info-label">Head Office</h4>
                            <div class="contact-info-detail">
                                <?php echo nl2br(e($info->address ?? 'Shimla Highway, Solan, Himachal Pradesh - 173212, India')); ?>

                            </div>
                        </div>
                    </div>

                    <!-- 2. Email Support -->
                    <div class="contact-info-item">
                        <div class="contact-info-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        </div>
                        <div>
                            <h4 class="contact-info-label">Email Support</h4>
                            <div class="contact-info-detail">
                                <?php if(!empty($info) && !empty($info->email)): ?>
                                    <a href="mailto:<?php echo e($info->email); ?>"><?php echo e($info->email); ?></a>
                                <?php else: ?>
                                    <a href="mailto:enquiries@ulhasvilas.com">enquiries@ulhasvilas.com</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Call Us -->
                    <div class="contact-info-item">
                        <div class="contact-info-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.12 6.12l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                        </div>
                        <div>
                            <h4 class="contact-info-label">Call Us</h4>
                            <div class="contact-info-detail">
                                <?php if(!empty($info) && !empty($info->mobile)): ?>
                                    <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $info->mobile)); ?>"><?php echo e($info->mobile); ?></a>
                                <?php else: ?>
                                    <a href="tel:+919876543210">+91 98765 43210</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Office Hour -->
                    <div class="contact-info-item">
                        <div class="contact-info-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        </div>
                        <div>
                            <h4 class="contact-info-label">Office Hour</h4>
                            <div class="contact-info-detail">
                                <?php echo nl2br(e($info->office_time ?? "Mon - Sat : 09:00 - 18:00\nSun : 10:00 - 17:00")); ?>

                            </div>
                        </div>
                    </div>

                </div>

                <!-- Social Network Row -->
                <?php
                    $fb = $info->facebook_link ?? null;
                    $insta = $info->instagram_link ?? null;
                    $tw = $info->twitter_link ?? null;
                    $yt = $info->youtube_link ?? null;
                    $li = $info->linkedin_link ?? null;
                ?>
                <?php if(!empty($fb) || !empty($insta) || !empty($tw) || !empty($yt) || !empty($li)): ?>
                <div class="contact-social-section">
                    <h4 class="contact-social-title">Follow us on social network</h4>
                    <div class="contact-social-btns-row">
                        <?php if(!empty($fb)): ?>
                            <a href="<?php echo e($fb); ?>" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Facebook">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if(!empty($insta)): ?>
                            <a href="<?php echo e($insta); ?>" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Instagram">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if(!empty($tw)): ?>
                            <a href="<?php echo e($tw); ?>" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Twitter">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if(!empty($li)): ?>
                            <a href="<?php echo e($li); ?>" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="LinkedIn">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if(!empty($yt)): ?>
                            <a href="<?php echo e($yt); ?>" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="YouTube">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>

            <!-- RIGHT COLUMN: Send Us A Message Form Card -->
            <div class="contact-right-col">
                <div class="contact-form-card" id="contactFormWrapper">
                    <h3 class="contact-form-card-title">Send Us A <span>Message</span></h3>
                    <p class="contact-form-card-sub">Our relationship managers are available to assist you with private site visits and residence details.</p>

                    <form id="lightContactForm" method="post" action="<?php echo e(url('/contact_submit')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row-2col">
                            <div class="form-field-group" style="margin-bottom:0;">
                                <label for="cName" class="form-field-label">Full Name *</label>
                                <input type="text" name="name" id="cName" class="form-field-input" placeholder="Full Name" required minlength="2" maxlength="100">
                            </div>
                            <div class="form-field-group" style="margin-bottom:0;">
                                <label for="cPhone" class="form-field-label">Mobile Number *</label>
                                <input type="tel" name="mobile" id="cPhone" class="form-field-input" placeholder="10-digit Mobile Number" required minlength="10" maxlength="10" pattern="[0-9]{10}" inputmode="numeric">
                                <span class="field-validation-error" id="cPhoneError" style="display:none; color:#dc2626; font-size:12px; font-weight:600; margin-top:4px;">Please enter a valid 10-digit mobile number.</span>
                            </div>
                        </div>

                        <div class="form-row-2col">
                            <div class="form-field-group" style="margin-bottom:0;">
                                <label for="cEmail" class="form-field-label">Email Address *</label>
                                <input type="email" name="email" id="cEmail" class="form-field-input" placeholder="Email Address" required maxlength="150">
                            </div>
                            <div class="form-field-group" style="margin-bottom:0;">
                                <label for="cCity" class="form-field-label">City *</label>
                                <input type="text" name="city" id="cCity" class="form-field-input" placeholder="City / Location" required minlength="2" maxlength="100">
                            </div>
                        </div>

                        <div class="form-field-group">
                            <label for="cConfig" class="form-field-label">Preferred Residence / Typology *</label>
                            <select name="residence_id" id="cConfig" class="form-field-select" required>
                                <option value="" disabled selected>Select Preferred Residence</option>
                                <?php if(!empty($residences) && count($residences) > 0): ?>
                                    <?php $__currentLoopData = $residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($res->id); ?>"><?php echo e($res->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif(!empty($categories) && count($categories) > 0): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->category_name); ?>"><?php echo e($cat->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option value="1 BHK Villa">1 BHK Villa</option>
                                    <option value="2 BHK Villa">2 BHK Villa</option>
                                    <option value="3 BHK Villa">3 BHK Villa</option>
                                    <option value="4 BHK Villa">4 BHK Villa</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-field-group">
                            <label for="cMessage" class="form-field-label">Message *</label>
                            <textarea name="message" id="cMessage" class="form-field-textarea" placeholder="Tell us about your requirements or preferred visit dates..." required minlength="5" maxlength="1000"></textarea>
                        </div>

                        <button type="submit" id="contactSubmitBtn" class="send-msg-btn">SEND US A MESSAGE</button>
                    </form>
                </div>
            </div>

        </div>
    </section>

    <!-- =========================================================
         MAP SECTION (FULL WIDTH DIRECTLY BELOW CONTENT)
    ========================================================= -->
    <section class="contact-map-fullwidth">
        <?php
            $rawMap = !empty($info) && !empty($info->map_link) ? trim($info->map_link) : '';
            $mapSrc = '';
            if (!empty($rawMap)) {
                if (preg_match('/src=[\'"]([^\'"]+)[\'"]/', $rawMap, $matches)) {
                    $mapSrc = $matches[1];
                } else {
                    $mapSrc = $rawMap;
                }
            }
        ?>
        <?php if(!empty($mapSrc)): ?>
            <iframe src="<?php echo e($mapSrc); ?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        <?php else: ?>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d109252.12480373859!2d77.05436665000001!3d31.1048145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390578e3e35d6e67%3A0x7d02377b212f717!2sShimla%2C%20Himachal%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        <?php endif; ?>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var form = document.getElementById('lightContactForm');
            var phoneInput = document.getElementById('cPhone');
            var phoneError = document.getElementById('cPhoneError');

            if (phoneInput && phoneError) {
                phoneInput.addEventListener('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
                    if (this.value.length === 10) {
                        phoneError.style.display = 'none';
                        phoneInput.style.borderColor = '';
                    } else if (this.value.length > 0) {
                        phoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                        phoneError.style.display = 'block';
                        phoneInput.style.borderColor = '#dc2626';
                    } else {
                        phoneError.style.display = 'none';
                        phoneInput.style.borderColor = '';
                    }
                });

                phoneInput.addEventListener('blur', function() {
                    if (this.value.length > 0 && this.value.length !== 10) {
                        phoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                        phoneError.style.display = 'block';
                        phoneInput.style.borderColor = '#dc2626';
                    }
                });
            }

            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();

                    if (phoneInput && phoneInput.value.trim().length !== 10) {
                        if (phoneError) {
                            phoneError.textContent = 'Mobile number must be exactly 10 digits.';
                            phoneError.style.display = 'block';
                        }
                        phoneInput.style.borderColor = '#dc2626';
                        phoneInput.focus();
                        return;
                    }

                    var submitBtn = document.getElementById('contactSubmitBtn');
                    var originalText = submitBtn.innerHTML;
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<span class="form-btn-spinner"></span> SENDING MESSAGE...';

                    var formData = new FormData(form);

                    fetch("<?php echo e(url('/contact_submit')); ?>", {
                        method: "POST",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: formData
                    })
                    .then(function(res) {
                        return res.json().then(function(data) {
                            return { status: res.status, ok: res.ok, data: data };
                        }).catch(function() {
                            return { status: res.status, ok: res.ok, data: null };
                        });
                    })
                    .then(function(result) {
                        var data = result.data;
                        if (result.ok && data && data.success) {
                            try {
                                sessionStorage.setItem('allow_thankyou', 'true');
                            } catch(e) {}
                            submitBtn.innerHTML = '<span class="form-btn-spinner"></span> REDIRECTING...';
                            window.location.href = data.redirect_url || "<?php echo e(url('/thank-you')); ?>";
                        } else {
                            submitBtn.disabled = false;
                            submitBtn.innerHTML = originalText;
                            var errMsg = (data && (data.message || data.error)) ? (data.message || data.error) : 'Submission failed. Please check the entered fields.';
                            if (typeof alertify !== 'undefined') {
                                alertify.error(errMsg);
                            } else if (typeof Swal !== 'undefined') {
                                Swal.fire({ icon: 'error', title: 'Notice', text: errMsg });
                            } else {
                                alert(errMsg);
                            }
                        }
                    })
                    .catch(function(err) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                        var errorText = err && err.message ? err.message : 'Unable to connect. Please check your connection and try again.';
                        if (typeof alertify !== 'undefined') {
                            alertify.error(errorText);
                        } else {
                            alert(errorText);
                        }
                    });
                });
            }
        });
    </script>

    <!-- FOOTER & SCRIPTS -->
    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/contact.blade.php ENDPATH**/ ?>