<?php if(Session::get('admin_login')): ?>
<?php $__currentLoopData = session()->get('admin_login'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminlogin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('main-content'); ?>


<style>
.table-responsive-athlo {
    width: 100%;
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
}
.table-athlo {
    margin-bottom: 0 !important;
    white-space: nowrap;
    width: 100%;
}
.table-athlo th {
    background-color: #f8fafc;
    color: #475569;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    padding: 12px 16px;
    border-bottom: 2px solid #e2e8f0;
    white-space: nowrap;
}
.table-athlo td {
    padding: 12px 16px;
    vertical-align: middle;
    color: #334155;
    font-size: 13px;
    white-space: nowrap;
}
.th-nowrap th { white-space: nowrap; }
.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 34px;
    height: 34px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
    font-size: 15px;
}
.action-btn:hover { transform: scale(1.15); box-shadow: 0 4px 12px rgba(0,0,0,0.18); }
.btn-edit  { background: linear-gradient(135deg,#f7971e,#ffd200); color:#fff; }
.btn-edit:hover  { background: linear-gradient(135deg,#e08a10,#f0c400); color:#fff; }
.btn-del   { background: linear-gradient(135deg,#f5515f,#c0392b); color:#fff; }
.btn-del:hover   { background: linear-gradient(135deg,#c0392b,#96281b); color:#fff; }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
                    <!-- Single Outer Main Card Container -->
                    <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                        <!-- AthloNext Single Balanced Filter Card Container -->
                        <div class="filter-card-container mb-4">
                            <div class="row align-items-end g-3">
                                <!-- Search FAQ -->
                                <div class="col-xl-4 col-lg-5 col-md-6">
                                    <label class="filter-section-title">SEARCH FAQ</label>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="search-input-pill flex-grow-1">
                                            <i class="bi bi-search"></i>
                                            <input type="text" class="search_contact" placeholder="Search Here..." />
                                        </div>
                                        <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel / CSV">
                                            <i class="bi bi-file-earmark-excel-fill"></i>
                                        </a>
                                    </div>
                                </div>

                                <!-- Reset Button -->
                                <div class="col-xl-auto col-lg-auto col-md-auto">
                                    <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                                    </button>
                                </div>

                                <!-- Add FAQ Button -->
                                <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                                    <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddFaqModal">
                                        <i class="bi bi-plus-lg me-1"></i> Add FAQ
                                    </button>
                                </div>
                            </div>
                        </div>

                            <!-- AthloNext Table Container Inside Same Main Card -->
                            <div class="table-responsive-athlo mb-3">
                                <table id="myTable" class="table table-hover table-athlo align-middle">
                                    <thead class="th-nowrap">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Action</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Question</th>
                                            <th scope="col">Answer</th>
                                            <th scope="col">Datetime</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination Start Here -->
                            <nav class="mt-2">
                                <ul id="pagination" class="pagination justify-content-center"></ul>
                            </nav>
                            <!-- Pagination End Here -->
                        </div>
                    </div>
                </div>
            </div>


<!-- Modal -->
<div class="modal fade" id="AddFaqModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-question-circle me-2"></i>Add FAQ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d">
                <form id="add_form" action="javascript:void(0);" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    
                    <div class="mb-3">
                        <label for="question" class="form-label form-label-3d">Question</label>
                        <textarea class="form-control form-control-3d summernote" name="question" id="question" placeholder="Question"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="answer" class="form-label form-label-3d">Answer</label>
                        <textarea class="form-control form-control-3d summernote" name="answer" id="answer" placeholder="Answer"></textarea>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
        <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
            <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                <div style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                    <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                </div>
                <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
            </div>
            <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this record? This action <strong>cannot be undone.</strong></p>
            </div>
            <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="delete_id" value="">
                    <button type="button" class="btn" data-bs-dismiss="modal"
                        style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                    <button type="submit" class="btn btn_delete"
                        style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal -->
<!-- Edit Modal -->
<div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="editModalLabel"><i class="bi bi-pencil-square me-2"></i>Edit FAQ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d">
                <form id="edit_form" action="javascript:void(0);" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="edit_id" value="">
                    
                    <div class="mb-3">
                        <label for="edit_question" class="form-label form-label-3d">Question</label>
                        <textarea class="form-control form-control-3d summernote" name="question" id="edit_question"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="edit_answer" class="form-label form-label-3d">Answer</label>
                        <textarea class="form-control form-control-3d summernote" name="answer" id="edit_answer"></textarea>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_update"><i class="bi bi-check2-circle me-1"></i>Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Edit Modal -->






<script>
    let currentPage = 1;
    var searchKeyword = '';
    $(document).ready(function() {
        $('.search_contact').keyup(function() {
            var searchKeyword = $(this).val();
            if (searchKeyword.length >= 3) {
                currentPage = 1;
                showdata(currentPage, searchKeyword);
            } else {
                showdata(currentPage);
            }
        });
        $('#reset_filter').click(function() {
            $('.search_contact').val('');
            currentPage = 1;
            showdata(1);
        });
        showdata();
    });

    // category add here 
    $("#add_form").submit(function(e) {
        $(".btn_submit").prop('disabled', true);
        e.preventDefault();

        var question = $("#question").val();
        var answer = $("#answer").val();
        if(!question){
            showToast('Question Required', 'error');
        }
        if(!answer){
            showToast('Answer Required', 'error');
        }
        
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "<?php echo e(url('/add_faq')); ?>",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {
                    // Reset the form here
                    $('#question').summernote('reset');
                    $('#answer').summernote('reset');
    
                    document.getElementById("add_form").reset();
                    $(".btn_submit").prop('disabled', false);
                    $("#AddFaqModal").modal("hide");
                    showToast('Faq Added Successfully', 'success');
                    showdata(currentPage, searchKeyword);
                } else {
                    $(".btn_submit").prop("disabled", false);
                    showToast(data.message || "Faq Not Added", 'error');
                }
            },
            error: function(err) {
                $(".btn_submit").prop("disabled", false);
                showToast("Something went wrong", 'error');
            }
        });

    });
    // category end here

    // Show data function here 
    function showdata(page = 1, search = '') {
        var search_data = search || $(".search_contact").val();
        // FormData For search Condition 
        var formData = new FormData();
        formData.append('search', search_data);
        formData.append('page', page);
        // end here 

        $.ajax({
            type: "POST",
            url: "<?php echo e(url('show_faq')); ?>",
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            encode: true,
            success: function(response) {
                console.log(response);
                var tbody = $("#myTable tbody");
                var pagination = $('#pagination');
                tbody.html('');
                pagination.empty();
                if (response.data && response.data.length > 0) {
                    currentPage = response.current_page;
                } else {
                    if (page > 1) {
                        showdata(page - 1, searchKeyword);
                        return;
                    }
                    currentPage = 1;
                }
                var total_enquiries = response.total;
                var per_page = response.per_page;
                result = response.data;
                
                result.forEach(function(data, index) {
                    var createdAtVal = formatDateTime(data.created_at || data.date);

                    tbody.append(`<tr>
                        <td>${index + 1 + (response.current_page - 1) * response.per_page}</td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="javascript:void(0);" class="btn-act-edit edit" title="Edit" data-question="${encodeURIComponent(data.question || '')}" data-answer="${encodeURIComponent(data.answer || '')}" data-id="${data.id}"><i class="bi bi-pencil-fill"></i></a>
                                <a class="btn-act-del delete" title="Delete" href="javascript:void(0);" data-id="${data.id}"><i class="bi bi-trash3-fill"></i></a>
                            </div>
                        </td>
                        <td class="text-center">
                            <label class="custom-switch">
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input StatusSwitch" value="${data.id}" ${data.status == 1 ? 'checked' : ''}>
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </td>
                        <td>${data.question ?? ''}</td>
                        <td>${data.answer ?? ''}</td>
                        <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                    </tr>`);
                });

                // Function to handle the pagination links with ellipsis (1 2 ... 7 8)
                function generatePaginationLinks(currentPage, lastPage, searchKeyword) {
                    let pagination = $('#pagination');
                    searchKeyword = searchKeyword || '';
                    pagination.html('');
                    if (currentPage > 3) {
                        pagination.append(`
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(1, '${searchKeyword}')">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(2, '${searchKeyword}')">2</a>
                            </li>
                            <li class="page-item disabled"><a class="page-link">...</a></li>
                        `);
                    }

                    // Show the current page and two pages before and after it
                    for (let i = Math.max(1, currentPage - 2); i <= Math.min(lastPage, currentPage + 2); i++) {
                        pagination.append(`
                            <li class="page-item ${i === currentPage ? 'active' : ''}">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${i}, '${searchKeyword}')">${i}</a>
                            </li>
                        `);
                    }

                    // Show the last two pages
                    if (currentPage < lastPage - 2) {
                        pagination.append(`
                            <li class="page-item disabled"><a class="page-link">...</a></li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage - 1}, '${searchKeyword}')">${lastPage - 1}</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage}, '${searchKeyword}')">${lastPage}</a>
                            </li>
                        `);
                    }
                }

                // Call this function where you handle pagination
                if (response.last_page > 1) {
                    generatePaginationLinks(response.current_page, response.last_page);
                }

            },
            error: function(err) {

            }
        });
    }

    // delete 
    $(document).on('click', '.delete', function() {
        var id = $(this).data("id");
        $("#delete_id").val(id);
        $("#deletemodal").modal("show");
    });

    // delete here 
    $("#delete_form").submit(function(e) {
        $(".btn_delete").prop('disabled', true);
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "POST",
            url: "<?php echo e(url('/delete_faq')); ?>",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {

                    $(".btn_delete").prop('disabled', false);
                    $("#deletemodal").modal("hide");
                    $("#delete_form")[0].reset();
                    showToast('Faq Deleted Successfully', 'success');
                    showdata(currentPage, searchKeyword);
                } else {
                    showToast(data.message || 'Faq Not Deleted', 'error');
                    $(".btn_delete").prop("disabled", false);
                }
            },
            error: function(error) {
                showToast('Something Went Wrong!', 'error');
                $(".btn_delete").prop("disabled", false);
            }
        });
    });

    // edit category modal 
    $(document).on('click', '.edit', function() {
        var id = $(this).data('id');
        var question = decodeURIComponent($(this).data('question') || '');
        var answer = decodeURIComponent($(this).data('answer') || '');
    
        $("#edit_id").val(id);
        $("#edit_question").summernote('code', question);
        $("#edit_answer").summernote('code', answer);
        $("#editmodal").modal("show");
    });



    // update category 
    $("#edit_form").submit(function(e) {
        $(".btn_update").prop("disabled", true);
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "<?php echo e(url('/update_faq')); ?>",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {
                    $(".btn_update").prop("disabled", false);
                    $("#edit_form")[0].reset();
                    $("#editmodal").modal("hide");
                    showToast('Faq Updated Successfully', 'success');
                    showdata(currentPage, searchKeyword);
                } else {
                    showToast(data.message || "Faq Not Updated!", "error");
                    $(".btn_update").prop('disabled', false);
                }
            },
            error: function(errResponse) {
                showToast("Something Went Wrong!", "error");
                $(".btn_update").prop('disabled', false);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<script>
    location.href = "<?php echo e(url('/login')); ?>";
</script>
<?php endif; ?>
<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Admin/pages/faq.blade.php ENDPATH**/ ?>