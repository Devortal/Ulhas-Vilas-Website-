<?php
    if (!isset($residences) || empty($residences) || count($residences) === 0) {
        $modalResidences = DB::table('residences')
            ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
            ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
            ->where('residences.status', 1)
            ->orderBy('residences.id', 'asc')
            ->get();
    } else {
        $modalResidences = $residences;
    }
?>

<!-- =========================================================================
     GLOBAL LUXURY RESIDENCE & INQUIRY MODAL (Common Reusable Component)
     ========================================================================= -->
<div id="residenceQuoteModal" class="luxury-quote-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="globalQuoteModalTitle">
    <div class="luxury-quote-modal-dialog">
        <div class="luxury-quote-modal-content">
            <button type="button" class="luxury-quote-modal-close" id="closeQuoteModalBtn" aria-label="Close modal">&times;</button>
            
            <div class="luxury-quote-modal-header">
                <span class="quote-modal-tagline">RESIDENCE BOOKING &amp; INQUIRY</span>
                <h3 class="quote-modal-title" id="globalQuoteModalTitle">Request A Private Quote</h3>
                <p class="quote-modal-sub" id="quoteModalSub">Connect directly with our estate management team for booking guidance, floor plans &amp; pricing.</p>
            </div>

            <form id="residenceQuoteForm" class="luxury-quote-form" method="post" action="<?php echo e(url('/contact_submit')); ?>">
                <?php echo csrf_field(); ?>
                <div class="quote-form-row">
                    <div class="quote-form-group">
                        <label class="quote-form-label" for="quoteName">Full Name *</label>
                        <input type="text" id="quoteName" name="name" class="quote-form-input" placeholder="Your full name" required minlength="2" maxlength="100">
                    </div>
                    <div class="quote-form-group">
                        <label class="quote-form-label" for="quotePhone">Phone Number *</label>
                        <input type="tel" id="quotePhone" name="mobile" class="quote-form-input" placeholder="10-digit Mobile Number" required minlength="10" maxlength="10" pattern="[0-9]{10}" inputmode="numeric">
                        <span class="field-validation-error" id="quotePhoneError" style="display:none; color:#ef4444; font-size:12px; font-weight:600; margin-top:5px;">Please enter a valid 10-digit mobile number.</span>
                    </div>
                </div>

                <div class="quote-form-row">
                    <div class="quote-form-group">
                        <label class="quote-form-label" for="quoteEmail">Email Address *</label>
                        <input type="email" id="quoteEmail" name="email" class="quote-form-input" placeholder="Your email address" required maxlength="150">
                    </div>
                    <div class="quote-form-group">
                        <label class="quote-form-label" for="quoteCity">City / Location</label>
                        <input type="text" id="quoteCity" name="city" class="quote-form-input" placeholder="e.g. Mumbai, Delhi, Chandigarh">
                    </div>
                </div>

                <div class="quote-form-group">
                    <label class="quote-form-label" for="quoteResidenceSelect">Preferred Residence *</label>
                    <select id="quoteResidenceSelect" name="residence_id" class="quote-form-select" required>
                        <option value="" disabled selected>Select Preferred Residence</option>
                        <?php if(!empty($modalResidences) && count($modalResidences) > 0): ?>
                            <?php $__currentLoopData = $modalResidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($res->id); ?>"><?php echo e($res->name); ?><?php echo e(!empty($res->category_name) ? ' (' . $res->category_name . ')' : ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="quote-form-group">
                    <label class="quote-form-label" for="quoteMessage">Special Inquiries / Message *</label>
                    <textarea id="quoteMessage" name="message" class="quote-form-textarea" rows="3" placeholder="Tell us about your requirements, schedule, or questions..." required minlength="3" maxlength="1000"></textarea>
                </div>

                <button type="submit" id="quoteSubmitBtn" class="quote-form-submit-btn">
                    <span>SUBMIT QUOTE REQUEST</span>
                    <span class="btn-arrow">&rarr;</span>
                </button>
            </form>
        </div>
    </div>
</div>

<style>
/* ═══════════════════════════════════════════════════
   GLOBAL LUXURY QUOTE MODAL STYLES (PREMIUM LIGHT THEME)
════════════════════════════════════════════════════ */
.luxury-quote-modal-overlay {
    position: fixed;
    inset: 0;
    z-index: 99999;
    background: rgba(7, 21, 36, 0.75);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: opacity 0.3s ease, visibility 0.3s ease;
}
.luxury-quote-modal-overlay.show {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
}
.luxury-quote-modal-dialog {
    width: 100%;
    max-width: 580px;
    transform: translateY(20px) scale(0.96);
    transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.luxury-quote-modal-overlay.show .luxury-quote-modal-dialog {
    transform: translateY(0) scale(1);
}
.luxury-quote-modal-content {
    position: relative;
    background: #ffffff;
    border: 1.5px solid rgba(204, 164, 59, 0.45);
    border-radius: 24px;
    padding: 38px 34px;
    box-shadow: 0 30px 80px rgba(0, 0, 0, 0.35), 0 0 35px rgba(204, 164, 59, 0.15);
    color: #071524;
}
.luxury-quote-modal-close,
.quote-modal-close-btn {
    position: absolute;
    top: 18px;
    right: 22px;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
    color: #64748b;
    font-size: 26px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.25s ease;
    z-index: 10;
    line-height: 1;
}
.luxury-quote-modal-close:hover,
.quote-modal-close-btn:hover {
    background: #cca43b;
    border-color: #cca43b;
    color: #071524;
    transform: rotate(90deg);
}
.luxury-quote-modal-header {
    text-align: center;
    margin-bottom: 22px;
}
.quote-modal-tagline {
    display: inline-block;
    color: #9a741c;
    background: rgba(204, 164, 59, 0.12);
    border: 1px solid rgba(204, 164, 59, 0.35);
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 10.5px;
    font-weight: 800;
    letter-spacing: 1.8px;
    text-transform: uppercase;
    margin-bottom: 8px;
}
.quote-modal-title {
    color: #071524;
    font-family: 'Marcellus', Georgia, serif;
    font-size: 26px;
    font-weight: 700;
    margin: 0 0 8px 0;
    letter-spacing: 0.5px;
}
.quote-modal-sub {
    color: #556980;
    font-size: 13.5px;
    margin: 0;
    line-height: 1.55;
}
.luxury-quote-form {
    display: flex;
    flex-direction: column;
    gap: 14px;
    margin-top: 18px;
}
.quote-form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}
.quote-form-group {
    display: flex;
    flex-direction: column;
}
.quote-form-label {
    font-size: 11.5px;
    font-weight: 700;
    color: #334155;
    margin-bottom: 6px;
    text-transform: uppercase;
    letter-spacing: 0.6px;
}
.quote-form-input,
.quote-form-select,
.quote-form-textarea {
    width: 100%;
    background: #f8fafc;
    border: 1.5px solid #cbd5e1;
    border-radius: 10px;
    padding: 11px 14px;
    color: #071524;
    font-size: 14px;
    font-weight: 500;
    outline: none;
    transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
    box-sizing: border-box;
}
.quote-form-input::placeholder,
.quote-form-textarea::placeholder {
    color: #94a3b8;
}
.quote-form-input:focus,
.quote-form-select:focus,
.quote-form-textarea:focus {
    border-color: #cca43b;
    background: #ffffff;
    box-shadow: 0 0 0 3.5px rgba(204, 164, 59, 0.18);
}
.quote-form-select {
    cursor: pointer;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23cca43b' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 14px center;
    padding-right: 36px;
}
.quote-form-select option {
    background: #ffffff;
    color: #071524;
}
.quote-form-textarea {
    resize: vertical;
    min-height: 85px;
}
.quote-form-submit-btn {
    background: linear-gradient(135deg, #c99e32 0%, #f3d782 50%, #c99e32 100%);
    color: #071524;
    font-weight: 800;
    font-size: 13.5px;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    padding: 14px 24px;
    border: none;
    border-radius: 50px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: 6px;
    transition: transform 0.2s, box-shadow 0.2s, opacity 0.2s;
    width: 100%;
    box-shadow: 0 6px 20px rgba(201, 158, 50, 0.35);
}
.quote-form-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(201, 158, 50, 0.5);
    color: #000000;
}
.quote-form-submit-btn:active {
    transform: translateY(0);
}
.quote-form-submit-btn:disabled {
    opacity: 0.65;
    cursor: not-allowed;
    transform: none;
}
@media (max-width: 600px) {
    .quote-form-row {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    .luxury-quote-modal-content {
        padding: 28px 20px;
    }
    .quote-modal-title {
        font-size: 22px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const quoteModal = document.getElementById('residenceQuoteModal');
    const closeQuoteModalBtn = document.getElementById('closeQuoteModalBtn');
    const quoteResidenceSelect = document.getElementById('quoteResidenceSelect');
    const quoteModalSub = document.getElementById('quoteModalSub');
    const quoteForm = document.getElementById('residenceQuoteForm');
    const quoteSubmitBtn = document.getElementById('quoteSubmitBtn');
    const quotePhoneInput = document.getElementById('quotePhone');
    const quotePhoneError = document.getElementById('quotePhoneError');

    // Real-time 10-digit mobile formatting and validation for Quote Modal
    if (quotePhoneInput && quotePhoneError) {
        quotePhoneInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
            if (this.value.length === 10) {
                quotePhoneError.style.display = 'none';
                quotePhoneInput.style.borderColor = '';
            } else if (this.value.length > 0) {
                quotePhoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                quotePhoneError.style.display = 'block';
                quotePhoneInput.style.borderColor = '#ef4444';
            } else {
                quotePhoneError.style.display = 'none';
                quotePhoneInput.style.borderColor = '';
            }
        });

        quotePhoneInput.addEventListener('blur', function() {
            if (this.value.length > 0 && this.value.length !== 10) {
                quotePhoneError.textContent = 'Mobile number must be exactly 10 digits (' + this.value.length + '/10 entered).';
                quotePhoneError.style.display = 'block';
                quotePhoneInput.style.borderColor = '#ef4444';
            }
        });
    }

    let isQuoteSubmitting = false;

    function openQuoteModal(resId, resName, catName) {
        if (quoteResidenceSelect) {
            if (resId) {
                quoteResidenceSelect.value = resId;
            } else if (resName) {
                // Try matching by option text
                let matched = false;
                for (let i = 0; i < quoteResidenceSelect.options.length; i++) {
                    if (quoteResidenceSelect.options[i].text.toLowerCase().includes(resName.toLowerCase())) {
                        quoteResidenceSelect.selectedIndex = i;
                        matched = true;
                        break;
                    }
                }
                if (!matched && quoteResidenceSelect.options.length > 1) {
                    quoteResidenceSelect.selectedIndex = 1;
                }
            } else if (quoteResidenceSelect.options.length > 1) {
                quoteResidenceSelect.selectedIndex = 1;
            }
        }

        if (quoteModalSub && resName) {
            quoteModalSub.textContent = `Inquiring for: ${resName}` + (catName ? ` (${catName})` : '');
        } else if (quoteModalSub) {
            quoteModalSub.textContent = 'Connect directly with our estate management team for booking guidance, floor plans, amenity details & pricing.';
        }

        const msgEl = document.getElementById('quoteMessage');
        if (msgEl && resName && (!msgEl.value || msgEl.value.trim() === '')) {
            msgEl.value = `I am interested in learning more about ${resName} at The Ulhas Vilas.`;
        }

        if (quoteModal) {
            quoteModal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeQuoteModal() {
        if (isQuoteSubmitting) return; // Prevent closing while submitting
        if (quoteModal) {
            quoteModal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    window.openQuoteModal = openQuoteModal;
    window.closeQuoteModal = closeQuoteModal;

    // Attach click listeners to any trigger buttons across any page
    document.querySelectorAll('.open-residence-quote-btn, .amenity-view-btn, .wellness-brochure-btn, [data-open-quote-modal], [data-modal-target="residenceQuoteModal"]').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            const card = this.closest('.amenity-card, .residence-card, .res-card');
            const resId = this.getAttribute('data-residence-id') || '';
            const resName = this.getAttribute('data-residence-name') || this.getAttribute('data-title') || (card ? card.getAttribute('data-title') : '') || '';
            const catName = this.getAttribute('data-category-name') || (card ? (card.getAttribute('data-category') ? card.getAttribute('data-category').toUpperCase() : '') : '');
            openQuoteModal(resId, resName, catName);
        });
    });

    if (closeQuoteModalBtn) {
        closeQuoteModalBtn.addEventListener('click', function(e) {
            if (isQuoteSubmitting) return;
            closeQuoteModal();
        });
    }

    if (quoteModal) {
        quoteModal.addEventListener('click', function(e) {
            if (isQuoteSubmitting) return;
            if (e.target === quoteModal) {
                closeQuoteModal();
            }
        });
    }

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && quoteModal && quoteModal.classList.contains('show')) {
            if (isQuoteSubmitting) return;
            closeQuoteModal();
        }
    });

    // AJAX submit for Quote Modal Form (With Lazy Loader Spinner & Redirect to Thank You)
    if (quoteForm) {
        quoteForm.addEventListener('submit', function (e) {
            e.preventDefault();

            if (isQuoteSubmitting) return;

            if (quotePhoneInput && quotePhoneInput.value.trim().length !== 10) {
                if (quotePhoneError) {
                    quotePhoneError.textContent = 'Mobile number must be exactly 10 digits.';
                    quotePhoneError.style.display = 'block';
                }
                quotePhoneInput.focus();
                return;
            }

            isQuoteSubmitting = true;
            const origBtnHtml = quoteSubmitBtn ? quoteSubmitBtn.innerHTML : '<span>SUBMIT QUOTE REQUEST</span>';
            if (quoteSubmitBtn) {
                quoteSubmitBtn.disabled = true;
                quoteSubmitBtn.innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(10,15,29,0.3);border-top-color:#0a0f1d;border-radius:50%;animation:spin 0.6s linear infinite;margin-right:6px;vertical-align:middle;"></span><span>SUBMITTING INQUIRY...</span>';
            }
            if (closeQuoteModalBtn) {
                closeQuoteModalBtn.style.pointerEvents = 'none';
                closeQuoteModalBtn.style.opacity = '0.35';
                closeQuoteModalBtn.style.cursor = 'not-allowed';
            }

            const formData = new FormData(quoteForm);

            fetch("<?php echo e(url('/contact_submit')); ?>", {
                method: "POST",
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(function(res) {
                return res.json().then(function(data) {
                    return { ok: res.ok, status: res.status, data: data };
                }).catch(function() {
                    return { ok: res.ok, status: res.status, data: null };
                });
            })
            .then(function(result) {
                const data = result.data;
                if (result.ok && data && data.success) {
                    try {
                        sessionStorage.setItem('allow_thankyou', 'true');
                    } catch(e) {}
                    if (quoteSubmitBtn) {
                        quoteSubmitBtn.innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(10,15,29,0.3);border-top-color:#0a0f1d;border-radius:50%;animation:spin 0.6s linear infinite;margin-right:6px;vertical-align:middle;"></span><span>REDIRECTING...</span>';
                    }
                    setTimeout(function() {
                        window.location.href = data.redirect_url || "<?php echo e(url('/thank-you')); ?>";
                    }, 400);
                } else {
                    isQuoteSubmitting = false;
                    if (quoteSubmitBtn) {
                        quoteSubmitBtn.disabled = false;
                        quoteSubmitBtn.innerHTML = origBtnHtml;
                    }
                    if (closeQuoteModalBtn) {
                        closeQuoteModalBtn.style.pointerEvents = '';
                        closeQuoteModalBtn.style.opacity = '';
                        closeQuoteModalBtn.style.cursor = '';
                    }
                    const errMsg = (data && data.message) ? data.message : 'Failed to submit quote request. Please try again.';
                    if (typeof alertify !== 'undefined') {
                        alertify.error(errMsg);
                    } else if (typeof Swal !== 'undefined') {
                        Swal.fire({ icon: 'error', title: 'Submission Error', text: errMsg });
                    } else {
                        alert(errMsg);
                    }
                }
            })
            .catch(function(err) {
                isQuoteSubmitting = false;
                if (quoteSubmitBtn) {
                    quoteSubmitBtn.disabled = false;
                    quoteSubmitBtn.innerHTML = origBtnHtml;
                }
                if (closeQuoteModalBtn) {
                    closeQuoteModalBtn.style.pointerEvents = '';
                    closeQuoteModalBtn.style.opacity = '';
                    closeQuoteModalBtn.style.cursor = '';
                }
                const errorText = err && err.message ? err.message : 'Network error. Please try again.';
                if (typeof alertify !== 'undefined') {
                    alertify.error(errorText);
                } else {
                    alert(errorText);
                }
            });
        });
    }
});
</script>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/includes/QuoteModal.blade.php ENDPATH**/ ?>