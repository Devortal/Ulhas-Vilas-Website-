<?php
    $info = DB::table('information')->first();
    $headerCategories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'asc')->get();
    $headerResidences = DB::table('residences')
        ->leftJoin('categories', 'residences.category_id', '=', 'categories.id')
        ->select('residences.*', DB::raw('COALESCE(categories.category_name, residences.category_name) as category_name'))
        ->whereIn('residences.status', [1, '1'])
        ->orderBy('residences.id', 'asc')
        ->get();
    $headerLogo = (!empty($info) && !empty($info->header_logo)) ? asset($info->header_logo) : ((!empty($info) && !empty($info->info_header_logo)) ? asset($info->info_header_logo) : asset('Website/assets/images/ulhas-logo.png'));
    $fb = $info->facebook_link ?? $info->info_facebook_link ?? 'https://facebook.com';
    $insta = $info->instagram_link ?? $info->info_instagram_link ?? 'https://instagram.com';
    $tw = $info->twitter_link ?? $info->info_twitter_link ?? $info->info_xtwitter_link ?? null;
    $yt = $info->youtube_link ?? null;
    $li = $info->linkedin_link ?? null;
?>

<!-- Glass Header Navigation -->
<div class="mobile-nav-backdrop" id="mobileNavBackdrop"></div>

<header class="hero-header">
    <a href="<?php echo e(url('/')); ?>" class="brand-logo">
        <img src="<?php echo e($headerLogo); ?>" alt="The Ulhas Vilas logo" class="brand-mark">
        <span class="brand-copy">
            <span class="brand-title">The Ulhas Vilas</span>
            <span class="brand-subtitle">Where serenity whispers joy!</span>
        </span>
    </a>

    <nav class="nav-container" id="navContainer">
        <div class="mobile-drawer-header">
            <a href="<?php echo e(url('/')); ?>" class="brand-logo" style="text-decoration: none;">
                <img src="<?php echo e($headerLogo); ?>" alt="The Ulhas Vilas logo" class="brand-mark" style="width: 44px; height: 44px; object-fit: contain;">
                <span class="brand-copy" style="display: flex; flex-direction: column;">
                    <span class="brand-title" style="color: #111827 !important; font-family: 'Marcellus', serif; font-size: 1.25rem !important; line-height: 1.15; font-weight: 600;">The Ulhas Vilas</span>
                    <span class="brand-subtitle" style="color: #927538 !important; font-size: 0.52rem !important; margin-top: 2px; letter-spacing: 0.04em;">Where serenity whispers joy!</span>
                </span>
            </a>
            <button type="button" class="mobile-drawer-close" id="mobileDrawerClose" aria-label="Close navigation menu">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>

        <ul class="nav-links">
            <li><a href="<?php echo e(url('/')); ?>" class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a></li>
            <li><a href="<?php echo e(url('/about')); ?>" class="nav-link <?php echo e(request()->is('about*') ? 'active' : ''); ?>">About Us</a></li>
            <li class="nav-dropdown">
                <a href="<?php echo e(url('/residences')); ?>" class="nav-link nav-dropdown-toggle <?php echo e((request()->is('residence*') || request()->is('residences*')) ? 'active' : ''); ?>" aria-expanded="false" data-url="<?php echo e(url('/residences')); ?>">Residences</a>
                <ul class="nav-dropdown-menu">
                    <?php if(!empty($headerResidences) && count($headerResidences) > 0): ?>
                        <?php $__currentLoopData = $headerResidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $hSlug = !empty($hRes->slug) ? $hRes->slug : $hRes->id;
                            ?>
                            <li>
                                <a href="<?php echo e(url('/residence/' . $hSlug)); ?>" class="nav-dropdown-link"><?php echo e($hRes->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif(!empty($headerCategories) && count($headerCategories) > 0): ?>
                        <?php $__currentLoopData = $headerCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/residence-by-category/' . $cat->id)); ?>" class="nav-dropdown-link"><?php echo e($cat->category_name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </li>
            <li><a href="<?php echo e(url('/amenities-wellness')); ?>" class="nav-link <?php echo e((request()->is('amenit*') || request()->is('wellness*')) ? 'active' : ''); ?>">Amenities & Wellness</a></li>
            <li><a href="<?php echo e(url('/gallery')); ?>" class="nav-link <?php echo e(request()->is('gallery*') ? 'active' : ''); ?>">Gallery</a></li>
            <li><a href="<?php echo e(url('/blogs')); ?>" class="nav-link <?php echo e((request()->is('blogs*') || request()->is('blog*')) ? 'active' : ''); ?>">Blogs</a></li>
            <li><a href="<?php echo e(url('/faq')); ?>" class="nav-link <?php echo e(request()->is('faq*') ? 'active' : ''); ?>">FAQs</a></li>
        </ul>

        <!-- Mobile Drawer Social Links Section -->
        <div class="mobile-drawer-social-section">
            <span class="mobile-drawer-social-label">Connect With Us</span>
            <div class="mobile-drawer-social-row">
                <?php if(!empty($insta)): ?>
                    <a href="<?php echo e($insta); ?>" target="_blank" rel="noopener noreferrer" class="mobile-drawer-social-btn" aria-label="Instagram" title="Instagram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                    </a>
                <?php endif; ?>
                <?php if(!empty($fb)): ?>
                    <a href="<?php echo e($fb); ?>" target="_blank" rel="noopener noreferrer" class="mobile-drawer-social-btn" aria-label="Facebook" title="Facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if(!empty($tw)): ?>
                    <a href="<?php echo e($tw); ?>" target="_blank" rel="noopener noreferrer" class="mobile-drawer-social-btn" aria-label="X (Twitter)" title="X (Twitter)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/></svg>
                    </a>
                <?php endif; ?>
                <?php if(!empty($yt)): ?>
                    <a href="<?php echo e($yt); ?>" target="_blank" rel="noopener noreferrer" class="mobile-drawer-social-btn" aria-label="YouTube" title="YouTube">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
                    </a>
                <?php endif; ?>
                <?php if(!empty($li)): ?>
                    <a href="<?php echo e($li); ?>" target="_blank" rel="noopener noreferrer" class="mobile-drawer-social-btn" aria-label="LinkedIn" title="LinkedIn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="mobile-cta-wrapper">
            <a href="<?php echo e(url('/contact')); ?>" class="send-msg-btn nav-btn">Enquire Now</a>
        </div>
    </nav>

    <div class="header-cta">
        <a href="<?php echo e(url('/contact')); ?>" class="nav-btn">Enquire Now</a>
    </div>

    <button type="button" class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="navContainer">
        <span></span>
        <span></span>
        <span></span>
    </button>
</header>

<script>
    (function() {
        function updateHeaderScroll() {
            var header = document.querySelector('.hero-header');
            if (header) {
                var scrollTop = Math.max(window.scrollY || 0, window.pageYOffset || 0, document.documentElement.scrollTop || 0, document.body.scrollTop || 0);
                if (scrollTop > 35) {
                    header.classList.add('scrolled');
                } else {
                    header.classList.remove('scrolled');
                }
            }
        }
        window.addEventListener('scroll', updateHeaderScroll, { passive: true });
        document.addEventListener('scroll', updateHeaderScroll, { passive: true });
        window.addEventListener('resize', updateHeaderScroll, { passive: true });
        
        function initMobileMenu() {
            updateHeaderScroll();
            var toggleBtn = document.getElementById('mobileMenuToggle');
            var navContainer = document.getElementById('navContainer');
            var closeBtn = document.getElementById('mobileDrawerClose');
            var backdrop = document.getElementById('mobileNavBackdrop');
            if (!toggleBtn || !navContainer || navContainer.dataset.menuReady === 'true') {
                return;
            }
            navContainer.dataset.menuReady = 'true';

            function openMenu() {
                if (toggleBtn) toggleBtn.classList.add('active');
                if (navContainer) navContainer.classList.add('active');
                if (backdrop) backdrop.classList.add('active');
                if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'true');
                document.body.style.overflow = 'hidden';
            }

            function closeMenu() {
                if (toggleBtn) toggleBtn.classList.remove('active');
                if (navContainer) navContainer.classList.remove('active');
                if (backdrop) backdrop.classList.remove('active');
                if (navContainer) {
                    var openedDropdowns = navContainer.querySelectorAll('.nav-dropdown.open');
                    openedDropdowns.forEach(function(dropdown) {
                        dropdown.classList.remove('open');
                    });
                }
                if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }

            if (toggleBtn) {
                toggleBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    if (navContainer && navContainer.classList.contains('active')) {
                        closeMenu();
                    } else {
                        openMenu();
                    }
                });
            }

            if (closeBtn) closeBtn.addEventListener('click', closeMenu);
            if (backdrop) backdrop.addEventListener('click', closeMenu);

            var residenceDropdown = navContainer ? navContainer.querySelector('.nav-dropdown') : null;
            var residenceToggle = residenceDropdown ? residenceDropdown.querySelector('.nav-dropdown-toggle') : null;
            if (residenceToggle && residenceDropdown) {
                residenceToggle.addEventListener('click', function(e) {
                    if (window.matchMedia('(max-width: 1024px)').matches) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        var isOpen = residenceDropdown.classList.toggle('open');
                        residenceToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
                    } else {
                        var url = residenceToggle.getAttribute('data-url');
                        if (url) window.location.href = url;
                    }
                });
            }

            if (navContainer) {
                var links = navContainer.querySelectorAll('a');
                links.forEach(function(l) {
                    l.addEventListener('click', function(e) {
                        var href = l.getAttribute('href') || '';
                        if (!href || href === '#') {
                            e.preventDefault();
                            return;
                        }
                        if (href.charAt(0) === '#') {
                            e.preventDefault();
                            closeMenu();
                            window.location.hash = href;
                            return;
                        }
                        closeMenu();
                    });
                });
            }
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initMobileMenu);
        } else {
            initMobileMenu();
        }
    })();
</script>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/includes/Header.blade.php ENDPATH**/ ?>