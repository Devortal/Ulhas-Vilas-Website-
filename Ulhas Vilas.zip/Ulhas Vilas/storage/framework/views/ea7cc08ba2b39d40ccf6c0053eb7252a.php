<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="contact-hero-light">
        <div class="contact-hero-slider-track" id="faqHeroTrack">
            <div class="contact-hero-slide active">
                <img src="<?php echo e(asset('Website/assets/images/mountain.jpeg')); ?>" alt="Frequently Asked Questions">
            </div>
        </div>
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">Frequently Asked <span>Questions</span></h1>
            <p class="contact-hero-light-sub">Clear answers on residences, ownership, amenities, compliance, and private visits.</p>
        </div>
    </section>

<style>
    .faq-accordion-list {
        display: flex !important;
        flex-direction: column !important;
        gap: 0.75rem !important;
        margin-bottom: 0 !important;
    }
    .faq-item {
        background: #ffffff;
        border: 1px solid rgba(20, 24, 28, 0.08);
        border-left: 3px solid transparent;
        border-radius: 14px;
        padding: 1.15rem 1.5rem;
        transition: all 0.25s ease;
        cursor: pointer;
        overflow: hidden;
        box-shadow: 0 4px 16px rgba(20, 24, 28, 0.04);
        margin: 0 !important;
        margin-bottom: 0 !important;
    }
    .faq-item:hover {
        background: #ffffff;
        border-color: rgba(220, 182, 88, 0.4);
        box-shadow: 0 8px 24px rgba(20, 24, 28, 0.06);
    }
    .faq-item.active {
        background: #ffffff;
        border-color: rgba(220, 182, 88, 0.65);
        border-left: 3px solid #DCB658;
        box-shadow: 0 10px 28px rgba(20, 24, 28, 0.07);
    }
    .faq-question-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        user-select: none;
    }
    .faq-question-title {
        font-family: var(--font-body, 'Manrope', system-ui, sans-serif);
        font-size: 1.05rem;
        font-weight: 600;
        color: #14181c;
        text-transform: none !important;
        letter-spacing: normal;
        line-height: 1.4;
        margin: 0;
    }
    .faq-icon-toggle {
        width: 30px;
        height: 30px;
        flex-shrink: 0;
        border-radius: 50%;
        background: #f0ebe1;
        border: 1px solid rgba(20, 24, 28, 0.08);
        color: #14181c;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.3s ease, background 0.3s ease, color 0.3s ease;
    }
    .faq-item.active .faq-icon-toggle {
        background: #DCB658;
        border-color: #DCB658;
        color: #0a0c0e;
        transform: rotate(180deg);
    }
    .faq-answer-content {
        display: none;
        padding-top: 0.75rem;
        margin-top: 0.75rem;
        border-top: 1px solid rgba(20, 24, 28, 0.07);
    }
    .faq-item.active .faq-answer-content {
        display: block;
    }
    .faq-answer-text {
        font-family: var(--font-body, system-ui, sans-serif);
        font-size: 0.92rem;
        line-height: 1.6;
        color: rgba(20, 24, 28, 0.72);
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        border-top: none !important;
    }
</style>

    <section class="faq-section faq-page-section">
        <div class="faq-container">
            <div class="gallery-header-center faq-page-header">
                <span class="contact-eyebrow">CURATED INQUIRIES</span>
                <h2 class="contact-heading">Answers For <span>Effortless</span> Decisions</h2>
                <p class="gallery-intro-desc">
                    Explore the details most buyers ask before choosing their mountain residence at The Ulhas Vilas.
                </p>
            </div>

            <div class="faq-page-grid">
                <!-- Left Column: Accordion Questions (Dynamic from Database) -->
                <div class="faq-accordion-list" id="faqAccordion">
                    <?php if(!empty($faqs) && count($faqs) > 0): ?>
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="faq-item <?php echo e($key === 0 ? 'active' : ''); ?>" onclick="toggleFaqCard(this)">
                                <div class="faq-question-header">
                                    <h3 class="faq-question-title"><?php echo e($faq->question); ?></h3>
                                    <div class="faq-icon-toggle">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </div>
                                </div>
                                <div class="faq-answer-content" style="<?php echo e($key === 0 ? 'display: block;' : 'display: none;'); ?>">
                                    <p class="faq-answer-text"><?php echo nl2br(e($faq->answer)); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="faq-item active" onclick="toggleFaqCard(this)">
                            <div class="faq-question-header">
                                <h3 class="faq-question-title">What architectural customization options are available?</h3>
                                <div class="faq-icon-toggle">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                </div>
                            </div>
                            <div class="faq-answer-content" style="display: block;">
                                <p class="faq-answer-text">Buyers can discuss layout preferences, finish palettes, outdoor decks, premium fittings, and selected interior upgrades with the estate team.</p>
                            </div>
                        </div>

                        <div class="faq-item" onclick="toggleFaqCard(this)">
                            <div class="faq-question-header">
                                <h3 class="faq-question-title">Is The Ulhas Vilas compliant and title verified?</h3>
                                <div class="faq-icon-toggle">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                </div>
                            </div>
                            <div class="faq-answer-content" style="display: none;">
                                <p class="faq-answer-text">Project documentation, approvals, and title-related details can be reviewed with our sales and legal coordination team during your private consultation.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Unified Right Column Card: Image Header + Enquiry Body in ONE Section -->
                <div class="faq-form-card faq-page-card" style="padding: 0; overflow: hidden; border-radius: 24px; border: 1.5px solid rgba(204,164,59,0.35); box-shadow: 0 20px 45px rgba(0,0,0,0.08); background: #ffffff;">
                    
                    <!-- Top Integrated Image Header -->
                    <div style="position: relative; width: 100%; height: 220px; overflow: hidden; background: #071524;">
                        <img src="<?php echo e(asset('Website/assets/images/faq.jpeg')); ?>" alt="The Ulhas Vilas Luxury Estate View" style="width: 100%; height: 100%; object-fit: cover; display: block;">
                        <div style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(7,21,36,0.1) 0%, rgba(7,21,36,0.82) 100%); display: flex; flex-direction: column; justify-content: flex-end; padding: 18px 22px;">
                            <span style="font-size: 10px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; color: #cca43b; margin-bottom: 4px;">ALPINE SANCTUARY</span>
                            <h4 style="font-family: 'Marcellus', Georgia, serif; font-size: 18px; color: #ffffff; margin: 0; font-weight: 700; letter-spacing: 0.5px;">The Ulhas Vilas Estates</h4>
                        </div>
                    </div>

                    <!-- Bottom Body Content -->
                    <div style="padding: 26px 24px 28px 24px;">
                        <div class="faq-form-header" style="margin-bottom: 20px;">
                            <span class="faq-form-tagline" style="margin-bottom: 6px;">PRIVATE ENQUIRY</span>
                            <h3 class="faq-form-title" style="margin-bottom: 8px;">Still Need Clarity?</h3>
                            <p class="faq-form-subtitle" style="margin-bottom: 0;">Share your questions and our estate advisor will help you with residence details, visit planning, and purchase guidance.</p>
                        </div>

                        <a href="<?php echo e(url('/contact')); ?>" class="send-msg-btn gallery-cta-btn" style="width: 100%; text-align: center; justify-content: center; box-sizing: border-box;">CONTACT ESTATE TEAM</a>
                        <a href="<?php echo e(url('/residences')); ?>" class="gallery-tab-btn faq-page-secondary-link" style="width: 100%; text-align: center; justify-content: center; box-sizing: border-box; margin-top: 10px;">EXPLORE RESIDENCES</a>
                    </div>

                </div>
            </div>

        </div>
    </section>

    <section class="gallery-cta-section">
        <div class="gallery-cta-card">
            <span class="contact-eyebrow">PRIVATE GUIDED VISITS</span>
            <h2 class="gallery-cta-title">Experience The Estate <span>In Person</span></h2>
            <p class="gallery-cta-desc">
                Walk through the residences, views, amenities, and ownership details with our team.
            </p>
            <a href="<?php echo e(url('/contact')); ?>" class="send-msg-btn gallery-cta-btn">BOOK A PRIVATE VISIT</a>
        </div>
    </section>

    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        function toggleFaqCard(element) {
            var accordion = element.closest('.faq-accordion-list') || document.getElementById('faqAccordion');
            var isAlreadyActive = element.classList.contains('active');
            
            // Close all items inside this accordion
            if (accordion) {
                var allItems = accordion.querySelectorAll('.faq-item');
                allItems.forEach(function(item) {
                    item.classList.remove('active');
                    var ans = item.querySelector('.faq-answer-content');
                    if (ans) {
                        ans.style.display = 'none';
                    }
                });
            }
            
            // If the clicked item was not active, open it
            if (!isAlreadyActive) {
                element.classList.add('active');
                var activeAns = element.querySelector('.faq-answer-content');
                if (activeAns) {
                    activeAns.style.display = 'block';
                }
            }
        }
    </script>
</body>
</html>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/faq.blade.php ENDPATH**/ ?>