<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<!-- Leaflet JS for Luxury Interactive Map -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- All Website Custom JavaScript -->
<script>

document.addEventListener('DOMContentLoaded', () => {
  const bgVideo = document.getElementById('bgVideo');
  const heroFallbackImg = document.getElementById('heroBgFallbackImg');

  if (bgVideo) {
    bgVideo.playbackRate = 0.85;

    const revealHeroVideo = () => {
      bgVideo.classList.add('video-loaded');
      if (heroFallbackImg) {
        heroFallbackImg.style.opacity = '0';
      }
    };

    if (bgVideo.readyState >= 2 || !bgVideo.paused) {
      revealHeroVideo();
    } else {
      bgVideo.addEventListener('playing', revealHeroVideo, { once: true });
      bgVideo.addEventListener('canplay', revealHeroVideo, { once: true });
      bgVideo.addEventListener('timeupdate', revealHeroVideo, { once: true });
      bgVideo.addEventListener('loadeddata', revealHeroVideo, { once: true });
    }
  }

  // ═════════════════════════════════════════════════════════════════
  // UNIVERSAL SAFARI / IOS / ANDROID VIDEO AUTOPLAY ENGINE
  // ═════════════════════════════════════════════════════════════════
  (function initSafariVideoAutoplay() {
    function setupVideoElement(video) {
      if (!video) return;
      try {
        video.muted = true;
        video.defaultMuted = true;
        video.playsInline = true;
        video.setAttribute('muted', '');
        video.setAttribute('playsinline', '');
        video.setAttribute('webkit-playsinline', '');
        video.setAttribute('x5-playsinline', '');
        video.setAttribute('disablepictureinpicture', '');
        video.setAttribute('disableremoteplayback', '');
        video.style.backgroundColor = 'transparent';
      } catch (e) {}
    }

    function safePlay(video) {
      if (!video) return;
      setupVideoElement(video);
      try {
        const promise = video.play();
        if (promise !== undefined) {
          promise.then(() => {
            video.classList.add('video-playing');
            if (video.id === 'bgVideo') {
              video.classList.add('video-loaded');
              const fb = document.getElementById('heroBgFallbackImg');
              if (fb) fb.style.opacity = '0';
            }
          }).catch((err) => {
            // Low power mode or autoplay restriction: will automatically play on first gesture
          });
        }
      } catch (err) {}
    }

    function playAllBackgroundVideos() {
      document.querySelectorAll('video').forEach((vid) => {
        safePlay(vid);
      });
    }

    // 1. Initial setup of all videos on page
    document.querySelectorAll('video').forEach((v) => {
      setupVideoElement(v);
    });

    // 2. Immediate playback attempt for hero and visible videos
    playAllBackgroundVideos();

    // 3. User interaction listener for Safari/iOS low power mode unlock
    const interactionEvents = ['touchstart', 'touchend', 'click', 'scroll', 'wheel', 'keydown', 'pointerdown'];
    function handleUserInteraction() {
      document.querySelectorAll('video').forEach((v) => {
        if (v.paused) {
          safePlay(v);
        }
      });
    }
    interactionEvents.forEach((evt) => {
      window.addEventListener(evt, handleUserInteraction, { passive: true, once: false });
      document.addEventListener(evt, handleUserInteraction, { passive: true, once: false });
    });

    // 4. Tab visibility change handling
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        playAllBackgroundVideos();
      }
    });

    // 5. IntersectionObserver for high-performance lazy playback
    if ('IntersectionObserver' in window) {
      const videoObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          const v = entry.target;
          if (entry.isIntersecting) {
            safePlay(v);
          } else {
            if (v.id !== 'bgVideo' && !v.classList.contains('hero-video')) {
              try { v.pause(); } catch (e) {}
            }
          }
        });
      }, { rootMargin: '200px 0px', threshold: 0.05 });

      document.querySelectorAll('video').forEach((v) => {
        videoObserver.observe(v);
      });
    }
  })();

  // Title & Subtitle Carousel Setup
  const slides = document.querySelectorAll('.title-slide');
  const progressBarFill = document.querySelector('.progress-bar-fill');
  const currentCountEl = document.querySelector('.current-slide-num');
  const totalCountEl = document.querySelector('.total-slide-num');
  const prevBtn = document.querySelector('.prev-title-btn');
  const nextBtn = document.querySelector('.next-title-btn');

  let currentIndex = 0;
  const slideDuration = 5500; // 5.5 seconds per slide change
  let startTime = null;
  let animationFrameId = null;

  if (totalCountEl && slides.length > 0) {
    totalCountEl.textContent = String(slides.length).padStart(2, '0');
  }

  function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.classList.remove('active', 'exit');
      if (i === index) {
        slide.classList.add('active');
      } else {
        slide.classList.add('exit');
      }
    });

    currentIndex = index;
    if (currentCountEl) {
      currentCountEl.textContent = String(currentIndex + 1).padStart(2, '0');
    }
    
    // Reset Progress Bar
    startTime = performance.now();
  }

  function updateProgress(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;
    const progress = Math.min((elapsed / slideDuration) * 100, 100);

    if (progressBarFill) {
      progressBarFill.style.width = `${progress}%`;
    }

    if (elapsed >= slideDuration) {
      const nextIndex = (currentIndex + 1) % slides.length;
      showSlide(nextIndex);
    }

    animationFrameId = requestAnimationFrame(updateProgress);
  }

  if (slides.length > 0) {
    showSlide(0);
    animationFrameId = requestAnimationFrame(updateProgress);

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        const prevIndex = (currentIndex - 1 + slides.length) % slides.length;
        showSlide(prevIndex);
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        const nextIndex = (currentIndex + 1) % slides.length;
        showSlide(nextIndex);
      });
    }
  }

  function formatCounterValue(value, el) {
    const suffix = el.dataset.suffix || '';
    const pad = parseInt(el.dataset.pad || '0', 10);
    const formatted = el.dataset.format === 'comma'
      ? value.toLocaleString('en-US')
      : String(value).padStart(pad, '0');

    return `${formatted}${suffix}`;
  }

  function runCounterAnimation(el) {
    const targetValue = parseInt(el.dataset.countTo || '0', 10);
    const duration = 1600;
    const startTime = performance.now();

    function tick(timestamp) {
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const currentValue = Math.round(eased * targetValue);

      el.textContent = formatCounterValue(currentValue, el);

      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        el.textContent = formatCounterValue(targetValue, el);
      }
    }

    requestAnimationFrame(tick);
  }

  const statCounters = document.querySelectorAll('.stat-counter');
  if (statCounters.length) {
    const statsObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.dataset.counted) {
          entry.target.dataset.counted = 'true';
          runCounterAnimation(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    statCounters.forEach(counter => statsObserver.observe(counter));
  }

  // Scroll Intersection Observer for Left/Right Video Cards & About Section
  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -80px 0px',
    threshold: 0.12
  };

  const animatedElements = document.querySelectorAll('.animate-from-left, .animate-from-right, .animate-fade-up');

  const scrollObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
      }
    });
  }, observerOptions);

  animatedElements.forEach(el => scrollObserver.observe(el));

  // Villa Showcase Category Filter Tabs
  const filterBtns = document.querySelectorAll('.villa-tab-btn');
  const villaCards = document.querySelectorAll('.villa-card');

  if (filterBtns.length > 0 && villaCards.length > 0) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const filterValue = btn.getAttribute('data-filter');

        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        villaCards.forEach(card => {
          const category = card.getAttribute('data-category');
          if (filterValue === 'all' || category === filterValue) {
            card.style.display = 'flex';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }

  // Villa Card Multi-Image Auto-Slider
  const cardElements = document.querySelectorAll('.villa-card');

  cardElements.forEach(card => {
    const slides = card.querySelectorAll('.villa-slide-img');
    const dots = card.querySelectorAll('.villa-slider-dots .dot');
    if (slides.length <= 1) return;

    let currentSlide = 0;

    function nextSlide() {
      slides[currentSlide].classList.remove('active');
      if (dots[currentSlide]) dots[currentSlide].classList.remove('active');

      currentSlide = (currentSlide + 1) % slides.length;

      slides[currentSlide].classList.add('active');
      if (dots[currentSlide]) dots[currentSlide].classList.add('active');
    }

    let sliderTimer = setInterval(nextSlide, 3500 + Math.random() * 800);

    card.addEventListener('mouseenter', () => clearInterval(sliderTimer));
    card.addEventListener('mouseleave', () => {
      sliderTimer = setInterval(nextSlide, 3500 + Math.random() * 800);
    });

    dots.forEach((dot, dotIdx) => {
      dot.addEventListener('click', (e) => {
        e.stopPropagation();
        slides[currentSlide].classList.remove('active');
        if (dots[currentSlide]) dots[currentSlide].classList.remove('active');
        currentSlide = dotIdx;
        slides[currentSlide].classList.add('active');
        dot.classList.add('active');
      });
    });
  });

  // Luxury Interactive Leaflet Map & Auto Location Showcase Controller
  const nearbyPlaces = [
    {
      id: 'chail',
      name: 'Chail Town',
      distance: '16 KMS AWAY',
      distVal: '16 km',
      time: '25 Mins Drive',
      coords: [30.9686, 77.1994],
      desc: "Encircled by pine forests, home to the world's highest cricket ground, scenic sanctuary trails, and heritage royal retreats.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-22 at 4.05.04 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2-7 10h4l-4 8h14l-4-8h4z"/><path d="M12 20v2"/></svg>'
    },
    {
      id: 'kufri',
      name: 'Kufri',
      distance: '33 KMS AWAY',
      distVal: '33 km',
      time: '50 Mins Drive',
      coords: [31.0979, 77.2678],
      desc: "Famous for snow-capped panoramic ridges, Himalayan wildlife parks, adventure sports, and alpine hiking trails.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m8 3 4 8 5-5 5 15H2L8 3z"/></svg>'
    },
    {
      id: 'sanjauli',
      name: 'Sanjauli Helipad',
      distance: '43 KMS AWAY',
      distVal: '43 km',
      time: 'Direct Air Transit',
      coords: [31.1041, 77.1960],
      desc: "Direct helicopter terminal providing swift aerial transit to Chandigarh and Delhi NCR.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.48 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M8 12h8"/></svg>'
    },
    {
      id: 'kandaghat',
      name: 'Kandaghat',
      distance: '44.3 KMS AWAY',
      distVal: '44.3 km',
      time: '1.1 Hrs Drive',
      coords: [30.9667, 77.1000],
      desc: "Charming UNESCO Toy Train railway station connecting Kalka with the Shimla mountain line.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-22 at 3.41.00 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="16" x="4" y="3" rx="2"/><path d="M4 11h16M12 3v8M8 19l-3 3M16 19l3 3M8 15h.01M16 15h.01"/></svg>'
    },
    {
      id: 'naldhera',
      name: 'Naldhera',
      distance: '57 KMS AWAY',
      distVal: '57 km',
      time: '1.4 Hrs Drive',
      coords: [31.1822, 77.1970],
      desc: "Historic 18-hole mountain golf course carpeted under ancient Deodar trees and rolling hilltops.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22V2l10 5-10 5"/><ellipse cx="12" cy="20" rx="8" ry="2"/></svg>'
    },
    {
      id: 'shimla',
      name: 'Shimla',
      distance: '48 KMS AWAY',
      distVal: '48 km',
      time: '1.2 Hrs Drive',
      coords: [31.1048, 77.1734],
      desc: "Colonial architecture, vibrant promenade dining, boutique shops, and historic cultural landmarks.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-22 at 3.41.22 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22h16M4 2h16M6 6v12M10 6v12M14 6v12M18 6v12M2 6h20M2 18h20"/></svg>'
    },
    {
      id: 'chandigarh',
      name: 'Chandigarh',
      distance: '121 KMS AWAY',
      distVal: '121 km',
      time: '3.0 Hrs Drive',
      coords: [30.6735, 76.7885],
      desc: "Major international aviation hub connecting luxury travelers with non-stop domestic & international flights.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3.5c-.5-.5-2.5 0-4 1.5L13.5 8.5 5.3 6.7c-.8-.2-1.6.1-2 .8l-.8 1.4 5.3 3.5-3.5 3.5-2.3-.5c-.4-.1-.9.1-1.1.5L.2 17c-.3.4-.2 1 .2 1.3l3.5 2.5 2.5 3.5c.3.4.9.5 1.3.2l1.1-.7c.4-.2.6-.7.5-1.1l-.5-2.3 3.5-3.5 3.5 5.3c.7.4 1.6.2 1.8-.6l1.4-.8c.7-.4 1-.12.8-2z"/></svg>'
    },
    {
      id: 'delhi',
      name: 'Delhi NCR',
      distance: '354 KMS AWAY',
      distVal: '354 km',
      time: '6.0 Hrs Drive',
      coords: [28.6139, 77.2090],
      desc: "Smooth 6-hour highway connectivity via National Expressway directly reaching the foothills.",
      img: "<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 5.00.19 PM.jpeg')); ?>",
      iconSvg: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H7.5a1 1 0 0 0-.8.4L4 11l-2.16.36A1 1 0 0 0 1 12.35V16h3"/><circle cx="6.5" cy="16.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></svg>'
    }
  ];

  const mapElement = document.getElementById('leaflet-map');
  let leafletMap = null;
  let leafletMarkers = {};

  if (mapElement && typeof L !== 'undefined') {
    try {
      leafletMap = L.map('leaflet-map', {
        center: [30.9850, 77.2000],
        zoom: 11,
        zoomControl: false,
        attributionControl: false
      });

      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        attribution: 'Esri Topo Map'
      }).addTo(leafletMap);

      // Render schematic waypoint nodes matching reference image
      nearbyPlaces.forEach(place => {
        const isOrigin = (place.id === 'chandigarh' || place.id === 'delhi');
        const customIcon = L.divIcon({
          className: 'leaflet-custom-marker-wrapper',
          html: `
            <div class="map-node-wrapper ${isOrigin ? 'origin-node' : ''} ${place.id === 'chail' ? 'active-node gold-pin' : ''}" id="marker-pin-${place.id}" title="${place.name}">
              <div class="map-node-circle"></div>
              <div class="map-node-label">${place.name}</div>
            </div>
          `,
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });

        const marker = L.marker(place.coords, { icon: customIcon }).addTo(leafletMap);
        marker.on('click', () => {
          selectPlace(place.id);
        });
        leafletMarkers[place.id] = marker;
      });

      // The Ulhas Vilas Dedicated Highlight Location & Luxury Emblem Pin
      const ulhasVilasCoords = [30.9780, 77.2150];
      const ulhasIcon = L.divIcon({
        className: 'leaflet-custom-marker-wrapper ulhas-estate-wrapper-outer',
        html: `
          <div class="ulhas-estate-pin-wrapper" id="marker-pin-ulhas" title="The Ulhas Vilas Estate">
            <div class="ulhas-radar-pulse"></div>
            <div class="ulhas-radar-pulse pulse-delayed"></div>
            <div class="ulhas-estate-badge-top">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#C89D48"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
              <span class="estate-name">The Ulhas Vilas</span>
            </div>
            <div class="ulhas-estate-disc">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </div>
          </div>
        `,
        iconSize: [120, 60],
        iconAnchor: [60, 38]
      });

      const ulhasMarker = L.marker(ulhasVilasCoords, { icon: ulhasIcon, zIndexOffset: 2000 }).addTo(leafletMap);
      ulhasMarker.on('click', () => {
        if (leafletMap) {
          leafletMap.flyTo(ulhasVilasCoords, 13, { duration: 1.2 });
        }
      });

      // Clean Continuous Highway Route Line (Smooth White Route with Amber Glow)
      const scenicRouteCoords = [
        [30.6735, 76.7885], // Chandigarh
        [30.8344, 76.9328], // Pinjore
        [30.9045, 77.0967], // Solan
        [30.9667, 77.1000], // Kandaghat
        [30.9686, 77.1994], // Chail
        [30.9780, 77.2150], // The Ulhas Vilas
        [31.1048, 77.1734], // Shimla
        [31.1041, 77.1960], // Sanjauli
        [31.0979, 77.2678], // Kufri
        [31.1822, 77.1970]  // Naldhera
      ];

      // Outer gold glow line
      L.polyline(scenicRouteCoords, {
        color: '#C89D48',
        weight: 6,
        opacity: 0.65,
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(leafletMap);

      // Inner crisp white road line
      L.polyline(scenicRouteCoords, {
        color: '#FFFFFF',
        weight: 3.5,
        opacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(leafletMap);

      // Smooth link from Delhi to Chandigarh
      const delhiToChandigarh = [
        [28.6139, 77.2090],
        [30.6735, 76.7885]
      ];
      L.polyline(delhiToChandigarh, {
        color: '#C89D48',
        weight: 3,
        opacity: 0.7,
        dashArray: '5, 8'
      }).addTo(leafletMap);

      setTimeout(() => {
        if (leafletMap) leafletMap.invalidateSize();
      }, 500);
      window.addEventListener('resize', () => {
        if (leafletMap) leafletMap.invalidateSize();
      });

    } catch (e) {
      console.warn('Leaflet map initialization skipped or offline:', e);
    }
  }

  let currentPlaceIndex = 0;

  function selectPlace(placeId) {
    const idx = nearbyPlaces.findIndex(p => p.id === placeId);
    if (idx === -1) return;

    currentPlaceIndex = idx;
    const place = nearbyPlaces[idx];

    // Update left grid cards
    const gridCards = document.querySelectorAll('.place-grid-card');
    gridCards.forEach(card => {
      if (card.getAttribute('data-place-id') === placeId) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });

    // Update Photo Card Overlay
    const featuredImg = document.getElementById('featured-img');
    const featuredTitle = document.getElementById('featured-title');
    const featuredDist = document.getElementById('featured-dist');
    const featuredTime = document.getElementById('featured-time');
    const featuredDesc = document.getElementById('featured-desc');

    if (featuredImg) {
      featuredImg.style.opacity = '0';
      setTimeout(() => {
        featuredImg.src = place.img;
        featuredImg.style.opacity = '1';
      }, 150);
    }
    if (featuredTitle) featuredTitle.textContent = place.name;
    if (featuredDist) featuredDist.textContent = place.distance;
    if (featuredTime) featuredTime.textContent = place.time;
    if (featuredDesc) featuredDesc.textContent = place.desc;

    // Update Dots
    const dots = document.querySelectorAll('#photo-dots .dot');
    dots.forEach((dot, dIdx) => {
      if (dIdx === idx) dot.classList.add('active');
      else dot.classList.remove('active');
    });

    // Update Map View & Marker Highlights
    if (leafletMap) {
      leafletMap.flyTo(place.coords, 12, { duration: 1.2 });
      Object.keys(leafletMarkers).forEach(k => {
        const pinEl = document.getElementById(`marker-pin-${k}`);
        if (pinEl) {
          if (k === placeId) {
            pinEl.classList.add('active-node', 'gold-pin');
          } else {
            pinEl.classList.remove('active-node', 'gold-pin');
          }
        }
      });
    }
  }

  // Set up grid card clicks
  const gridCards = document.querySelectorAll('.place-grid-card');
  gridCards.forEach(card => {
    const id = card.getAttribute('data-place-id');
    card.addEventListener('click', () => {
      selectPlace(id);
    });
  });

  // Set up dot clicks
  const photoDots = document.querySelectorAll('#photo-dots .dot');
  photoDots.forEach((dot, dIdx) => {
    dot.addEventListener('click', () => {
      if (nearbyPlaces[dIdx]) {
        selectPlace(nearbyPlaces[dIdx].id);
      }
    });
  });

  // =========================================
  // AMENITIES & WELLNESS SECTION LOGIC
  // =========================================
  const amenitiesTrack = document.getElementById('amenitiesTrack');
  const prevAmenityBtn = document.querySelector('.prev-amenity-btn');
  const nextAmenityBtn = document.querySelector('.next-amenity-btn');
  const amenityTabBtns = document.querySelectorAll('.amenity-tab-btn');
  const amenityCards = document.querySelectorAll('.amenity-card');

  // Carousel Arrow Scroll Navigation
  if (amenitiesTrack && prevAmenityBtn && nextAmenityBtn) {
    prevAmenityBtn.addEventListener('click', () => {
      amenitiesTrack.scrollBy({ left: -320, behavior: 'smooth' });
    });
    nextAmenityBtn.addEventListener('click', () => {
      amenitiesTrack.scrollBy({ left: 320, behavior: 'smooth' });
    });
  }

  // Category Filter Tabs Logic
  if (amenityTabBtns.length > 0 && amenityCards.length > 0) {
    amenityTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const filter = btn.getAttribute('data-filter');
        
        amenityTabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        amenityCards.forEach(card => {
          const category = card.getAttribute('data-category');
          if (filter === 'all' || category === filter) {
            card.classList.remove('hidden');
          } else {
            card.classList.add('hidden');
          }
        });

        if (amenitiesTrack) {
          amenitiesTrack.scrollTo({ left: 0, behavior: 'smooth' });
        }
        updateActiveDot();
      });
    });
  }

  // Pagination Dots Sync & Click Logic
  const amenityDots = document.querySelectorAll('.amenity-dot');

  function updateActiveDot() {
    if (!amenitiesTrack || amenityDots.length === 0) return;
    const visibleCards = Array.from(amenityCards).filter(c => !c.classList.contains('hidden'));
    if (visibleCards.length === 0) return;

    const trackRect = amenitiesTrack.getBoundingClientRect();
    let activeIndex = 0;
    let minDistance = Infinity;

    visibleCards.forEach((card, idx) => {
      const cardRect = card.getBoundingClientRect();
      const dist = Math.abs(cardRect.left - trackRect.left);
      if (dist < minDistance) {
        minDistance = dist;
        activeIndex = idx;
      }
    });

    amenityDots.forEach((dot, idx) => {
      if (idx === activeIndex) {
        dot.classList.add('active');
        dot.style.display = 'inline-block';
      } else if (idx < visibleCards.length) {
        dot.classList.remove('active');
        dot.style.display = 'inline-block';
      } else {
        dot.classList.remove('active');
        dot.style.display = 'none';
      }
    });
  }

  if (amenityDots.length > 0 && amenitiesTrack) {
    amenityDots.forEach((dot, idx) => {
      dot.addEventListener('click', () => {
        const visibleCards = Array.from(amenityCards).filter(c => !c.classList.contains('hidden'));
        if (visibleCards[idx]) {
          visibleCards[idx].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
        }
      });
    });

    amenitiesTrack.addEventListener('scroll', updateActiveDot);
  }

  // View Details Modal Logic
  const modalBackdrop = document.getElementById('amenityModal');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const modalTitle = document.getElementById('modalTitle');
  const modalDesc = document.getElementById('modalDesc');
  const modalDuration = document.getElementById('modalDuration');
  const modalLevel = document.getElementById('modalLevel');
  const modalCategory = document.getElementById('modalCategory');
  const modalImg = document.getElementById('modalImg');

  // View Details Click -> Open Contacts / Quote Modal
  const viewBtns = document.querySelectorAll('.amenity-view-btn');
  viewBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const card = btn.closest('.amenity-card');
      const title = card ? (card.getAttribute('data-title') || 'Wellness & Yoga') : 'Wellness & Yoga';
      const category = card ? (card.getAttribute('data-category') ? card.getAttribute('data-category').toUpperCase() + ' & WELLNESS' : 'Wellness & Amenities') : 'Wellness & Amenities';

      // 1. If global openQuoteModal exists
      if (typeof window.openQuoteModal === 'function') {
        window.openQuoteModal('', title, category);
        return;
      }

      // 2. If #residenceQuoteModal is on the page
      const quoteModal = document.getElementById('residenceQuoteModal');
      if (quoteModal) {
        const select = document.getElementById('quoteResidenceSelect');
        if (select && select.options.length > 1) {
          select.selectedIndex = 1;
        }
        const sub = document.getElementById('quoteModalSub');
        if (sub) sub.textContent = `Inquiring for: ${title} (${category})`;
        const msgEl = document.getElementById('quoteMessage');
        if (msgEl && (!msgEl.value || msgEl.value.trim() === '')) {
          msgEl.value = `I am interested in learning more about ${title} and wellness experiences at The Ulhas Vilas.`;
        }
        quoteModal.classList.add('show');
        document.body.style.overflow = 'hidden';
        return;
      }

      // 3. Fallback to amenityModal
      if (modalBackdrop) {
        modalBackdrop.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  // =========================================
  // INVESTMENT BENEFITS INTERACTIVE SHOWCASE LOGIC (Image 1 Style)
  // =========================================
  const investmentItems = document.querySelectorAll('.investment-item');
  const investmentFeaturedImg = document.getElementById('investmentFeaturedImg');
  const investmentBadgeText = document.getElementById('investmentBadgeText');
  const investmentThumbs = document.querySelectorAll('.investment-thumb');

  if (investmentItems.length > 0) {
    investmentItems.forEach(item => {
      item.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        
        // Remove active class from all items
        investmentItems.forEach(i => i.classList.remove('active'));
        
        if (!isActive) {
          item.classList.add('active');
        } else {
          item.classList.add('active');
        }

        const imgSrc = item.getAttribute('data-img');
        const badgeText = item.getAttribute('data-badge');
        
        if (investmentFeaturedImg && imgSrc) {
          investmentFeaturedImg.style.opacity = '0';
          setTimeout(() => {
            investmentFeaturedImg.src = imgSrc;
            investmentFeaturedImg.style.opacity = '1';
          }, 180);
        }
        
        if (investmentBadgeText && badgeText) {
          investmentBadgeText.textContent = badgeText;
        }
      });
    });
  }

  // Thumbnail clicks on left column
  if (investmentThumbs.length > 0) {
    investmentThumbs.forEach(thumb => {
      thumb.addEventListener('click', (e) => {
        e.stopPropagation();
        investmentThumbs.forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        
        const imgSrc = thumb.getAttribute('data-img');
        if (investmentFeaturedImg && imgSrc) {
          investmentFeaturedImg.style.opacity = '0';
          setTimeout(() => {
            investmentFeaturedImg.src = imgSrc;
            investmentFeaturedImg.style.opacity = '1';
          }, 180);
        }
      });
    });
  }

  // =========================================
  // TESTIMONIALS CAROUSEL LOGIC (Swiper Continuous Loop)
  // =========================================
  if (typeof Swiper !== 'undefined' && document.querySelector('.testimonialSwiper')) {
    const testimonialSwiper = new Swiper('.testimonialSwiper', {
      slidesPerView: 1,
      spaceBetween: 20,
      loop: true,
      loopAdditionalSlides: 2,
      speed: 600,
      autoplay: {
        delay: 5000,
        disableOnInteraction: false,
        pauseOnMouseEnter: true,
      },
      navigation: {
        nextEl: '.testimonial-next-btn',
        prevEl: '.testimonial-prev-btn',
      },
      breakpoints: {
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        1024: {
          slidesPerView: 3,
          spaceBetween: 24,
        }
      }
    });
  }

  // =========================================
  // GALLERY MOSAIC SWIPER (Curated Frames)
  // =========================================
  if (typeof Swiper !== 'undefined' && document.querySelector('.gallerySwiper')) {
    const gallerySwiper = new Swiper('.gallerySwiper', {
      slidesPerView: 1,
      spaceBetween: 0,
      loop: true,
      autoHeight: true,
      watchOverflow: true,
      speed: 600,
      autoplay: {
        delay: 5000,
        disableOnInteraction: false,
        pauseOnMouseEnter: true,
      },
      pagination: {
        el: '.gallery-dots',
        clickable: true,
        bulletClass: 'gallery-dot',
        bulletActiveClass: 'active',
        renderBullet: function (index, className) {
          return '<button type="button" class="' + className + '" aria-label="Gallery set ' + (index + 1) + '"></button>';
        }
      }
    });
  }

  /* =========================================
     FAQ ACCORDION & CATEGORY FILTER LOGIC
     ========================================= */
  window.toggleFaqCard = function(element) {
    var accordion = element.closest('.faq-accordion-list') || document.getElementById('faqAccordion');
    var isAlreadyActive = element.classList.contains('active');
    
    if (accordion) {
      var allItems = accordion.querySelectorAll('.faq-item');
      allItems.forEach(function(item) {
        item.classList.remove('active');
        var ans = item.querySelector('.faq-answer-content');
        if (ans) {
          ans.style.display = 'none';
        }
      });
    }
    
    if (!isAlreadyActive) {
      element.classList.add('active');
      var activeAns = element.querySelector('.faq-answer-content');
      if (activeAns) {
        activeAns.style.display = 'block';
      }
    }
  };

  const faqTabBtns = document.querySelectorAll('.faq-tab-btn');

  // Category Filtering
  faqTabBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const category = btn.getAttribute('data-category');

      // Update active tab button
      faqTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Filter FAQ items
      document.querySelectorAll('.faq-item').forEach(item => {
        const itemCategory = item.getAttribute('data-category');
        if (category === 'all' || itemCategory === category) {
          item.style.display = 'block';
          item.style.opacity = '0';
          setTimeout(() => {
            item.style.opacity = '1';
          }, 50);
        } else {
          item.style.display = 'none';
        }
      });
    });
  });

  // Sticky Floating Glass Pill Header Scroll Listener
  const heroHeader = document.querySelector('.hero-header');
  if (heroHeader) {
    const onScrollHeader = () => {
      const scrollTop = Math.max(window.scrollY || 0, window.pageYOffset || 0, document.documentElement.scrollTop || 0, document.body.scrollTop || 0);
      if (scrollTop > 35) {
        heroHeader.classList.add('scrolled');
      } else {
        heroHeader.classList.remove('scrolled');
      }
    };
    window.addEventListener('scroll', onScrollHeader, { passive: true });
    document.addEventListener('scroll', onScrollHeader, { passive: true });
    onScrollHeader();
  }
});




</script>




 <script>
        // ---- HERO SLIDER ----
        (function() {
            const heroSlides = document.querySelectorAll('.residence-hero-slide');
            const heroDots   = document.querySelectorAll('.hero-dot');
            const heroTrack  = document.getElementById('heroTrack');
            
            if (!heroSlides.length || !heroTrack) return;
            
            let heroIdx = 0;
            const heroMax = heroSlides.length - 1;

            window.heroGoTo = function(n) {
                if (!heroSlides[heroIdx]) return;
                heroSlides[heroIdx].classList.remove('active');
                if (heroDots[heroIdx]) heroDots[heroIdx].classList.remove('active');
                heroIdx = Math.max(0, Math.min(n, heroMax));
                if (heroSlides[heroIdx]) heroSlides[heroIdx].classList.add('active');
                if (heroDots[heroIdx]) heroDots[heroIdx].classList.add('active');
                heroTrack.style.transform = `translateX(-${heroIdx * 100}%)`;
            };

            window.heroSlide = function(dir) { window.heroGoTo(heroIdx + dir); };

            // Auto-advance every 5s
            setInterval(() => window.heroGoTo(heroIdx < heroMax ? heroIdx + 1 : 0), 5000);

            // Touch swipe
            let sx = 0;
            heroTrack.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
            heroTrack.addEventListener('touchend', e => {
                const dx = sx - e.changedTouches[0].clientX;
                if (Math.abs(dx) > 40) window.heroSlide(dx > 0 ? 1 : -1);
            }, { passive: true });
        })();

        // ---- LIGHTBOX ----
        function openLightbox(src) {
            const img = document.getElementById('lbImg');
            const m = document.getElementById('lbModal');
            if (!img || !m) return;
            img.src = src;
            m.style.opacity = '1'; m.style.pointerEvents = 'auto';
            document.body.style.overflow = 'hidden';
        }
        function closeLb(e) {
            const m = document.getElementById('lbModal');
            if (!m) return;
            m.style.opacity = '0'; m.style.pointerEvents = 'none';
            document.body.style.overflow = 'auto';
        }
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLb(); });

        // Click hero slides to open lightbox
        document.querySelectorAll('.residence-hero-slide').forEach((s, i) => {
            s.style.cursor = 'pointer';
            s.addEventListener('click', () => openLightbox(s.querySelector('img')?.src));
        });

        // ---- READ MORE ----
        function toggleMore(btn) {
            const el = document.getElementById('moreText');
            if (!el) return;
            const show = el.style.display === 'none';
            el.style.display = show ? 'block' : 'none';
            btn.textContent = show ? 'Read less' : 'Read more';
        }

        // ---- FAQ ----
        function toggleFaqCard(id) {
            const card = document.getElementById(id);
            if (!card) return;
            const isOpen = card.classList.contains('open');
            document.querySelectorAll('.faq-card-new').forEach(c => c.classList.remove('open'));
            if (!isOpen) card.classList.add('open');
        }

        // ---- FORM ----
        function handleSubmit(e) {
            e.preventDefault();
            const form = document.getElementById('resBookingForm');
            const success = document.getElementById('formSuccess');
            if (form) form.style.display = 'none';
            if (success) success.style.display = 'block';
        }

        // ---- OTHER BHK CAROUSEL ----
        let bhkIdx = 0;
        function moveBhkCarousel(dir) {
            const track = document.getElementById('bhkTrack');
            const cards = document.querySelectorAll('.bhk-card');
            if (!track || !cards.length) return;
            const cardWidth = cards[0].offsetWidth + 24;
            const visibleCards = window.innerWidth <= 640 ? 1 : (window.innerWidth <= 1024 ? 2 : 3);
            const maxIdx = Math.max(0, cards.length - visibleCards);
            bhkIdx = Math.max(0, Math.min(bhkIdx + dir, maxIdx));
            track.style.transform = `translateX(-${bhkIdx * cardWidth}px)`;
        }

        // ---- SHOWCASE GALLERY FILTER ----
        function filterGallery(category, btnElement) {
            const items = document.querySelectorAll('.res-gallery-item');
            const btns = document.querySelectorAll('.res-gallery-tab-btn');
            btns.forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');

            items.forEach(item => {
                if (category === 'all' || item.getAttribute('data-category') === category) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // ---- CONTACT PAGE LIGHT FORM ----
        function handleLightSubmit(e) {
            e.preventDefault();
            const form = document.getElementById('lightContactForm');
            const success = document.getElementById('lightFormSuccess');
            if (form) form.style.display = 'none';
            if (success) success.style.display = 'block';
        }

        // ---- GALLERY PAGE FILTERING LOGIC (Instant & Quick) ----
        function filterGalleryCategory(category, btnElement) {
            const items = document.querySelectorAll('.gallery-card-item');
            const btns = document.querySelectorAll('.gallery-tab-btn');
            
            btns.forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');

            items.forEach(item => {
                const itemCategory = item.getAttribute('data-category');
                if (category === 'all' || itemCategory === category) {
                    item.style.display = 'block';
                    item.style.opacity = '1';
                    item.style.transform = 'scale(1)';
                } else {
                    item.style.display = 'none';
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.98)';
                }
            });
        }

        // ---- GALLERY HERO BACKGROUND SLIDER ----
        (function() {
            const track = document.getElementById('galleryHeroTrack');
            if (!track) return;
            const slides = track.querySelectorAll('.contact-hero-slide');
            if (slides.length <= 1) return;
            
            let idx = 0;
            const max = slides.length - 1;
            
            setInterval(() => {
                if (slides[idx]) slides[idx].classList.remove('active');
                idx = idx < max ? idx + 1 : 0;
                if (slides[idx]) slides[idx].classList.add('active');
                track.style.transform = `translateX(-${idx * 100}%)`;
            }, 4500);
        })();

        // ---- BLOG PAGE FILTERING LOGIC ----
        function filterBlogCategory(category, btnElement) {
            const items = document.querySelectorAll('.blog-card-item');
            const btns = document.querySelectorAll('.gallery-tab-btn');
            
            btns.forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');

            items.forEach(item => {
                const itemCategory = item.getAttribute('data-category');
                if (category === 'all' || itemCategory === category) {
                    item.style.display = 'flex';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'translateY(0)';
                    }, 50);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'translateY(15px)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 250);
                }
            });
        }

        // ---- BLOG HERO BACKGROUND SLIDER ----
        (function() {
            const track = document.getElementById('blogHeroTrack');
            if (!track) return;
            const slides = track.querySelectorAll('.contact-hero-slide');
            if (slides.length <= 1) return;
            
            let idx = 0;
            const max = slides.length - 1;
            
            setInterval(() => {
                if (slides[idx]) slides[idx].classList.remove('active');
                idx = idx < max ? idx + 1 : 0;
                if (slides[idx]) slides[idx].classList.add('active');
                track.style.transform = `translateX(-${idx * 100}%)`;
            }, 4500);
        })();

        // ---- BLOG DETAIL HERO BACKGROUND SLIDER ----
        (function() {
            const track = document.getElementById('blogDetailHeroTrack');
            if (!track) return;
            const slides = track.querySelectorAll('.contact-hero-slide');
            if (!slides.length) return;
            
            let idx = 0;
            const max = slides.length - 1;
            
            setInterval(() => {
                if (slides[idx]) slides[idx].classList.remove('active');
                idx = idx < max ? idx + 1 : 0;
                if (slides[idx]) slides[idx].classList.add('active');
                track.style.transform = `translateX(-${idx * 100}%)`;
            }, 4500);
        })();

        // ---- CONTACT HERO BACKGROUND SLIDER ----
        (function() {
            const track = document.getElementById('contactHeroTrack');
            const slides = document.querySelectorAll('.contact-hero-slide');
            if (!track || !slides.length) return;
            
            let idx = 0;
            const max = slides.length - 1;
            
            setInterval(() => {
                if (slides[idx]) slides[idx].classList.remove('active');
                idx = idx < max ? idx + 1 : 0;
                if (slides[idx]) slides[idx].classList.add('active');
                track.style.transform = `translateX(-${idx * 100}%)`;
            }, 4500);
        })();
    </script>
</body>
</html><?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/includes/JsLink.blade.php ENDPATH**/ ?>