    <?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
    .residences-page-body {
        background: #FDFBF7;
        color: #1A202C;
        font-family: var(--font-body);
        overflow-x: hidden;
    }

    /* 1. Residences Hero Banner */
    .residences-hero-section {
        position: relative;
        min-height: 58vh;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background: #0B0E12;
        padding: 9.5rem 1.5rem 5rem;
    }

    .residences-hero-bg-wrapper {
        position: absolute;
        inset: 0;
        z-index: 1;
        overflow: hidden;
    }

    .residences-hero-bg-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        filter: brightness(0.85);
        transform: scale(1.02);
    }

    .residences-hero-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(8, 10, 14, 0.72) 0%, rgba(8, 10, 14, 0.52) 50%, rgba(8, 10, 14, 0.88) 100%);
        z-index: 2;
    }

    .residences-hero-content {
        position: relative;
        z-index: 5;
        max-width: 920px;
        margin: 0 auto;
        text-align: center;
    }

    .residences-hero-eyebrow {
        display: inline-block;
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658;
        margin-bottom: 0.75rem;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
    }

    .residences-hero-title {
        font-family: var(--font-heading);
        font-size: clamp(2.2rem, 4.5vw, 3.6rem) !important;
        line-height: 1.15;
        color: #FFFFFF;
        font-weight: 400;
        margin-bottom: 1rem;
        text-shadow: 0 3px 20px rgba(0, 0, 0, 0.75);
    }

    .residences-hero-title span {
        color: #DCB658;
    }

    .residences-hero-desc {
        font-size: clamp(0.92rem, 1.2vw, 1.05rem);
        color: rgba(255, 255, 255, 0.9);
        line-height: 1.7;
        max-width: 720px;
        margin: 0 auto 2rem;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.6);
    }

    .residences-hero-badges {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1.5rem;
        flex-wrap: wrap;
    }

    .res-badge-item {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.16);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        padding: 0.45rem 1rem;
        border-radius: 9999px;
        font-size: 0.78rem;
        font-weight: 600;
        color: #FFFFFF;
        letter-spacing: 0.03em;
    }

    .res-badge-item svg {
        color: #DCB658;
    }

    /* 2. Main Wrapper & Filter Tabs */
    .residences-main-wrapper {
        padding: 5rem 1.5rem 6rem;
        background: #FDFBF7;
    }

    .residences-main-container {
        max-width: 1320px;
        margin: 0 auto;
    }

    .residences-header-center {
        text-align: center;
        max-width: 780px;
        margin: 0 auto 3rem;
    }

    .residences-filter-tabs {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        flex-wrap: wrap;
        margin-bottom: 3.5rem;
    }

    .res-tab-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: #FFFFFF;
        border: 1px solid #E5DFD3;
        color: #4A5568;
        padding: 0.75rem 1.4rem;
        border-radius: 9999px;
        font-family: var(--font-body);
        font-size: 0.86rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.25s ease;
        outline: none;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
    }

    .res-tab-btn .tab-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #F1ECE1;
        color: #6B7280;
        font-size: 0.72rem;
        font-weight: 700;
        padding: 0.15rem 0.5rem;
        border-radius: 999px;
        line-height: 1;
        transition: all 0.2s ease;
    }

    .res-tab-btn:hover {
        border-color: #DCB658;
        color: #0E1114;
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
    }

    .res-tab-btn.active {
        background: #111827;
        color: #FFFFFF;
        border-color: #111827;
        box-shadow: 0 6px 20px rgba(17, 24, 39, 0.22);
        transform: translateY(-2px);
    }

    .res-tab-btn.active .tab-count {
        background: #DCB658;
        color: #0E1114;
    }

    /* 3. Residences Cards Grid (3 Columns) */
    .residences-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.75rem;
    }

    .residence-card {
        background: #FFFFFF;
        border: 1px solid #EBE6DC;
        border-radius: 18px;
        overflow: hidden;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        display: flex;
        flex-direction: column;
        position: relative;
    }

    .residence-card:hover {
        transform: translateY(-8px);
        border-color: #D1AC62;
        box-shadow: 0 18px 40px rgba(17, 24, 39, 0.11);
    }

    /* Card Media Area & Image Slider */
    .residence-card-media {
        position: relative;
        width: 100%;
        height: 250px;
        overflow: hidden;
        background: #0E1114;
    }

    .residence-image-slider {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .residence-slide-img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0;
        transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .residence-slide-img.active,
    .residence-slide-img:first-child {
        opacity: 1;
        z-index: 2;
    }

    .residence-card:hover .residence-slide-img.active,
    .residence-card:hover .residence-slide-img:first-child {
        transform: scale(1.08);
    }

    .res-media-top-tags {
        position: absolute;
        top: 1rem;
        right: 1rem;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        z-index: 5;
        pointer-events: none;
    }

    .res-category-tag {
        background: rgba(17, 24, 39, 0.85);
        border: 1px solid rgba(220, 182, 88, 0.5);
        color: #FDFBF7;
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 0.35rem 0.75rem;
        border-radius: 6px;
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
    }

    .res-price-tag {
        background: #DCB658;
        color: #0E1114;
        font-family: var(--font-heading);
        font-size: 0.82rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        padding: 0.35rem 0.85rem;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.22);
    }

    /* Slider Dots */
    .residence-slider-dots {
        position: absolute;
        bottom: 0.85rem;
        right: 1rem;
        display: flex;
        align-items: center;
        gap: 5px;
        z-index: 6;
    }

    .residence-slider-dots .res-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.45);
        backdrop-filter: blur(4px);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .residence-slider-dots .res-dot.active {
        width: 18px;
        border-radius: 9999px;
        background-color: #DCB658;
        box-shadow: 0 0 8px rgba(220, 182, 88, 0.6);
    }

    /* Card Body */
    .residence-card-body {
        padding: 1.45rem 1.4rem 1.65rem;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    }

    .res-card-header {
        display: flex;
        flex-direction: column;
        margin-bottom: 0.85rem;
    }

    .res-card-title {
        font-family: var(--font-heading);
        font-size: 1.28rem;
        font-weight: 400;
        color: #111827;
        margin-bottom: 0.25rem;
        line-height: 1.25;
    }

    .res-card-subtitle {
        font-size: 0.78rem;
        color: #8C7335;
        font-weight: 600;
        letter-spacing: 0.03em;
        text-transform: uppercase;
    }

    .res-card-desc {
        font-size: 0.86rem;
        color: #555555;
        line-height: 1.55;
        margin-bottom: 1.15rem;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    /* Specs Grid Row (3 Columns) */
    .res-card-specs-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 0.5rem;
        background: #F9F8F5;
        border: 1px solid #ECE7DC;
        border-radius: 12px;
        padding: 0.85rem 0.6rem;
        margin-bottom: 1.5rem;
        text-align: center;
    }

    .res-spec-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .res-spec-item:not(:last-child) {
        border-right: 1px solid #E5DFD3;
    }

    .res-spec-val {
        font-family: var(--font-heading);
        font-size: 1.05rem;
        font-weight: 700;
        color: #111827;
        line-height: 1.15;
    }

    .res-spec-lbl {
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        color: #718096;
        letter-spacing: 0.05em;
        margin-top: 0.2rem;
    }

    /* Actions Footer (Side-by-Side View Details & Send Quote Buttons) */
    .res-card-actions {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        margin-top: auto;
        padding-top: 0.25rem;
    }

    .res-btn-primary {
        flex: 1.25;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.35rem;
        background: #111827;
        color: #FFFFFF !important;
        border: 1px solid #111827;
        border-radius: 9999px;
        padding: 0.68rem 0.75rem;
        font-size: 0.76rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.3s ease;
        white-space: nowrap;
    }

    .res-btn-primary:hover {
        background: #DCB658;
        color: #0E1114 !important;
        border-color: #DCB658;
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(220, 182, 88, 0.28);
    }

    .res-btn-secondary {
        flex: 1;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.35rem;
        background: #F4F1EA;
        color: #1F2937 !important;
        border: 1px solid #E5DFD3;
        border-radius: 9999px;
        padding: 0.68rem 0.75rem;
        font-size: 0.76rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.25s ease;
        white-space: nowrap;
    }

    .res-btn-secondary:hover {
        background: #DCB658;
        color: #0E1114 !important;
        border-color: #DCB658;
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(220, 182, 88, 0.28);
    }

    /* 4. Estate Ownership Privileges Section (Light Glassmorphism on Ambient Video) */
    .res-privileges-section {
        position: relative;
        padding: 3.5rem 1.5rem 3.75rem;
        background: #0B0E13;
        overflow: hidden;
    }

    .res-privileges-video-wrapper {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .res-privileges-bg-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 1;
        filter: brightness(0.95) contrast(1.05);
        transform: scale(1.02);
    }

    .res-privileges-dark-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(180deg, rgba(8, 12, 17, 0.42) 0%, rgba(10, 14, 20, 0.30) 50%, rgba(8, 12, 17, 0.52) 100%);
        pointer-events: none;
        z-index: 2;
    }

    .res-privileges-container {
        position: relative;
        z-index: 5;
        max-width: 1320px;
        margin: 0 auto;
    }

    .res-privileges-header {
        text-align: center;
        max-width: 800px;
        margin: 0 auto 2.75rem;
    }

    .res-privileges-header .contact-eyebrow {
        display: inline-block;
        font-family: var(--font-body);
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658 !important;
        margin-bottom: 0.75rem;
        text-align: center;
    }

    .res-privileges-title {
        font-family: var(--font-heading);
        font-size: clamp(2rem, 3.8vw, 3rem);
        color: #FFFFFF !important;
        font-weight: 400;
        margin-bottom: 0.85rem;
        text-align: center;
        letter-spacing: -0.01em;
        text-shadow: 0 2px 14px rgba(0, 0, 0, 0.75);
    }

    .res-privileges-title span {
        color: #DCB658;
        font-style: normal;
    }

    .res-privileges-desc {
        font-family: var(--font-body);
        font-size: 1rem;
        line-height: 1.68;
        color: rgba(255, 255, 255, 0.9) !important;
        text-align: center;
        max-width: 720px;
        margin: 0 auto;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.75);
    }

    .res-privileges-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.25rem;
        margin-top: 2rem;
    }

    .res-privilege-card {
        background: rgba(255, 255, 255, 0.18);
        backdrop-filter: blur(18px);
        -webkit-backdrop-filter: blur(18px);
        border: 1px solid rgba(255, 255, 255, 0.35);
        border-radius: 18px;
        padding: 2rem 1.4rem;
        text-align: center;
        box-shadow: 0 14px 36px rgba(0, 0, 0, 0.2), inset 0 1px 1px rgba(255, 255, 255, 0.45);
        transition: all 0.35s ease;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .res-privilege-card:hover {
        transform: translateY(-6px);
        background: rgba(255, 255, 255, 0.28);
        border-color: rgba(255, 255, 255, 0.65);
        box-shadow: 0 20px 48px rgba(0, 0, 0, 0.32), inset 0 1px 1px rgba(255, 255, 255, 0.65);
    }

    .res-privilege-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.22);
        border: 1px solid rgba(255, 255, 255, 0.45);
        backdrop-filter: blur(8px);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #FFFFFF;
        margin-bottom: 1.15rem;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.12);
        transition: all 0.3s ease;
    }

    .res-privilege-card:hover .res-privilege-icon {
        background: #D4AF37;
        color: #0E1114;
        border-color: #D4AF37;
        transform: rotate(5deg) scale(1.06);
        box-shadow: 0 6px 20px rgba(212, 175, 55, 0.45);
    }

    .res-privilege-title {
        font-family: var(--font-heading);
        font-size: 1.18rem;
        font-weight: 600;
        color: #FFFFFF;
        margin-bottom: 0.55rem;
        text-shadow: 0 1px 4px rgba(0, 0, 0, 0.45);
    }

    .res-privilege-desc {
        font-size: 0.84rem;
        color: rgba(255, 255, 255, 0.92);
        line-height: 1.55;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.35);
    }

    /* =========================================================
       4B. THE RIGHT CHOICE OF INVESTMENT SECTION (LIGHT LUXURY BENTO)
       ========================================================= */
    .res-investment-section {
        background: #FAF8F4;
        border-top: 1px solid #EBE3D3;
        border-bottom: 1px solid #EBE3D3;
        padding: 5.5rem 1.5rem 6rem;
        position: relative;
        overflow: hidden;
    }

    .res-investment-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 800px;
        height: 350px;
        background: radial-gradient(circle, rgba(220, 182, 88, 0.08) 0%, rgba(250, 248, 244, 0) 70%);
        pointer-events: none;
    }

    .res-investment-container {
        max-width: 1280px;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }

    .res-investment-header {
        text-align: center;
        max-width: 820px;
        margin: 0 auto 3.5rem;
    }

    .res-investment-eyebrow {
        display: inline-block;
        font-family: var(--font-body);
        font-size: 0.76rem;
        font-weight: 800;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: #7E5420;
        margin-bottom: 0.5rem;
    }

    .res-investment-title {
        font-family: 'Marcellus', serif !important;
        font-size: clamp(2rem, 3.5vw, 2.75rem);
        color: #1A1510;
        line-height: 1.25;
        margin-bottom: 0.75rem;
        letter-spacing: -0.01em;
    }

    .res-investment-line {
        display: block;
        width: 50px;
        height: 2px;
        background: #DCB658;
        margin: 0 auto 1.25rem;
        border-radius: 2px;
    }

    .res-investment-desc {
        font-family: var(--font-body);
        font-size: 1.02rem;
        color: #5C6758;
        line-height: 1.65;
        margin: 0 auto;
    }

    /* Bento / Dynamic Card Grid */
    .res-investment-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.5rem;
    }

    .res-inv-card {
        background: linear-gradient(180deg, #FFFFFF 0%, #FAF6EE 100%);
        border: 1px solid #EBE2D0;
        border-radius: 20px;
        padding: 2.25rem 2rem;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 6px 24px rgba(126, 84, 32, 0.04);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        position: relative;
        overflow: hidden;
    }

    .res-inv-card::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, #7E5420, #DCB658);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .res-inv-card:hover {
        transform: translateY(-6px);
        border-color: #DCB658;
        box-shadow: 0 16px 40px rgba(126, 84, 32, 0.12), 0 0 0 1px rgba(220, 182, 88, 0.25);
    }

    .res-inv-card:hover::after {
        opacity: 1;
    }

    .res-inv-card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1.5rem;
    }

    .res-inv-icon-box {
        width: 56px;
        height: 56px;
        border-radius: 16px;
        background: #FAF4E8;
        border: 1px solid #EBDBC2;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #7E5420;
        transition: transform 0.3s ease, background 0.3s ease;
    }

    .res-inv-card:hover .res-inv-icon-box {
        transform: scale(1.08) rotate(3deg);
        background: #7E5420;
        color: #FFFFFF;
        border-color: #7E5420;
    }

    .res-inv-tag {
        font-family: 'Manrope', sans-serif;
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #7E5420;
        background: #F4EAD9;
        padding: 0.35rem 0.75rem;
        border-radius: 999px;
        border: 1px solid #E8D7BF;
    }

    .res-inv-metric-badge {
        font-family: 'Marcellus', serif !important;
        font-size: 2.35rem;
        color: #7E5420;
        font-weight: 600;
        line-height: 1.1;
        margin-bottom: 0.35rem;
        display: block;
    }

    .res-inv-card-title {
        font-family: 'Marcellus', serif !important;
        font-size: 1.32rem;
        color: #1A1510;
        font-weight: 500;
        line-height: 1.35;
        margin-bottom: 0.75rem;
    }

    .res-inv-card-desc {
        font-family: 'Manrope', sans-serif;
        font-size: 0.9rem;
        color: #4B5563;
        line-height: 1.6;
        margin: 0;
    }

    @media (max-width: 1024px) {
        .res-investment-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.25rem;
        }
    }

    @media (max-width: 640px) {
        .res-investment-grid {
            grid-template-columns: 1fr;
            gap: 1.15rem;
        }
        .res-investment-section {
            padding: 3.5rem 1.25rem 4rem;
        }
    }

    /* 6. Floor Plan & Send Quote Modal (Split Layout) */
    .res-modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(10, 12, 16, 0.85);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        z-index: 99998;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.35s ease;
        padding: 1.25rem;
    }

    .res-modal-overlay.active {
        opacity: 1;
        pointer-events: auto;
    }

    .res-modal-content {
        background: #FFFFFF;
        border-radius: 24px;
        max-width: 900px;
        width: 100%;
        max-height: 92vh;
        overflow-y: auto;
        padding: 0;
        position: relative;
        box-shadow: 0 30px 70px rgba(0, 0, 0, 0.35);
        border: 1px solid #EAE5D9;
        transform: translateY(24px) scale(0.98);
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        overflow: hidden;
    }

    .res-modal-overlay.active .res-modal-content {
        transform: translateY(0) scale(1);
    }

    .res-modal-close {
        position: absolute;
        top: 1.25rem;
        right: 1.25rem;
        background: rgba(255, 255, 255, 0.9);
        border: 1px solid #E0D9CB;
        color: #1A202C;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
        z-index: 10;
        transition: all 0.2s ease;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
    }

    .res-modal-close:hover {
        background: #111827;
        color: #FFFFFF;
        border-color: #111827;
        transform: rotate(90deg);
    }

    .res-modal-split-grid {
        display: grid;
        grid-template-columns: 1fr 1.15fr;
        min-height: 520px;
    }

    /* Modal Left: Image & Specs Card */
    .res-modal-left-col {
        position: relative;
        background: #0E1114;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding: 2.25rem 2rem;
        overflow: hidden;
    }

    .res-modal-bg-img {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.85;
        transition: transform 0.8s ease;
    }

    .res-modal-left-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(14, 18, 24, 0.55) 0%, rgba(14, 18, 24, 0.4) 40%, rgba(10, 13, 18, 0.95) 100%);
        z-index: 2;
    }

    .res-modal-left-top {
        position: relative;
        z-index: 5;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .res-modal-brand-badge {
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: #DCB658;
        background: rgba(14, 18, 24, 0.7);
        padding: 0.35rem 0.75rem;
        border-radius: 4px;
        border: 1px solid rgba(220, 182, 88, 0.4);
        backdrop-filter: blur(6px);
    }

    .res-modal-left-bottom {
        position: relative;
        z-index: 5;
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .res-modal-price-pill {
        display: inline-block;
        background: #DCB658;
        color: #0E1114;
        font-family: var(--font-heading);
        font-size: 0.88rem;
        font-weight: 700;
        padding: 0.35rem 0.85rem;
        border-radius: 6px;
        align-self: flex-start;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.3);
    }

    .res-modal-res-title {
        font-family: var(--font-heading);
        font-size: 1.65rem;
        font-weight: 400;
        color: #FFFFFF;
        line-height: 1.2;
        margin: 0;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
    }

    .res-modal-res-specs {
        font-size: 0.82rem;
        color: rgba(255, 255, 255, 0.85);
        font-weight: 500;
        margin: 0;
    }

    .res-modal-perks-list {
        list-style: none;
        padding: 0.75rem 0 0;
        margin: 0;
        border-top: 1px solid rgba(255, 255, 255, 0.18);
        display: flex;
        flex-direction: column;
        gap: 0.4rem;
    }

    .res-modal-perk-item {
        font-size: 0.76rem;
        color: #E2E8F0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .res-modal-perk-item svg {
        color: #DCB658;
        flex-shrink: 0;
    }

    /* Modal Right: Form Column */
    .res-modal-right-col {
        padding: 2.5rem 2.5rem 2.25rem;
        background: #FFFFFF;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .res-modal-form-header {
        margin-bottom: 1.5rem;
    }

    .res-modal-form-eyebrow {
        font-size: 0.74rem;
        font-weight: 700;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: #8C7335;
        display: block;
        margin-bottom: 0.35rem;
    }

    .res-modal-form-title {
        font-family: var(--font-heading);
        font-size: 1.65rem;
        color: #111827;
        margin: 0 0 0.4rem;
        line-height: 1.2;
    }

    .res-modal-form-desc {
        font-size: 0.84rem;
        color: #64748B;
        margin: 0;
        line-height: 1.5;
    }

    .res-modal-form {
        display: flex;
        flex-direction: column;
        gap: 0.9rem;
    }

    .res-form-group {
        display: flex;
        flex-direction: column;
        gap: 0.3rem;
    }

    .res-form-label {
        font-size: 0.75rem;
        font-weight: 600;
        color: #374151;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }

    .res-modal-input,
    .res-modal-select {
        width: 100%;
        background: #FDFBF7;
        border: 1px solid #DCD5C5;
        border-radius: 10px;
        padding: 0.75rem 1rem;
        font-size: 0.88rem;
        font-family: var(--font-body);
        color: #1A202C;
        outline: none;
        transition: all 0.2s ease;
    }

    .res-modal-input:focus,
    .res-modal-select:focus {
        border-color: #DCB658;
        background: #FFFFFF;
        box-shadow: 0 0 0 3px rgba(220, 182, 88, 0.15);
    }

    .res-modal-submit-btn {
        background: #111827;
        color: #FFFFFF;
        border: 1px solid #111827;
        padding: 0.85rem 1.5rem;
        border-radius: 30px;
        font-weight: 600;
        letter-spacing: 0.05em;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: var(--font-heading);
        font-size: 0.88rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        margin-top: 0.25rem;
    }

    .res-modal-submit-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(220, 182, 88, 0.3);
    }

    .res-modal-trust-note {
        font-size: 0.72rem;
        color: #94A3B8;
        text-align: center;
        margin-top: 0.25rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.4rem;
    }

    /* Responsive Media Queries for Residences */
    @media (max-width: 1200px) {
        .residences-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }
    }

    @media (max-width: 1024px) {
        .res-privileges-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        .res-modal-split-grid {
            grid-template-columns: 1fr;
            min-height: auto;
        }
        .res-modal-left-col {
            min-height: 260px;
            padding: 1.75rem 1.5rem;
        }
        .res-modal-right-col {
            padding: 2rem 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .residences-grid {
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }
        .residences-hero-section {
            min-height: 50vh;
            padding: 7.5rem 1.25rem 4rem;
        }
        .residences-main-wrapper {
            padding: 3.5rem 1.25rem 4.5rem;
        }
        .residences-filter-tabs {
            gap: 0.5rem;
            margin-bottom: 2.5rem;
        }
        .res-tab-btn {
            padding: 0.6rem 1rem;
            font-size: 0.8rem;
        }
        .residence-card-media {
            height: 240px;
        }
        .residence-card-body {
            padding: 1.35rem 1.2rem 1.5rem;
        }
        .res-card-specs-grid {
            /*grid-template-columns: repeat(3, 1fr);*/
            grid-template-columns: repeat(2, 1fr);
            gap: 0.35rem;
            padding: 0.75rem 0.4rem;
        }
        .res-card-actions {
            flex-direction: column;
            width: 100%;
        }
        .res-btn-primary,
        .res-btn-secondary {
            width: 100%;
            text-align: center;
        }
        .res-privileges-grid {
            grid-template-columns: 1fr;
            gap: 1.25rem;
        }
    }
    
    .residences-hero-section {
    position: relative;
    min-height: 100vh !important;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    background: #0B0E12;
    padding: 9.5rem 1.5rem 5rem;
}
    </style>

<body class="residences-page-body">

    <!-- GLASS HEADER NAVIGATION -->
    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- =========================================================
         1. HERO SECTION (WITH RESIDENCES HERO BACKGROUND & LUXURY BADGES)
    ========================================================= -->
    <section class="residences-hero-section">
        <div class="residences-hero-bg-wrapper">
            <!--<img src="<?php echo e(asset('Website/assets/images/residences2.jpeg')); ?>" alt="The Ulhas Vilas Luxury Residences" class="residences-hero-bg-img">-->
            <video class="about-promo-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/tracking_video.mp4')); ?>" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
        </div>
        <div class="residences-hero-overlay"></div>
        
        <div class="residences-hero-content">
            <span class="residences-hero-eyebrow">CURATED VILLA PORTFOLIO</span>
            <h1 class="residences-hero-title">The Residences <span>Collection</span></h1>
            <p class="residences-hero-desc">
                Distinct architectural typologies engineered for luxury, privacy, and seamless alpine living. Explore our bespoke villas.
            </p>

            <div class="residences-hero-badges">
                <div class="res-badge-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    100% Freehold Ownership
                </div>
                <div class="res-badge-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                    Prime Solan Heights
                </div>
                <div class="res-badge-item">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="3" y1="9" x2="21" y2="9"></line>
                        <line x1="9" y1="21" x2="9" y2="9"></line>
                    </svg>
                    Panoramic Valley Sundecks
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         2. CATEGORY FILTER TABS & RESIDENCES SHOWCASE
    ========================================================= -->
    <section class="residences-main-wrapper" id="residenceDirectory">
        <div class="residences-main-container">
            
            <!-- SECTION HEADER -->
            <div class="residences-header-center">
                <span class="contact-eyebrow">CURATED VILLA PORTFOLIO</span>
                <h2 class="contact-heading">The Residences <span>Collection</span></h2>
                <p class="gallery-intro-desc">
                    Distinct architectural typologies engineered for luxury, privacy, and seamless alpine living.
                </p>
            </div>

            

            <!-- RESIDENCES CARDS GRID (3 CARDS PER ROW ON DESKTOP - DYNAMIC) -->
            <div class="residences-grid" id="residencesGrid">
                <?php if(!empty($residences) && count($residences) > 0): ?>
                    <?php $__currentLoopData = $residences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $rSlug = !empty($res->slug) ? $res->slug : $res->id;
                            $detailUrl = url('/residence/' . $rSlug);
                            $rCategoryClass = 'cat-' . $res->category_id;
                            
                            // Image parsing (multi-image support)
                            $slideImages = [];
                            if (!empty($res->image)) {
                                if (str_starts_with(trim($res->image), '[')) {
                                    $rawImgs = json_decode($res->image, true) ?: [];
                                } else {
                                    $rawImgs = explode(',', $res->image);
                                }
                                foreach ($rawImgs as $rImg) {
                                    $rImg = trim($rImg);
                                    if (!empty($rImg)) {
                                        $slideImages[] = \Illuminate\Support\Str::startsWith($rImg, ['http://', 'https://']) ? $rImg : asset($rImg);
                                    }
                                }
                            }
                            if (empty($slideImages)) {
                                $slideImages[] = asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg');
                            }
                            
                            // Price
                            $pricePrefix = !empty($res->price_prefix) ? $res->price_prefix : 'From';
                            $priceText = '';
                            if (!empty($res->price)) {
                                $priceText = $pricePrefix . ' ₹' . $res->price;
                                if (!str_contains(strtolower($res->price), 'lac') && !str_contains(strtolower($res->price), 'cr')) {
                                    $priceText .= ' Lacs';
                                }
                            } else {
                                $priceText = 'Price on Request';
                            }
                        ?>

                        <div class="residence-card" data-category="<?php echo e($rCategoryClass); ?>">
                            <div class="residence-card-media" onclick="window.location.href='<?php echo e($detailUrl); ?>'" style="cursor: pointer;">
                                <div class="residence-image-slider">
                                    <?php $__currentLoopData = $slideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($sImg); ?>" alt="<?php echo e($res->name); ?>" class="residence-slide-img <?php echo e($imgIdx === 0 ? 'active' : ''); ?>" loading="lazy">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                
                                <div class="res-media-top-tags">
                                    <span class="res-price-tag"><?php echo e($priceText); ?></span>
                                </div>

                                <?php if(count($slideImages) > 1): ?>
                                    <div class="residence-slider-dots">
                                        <?php $__currentLoopData = $slideImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgIdx => $sImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="res-dot <?php echo e($imgIdx === 0 ? 'active' : ''); ?>"></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="residence-card-body">
                                <div class="res-card-header">
                                    <h3 class="res-card-title"><a href="<?php echo e($detailUrl); ?>" style="color: inherit; text-decoration: none;"><?php echo e($res->name); ?></a></h3>
                                </div>
                                
                                <p class="res-card-desc">
                                    <?php echo e($res->short_description ?? 'Bespoke mountain villa crafted with natural slate, cedar wood, and panoramic glass vistas.'); ?>

                                </p>

                                <!-- Specs Grid (3 items) -->
                                <div class="res-card-specs-grid">
                                    <div class="res-spec-item">
                                        <span class="res-spec-val"><?php echo e($res->carpet_area ?? '1000.2 SQ FT'); ?></span>
                                        <span class="res-spec-lbl">CARPET AREA</span>
                                    </div>
                                    <div class="res-spec-item">
                                        <span class="res-spec-val"><?php echo e($res->rooms ?? ($res->suites ?? '2 Rooms')); ?></span>
                                        <span class="res-spec-lbl">ROOMS</span>
                                    </div>
                                    <div class="res-spec-item">
                                        <span class="res-spec-val"><?php echo e($res->d_room ?? '1 D Room'); ?></span>
                                        <span class="res-spec-lbl">DINING</span>
                                    </div>
                                </div>

                                <!-- Action Buttons -->
                                <div class="res-card-actions">
                                    <a href="<?php echo e($detailUrl); ?>" class="res-btn-primary">
                                        VIEW DETAILS
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                                    </a>
                                    <button type="button" class="res-btn-secondary open-residence-quote-btn" data-residence-id="<?php echo e($res->id); ?>" data-residence-name="<?php echo e($res->name); ?>" data-category-name="<?php echo e($res->category_name ?? ''); ?>">
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                                        SEND QUOTE
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem; color: #718096;">
                        <h3>No residences available at the moment.</h3>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </section>


    <!-- =========================================================
         4. ESTATE OWNERSHIP PRIVILEGES (4 PILLARS)
    ========================================================= -->
    <section class="res-privileges-section">
        <!-- Background Ambient Video Player -->
        <div class="res-privileges-video-wrapper">
            <video class="res-privileges-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="<?php echo e(asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM (1).jpeg')); ?>">
                <source src="<?php echo e(asset('Website/assets/images/Real Estate video for villa promotion. Interior Videographer in Dubai, UAE - OG Videography (1080p, h264).mp4')); ?>" type="video/mp4">
                <source src="<?php echo e(asset('Website/assets/images/2333673_Aerial_Mountainside_1920x1080.mp4')); ?>" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="res-privileges-dark-overlay"></div>
        </div>

        <div class="res-privileges-container">
            
            <div class="res-privileges-header text-center">
                <span class="contact-eyebrow" style="color: #DCB658;">OWNERSHIP PRIVILEGES</span>
                <h2 class="res-privileges-title">The Benefits of <span>Estate Living</span></h2>
                <p class="res-privileges-desc">
                    Every residence owner at The Ulhas Vilas enjoys an unmatched suite of hospitality services, rental yield management, and wellness privileges.
                </p>
            </div>

            <!-- 4 PRIVILEGE PILLAR CARDS -->
            <div class="res-privileges-grid">
                
                <div class="res-privilege-card">
                    <div class="res-privilege-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        </svg>
                    </div>
                    <h3 class="res-privilege-title">Freehold Alpine Title</h3>
                    <p class="res-privilege-desc">
                        100% legally verified, clear individual titles with dedicated private land demarcation in prime Solan.
                    </p>
                </div>

                <div class="res-privilege-card">
                    <div class="res-privilege-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                            <polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                    </div>
                    <h3 class="res-privilege-title">Rental &amp; Asset Management</h3>
                    <p class="res-privilege-desc">
                        Turnkey luxury rental program managed by our hospitality team delivering hands-free seasonal yields.
                    </p>
                </div>

                <div class="res-privilege-card">
                    <div class="res-privilege-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                        </svg>
                    </div>
                    <h3 class="res-privilege-title">24/7 Dedicated Concierge</h3>
                    <p class="res-privilege-desc">
                        On-site housekeeping, private chef on request, airport transfers, and round-the-clock estate security.
                    </p>
                </div>

                <div class="res-privilege-card">
                    <div class="res-privilege-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M18 8h1a4 4 0 0 1 0 8h-1"/>
                            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/>
                            <line x1="6" y1="1" x2="6" y2="4"/>
                            <line x1="10" y1="1" x2="10" y2="4"/>
                            <line x1="14" y1="1" x2="14" y2="4"/>
                        </svg>
                    </div>
                    <h3 class="res-privilege-title">Club &amp; Wellness Pass</h3>
                    <p class="res-privilege-desc">
                        Complimentary lifetime access to our heated swimming pool, Himalayan stone spa, yoga deck, and restaurant.
                    </p>
                </div>

            </div>

        </div>
    </section>

    <!-- =========================================================
         4B. THE RIGHT CHOICE OF INVESTMENT (LIGHT LUXURY BENTO)
    ========================================================= -->
    <section class="res-investment-section" id="investment-choice">
        <div class="res-investment-container">
            <div class="res-investment-header">
                <span class="res-investment-eyebrow">CAPITAL ADVANTAGE &amp; LEISURE ASSET</span>
                <h2 class="res-investment-title">The Right Choice Of Investment</h2>
                <span class="res-investment-line"></span>
                <p class="res-investment-desc">
                    Exclusive benefits of owning a holiday apartment at Ulhas Vilas
                </p>
            </div>

            <div class="res-investment-grid">
                <!-- Card 1: Luxury Apartment Ownership -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="8" r="6"/>
                                    <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">Freehold Title</span>
                        </div>
                        <h3 class="res-inv-card-title">Luxury Apartment Ownership</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        100% individual freehold ownership of bespoke, fully furnished holiday residences set in pristine Himachal mountainscapes.
                    </p>
                </div>

                <!-- Card 2: 7 - 12% ROI -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="12" y1="1" x2="12" y2="23"/>
                                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">High Yield</span>
                        </div>
                        <h3 class="res-inv-card-title">7 – 12% ROI</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        Hands-free luxury rental program with high seasonal occupancy, robust capital appreciation, and assured yield management.
                    </p>
                </div>

                <!-- Card 3: 20 Free Holiday -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">Leisure Pass</span>
                        </div>
                        <h3 class="res-inv-card-title">20 Free Holiday</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        Enjoy 20 days of complimentary vacation nights every year for yourself, family, or personal guests with full VIP estate privileges.
                    </p>
                </div>

                <!-- Card 4: Free Professional Maintenance -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">Zero Hassle</span>
                        </div>
                        <h3 class="res-inv-card-title">Free Professional Maintenance</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        Full-spectrum upkeep, preventative property servicing, and meticulous housekeeping managed seamlessly without personal effort.
                    </p>
                </div>

                <!-- Card 5: Cygnett Ownership Program -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 21h18M3 7v14M21 7v14M6 7V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v3M9 21v-4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v4"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">Hospitality Brand</span>
                        </div>
                        <h3 class="res-inv-card-title">Enjoy Benefit Of Cygnett Ownership Program</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        Enjoy the elite privileges, reservation network, and premium hospitality standards powered by the prestigious Cygnett brand.
                    </p>
                </div>

                <!-- Card 6: Ayurvyaas Proximity -->
                <div class="res-inv-card">
                    <div>
                        <div class="res-inv-card-header">
                            <div class="res-inv-icon-box">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M12 2a10 10 0 0 0-7.54 16.57l7.54 4.43 7.54-4.43A10 10 0 0 0 12 2z"/>
                                    <circle cx="12" cy="11" r="3"/>
                                </svg>
                            </div>
                            <span class="res-inv-tag">Holistic Wellness</span>
                        </div>
                        <h3 class="res-inv-card-title">In Proximity to Upscale Luxury Lifestyle &amp; Wellness Brand Ayurvyaas</h3>
                    </div>
                    <p class="res-inv-card-desc">
                        In direct proximity to the upscale luxury lifestyle, Ayurvedic wellness sanctuary, and rejuvenation experiences of brand Ayurvyaas.
                    </p>
                </div>
            </div>
        </div>
    </section>



    <!-- FOOTER & JS INCLUDES -->
    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- =========================================================
         7. PAGE INTERACTIVE JAVASCRIPT
    ========================================================= -->
    <script>
        // 1. Residence Cards Multi-Image Auto-Slider (Same as Home page)
        (function() {
            var cards = document.querySelectorAll('.residence-card');
            cards.forEach(function(card) {
                var slides = card.querySelectorAll('.residence-slide-img');
                var dots = card.querySelectorAll('.residence-slider-dots .res-dot');
                if (slides.length <= 1) return;

                var currentSlide = 0;

                function nextSlide() {
                    slides[currentSlide].classList.remove('active');
                    if (dots[currentSlide]) dots[currentSlide].classList.remove('active');

                    currentSlide = (currentSlide + 1) % slides.length;

                    slides[currentSlide].classList.add('active');
                    if (dots[currentSlide]) dots[currentSlide].classList.add('active');
                }

                var sliderTimer = setInterval(nextSlide, 3500 + Math.random() * 800);

                card.addEventListener('mouseenter', function() {
                    clearInterval(sliderTimer);
                });
                card.addEventListener('mouseleave', function() {
                    sliderTimer = setInterval(nextSlide, 3500 + Math.random() * 800);
                });

                dots.forEach(function(dot, dotIdx) {
                    dot.addEventListener('click', function(e) {
                        e.stopPropagation();
                        slides[currentSlide].classList.remove('active');
                        if (dots[currentSlide]) dots[currentSlide].classList.remove('active');
                        currentSlide = dotIdx;
                        slides[currentSlide].classList.add('active');
                        dot.classList.add('active');
                    });
                });
            });
        })();

        // 2. Category Filtering Logic
        function filterResidenceCategory(category, btnElement) {
            var tabBtns = document.querySelectorAll('.res-tab-btn');
            tabBtns.forEach(function(b) { b.classList.remove('active'); });
            if (btnElement) btnElement.classList.add('active');

            var cards = document.querySelectorAll('.residence-card');
            cards.forEach(function(card) {
                var cardCat = card.getAttribute('data-category');
                if (category === 'all' || cardCat === category) {
                    card.style.display = 'flex';
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(15px)';
                    setTimeout(function() {
                        card.style.transition = 'all 0.35s cubic-bezier(0.16, 1, 0.3, 1)';
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 30);
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // 3. Auto-filter by URL parameter (e.g. /residences?category=cat-2)
        document.addEventListener('DOMContentLoaded', function() {
            var urlParams = new URLSearchParams(window.location.search);
            var cat = urlParams.get('category') || urlParams.get('cat');
            if (cat) {
                if (!cat.startsWith('cat-') && cat !== 'all') {
                    cat = 'cat-' + cat;
                }
                var matchingBtn = document.querySelector('.res-tab-btn[onclick*="\'' + cat + '\'"]');
                if (matchingBtn) {
                    filterResidenceCategory(cat, matchingBtn);
                    var directory = document.getElementById('residenceDirectory');
                    if (directory) {
                        directory.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            }
        });
    </script>

</body>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/residences.blade.php ENDPATH**/ ?>