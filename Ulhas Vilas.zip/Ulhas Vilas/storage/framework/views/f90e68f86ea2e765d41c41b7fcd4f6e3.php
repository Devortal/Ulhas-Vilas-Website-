<?php echo $__env->make('Website.includes.CssLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- GLASS HEADER NAVIGATION -->
    <?php echo $__env->make('Website.includes.Header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>
    /* =========================================================
       LUXURY LIGHTBOX STYLING WITH FULL NAVIGATION CONTROLS
    ========================================================= */
    .gallery-lightbox-modal {
        position: fixed;
        inset: 0;
        background: rgba(8, 10, 14, 0.94);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        user-select: none;
    }

    .gallery-lightbox-modal.active {
        opacity: 1;
        pointer-events: auto;
    }

    .lb-close-btn {
        position: absolute;
        top: 1.5rem;
        right: 2rem;
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.22);
        color: #ffffff;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        transition: all 0.25s ease;
    }

    .lb-close-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: rotate(90deg) scale(1.08);
        box-shadow: 0 4px 20px rgba(220, 182, 88, 0.4);
    }

    /* Navigation Arrows */
    .lb-nav-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: rgba(255, 255, 255, 0.12);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: #ffffff;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 100;
        transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    }

    .lb-prev-btn {
        left: 2rem;
    }

    .lb-next-btn {
        right: 2rem;
    }

    .lb-nav-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: translateY(-50%) scale(1.12);
        box-shadow: 0 10px 30px rgba(220, 182, 88, 0.5);
    }

    .lb-nav-btn:active {
        transform: translateY(-50%) scale(0.95);
    }

    /* Lightbox Image Container & Content */
    .lb-content-wrap {
        position: relative;
        max-width: 90vw;
        max-height: 92vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10;
    }

    .lb-image-container {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        max-width: 86vw;
        max-height: 76vh;
    }

    .lb-main-image {
        max-width: 86vw;
        max-height: 76vh;
        border-radius: 12px;
        box-shadow: 0 25px 70px rgba(0, 0, 0, 0.7);
        object-fit: contain;
        border: 1px solid rgba(255, 255, 255, 0.14);
        transition: opacity 0.22s ease, transform 0.25s ease;
    }

    .lb-caption-bar {
        width: 100%;
        max-width: 86vw;
        margin-top: 0.85rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.5rem;
        padding: 0.75rem 1.4rem;
        background: rgba(18, 22, 28, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 12px;
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
    }

    .lb-caption-info {
        display: flex;
        flex-direction: column;
        gap: 0.2rem;
        text-align: left;
    }

    .lb-category-tag {
        font-size: 0.68rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.14em;
        color: #DCB658;
    }

    .lb-title-text {
        font-family: var(--font-heading, 'Marcellus', serif);
        font-size: 1.2rem;
        color: #ffffff;
        margin: 0;
        line-height: 1.25;
    }

    .lb-desc-text {
        font-size: 0.85rem;
        color: rgba(255, 255, 255, 0.75);
        margin: 0;
        line-height: 1.4;
    }

    .lb-counter {
        font-size: 0.85rem;
        font-weight: 700;
        color: #DCB658;
        background: rgba(220, 182, 88, 0.12);
        border: 1px solid rgba(220, 182, 88, 0.3);
        padding: 0.4rem 0.95rem;
        border-radius: 9999px;
        white-space: nowrap;
        letter-spacing: 0.05em;
    }

    @media (max-width: 768px) {
        .lb-prev-btn {
            left: 0.6rem;
            width: 44px;
            height: 44px;
        }
        .lb-next-btn {
            right: 0.6rem;
            width: 44px;
            height: 44px;
        }
        .lb-close-btn {
            top: 0.85rem;
            right: 0.85rem;
            width: 40px;
            height: 40px;
        }
        .lb-caption-bar {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
            padding: 0.65rem 1rem;
        }
        .lb-counter {
            align-self: flex-end;
        }
    }

    /* Decreased Gap & Decreased Border Radius for Gallery Grid & Cards */
    .gallery-grid {
        display: grid !important;
        grid-template-columns: repeat(4, 1fr) !important;
        gap: 0.75rem !important;
    }

    @media (max-width: 1100px) {
        .gallery-grid {
            grid-template-columns: repeat(3, 1fr) !important;
            gap: 0.65rem !important;
        }
    }

    @media (max-width: 768px) {
        .gallery-grid {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 0.5rem !important;
        }
    }

    @media (max-width: 480px) {
        .gallery-grid {
            grid-template-columns: 1fr !important;
            gap: 0.5rem !important;
        }
    }

    .gallery-card-item {
        border-radius: 4px !important;
        overflow: hidden !important;
    }

    .gallery-img-wrapper {
        border-radius: 4px !important;
        overflow: hidden !important;
    }

    .gallery-img-wrapper img {
        border-radius: 4px !important;
    }
    
    .contact-hero-light {
    position: relative;
    width: 100%;
    height: 380px !important;
    background: #111518;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
    margin-top: 0;
}

.gallery-main-wrapper {
    background: #ffffff;
    padding: 2rem 0 5rem 0;
}

.contact-heading {
    font-family: 'Marcellus', serif;
    font-size: clamp(2.1rem, 3.5vw, 2.6rem);
    font-weight: 400;
    color: #111111;
    line-height: 1.2;
    margin-bottom: 1.25rem;
    letter-spacing: -0.01em;
}


    </style>

    <!-- =========================================================
         HERO BANNER (WITH BACKGROUND IMAGE SLIDER)
    ========================================================= -->
    <section class="contact-hero-light">
        <div class="contact-hero-slider-track" id="galleryHeroTrack">
            <div class="contact-hero-slide active">
                <img src="<?php echo e(asset('Website/assets/images/mountain2.jpeg')); ?>" alt="The Ulhas Vilas Estate Gallery">
            </div>
        </div>
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">Estate <span>Gallery</span></h1>
            <p class="contact-hero-light-sub">Immerse yourself in the architectural grandeur, serene vistas, and refined living spaces of The Ulhas Vilas.</p>
        </div>
    </section>

    <!-- =========================================================
         GALLERY FILTER & GRID SECTION
    ========================================================= -->
    <section class="gallery-main-wrapper">
        <div class="gallery-main-container">
            
            <!-- SECTION INTRO HEADER -->
            <div class="gallery-header-center">
                <span class="contact-eyebrow">VISUAL EXPERIENCE</span>
                <h2 class="contact-heading">Curated <span>Moments</span> Of Serenity & Luxury</h2>
                <p class="gallery-intro-desc">
                    Discover every angle of our luxury hill estate. From sun-drenched private balconies and master suites to lush landscaped gardens and world-class leisure facilities.
                </p>
            </div>

            <!-- CATEGORY FILTER TABS -->
            <!--<div class="gallery-filter-tabs">-->
            <!--    <button type="button" class="gallery-tab-btn active" onclick="filterGalleryCategory('all', this)">-->
            <!--        All Photographs-->
            <!--    </button>-->
            <!--    <?php if(!empty($categories)): ?>-->
            <!--        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
            <!--            <button type="button" class="gallery-tab-btn" onclick="filterGalleryCategory('cat-<?php echo e($cat->id); ?>', this)">-->
            <!--                <?php echo e($cat->category_name); ?>-->
            <!--            </button>-->
            <!--        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
            <!--    <?php endif; ?>-->
            <!--</div>-->

            <!-- GALLERY GRID CONTAINER (4 COLUMNS RESPONSIVE) -->
            <div class="gallery-grid" id="galleryGrid">
                <?php if(!empty($galleries) && count($galleries) > 0): ?>
                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $imgUrl = !empty($item->image) ? (str_starts_with($item->image, 'http') || str_starts_with($item->image, '/') ? $item->image : asset($item->image)) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg');
                            $catTag = !empty($item->category_name) ? strtoupper($item->category_name) : 'ESTATE';
                            $photoTitle = !empty($item->title) && $item->title !== '-' ? $item->title : 'The Ulhas Vilas';
                            $catClass = !empty($item->category_id) ? 'cat-' . $item->category_id : 'all';
                        ?>
                        <div class="gallery-card-item" data-category="<?php echo e($catClass); ?>" data-category-name="<?php echo e($catTag); ?>" onclick="openGalleryLightbox(this)">
                            <div class="gallery-img-wrapper">
                                <img src="<?php echo e($imgUrl); ?>" alt="<?php echo e($photoTitle); ?>" loading="lazy">
                                <div class="gallery-card-overlay">
                                    <h3 class="gallery-card-title"><?php echo e($photoTitle); ?></h3>
                                    <?php if(!empty($item->description)): ?>
                                        <p class="gallery-card-desc"><?php echo e($item->description); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem; color: #8a7a58;">
                        <p>No photographs uploaded yet. Stay tuned for breathtaking captures of The Ulhas Vilas.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div id="noGalleryMsg" style="display: none; text-align: center; padding: 3rem 1rem; color: #8a7a58;">
                <p>No photographs found for this specific category.</p>
            </div>

        </div>
    </section>

    <!-- =========================================================
         LIGHT LUXURY CTA BANNER
    ========================================================= -->
    <section class="gallery-cta-section">
        <div class="gallery-cta-card">
            <span class="contact-eyebrow">EXCLUSIVE PRIVATE TOURS</span>
            <h2 class="gallery-cta-title">Experience The Serenity <span>In Person</span></h2>
            <p class="gallery-cta-desc">
                Pictures convey beauty, but true luxury is felt. Book a private guided estate tour with our relationship management team today.
            </p>
            <a href="<?php echo e(url('/contact')); ?>" class="send-msg-btn gallery-cta-btn">BOOK A PRIVATE VISIT</a>
        </div>
    </section>

    <!-- =========================================================
         LIGHTBOX MODAL FOR FULLSCREEN PREVIEW WITH NAVIGATION
    ========================================================= -->
    <div id="lbModal" onclick="closeLb(event)" class="gallery-lightbox-modal">
        <!-- Close Button -->
        <button type="button" class="lb-close-btn" onclick="closeLb(event)" aria-label="Close Lightbox">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <!-- Previous Arrow Navigation Button -->
        <button type="button" class="lb-nav-btn lb-prev-btn" onclick="event.stopPropagation(); navigateLightbox(-1);" aria-label="Previous Image">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </button>

        <!-- Next Arrow Navigation Button -->
        <button type="button" class="lb-nav-btn lb-next-btn" onclick="event.stopPropagation(); navigateLightbox(1);" aria-label="Next Image">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </button>

        <!-- Center Image Container -->
        <div class="lb-content-wrap" onclick="event.stopPropagation()">
            <div class="lb-image-container">
                <img id="lbImg" src="" alt="Full view" class="lb-main-image">
            </div>
            <!-- Bottom Details Ribbon -->
            <div class="lb-caption-bar">
                <div class="lb-caption-info">
                    <span id="lbCategory" class="lb-category-tag">ESTATE</span>
                    <h4 id="lbTitle" class="lb-title-text">The Ulhas Vilas</h4>
                    <p id="lbDesc" class="lb-desc-text"></p>
                </div>
                <div class="lb-counter" id="lbCounter">1 / 1</div>
            </div>
        </div>
    </div>

    <!-- FOOTER & SCRIPTS -->
    <?php echo $__env->make('Website.includes.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Website.includes.JsLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
    (function() {
        var galleryItemsList = [];
        var currentLbIndex = 0;

        // Collect all currently visible gallery images
        function getVisibleItems() {
            var cards = document.querySelectorAll('.gallery-card-item');
            var items = [];
            cards.forEach(function(card) {
                if (card.style.display !== 'none') {
                    var img = card.querySelector('img');
                    var titleEl = card.querySelector('.gallery-card-title');
                    var descEl = card.querySelector('.gallery-card-desc');
                    var catTag = card.getAttribute('data-category-name') || 'ESTATE';
                    if (img) {
                        items.push({
                            src: img.src,
                            title: titleEl ? titleEl.textContent.trim() : 'The Ulhas Vilas',
                            desc: descEl ? descEl.textContent.trim() : '',
                            category: catTag,
                            card: card
                        });
                    }
                }
            });
            return items;
        }

        function renderLightbox() {
            if (!galleryItemsList.length) return;
            var item = galleryItemsList[currentLbIndex];
            var img = document.getElementById('lbImg');
            var titleEl = document.getElementById('lbTitle');
            var descEl = document.getElementById('lbDesc');
            var catEl = document.getElementById('lbCategory');
            var counterEl = document.getElementById('lbCounter');

            if (img) {
                img.style.opacity = '0.3';
                img.style.transform = 'scale(0.97)';
                
                var newImg = new Image();
                newImg.onload = function() {
                    img.src = item.src;
                    img.style.opacity = '1';
                    img.style.transform = 'scale(1)';
                };
                newImg.src = item.src;
            }

            if (titleEl) titleEl.textContent = item.title;
            if (descEl) {
                descEl.textContent = item.desc;
                descEl.style.display = item.desc ? 'block' : 'none';
            }
            if (catEl) catEl.textContent = item.category || 'ESTATE';
            if (counterEl) {
                counterEl.textContent = (currentLbIndex + 1) + ' / ' + galleryItemsList.length;
                counterEl.style.display = galleryItemsList.length > 1 ? 'block' : 'none';
            }

            var prevBtn = document.querySelector('.lb-prev-btn');
            var nextBtn = document.querySelector('.lb-next-btn');
            if (prevBtn) prevBtn.style.display = galleryItemsList.length > 1 ? 'flex' : 'none';
            if (nextBtn) nextBtn.style.display = galleryItemsList.length > 1 ? 'flex' : 'none';
        }

        window.openGalleryLightbox = function(cardElement) {
            galleryItemsList = getVisibleItems();
            if (!galleryItemsList.length) return;

            var foundIndex = galleryItemsList.findIndex(function(item) {
                return item.card === cardElement;
            });

            currentLbIndex = foundIndex !== -1 ? foundIndex : 0;
            renderLightbox();

            var modal = document.getElementById('lbModal');
            if (modal) {
                modal.classList.add('active');
                modal.style.opacity = '1';
                modal.style.pointerEvents = 'auto';
                document.body.style.overflow = 'hidden';
            }
        };

        window.openLightbox = function(src) {
            galleryItemsList = getVisibleItems();
            var foundIndex = galleryItemsList.findIndex(function(item) {
                return item.src === src;
            });
            if (foundIndex !== -1) {
                currentLbIndex = foundIndex;
            } else {
                galleryItemsList = [{ src: src, title: 'The Ulhas Vilas', desc: '', category: 'ESTATE' }];
                currentLbIndex = 0;
            }
            renderLightbox();

            var modal = document.getElementById('lbModal');
            if (modal) {
                modal.classList.add('active');
                modal.style.opacity = '1';
                modal.style.pointerEvents = 'auto';
                document.body.style.overflow = 'hidden';
            }
        };

        window.navigateLightbox = function(direction) {
            if (!galleryItemsList.length) return;
            currentLbIndex = (currentLbIndex + direction + galleryItemsList.length) % galleryItemsList.length;
            renderLightbox();
        };

        window.closeLb = function(e) {
            var modal = document.getElementById('lbModal');
            if (!modal) return;
            modal.classList.remove('active');
            modal.style.opacity = '0';
            modal.style.pointerEvents = 'none';
            document.body.style.overflow = '';
        };

        // Keyboard Navigation (Esc, Left Arrow, Right Arrow)
        document.addEventListener('keydown', function(e) {
            var modal = document.getElementById('lbModal');
            if (!modal || (!modal.classList.contains('active') && modal.style.opacity !== '1')) return;

            if (e.key === 'Escape') {
                closeLb();
            } else if (e.key === 'ArrowLeft') {
                navigateLightbox(-1);
            } else if (e.key === 'ArrowRight') {
                navigateLightbox(1);
            }
        });

        // Touch Swipe Navigation for mobile
        var touchStartX = 0;
        var touchEndX = 0;
        var modal = document.getElementById('lbModal');
        if (modal) {
            modal.addEventListener('touchstart', function(e) {
                touchStartX = e.changedTouches[0].screenX;
            }, { passive: true });

            modal.addEventListener('touchend', function(e) {
                touchEndX = e.changedTouches[0].screenX;
                var diff = touchEndX - touchStartX;
                if (Math.abs(diff) > 45) {
                    if (diff > 0) {
                        navigateLightbox(-1); // swipe right -> prev
                    } else {
                        navigateLightbox(1);  // swipe left -> next
                    }
                }
            }, { passive: true });
        }

        // Category filter update to hide/show and update no-items message
        window.filterGalleryCategory = function(category, btnElement) {
            var items = document.querySelectorAll('.gallery-card-item');
            var btns = document.querySelectorAll('.gallery-tab-btn');
            var noMsg = document.getElementById('noGalleryMsg');
            var visibleCount = 0;
            
            btns.forEach(function(b) { b.classList.remove('active'); });
            if (btnElement) btnElement.classList.add('active');

            items.forEach(function(item) {
                var itemCategory = item.getAttribute('data-category');
                if (category === 'all' || itemCategory === category) {
                    item.style.display = 'block';
                    item.style.opacity = '1';
                    item.style.transform = 'scale(1)';
                    visibleCount++;
                } else {
                    item.style.display = 'none';
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.98)';
                }
            });

            if (noMsg) {
                noMsg.style.display = visibleCount === 0 ? 'block' : 'none';
            }
        };
    })();
    </script>
<?php /**PATH /home/p231205a/public_html/ulhas-vilas.partnersindia.com/resources/views/Website/gallery.blade.php ENDPATH**/ ?>