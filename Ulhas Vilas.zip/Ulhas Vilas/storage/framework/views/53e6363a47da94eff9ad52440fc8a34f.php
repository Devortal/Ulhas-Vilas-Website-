<?php if(Session::get('admin_login')): ?>

<?php $__env->startSection('main-content'); ?>

<?php
    $categories = DB::table('categories')->where('status', 1)->get();
    $amenities = DB::table('amenities')->where('status', 1)->get();
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                <!-- Filter & Top Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="d-flex flex-wrap flex-lg-nowrap align-items-end gap-2 gap-xl-3">
                        <!-- Search Residences -->
                        <div class="flex-grow-1" style="min-width: 220px;">
                            <label class="filter-section-title">SEARCH RESIDENCES</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_residence" placeholder="Search title, size, suites, price..." />
                                </div>
                                <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill flex-shrink-0" title="Export Excel / CSV">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </a>
                            </div>
                        </div>

                        <!-- Category Filter -->
                        <div class="flex-shrink-0" style="width: 170px;">
                            <label class="filter-section-title">FILTER BY CATEGORY</label>
                            <select id="filter_category" class="form-select form-control-3d">
                                <option value="">All Categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Created Date Range -->
                        <div class="flex-shrink-0" style="width: 200px;">
                            <label class="filter-section-title">CREATED DATE RANGE</label>
                            <div class="input-group">
                                <span class="input-group-text date-icon-box" id="open_date_picker"><i class="bi bi-calendar3"></i></span>
                                <input type="text" id="filter_date_range" class="form-control filter-date-pill" placeholder="Select Date Range..." readonly />
                            </div>
                        </div>

                        <!-- Reset Filter Button -->
                        <div class="flex-shrink-0">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>

                        <!-- Add Residences Button -->
                        <div class="flex-shrink-0">
                            <button type="button" class="btn-add-primary-pill text-nowrap" data-bs-toggle="modal" data-bs-target="#AddResidenceModal">
                                <i class="bi bi-plus-lg me-1"></i> Add Residences
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Residences Data Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="residenceTable" class="table table-hover table-athlo align-middle">
                        <thead class="th-nowrap">
                            <tr>
                                <th>#</th>
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Images</th>
                                <th style="min-width: 180px;">Residence Name</th>
                                <th>Category</th>
                                <th>Amenities</th>
                                <th>Layout Plans</th>
                                <th>Property Size</th>
                                <th>Rooms</th>
                                <th>Drawing / Dining</th>
                                <th>Balconies</th>
                                <th>Toilets</th>
                                <th>Pantry</th>
                                <th>Highlight Feature</th>
                                <th>Starting Price / Value</th>
                                <th>Short Tagline</th>
                                <th>Description</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- View Gallery Modal -->
<div class="modal fade" id="ViewGalleryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="galleryModalTitle"><i class="bi bi-images me-2"></i>Residence Photos</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <div class="row g-3" id="galleryModalGrid"></div>
            </div>
        </div>
    </div>
</div>

<!-- View Amenities Modal -->
<div class="modal fade" id="ViewAmenitiesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="amenitiesModalTitle"><i class="bi bi-flower1 me-2 text-success"></i>Residence Amenities & Wellness</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <div class="row g-3" id="amenitiesModalGrid"></div>
            </div>
        </div>
    </div>
</div>

<!-- View Layout Plans Modal -->
<div class="modal fade" id="ViewLayoutPlansModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="layoutPlansModalTitle"><i class="bi bi-diagram-3-fill me-2 text-primary"></i>Architectural Layout Plans</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <div class="row g-3" id="layoutPlansModalGrid"></div>
            </div>
        </div>
    </div>
</div>

<!-- View Text / Description Modal -->
<div class="modal fade" id="ViewTextModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title" id="textModalTitle"><i class="bi bi-file-earmark-text me-2"></i>Residence Content</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <h6 class="fw-bold text-dark mb-3" id="textModalSubtitle"></h6>
                <div class="p-3 bg-light rounded-3 border text-secondary" id="textModalBody" style="max-height: 460px; overflow-y: auto; line-height: 1.7; font-size: 14px;"></div>
            </div>
        </div>
    </div>
</div>

<!-- Add Residence Modal -->
<div class="modal fade" id="AddResidenceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-building-add me-2"></i>Add Ulhas Vilas Residence</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="add_residence_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Residence Title / Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control form-control-3d" placeholder="e.g. Luxury Symphony 1BHK" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Category / Typology <span class="text-danger">*</span></label>
                            <select name="category_id" id="category_select" class="form-select form-control-3d" required>
                                <option value="">-- Select Category --</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <label class="form-label form-label-3d mb-0">Amenities & Wellness Experiences (Multiple Selection)</label>
                                <div class="d-flex align-items-center gap-1">
                                    <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2 rounded-pill select-all-amenities-add" style="font-size: 11px; font-weight: 600;"><i class="bi bi-check-all me-1"></i>Select All</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2 rounded-pill deselect-all-amenities-add" style="font-size: 11px; font-weight: 600;"><i class="bi bi-x-circle me-1"></i>Clear All</button>
                                </div>
                            </div>
                            <select name="amenity_id[]" id="amenity_select" class="form-select form-control-3d select2-multi" multiple style="width:100%;">
                                <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($amenity->id); ?>"><?php echo e($amenity->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Short Summary / Tagline</label>
                            <textarea name="short_description" class="form-control form-control-3d" rows="2" placeholder="e.g. Discover Serenity and Luxury in the Heart of Nature"></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Full Architectural Description</label>
                            <textarea name="description" id="add_description" class="form-control form-control-3d summernote" rows="4" placeholder="Detailed description of the residence, architecture, and luxury features..."></textarea>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Property Size (Carpet Area)</label>
                            <input type="text" name="carpet_area" class="form-control form-control-3d" placeholder="e.g. 1000.2 SQ FT">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Rooms / Bedrooms</label>
                            <input type="text" name="rooms" class="form-control form-control-3d" placeholder="e.g. 2 Rooms">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Drawing / Dining Room</label>
                            <input type="text" name="d_room" class="form-control form-control-3d" placeholder="e.g. 1 D Room">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Balconies</label>
                            <input type="text" name="balconies" class="form-control form-control-3d" placeholder="e.g. 2 Balconies">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Toilets / Bathrooms</label>
                            <input type="text" name="toilets" class="form-control form-control-3d" placeholder="e.g. 2 Toilets">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Pantry / Kitchen</label>
                            <input type="text" name="pantry" class="form-control form-control-3d" placeholder="e.g. 1 Pantry">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Highlight Feature <span class="badge bg-warning-subtle text-dark border ms-1"><i class="bi bi-star-fill text-warning"></i> Key Feature</span></label>
                            <input type="text" name="highlight_feature" class="form-control form-control-3d" placeholder="e.g. Infinity Pool">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Starting Price / Value</label>
                            <input type="text" name="price" class="form-control form-control-3d" placeholder="e.g. 1.30 Cr">
                        </div>

                        <!-- Images (Multiple Selection) - Full Row Cloud Dropzone -->
                        <div class="col-12">
                            <label class="form-label form-label-3d">Images (Multiple Selection)</label>
                            <div class="upload-dropzone-box" id="add_image_dropzone">
                                <input type="file" name="image[]" id="add_residence_images" accept="image/*" multiple>
                                <div class="upload-cloud-icon-circle">
                                    <i class="bi bi-cloud-arrow-up-fill"></i>
                                </div>
                                <div class="upload-primary-text">
                                    <span class="highlight">Click to upload</span> or drag & drop
                                </div>
                                <div class="upload-secondary-text">
                                    JPG, PNG, WEBP, GIF, etc. (Max 15 MB per image)
                                </div>
                            </div>
                        </div>

                        <!-- Add Images Previews Container -->
                        <div class="col-12" id="add_image_preview_wrapper" style="display:none;">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <label class="form-label form-label-3d text-muted small mb-0"><i class="bi bi-images me-1 text-primary"></i>Selected Images (<span id="add_image_count" class="fw-bold text-dark">0</span> images selected):</label>
                            </div>
                            <div id="add_image_preview" class="gallery-preview-container"></div>
                        </div>

                        <!-- Architectural 3D Layout Plans Section -->
                        <div class="col-12 mt-3">
                            <div class="p-3 border rounded-3 bg-light shadow-sm">
                                <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2" style="font-size: 15px;">
                                            <i class="bi bi-diagram-3-fill text-primary"></i> Architectural Master Plans & 3D Layouts
                                        </h6>
                                        <small class="text-muted">Add floor plans & 3D blueprints with layout title and image</small>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1 add-layout-plan-row-btn" data-target="#add_layout_plans_list">
                                        <i class="bi bi-plus-lg me-1"></i> Add Layout Plan
                                    </button>
                                </div>
                                <div id="add_layout_plans_list" class="d-flex flex-column gap-3">
                                    <!-- Dynamic layout rows injected here -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Save Residence</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Residence Modal -->
<div class="modal fade" id="EditResidenceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Ulhas Vilas Residence</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="edit_residence_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="edit_id">
                    <input type="hidden" name="existing_images" id="edit_existing_images">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Residence Title / Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="edit_name" class="form-control form-control-3d" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Category / Typology <span class="text-danger">*</span></label>
                            <select name="category_id" id="edit_category_select" class="form-select form-control-3d" required>
                                <option value="">-- Select Category --</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <label class="form-label form-label-3d mb-0">Amenities & Wellness Experiences (Multiple Selection)</label>
                                <div class="d-flex align-items-center gap-1">
                                    <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2 rounded-pill select-all-amenities-edit" style="font-size: 11px; font-weight: 600;"><i class="bi bi-check-all me-1"></i>Select All</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-2 rounded-pill deselect-all-amenities-edit" style="font-size: 11px; font-weight: 600;"><i class="bi bi-x-circle me-1"></i>Clear All</button>
                                </div>
                            </div>
                            <select name="amenity_id[]" id="edit_amenity_select" class="form-select form-control-3d select2-multi" multiple style="width:100%;">
                                <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($amenity->id); ?>"><?php echo e($amenity->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Short Summary / Tagline</label>
                            <textarea name="short_description" id="edit_short_description" class="form-control form-control-3d" rows="2"></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Full Architectural Description</label>
                            <textarea name="description" id="edit_description" class="form-control form-control-3d summernote" rows="4"></textarea>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Property Size (Carpet Area)</label>
                            <input type="text" name="carpet_area" id="edit_carpet_area" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Rooms / Bedrooms</label>
                            <input type="text" name="rooms" id="edit_rooms" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Drawing / Dining Room</label>
                            <input type="text" name="d_room" id="edit_d_room" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Balconies</label>
                            <input type="text" name="balconies" id="edit_balconies" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Toilets / Bathrooms</label>
                            <input type="text" name="toilets" id="edit_toilets" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label form-label-3d">Pantry / Kitchen</label>
                            <input type="text" name="pantry" id="edit_pantry" class="form-control form-control-3d">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Highlight Feature <span class="badge bg-warning-subtle text-dark border ms-1"><i class="bi bi-star-fill text-warning"></i> Key Feature</span></label>
                            <input type="text" name="highlight_feature" id="edit_highlight_feature" class="form-control form-control-3d" placeholder="e.g. Infinity Pool">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Starting Price / Value</label>
                            <input type="text" name="price" id="edit_price" class="form-control form-control-3d">
                        </div>

                        <!-- Edit Existing Images -->
                        <div class="col-12" id="edit_existing_image_wrapper" style="display:none;">
                            <label class="form-label form-label-3d text-muted small"><i class="bi bi-images me-1 text-success"></i>Current Uploaded Images (<span id="edit_existing_count" class="fw-bold text-dark">0</span> images - click &times; to delete):</label>
                            <div id="edit_existing_image_preview" class="gallery-preview-container"></div>
                        </div>

                        <!-- Add More Images (Multiple Selection) - Full Row Cloud Dropzone -->
                        <div class="col-12">
                            <label class="form-label form-label-3d">Add More Images (Multiple Selection)</label>
                            <div class="upload-dropzone-box" id="edit_image_dropzone">
                                <input type="file" name="image[]" id="edit_residence_images" accept="image/*" multiple>
                                <div class="upload-cloud-icon-circle">
                                    <i class="bi bi-cloud-arrow-up-fill"></i>
                                </div>
                                <div class="upload-primary-text">
                                    <span class="highlight">Click to upload</span> or drag & drop
                                </div>
                                <div class="upload-secondary-text">
                                    JPG, PNG, WEBP, GIF, etc. (Max 15 MB per image)
                                </div>
                            </div>
                        </div>

                        <!-- Edit New Images Preview -->
                        <div class="col-12" id="edit_new_image_wrapper" style="display:none;">
                            <label class="form-label form-label-3d text-muted small"><i class="bi bi-plus-circle me-1 text-primary"></i>Newly Selected Images (<span id="edit_new_count" class="fw-bold text-dark">0</span> new images - click &times; to remove):</label>
                            <div id="edit_new_image_preview" class="gallery-preview-container"></div>
                        </div>

                        <!-- Architectural 3D Layout Plans Section -->
                        <div class="col-12 mt-3">
                            <div class="p-3 border rounded-3 bg-light shadow-sm">
                                <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2" style="font-size: 15px;">
                                            <i class="bi bi-diagram-3-fill text-primary"></i> Architectural Master Plans & 3D Layouts
                                        </h6>
                                        <small class="text-muted">Manage floor plans & 3D blueprints with layout title and image</small>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1 add-layout-plan-row-btn" data-target="#edit_layout_plans_list">
                                        <i class="bi bi-plus-lg me-1"></i> Add Layout Plan
                                    </button>
                                </div>
                                <div id="edit_layout_plans_list" class="d-flex flex-column gap-3">
                                    <!-- Dynamic layout rows injected here -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Update Residence</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:420px">
        <div class="modal-content modal-content-3d">
            <div class="modal-body p-4 text-center">
                <i class="bi bi-trash3 text-danger" style="font-size:40px;"></i>
                <h5 class="fw-bold mt-3 mb-2">Delete Residence?</h5>
                <p class="text-muted small">Are you sure you want to permanently delete this residence?</p>
                <div class="d-flex justify-content-center gap-2 mt-4">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger rounded-3 px-4 delete_confirm_btn">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#amenity_select').select2({
            dropdownParent: $('#AddResidenceModal')
        });

        $('#EditResidenceModal').on('shown.bs.modal', function() {
            $('#edit_amenity_select').select2({
                dropdownParent: $('#EditResidenceModal')
            });
        });

        // Select All / Clear All Amenities - Add Modal
        $('.select-all-amenities-add').on('click', function(e) {
            e.preventDefault();
            $('#amenity_select > option').prop('selected', true);
            $('#amenity_select').trigger('change');
        });
        $('.deselect-all-amenities-add').on('click', function(e) {
            e.preventDefault();
            $('#amenity_select').val(null).trigger('change');
        });

        // Select All / Clear All Amenities - Edit Modal
        $('.select-all-amenities-edit').on('click', function(e) {
            e.preventDefault();
            $('#edit_amenity_select > option').prop('selected', true);
            $('#edit_amenity_select').trigger('change');
        });
        $('.deselect-all-amenities-edit').on('click', function(e) {
            e.preventDefault();
            $('#edit_amenity_select').val(null).trigger('change');
        });

        var fpInstance = null;
        if (typeof flatpickr !== 'undefined') {
            fpInstance = flatpickr("#filter_date_range", {
                mode: "range",
                dateFormat: "Y-m-d",
                allowInput: false,
                onClose: function (selectedDates, dateStr, instance) {
                    currentResidencePage = 1;
                    loadResidences(currentResidencePage);
                }
            });
        }

        $('#open_date_picker').click(function () {
            if (fpInstance) {
                fpInstance.open();
            }
        });

        var currentResidencePage = 1;
        loadResidences(currentResidencePage);

        $('.search_residence').on('keyup', function() {
            currentResidencePage = 1;
            loadResidences(currentResidencePage);
        });

        $('#filter_category').on('change', function() {
            currentResidencePage = 1;
            loadResidences(currentResidencePage);
        });

        $('#reset_filter').on('click', function() {
            $('.search_residence').val('');
            $('#filter_category').val('');
            if (fpInstance) {
                fpInstance.clear();
            }
            currentResidencePage = 1;
            loadResidences(currentResidencePage);
        });

        function formatDateTime(dtStr) {
            if (!dtStr) return '-';
            try {
                var d = new Date(dtStr);
                if (isNaN(d.getTime())) return dtStr;
                return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' +
                       d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
            } catch (e) {
                return dtStr;
            }
        }

        function loadResidences(page) {
            var search = $('.search_residence').val();
            var category_id = $('#filter_category').val();
            var date_data = $('#filter_date_range').val();
            $.ajax({
                url: "<?php echo e(url('/show_residence')); ?>",
                type: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    page: page,
                    search: search,
                    category_id: category_id,
                    date: date_data
                },
                success: function(res) {
                    var tbody = $('#residenceTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentResidencePage = res.current_page;
                        res.data.forEach(function(item, index) {
                            var imgArr = [];
                            if (item.image) {
                                if (typeof item.image === 'string') {
                                    if (item.image.trim().startsWith('[')) {
                                        try { imgArr = JSON.parse(item.image); } catch(e){ imgArr = item.image.split(','); }
                                    } else {
                                        imgArr = item.image.split(',').map(function(s){ return s.trim(); }).filter(Boolean);
                                    }
                                } else if (Array.isArray(item.image)) {
                                    imgArr = item.image;
                                }
                            }
                            var firstImg = imgArr.length > 0 ? imgArr[0] : 'Admin/assets/images/ulhas_logo.png';
                            var firstImgSrc = (firstImg.indexOf('http') === 0 || firstImg.indexOf('storage') === 0) ? firstImg : '/' + firstImg;
                            var imgCount = imgArr.length;

                            var cleanTitle = item.name ? item.name.replace(/"/g, '&quot;') : 'Residence';
                            var cleanImagesJson = JSON.stringify(imgArr).replace(/'/g, "&apos;");

                            var imagesCell = `
                                <div class="d-flex align-items-center gap-2">
                                    <a href="javascript:void(0);" class="open-residence-gallery d-inline-block position-relative" data-title="${cleanTitle}" data-images='${cleanImagesJson}' title="Click to view in Light Gallery">
                                        <img src="${firstImgSrc}" class="rounded-3 shadow-sm border" style="width:46px;height:46px;object-fit:cover;cursor:pointer;transition:transform 0.2s;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
                                    </a>
                                    ${imgCount > 1 ? `
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-2.5 py-1 open-residence-gallery text-nowrap" data-title="${cleanTitle}" data-images='${cleanImagesJson}' title="Click to view all ${imgCount} photos in Light Gallery">
                                            <i class="bi bi-images me-1"></i><strong>${imgCount}</strong> Photos
                                        </button>
                                    ` : (imgCount === 1 ? `
                                        <button type="button" class="btn btn-sm btn-light border rounded-pill px-2.5 py-1 open-residence-gallery text-nowrap" data-title="${cleanTitle}" data-images='${cleanImagesJson}' title="Click to view photo in Light Gallery">
                                            <i class="bi bi-eye text-primary me-1"></i>1 Photo
                                        </button>
                                    ` : `<span class="text-muted small">No Image</span>`)}
                                </div>
                            `;

                            var shortDescBtn = item.short_description 
                                ? `<button type="button" class="btn btn-sm btn-light border rounded-pill px-2.5 py-1 view-text-btn text-nowrap" data-title="${item.name.replace(/"/g, '&quot;')}" data-subtitle="Short Summary / Tagline" data-content="${encodeURIComponent(item.short_description)}"><i class="bi bi-eye text-primary me-1"></i>View Tagline</button>` 
                                : `<span class="text-muted small">-</span>`;

                            var descBtn = item.description 
                                ? `<button type="button" class="btn btn-sm btn-light border rounded-pill px-2.5 py-1 view-text-btn text-nowrap" data-title="${item.name.replace(/"/g, '&quot;')}" data-subtitle="Full Architectural Description" data-content="${encodeURIComponent(item.description)}"><i class="bi bi-file-earmark-text text-success me-1"></i>Read Details</button>` 
                                : `<span class="text-muted small">-</span>`;

                            var catName = item.category_name || '-';
                            var amenitiesList = item.amenities_data || [];
                            var amenitiesCount = amenitiesList.length;

                            var amenitiesBtn = amenitiesCount > 0 
                                ? `<button type="button" class="btn btn-sm btn-outline-success rounded-pill px-2.5 py-1 view-amenities-modal-btn text-nowrap" data-title="${item.name.replace(/"/g, '&quot;')}" data-amenities='${JSON.stringify(amenitiesList).replace(/'/g, "&apos;")}' title="Click to view assigned amenities"><i class="bi bi-flower1 me-1"></i><strong>${amenitiesCount}</strong> Amenities</button>` 
                                : `<span class="text-muted small">0 Amenities</span>`;

                            var layoutPlansCount = 0;
                            var layoutPlansArr = [];
                            if (item.layout_plans) {
                                try {
                                    layoutPlansArr = typeof item.layout_plans === 'string' ? JSON.parse(item.layout_plans) : item.layout_plans;
                                    if (Array.isArray(layoutPlansArr)) layoutPlansCount = layoutPlansArr.length;
                                } catch(e){}
                            }
                            var layoutPlansBtn = layoutPlansCount > 0 
                                ? `<button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-2.5 py-1 view-layout-plans-modal-btn text-nowrap" data-title="${item.name.replace(/"/g, '&quot;')}" data-layouts='${JSON.stringify(layoutPlansArr).replace(/'/g, "&apos;")}' title="Click to view architectural layout blueprints"><i class="bi bi-diagram-3-fill me-1"></i><strong>${layoutPlansCount}</strong> Plans</button>` 
                                : `<span class="text-muted small">0 Plans</span>`;

                            var cleanJson = JSON.stringify(item).replace(/'/g, "&apos;");
                            var createdAtVal = formatDateTime(item.created_at);
                            var updatedAtVal = formatDateTime(item.updated_at);

                            tbody.append(`
                                <tr>
                                    <td class="text-nowrap">${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td class="text-nowrap">
                                        <div class="d-flex gap-1">
                                            <button class="action-btn btn-act-edit edit_btn" data-json='${cleanJson}' title="Edit"><i class="bi bi-pencil-fill"></i></button>
                                            <button class="action-btn btn-act-del delete_btn" data-id="${item.id}" title="Delete"><i class="bi bi-trash-fill"></i></button>
                                        </div>
                                    </td>
                                    <td class="text-center text-nowrap">
                                        <label class="custom-switch m-0">
                                            <input type="checkbox" class="custom-switch-input StatusSwitch" data-id="${item.id}" ${item.status == 1 ? 'checked' : ''}>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </td>
                                    <td class="text-nowrap">${imagesCell}</td>
                                    <td class="fw-bold text-dark text-nowrap" style="min-width: 190px;">${item.name}</td>
                                    <td class="text-nowrap"><span class="badge bg-light text-dark border fw-normal text-nowrap" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-tag text-primary me-1"></i>${catName}</span></td>
                                    <td class="text-nowrap">${amenitiesBtn}</td>
                                    <td class="text-nowrap">${layoutPlansBtn}</td>
                                    <td class="text-nowrap">${item.carpet_area || '-'}</td>
                                    <td class="text-nowrap">${item.rooms || item.suites || '-'}</td>
                                    <td class="text-nowrap">${item.d_room || '1 D Room'}</td>
                                    <td class="text-nowrap">${item.balconies || '2 Balconies'}</td>
                                    <td class="text-nowrap">${item.toilets || item.bathrooms || '-'}</td>
                                    <td class="text-nowrap">${item.pantry || '1 Pantry'}</td>
                                    <td class="text-nowrap">${item.highlight_feature ? `<span class="badge bg-warning-subtle text-dark border"><i class="bi bi-star-fill text-warning me-1"></i>${item.highlight_feature}</span>` : '<span class="text-muted small">-</span>'}</td>
                                    <td class="fw-bold text-success text-nowrap">${item.price || '-'}</td>
                                    <td class="text-nowrap">${shortDescBtn}</td>
                                    <td class="text-nowrap">${descBtn}</td>
                                    <td style="white-space:nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                                    <td style="white-space:nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-arrow-repeat me-1 text-primary"></i>${updatedAtVal}</span></td>
                                </tr>
                            `);
                        });
                    } else {
                        if (page > 1) {
                            loadResidences(page - 1);
                            return;
                        }
                        currentResidencePage = 1;
                        tbody.html('<tr><td colspan="17" class="text-center py-4 text-muted">No residences found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link residence-page-btn" href="javascript:void(0);" data-page="${p}">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }

        $(document).on('click', '.residence-page-btn', function() {
            currentResidencePage = $(this).data('page');
            loadResidences(currentResidencePage);
        });



        // =========================================================================
        // 📄 VIEW TEXT / DESCRIPTION POPUP MODAL
        // =========================================================================
        $(document).on('click', '.view-text-btn', function() {
            var title = $(this).data('title');
            var subtitle = $(this).data('subtitle');
            var rawContent = $(this).data('content');
            var content = decodeURIComponent(rawContent || '');

            $('#textModalTitle').html('<i class="bi bi-file-earmark-text me-2"></i>' + title);
            $('#textModalSubtitle').text(subtitle);
            $('#textModalBody').html(content || '<span class="text-muted italic">No content available.</span>');

            $('#ViewTextModal').modal('show');
        });

        // =========================================================================
        // 🖼️ LIGHT GALLERY VIEWER (FANCYBOX LIGHTBOX)
        // =========================================================================
        $(document).on('click', '.open-residence-gallery', function(e) {
            e.preventDefault();
            var rawImages = $(this).data('images');
            var title = $(this).data('title') || 'Residence Photos';
            var images = [];
            if (rawImages) {
                if (typeof rawImages === 'string') {
                    try { images = JSON.parse(rawImages); } catch(e){ images = rawImages.split(','); }
                } else if (Array.isArray(rawImages)) {
                    images = rawImages;
                }
            }

            if (!images || images.length === 0) return;

            var galleryItems = images.map(function(img, idx) {
                var src = (img.indexOf('http') === 0 || img.indexOf('storage') === 0) ? img : '/' + img;
                return {
                    src: src,
                    type: "image",
                    caption: title + (images.length > 1 ? ` (${idx + 1}/${images.length})` : '')
                };
            });

            if (galleryItems.length > 0) {
                if (typeof Fancybox !== 'undefined') {
                    Fancybox.show(galleryItems, {
                        Toolbar: {
                            display: {
                                left: ["infobar"],
                                middle: [
                                    "zoomIn",
                                    "zoomOut",
                                    "toggle1to1",
                                    "rotateCCW",
                                    "rotateCW",
                                    "flipX",
                                    "flipY",
                                ],
                                right: ["slideshow", "thumbs", "close"],
                            },
                        },
                    });
                } else {
                    window.open(galleryItems[0].src, '_blank');
                }
            }
        });

        // =========================================================================
        // 🖼️ VIEW GALLERY POPUP MODAL (BACKUP)
        // =========================================================================
        $(document).on('click', '.view-gallery-modal-btn', function() {
            var title = $(this).data('title');
            var rawImages = $(this).data('images');
            var images = [];
            if (rawImages) {
                if (typeof rawImages === 'string') {
                    try { images = JSON.parse(rawImages); } catch(e){ images = rawImages.split(','); }
                } else if (Array.isArray(rawImages)) {
                    images = rawImages;
                }
            }

            $('#galleryModalTitle').html('<i class="bi bi-images me-2"></i>' + title + ' &mdash; Residence Photos');
            var grid = $('#galleryModalGrid');
            grid.empty();

            if (images && images.length > 0) {
                images.forEach(function(img, idx) {
                    var src = (img.indexOf('http') === 0 || img.indexOf('storage') === 0) ? img : '/' + img;
                    grid.append(`
                        <div class="col-md-4 col-sm-6">
                            <div class="gallery-preview-item w-100" style="height:170px;">
                                <a href="${src}" class="open-residence-gallery" data-title="${title}" data-images='${JSON.stringify(images)}'>
                                    <img src="${src}" class="w-100 h-100" style="object-fit:cover;cursor:pointer;" title="Click to view full photo">
                                </a>
                            </div>
                        </div>
                    `);
                });
            } else {
                grid.html('<div class="col-12 text-center text-muted py-4"><i class="bi bi-images text-muted d-block mb-2" style="font-size:32px;"></i>No photos uploaded yet.</div>');
            }

            $('#ViewGalleryModal').modal('show');
        });

        // =========================================================================
        // 🌸 VIEW AMENITIES POPUP MODAL
        // =========================================================================
        $(document).on('click', '.view-amenities-modal-btn', function() {
            var title = $(this).data('title');
            var rawAmenities = $(this).data('amenities');
            var amenities = [];
            if (rawAmenities) {
                if (typeof rawAmenities === 'string') {
                    try { amenities = JSON.parse(rawAmenities); } catch(e){}
                } else if (Array.isArray(rawAmenities)) {
                    amenities = rawAmenities;
                }
            }

            $('#amenitiesModalTitle').html(`<i class="bi bi-flower1 me-2 text-success"></i>${title} &mdash; Included Amenities`);
            var grid = $('#amenitiesModalGrid');
            grid.empty();

            if (amenities && amenities.length > 0) {
                amenities.forEach(function(item) {
                    var img = item.image ? item.image : 'Admin/assets/images/ulhas_logo.png';
                    var src = (img.indexOf('http') === 0 || img.indexOf('storage') === 0) ? img : '/' + img;
                    grid.append(`
                        <div class="col-md-6 col-sm-12">
                            <div class="d-flex align-items-center gap-3 p-3 rounded-3 border bg-light shadow-sm h-100">
                                <img src="${src}" class="rounded-3 border" style="width:52px;height:52px;object-fit:cover;flex-shrink:0;">
                                <div class="flex-grow-1">
                                    <h6 class="fw-bold mb-1 text-dark" style="font-size:14px;">${item.name || 'Amenity'}</h6>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill" style="font-size:11px;"><i class="bi bi-check-circle-fill me-1"></i>Included</span>
                                </div>
                            </div>
                        </div>
                    `);
                });
            } else {
                grid.html('<div class="col-12 text-center text-muted py-4"><i class="bi bi-flower1 text-muted d-block mb-2" style="font-size:32px;"></i>No amenities linked to this residence.</div>');
            }

            $('#ViewAmenitiesModal').modal('show');
        });

        // =========================================================================
        // 📐 ARCHITECTURAL 3D LAYOUT PLANS (REPEATER & PREVIEWS)
        // =========================================================================
        function createLayoutPlanRow(title = '', image = '', isEdit = false) {
            var imgSrc = '';
            if (image) {
                imgSrc = (image.indexOf('http') === 0 || image.indexOf('storage') === 0 || image.indexOf('Website') === 0) ? (image.indexOf('http') === 0 ? image : '/' + image) : '/' + image;
            }
            var hasImg = !!imgSrc;
            
            var rowHtml = `
                <div class="layout-plan-item p-3 border rounded-3 bg-white shadow-sm position-relative">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-5">
                            <label class="form-label form-label-3d mb-1 small fw-bold">Layout Heading / Title</label>
                            <input type="text" name="layout_titles[]" class="form-control form-control-3d form-control-sm layout-plan-title-input" placeholder="e.g. Layout Plan Type 4 - First Floor (3 BR)" value="${title.replace(/"/g, '&quot;')}">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label form-label-3d mb-1 small fw-bold">Blueprint Layout Image</label>
                            <input type="hidden" name="existing_layout_images[]" class="existing-layout-img-path" value="${image}">
                            <input type="file" name="layout_images[]" accept="image/*" class="form-control form-control-3d form-control-sm layout-plan-file-input">
                        </div>
                        <div class="col-md-2 d-flex align-items-center justify-content-end gap-2 pt-3">
                            <div class="layout-plan-thumb-box ${hasImg ? '' : 'd-none'}">
                                <img src="${imgSrc}" class="layout-plan-thumb-preview rounded border shadow-sm" style="width: 44px; height: 44px; object-fit: cover; cursor: pointer;" title="Preview blueprint">
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-danger rounded-pill px-2.5 py-1 remove-layout-plan-row-btn" title="Delete this layout plan">
                                <i class="bi bi-trash3-fill"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            return $(rowHtml);
        }

        // Add Layout Plan Row button handler
        $(document).on('click', '.add-layout-plan-row-btn', function() {
            var target = $(this).data('target');
            var isEdit = target.indexOf('edit') !== -1;
            var newRow = createLayoutPlanRow('', '', isEdit);
            $(target).append(newRow);
        });

        // Remove Layout Plan Row button handler
        $(document).on('click', '.remove-layout-plan-row-btn', function() {
            var row = $(this).closest('.layout-plan-item');
            row.fadeOut(200, function() {
                $(this).remove();
            });
        });

        // Preview image on file input change
        $(document).on('change', '.layout-plan-file-input', function(e) {
            var file = e.target.files[0];
            var row = $(this).closest('.layout-plan-item');
            var thumbBox = row.find('.layout-plan-thumb-box');
            var thumbImg = row.find('.layout-plan-thumb-preview');
            if (file) {
                var url = URL.createObjectURL(file);
                thumbImg.attr('src', url);
                thumbBox.removeClass('d-none');
            }
        });

        // View Layout Plans Modal from Table
        $(document).on('click', '.view-layout-plans-modal-btn', function() {
            var title = $(this).data('title');
            var rawLayouts = $(this).data('layouts');
            var layouts = [];
            if (rawLayouts) {
                if (typeof rawLayouts === 'string') {
                    try { layouts = JSON.parse(rawLayouts); } catch(e){}
                } else if (Array.isArray(rawLayouts)) {
                    layouts = rawLayouts;
                }
            }

            $('#layoutPlansModalTitle').html(`<i class="bi bi-diagram-3-fill me-2 text-primary"></i>${title} &mdash; Architectural Layout Plans`);
            var grid = $('#layoutPlansModalGrid');
            grid.empty();

            if (layouts && layouts.length > 0) {
                layouts.forEach(function(item, idx) {
                    var img = item.image ? item.image : 'Website/assets/images/Layout plan type 4 - First Floor (3 BR).png';
                    var src = (img.indexOf('http') === 0 || img.indexOf('storage') === 0 || img.indexOf('Website') === 0) ? (img.indexOf('http') === 0 ? img : '/' + img) : '/' + img;
                    grid.append(`
                        <div class="col-md-6 col-sm-12">
                            <div class="card border rounded-3 p-2 bg-light shadow-sm h-100">
                                <div style="height: 180px; overflow: hidden;" class="rounded bg-white d-flex align-items-center justify-content-center p-2 border">
                                    <a href="${src}" target="_blank" title="Click to view full layout">
                                        <img src="${src}" class="img-fluid rounded" style="max-height: 160px; object-fit: contain;">
                                    </a>
                                </div>
                                <div class="card-body p-2 pt-3 text-center">
                                    <h6 class="fw-bold text-dark mb-0" style="font-size: 13px;">${item.title || 'Layout Plan ' + (idx + 1)}</h6>
                                </div>
                            </div>
                        </div>
                    `);
                });
            } else {
                grid.html('<div class="col-12 text-center text-muted py-4"><i class="bi bi-diagram-3 text-muted d-block mb-2" style="font-size:32px;"></i>No layout plans added yet.</div>');
            }

            $('#ViewLayoutPlansModal').modal('show');
        });

        // Initialize Add Layout Plans with 1 starter row
        $('#add_layout_plans_list').append(createLayoutPlanRow('', '', false));

        // =========================================================================
        // 🖼️ ADD MODAL: DRAG-DROP & MULTIPLE IMAGES SELECTION & PREVIEW
        // =========================================================================
        let addDT = new DataTransfer();

        var addDropzone = document.getElementById('add_image_dropzone');
        if (addDropzone) {
            ['dragenter', 'dragover'].forEach(eventName => {
                addDropzone.addEventListener(eventName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    addDropzone.classList.add('dragover');
                }, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                addDropzone.addEventListener(eventName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    addDropzone.classList.remove('dragover');
                }, false);
            });
        }

        $('#add_residence_images').on('change', function(e) {
            var selectedFiles = Array.from(e.target.files);
            selectedFiles.forEach(function(file) {
                addDT.items.add(file);
            });
            this.files = addDT.files;
            renderAddImagePreviews();
        });

        function renderAddImagePreviews() {
            var container = $('#add_image_preview');
            var wrapper = $('#add_image_preview_wrapper');
            container.empty();

            var totalFiles = addDT.files.length;
            $('#add_image_count').text(totalFiles);

            if (totalFiles === 0) {
                wrapper.hide();
                return;
            }
            wrapper.show();

            Array.from(addDT.files).forEach(function(file, index) {
                var url = URL.createObjectURL(file);
                container.append(`
                    <div class="gallery-preview-item" data-index="${index}">
                        <img src="${url}" alt="Preview">
                        <button type="button" class="gallery-preview-remove remove-add-image" data-index="${index}" title="Remove image">&times;</button>
                    </div>
                `);
            });
        }

        $(document).on('click', '.remove-add-image', function(e) {
            e.stopPropagation();
            var indexToRemove = parseInt($(this).data('index'));
            var newDT = new DataTransfer();
            Array.from(addDT.files).forEach(function(file, idx) {
                if (idx !== indexToRemove) {
                    newDT.items.add(file);
                }
            });
            addDT = newDT;
            document.getElementById('add_residence_images').files = addDT.files;
            renderAddImagePreviews();
        });

        $('#AddResidenceModal').on('hidden.bs.modal', function() {
            $('#add_residence_form')[0].reset();
            $('#category_select').val('').trigger('change');
            $('#amenity_select').val(null).trigger('change');
            if ($('#add_description').summernote) {
                $('#add_description').summernote('reset');
            }
            addDT = new DataTransfer();
            renderAddImagePreviews();
            $('#add_layout_plans_list').empty().append(createLayoutPlanRow('', '', false));
        });

        // Add Residence Submit
        $('#add_residence_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                url: "<?php echo e(url('/add_residence')); ?>",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.success === 'success') {
                        $('#AddResidenceModal').modal('hide');
                        $('#add_residence_form')[0].reset();
                        $('#category_select').val('').trigger('change');
                        $('#amenity_select').val(null).trigger('change');
                        if ($('#add_description').summernote) {
                            $('#add_description').summernote('reset');
                        }
                        addDT = new DataTransfer();
                        renderAddImagePreviews();
                        showToast('Residence added successfully!', 'success');
                        loadResidences(currentResidencePage);
                    } else {
                        showToast(res.message || 'Failed to add residence', 'error');
                    }
                }
            });
        });

        // =========================================================================
        // 🖼️ EDIT MODAL: EXISTING & NEW IMAGES MANAGEMENT
        // =========================================================================
        let editExistingImages = [];
        let editDT = new DataTransfer();

        var editDropzone = document.getElementById('edit_image_dropzone');
        if (editDropzone) {
            ['dragenter', 'dragover'].forEach(eventName => {
                editDropzone.addEventListener(eventName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    editDropzone.classList.add('dragover');
                }, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                editDropzone.addEventListener(eventName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    editDropzone.classList.remove('dragover');
                }, false);
            });
        }

        function renderEditExistingImages() {
            var container = $('#edit_existing_image_preview');
            var wrapper = $('#edit_existing_image_wrapper');
            container.empty();

            var count = editExistingImages ? editExistingImages.length : 0;
            $('#edit_existing_count').text(count);

            if (!editExistingImages || editExistingImages.length === 0) {
                wrapper.hide();
                return;
            }
            wrapper.show();

            editExistingImages.forEach(function(imgPath, index) {
                var src = (imgPath.indexOf('http') === 0 || imgPath.indexOf('storage') === 0) ? imgPath : '/' + imgPath;
                container.append(`
                    <div class="gallery-preview-item">
                        <img src="${src}" alt="Existing">
                        <span class="gallery-badge-existing">Uploaded</span>
                        <button type="button" class="gallery-preview-remove remove-existing-image" data-index="${index}" title="Remove image">&times;</button>
                    </div>
                `);
            });
        }

        $(document).on('click', '.remove-existing-image', function(e) {
            e.stopPropagation();
            var indexToRemove = parseInt($(this).data('index'));
            editExistingImages.splice(indexToRemove, 1);
            $('#edit_existing_images').val(editExistingImages.join(','));
            renderEditExistingImages();
        });

        $('#edit_residence_images').on('change', function(e) {
            var selectedFiles = Array.from(e.target.files);
            selectedFiles.forEach(function(file) {
                editDT.items.add(file);
            });
            this.files = editDT.files;
            renderEditNewImages();
        });

        function renderEditNewImages() {
            var container = $('#edit_new_image_preview');
            var wrapper = $('#edit_new_image_wrapper');
            container.empty();

            var totalNew = editDT.files.length;
            $('#edit_new_count').text(totalNew);

            if (totalNew === 0) {
                wrapper.hide();
                return;
            }
            wrapper.show();

            Array.from(editDT.files).forEach(function(file, index) {
                var url = URL.createObjectURL(file);
                container.append(`
                    <div class="gallery-preview-item" data-index="${index}">
                        <img src="${url}" alt="New Preview">
                        <button type="button" class="gallery-preview-remove remove-edit-new-image" data-index="${index}" title="Remove image">&times;</button>
                    </div>
                `);
            });
        }

        $(document).on('click', '.remove-edit-new-image', function(e) {
            e.stopPropagation();
            var indexToRemove = parseInt($(this).data('index'));
            var newDT = new DataTransfer();
            Array.from(editDT.files).forEach(function(file, idx) {
                if (idx !== indexToRemove) {
                    newDT.items.add(file);
                }
            });
            editDT = newDT;
            document.getElementById('edit_residence_images').files = editDT.files;
            renderEditNewImages();
        });

        // Edit Trigger
        $(document).on('click', '.edit_btn', function() {
            var item = $(this).data('json');
            if (typeof item === 'string') {
                try { item = JSON.parse(item); } catch(e){}
            }

            $('#edit_id').val(item.id);
            $('#edit_name').val(item.name);
            $('#edit_price').val(item.price);
            $('#edit_carpet_area').val(item.carpet_area);
            $('#edit_rooms').val(item.rooms || item.suites || '2 Rooms');
            $('#edit_d_room').val(item.d_room || '1 D Room');
            $('#edit_balconies').val(item.balconies || '2 Balconies');
            $('#edit_toilets').val(item.toilets || item.bathrooms || '2 Toilets');
            $('#edit_pantry').val(item.pantry || '1 Pantry');
            $('#edit_highlight_feature').val(item.highlight_feature || '');
            $('#edit_short_description').val(item.short_description || '');

            if ($('#edit_description').summernote) {
                $('#edit_description').summernote('code', item.description || '');
            } else {
                $('#edit_description').val(item.description || '');
            }

            // Category (single select e.g. 1 or 2)
            var selectedCatId = item.category_id || '';
            if (typeof selectedCatId === 'string' && selectedCatId.trim().startsWith('[')) {
                try {
                    var parsed = JSON.parse(selectedCatId);
                    selectedCatId = Array.isArray(parsed) && parsed.length > 0 ? parsed[0] : '';
                } catch(e) {
                    selectedCatId = item.category_id;
                }
            }
            $('#edit_category_select').val(selectedCatId);

            // Amenities (multi select comma-separated e.g. 1,2,3)
            var selectedAmenities = [];
            var rawAmenity = item.amenity_id || '';
            if (rawAmenity) {
                if (typeof rawAmenity === 'string') {
                    if (rawAmenity.trim().startsWith('[')) {
                        try {
                            selectedAmenities = JSON.parse(rawAmenity);
                        } catch(e) {
                            selectedAmenities = rawAmenity.split(',');
                        }
                    } else {
                        selectedAmenities = rawAmenity.split(',').map(function(s){ return s.trim(); }).filter(Boolean);
                    }
                } else if (Array.isArray(rawAmenity)) {
                    selectedAmenities = rawAmenity;
                }
            }
            $('#edit_amenity_select').val(selectedAmenities).trigger('change');

            // Populate Multiple Images (comma-separated or JSON)
            editExistingImages = [];
            if (item.image) {
                if (typeof item.image === 'string') {
                    if (item.image.trim().startsWith('[')) {
                        try {
                            editExistingImages = JSON.parse(item.image);
                        } catch(e) {
                            editExistingImages = item.image.split(',');
                        }
                    } else {
                        editExistingImages = item.image.split(',').map(function(s){ return s.trim(); }).filter(Boolean);
                    }
                } else if (Array.isArray(item.image)) {
                    editExistingImages = item.image;
                }
            }
            $('#edit_existing_images').val(editExistingImages.join(','));
            renderEditExistingImages();

            // Reset new files DataTransfer for edit modal
            editDT = new DataTransfer();
            var editInput = document.getElementById('edit_residence_images');
            if (editInput) editInput.value = '';
            renderEditNewImages();

            // Populate Layout Plans in Edit Modal
            $('#edit_layout_plans_list').empty();
            var editLayoutPlans = [];
            if (item.layout_plans) {
                if (typeof item.layout_plans === 'string') {
                    try {
                        editLayoutPlans = JSON.parse(item.layout_plans);
                    } catch(e){}
                } else if (Array.isArray(item.layout_plans)) {
                    editLayoutPlans = item.layout_plans;
                }
            }
            if (editLayoutPlans && editLayoutPlans.length > 0) {
                editLayoutPlans.forEach(function(lp) {
                    $('#edit_layout_plans_list').append(createLayoutPlanRow(lp.title || '', lp.image || '', true));
                });
            } else {
                $('#edit_layout_plans_list').append(createLayoutPlanRow('', '', true));
            }

            $('#EditResidenceModal').modal('show');
        });

        // Edit Residence Submit
        $('#edit_residence_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                url: "<?php echo e(url('/update_residence')); ?>",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.success === 'success') {
                        $('#EditResidenceModal').modal('hide');
                        showToast('Residence updated successfully!', 'success');
                        loadResidences(currentResidencePage);
                    } else {
                        showToast(res.message || 'Failed to update residence', 'error');
                    }
                }
            });
        });

        // Delete Trigger
        var deleteId = null;
        $(document).on('click', '.delete_btn', function() {
            deleteId = $(this).data('id');
            $('#deletemodal').modal('show');
        });

        $('.delete_confirm_btn').click(function() {
            if (deleteId) {
                $.ajax({
                    url: "<?php echo e(url('/delete_residence')); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        id: deleteId
                    },
                    success: function(res) {
                        $('#deletemodal').modal('hide');
                        showToast('Residence deleted successfully!', 'success');
                        loadResidences(currentResidencePage);
                    }
                });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DOWNLOADS\ulhas-vilas\ulhas-vilas.partnersindia.com\resources\views/Admin/pages/residence.blade.php ENDPATH**/ ?>