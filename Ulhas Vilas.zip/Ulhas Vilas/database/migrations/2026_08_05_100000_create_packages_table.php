<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('packages')) {
            Schema::create('packages', function (Blueprint $table) {
                $table->id();
                $table->string('destination');
                $table->string('package_name');
                $table->unsignedBigInteger('category_id')->nullable();
                $table->string('price');
                $table->string('duration');
                $table->string('best_time')->nullable();
                $table->string('avg_temp')->nullable();
                $table->string('distance')->nullable();
                $table->text('description')->nullable();
                $table->text('highlights')->nullable();
                $table->text('inclusions')->nullable();
                $table->text('exclusions')->nullable();
                $table->text('travel_tips')->nullable();
                $table->text('image')->nullable();
                $table->integer('status')->default(1);
                $table->string('date')->nullable();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('packages');
    }
};
