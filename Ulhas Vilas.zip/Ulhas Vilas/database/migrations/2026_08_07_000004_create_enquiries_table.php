<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('enquiries')) {
            Schema::create('enquiries', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('mobile', 20);
                $table->string('email');
                $table->unsignedBigInteger('package_id')->nullable();
                $table->string('travel_date')->nullable();
                $table->integer('adults')->nullable();
                $table->integer('children')->nullable();
                $table->string('budget')->nullable();
                $table->text('message')->nullable();
                $table->string('status')->default('Pending');
                $table->string('date')->nullable();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('enquiries');
    }
};
