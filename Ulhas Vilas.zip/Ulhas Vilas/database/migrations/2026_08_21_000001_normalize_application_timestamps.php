<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private array $tables = [
        'users', 'categories', 'sub_categories', 'sliders', 'sizes', 'colors',
        'coupons', 'brands', 'banners', 'headings', 'contacts', 'information',
        'products', 'abouts', 'carts', 'orders', 'galleries', 'notices', 'faqs',
        'newsletter_subscribers', 'order_history', 'packages', 'bookings',
        'pickup_points', 'activities', 'enquiries',
    ];

    public function up(): void
    {
        if (Schema::hasTable('bookings')) {
            Schema::table('bookings', function (Blueprint $table) {
                if (!Schema::hasColumn('bookings', 'address')) {
                    $table->string('address', 255)->nullable();
                }
                if (!Schema::hasColumn('bookings', 'adults')) {
                    $table->string('adults', 255)->nullable();
                }
                if (!Schema::hasColumn('bookings', 'children')) {
                    $table->string('children', 255)->nullable();
                }
                if (!Schema::hasColumn('bookings', 'paid_amount')) {
                    $table->string('paid_amount', 255)->nullable();
                }
                if (!Schema::hasColumn('bookings', 'due_amount')) {
                    $table->string('due_amount', 255)->nullable();
                }
                if (!Schema::hasColumn('bookings', 'notes')) {
                    $table->string('notes', 255)->nullable();
                }
            });
        }

        foreach ($this->tables as $tableName) {
            if (!Schema::hasTable($tableName)) {
                continue;
            }

            Schema::table($tableName, function (Blueprint $table) use ($tableName) {
                if (!Schema::hasColumn($tableName, 'created_at')) {
                    $table->string('created_at', 255)->nullable();
                }
                if (!Schema::hasColumn($tableName, 'updated_at')) {
                    $table->string('updated_at', 255)->nullable();
                }
            });

            DB::statement("ALTER TABLE `{$tableName}` MODIFY `created_at` VARCHAR(255) NULL, MODIFY `updated_at` VARCHAR(255) NULL");
            DB::statement("UPDATE `{$tableName}` SET `created_at` = DATE_FORMAT(STR_TO_DATE(`created_at`, '%Y-%m-%d %H:%i:%s'), '%Y-%m-%d %h:%i %p') WHERE `created_at` REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$'");
            DB::statement("UPDATE `{$tableName}` SET `updated_at` = DATE_FORMAT(STR_TO_DATE(`updated_at`, '%Y-%m-%d %H:%i:%s'), '%Y-%m-%d %h:%i %p') WHERE `updated_at` REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$'");
        }
    }

    public function down(): void
    {
        // Timestamp strings are intentionally retained on rollback to avoid dropping existing data.
    }
};
