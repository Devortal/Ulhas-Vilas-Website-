<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->string('booking_no')->nullable();
            $table->string('user_id')->nullable();
            $table->string('package_id')->nullable();
            $table->string('package_title')->nullable();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->string('phone')->nullable();
            $table->string('travel_date')->nullable();
            $table->string('passengers')->nullable();
            $table->string('total_price')->nullable();
            $table->string('payment_status')->default('Pending');
            $table->string('booking_status')->default('Pending'); // Pending, Success, Accept, Reject
            $table->text('special_request')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
