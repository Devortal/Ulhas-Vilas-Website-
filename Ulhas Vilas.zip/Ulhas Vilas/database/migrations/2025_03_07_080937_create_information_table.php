<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('information', function (Blueprint $table) {
            $table->id();
            $table->string('info_deals');
            $table->string('info_address');
            $table->string('info_about');
            $table->string('info_contact_one');
            $table->string('info_contact_two');
            $table->string('info_contact_three');
            $table->string('info_contact_four');
            $table->string('info_email_one');
            $table->string('info_email_two');
            $table->string('info_facebook_link');
            $table->string('info_twitter_link');
            $table->string('info_xtwitter_link');
            $table->string('info_instagram_link');
            $table->string('info_header_logo');
            $table->string('info_footer_logo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('information');
    }
};
