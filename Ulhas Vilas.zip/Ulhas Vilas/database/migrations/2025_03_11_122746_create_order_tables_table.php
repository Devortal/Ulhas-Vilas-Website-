<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('order_tables', function (Blueprint $table) {
            $table->id();
            $table->string('user_id');
            $table->string('order_id');
            $table->string('invoice_no');
            $table->string('coupon_id');
            $table->string('coupon_discount');
            $table->string('state_id');
            $table->string('city');
            $table->string('order_status');
            $table->string('cancel_req');
            $table->string('return_req');
            $table->string('refund_req');
            $table->string('payment_status');
            $table->string('payment_id');
            $table->string('payment_res');
            $table->string('razorpay_order_id');
            $table->string('coupon_amount');
            $table->string('total_amount');
            $table->string('payment_mode');
            $table->string('date');
            $table->string('time');
            $table->string('assigned_date');
            $table->string('dispatch_date');
            $table->string('transit_date');
            $table->string('delivered_date');
            $table->string('cancelled_date');
            $table->string('return_date');
            $table->string('refund_date');
            $table->string('f_name');
            $table->string('l_name');
            $table->string('company');
            $table->string('email');
            $table->string('mobile');
            $table->string('address');
            $table->string('pincode');
            $table->string('billing_status');
            $table->string('sf_name');
            $table->string('sl_name');
            $table->string('scompany');
            $table->string('sstate_id');
            $table->string('scity');
            $table->string('semail');
            $table->string('smobile');
            $table->string('spincode');
            $table->string('saddress');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_tables');
    }
};
