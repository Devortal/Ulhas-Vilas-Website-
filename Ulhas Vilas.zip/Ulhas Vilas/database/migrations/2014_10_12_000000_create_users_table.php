<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration 
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('user_type')->nullable();
            $table->string('status')->nullable();
            $table->string('otp')->nullable();
            $table->string('platform')->nullable();
            $table->string('name')->nullable();
            $table->string('mobile')->unique();
            $table->string('email')->unique();
            $table->string('dob')->nullable();
            $table->string('gotra')->nullable();
            $table->string('city')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('created_at')->nullable();
            $table->string('updated_at')->nullable();
            $table->string('logout_status')->default('false')->nullable();
            $table->string('platform')->default('false')->nullable();
            $table->string('company_name')->nullable();
            $table->string('addhar_card')->nullable();
            $table->string('bussiness_card_number')->nullable();
            $table->rememberToken();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
