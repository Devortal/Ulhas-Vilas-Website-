<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('product_image');
            $table->string('product_tittle');
            $table->string('product_rating');
            $table->string('product_size');
            $table->string('product_category');
            $table->string('product_tag');
            $table->string('product_weight');
            $table->string('product_dimension');
            $table->string('product_material');
            $table->string('product_details');
            $table->string('product_other_info');
            $table->string('status');
            $table->string('date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
