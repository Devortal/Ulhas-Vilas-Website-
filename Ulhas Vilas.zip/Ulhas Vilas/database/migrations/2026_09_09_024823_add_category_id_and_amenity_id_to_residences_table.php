<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('residences', function (Blueprint $table) {
            if (!Schema::hasColumn('residences', 'category_id')) {
                $table->string('category_id')->nullable()->after('slug');
            }
            if (!Schema::hasColumn('residences', 'amenity_id')) {
                $table->text('amenity_id')->nullable()->after('category_ids');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('residences', function (Blueprint $table) {
            if (Schema::hasColumn('residences', 'category_id')) {
                $table->dropColumn('category_id');
            }
            if (Schema::hasColumn('residences', 'amenity_id')) {
                $table->dropColumn('amenity_id');
            }
        });
    }
};
