<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('information')) {
            Schema::table('information', function (Blueprint $table) {
                if (Schema::hasColumn('information', 'header_script')) {
                    $table->dropColumn('header_script');
                }
                if (Schema::hasColumn('information', 'footer_script')) {
                    $table->dropColumn('footer_script');
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('information')) {
            Schema::table('information', function (Blueprint $table) {
                if (!Schema::hasColumn('information', 'header_script')) {
                    $table->longText('header_script')->nullable();
                }
                if (!Schema::hasColumn('information', 'footer_script')) {
                    $table->longText('footer_script')->nullable();
                }
            });
        }
    }
};
