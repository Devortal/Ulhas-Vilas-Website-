<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Amenities Table
        if (!Schema::hasTable('amenities')) {
            Schema::create('amenities', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('category')->nullable();
                $table->string('image')->nullable();
                $table->text('icon')->nullable();
                $table->text('description')->nullable();
                $table->string('duration')->nullable();
                $table->string('level')->nullable();
                $table->integer('status')->default(1);
                $table->timestamps();
            });
        }

        // 2. Blogs Table (Dynamic, clean fields, without author)
        if (!Schema::hasTable('blogs')) {
            Schema::create('blogs', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->string('slug')->unique();
                $table->string('image')->nullable();
                $table->string('category')->nullable();
                $table->text('short_description')->nullable();
                $table->longText('content')->nullable();
                $table->string('meta_title')->nullable();
                $table->text('meta_description')->nullable();
                $table->integer('status')->default(1);
                $table->timestamps();
            });
        }

        // 3. Page SEO Table for Dynamic SEO Management across all pages
        if (!Schema::hasTable('page_seos')) {
            Schema::create('page_seos', function (Blueprint $table) {
                $table->id();
                $table->string('page_key')->unique();
                $table->string('page_name');
                $table->string('meta_title')->nullable();
                $table->text('meta_description')->nullable();
                $table->text('meta_keywords')->nullable();
                $table->string('og_image')->nullable();
                $table->timestamps();
            });

            // Seed standard pages with Ulhas Vilas SEO defaults
            $defaultPages = [
                [
                    'page_key' => 'home',
                    'page_name' => 'Home Page',
                    'meta_title' => 'Ulhas Vilas — Architectural Refinement & Luxury Estates',
                    'meta_description' => 'Discover The Ulhas Vilas in Himachal Pradesh. Luxury architectural estates, 1-4 BHK bespoke villas, private suites, and world-class wellness.',
                    'meta_keywords' => 'Ulhas Vilas, luxury villas, Himachal Pradesh real estate, luxury estates, mountain villas, holiday homes',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'residences',
                    'page_name' => 'Residences Collection',
                    'meta_title' => 'Curated Residences Collection | The Ulhas Vilas',
                    'meta_description' => 'Explore 1 BHK, 2 BHK, 3 BHK & 4 BHK luxury residences and duplexes at The Ulhas Vilas. Tailored architectural masterpieces.',
                    'meta_keywords' => '1 BHK villa, 2 BHK villa, 3 BHK duplex, 4 BHK duplex, luxury residences Himachal',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'residence_1bhk',
                    'page_name' => '1 BHK Residence Detail',
                    'meta_title' => 'The Sanctuary 1 BHK Luxury Villa | The Ulhas Vilas',
                    'meta_description' => 'Experience the intimate minimalist 1 BHK Sanctuary Villa featuring private plunge pool, courtyard, and 1,250 SQ FT of architectural living.',
                    'meta_keywords' => '1 BHK Villa, Sanctuary Villa, holiday home, private pool villa',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'residence_2bhk',
                    'page_name' => '2 BHK Residence Detail',
                    'meta_title' => 'The Horizon 2 BHK Luxury Villa | The Ulhas Vilas',
                    'meta_description' => 'Dual-suite coastal mountain residence with expansive glass facade, infinity pool, and sunset deck across 2,400 SQ FT.',
                    'meta_keywords' => '2 BHK Villa, Horizon Residence, luxury mountain suite, infinity pool villa',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'residence_3bhk',
                    'page_name' => '3 BHK Residence / Duplex Detail',
                    'meta_title' => 'The Grand Estate 3 BHK Residence / Duplex | The Ulhas Vilas',
                    'meta_description' => 'Masterpiece 3-bedroom duplex residence featuring ocean/mountain deck, private wellness spa, and 4,800 SQ FT of refined comfort.',
                    'meta_keywords' => '3 BHK Villa, 3 BHK Duplex, Grand Estate, luxury mountain duplex',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'residence_4bhk',
                    'page_name' => '4 BHK Residence / Duplex Detail',
                    'meta_title' => 'The Royal Pavilion 4 BHK Luxury Duplex | The Ulhas Vilas',
                    'meta_description' => 'Ultra-exclusive 4-suite royal pavilion featuring private terrace, staff quarters, and 8,500 SQ FT of architectural grandeur.',
                    'meta_keywords' => '4 BHK Villa, 4 BHK Duplex, Royal Pavilion, penthouse mansion',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'about_us',
                    'page_name' => 'About Us Page',
                    'meta_title' => 'About The Ulhas Vilas — Architectural Living & Heritage',
                    'meta_description' => 'Learn about our philosophy of designing for permanence, context, and timeless architectural luxury in the pine hills of Himachal Pradesh.',
                    'meta_keywords' => 'About Ulhas Vilas, architectural living, luxury estate developers, Himachal real estate',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'amenities',
                    'page_name' => 'Amenities & Wellness Page',
                    'meta_title' => 'Amenities & Holistic Wellness | The Ulhas Vilas',
                    'meta_description' => 'Immerse in holistic wellness: thermal infinity pool, Finnish sauna, hydrotherapy spa, yoga pavilions, and sky fitness studio.',
                    'meta_keywords' => 'Ulhas Vilas amenities, wellness resort, infinity pool, spa sauna, yoga sanctuary',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'gallery',
                    'page_name' => 'Gallery Page',
                    'meta_title' => 'Curated Visual Gallery | The Ulhas Vilas',
                    'meta_description' => 'A visual journey through interiors, terraces, lounges, private suites, and mountain panoramas at The Ulhas Vilas.',
                    'meta_keywords' => 'Ulhas Vilas gallery, villa photos, luxury interior gallery, estate images',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'blogs',
                    'page_name' => 'Blogs & Stories Page',
                    'meta_title' => 'Editorial Insights & Luxury Living Stories | The Ulhas Vilas',
                    'meta_description' => 'Read our latest architectural insights, lifestyle guides, mountain living chronicles, and real estate investment trends.',
                    'meta_keywords' => 'luxury real estate blog, architectural design, mountain lifestyle, investment ROI',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'faqs',
                    'page_name' => 'FAQs Page',
                    'meta_title' => 'Frequently Asked Questions | The Ulhas Vilas',
                    'meta_description' => 'Answers to your queries regarding villa customizations, freehold titles, RERA compliance, payment plans, and ownership privileges.',
                    'meta_keywords' => 'Ulhas Vilas FAQ, RERA compliance, villa ownership questions, freehold titles',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'page_key' => 'contact_us',
                    'page_name' => 'Contact Us Page',
                    'meta_title' => 'Schedule A Private Consultation | The Ulhas Vilas',
                    'meta_description' => 'Connect directly with our senior estate management team for exclusive previews, brochure queries, and personalized guidance.',
                    'meta_keywords' => 'Contact Ulhas Vilas, schedule consultation, estate manager contact, real estate enquiry',
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ];

            DB::table('page_seos')->insert($defaultPages);
        }

        // 4. Residences Table (Category wise with multiple category support, real estate fields)
        if (!Schema::hasTable('residences')) {
            Schema::create('residences', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('slug')->unique();
                $table->string('category_ids')->nullable(); // Multi-category IDs JSON / comma-separated
                $table->string('category_name')->nullable();
                $table->string('price_prefix')->default('From');
                $table->string('price')->nullable();
                $table->string('carpet_area')->nullable(); // e.g. 1,250 SQ FT
                $table->string('suites')->nullable(); // e.g. 1 Suite / 2 BHK
                $table->string('bathrooms')->nullable();
                $table->string('view_type')->nullable(); // e.g. Mountain Panorama / Valley View
                $table->string('image')->nullable(); // Main Featured Image
                $table->text('gallery_images')->nullable(); // JSON array of gallery images
                $table->string('floor_plan_image')->nullable();
                $table->text('short_description')->nullable();
                $table->longText('description')->nullable();
                $table->text('specifications')->nullable(); // Key specs (Pool, Deck, Furnishing, etc.)
                $table->string('meta_title')->nullable();
                $table->text('meta_description')->nullable();
                $table->integer('is_featured')->default(0);
                $table->integer('status')->default(1);
                $table->timestamps();
            });
        }

        // 5. Enquiries / Leads Table
        if (!Schema::hasTable('enquiries')) {
            Schema::create('enquiries', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('email')->nullable();
                $table->string('mobile')->nullable();
                $table->string('city')->nullable();
                $table->string('configuration')->nullable();
                $table->text('message')->nullable();
                $table->string('source')->default('contact_form'); // 'brochure_download' or 'contact_form'
                $table->string('status')->default('Pending');
                $table->timestamps();
            });
        } else {
            Schema::table('enquiries', function (Blueprint $table) {
                if (!Schema::hasColumn('enquiries', 'city')) {
                    $table->string('city')->nullable()->after('mobile');
                }
                if (!Schema::hasColumn('enquiries', 'configuration')) {
                    $table->string('configuration')->nullable()->after('city');
                }
                if (!Schema::hasColumn('enquiries', 'source')) {
                    $table->string('source')->default('contact_form')->after('message');
                }
            });
        }

        // 6. Information Table updates (brochure_file, rera_number, etc.)
        if (Schema::hasTable('information')) {
            Schema::table('information', function (Blueprint $table) {
                if (!Schema::hasColumn('information', 'brochure_file')) {
                    $table->string('brochure_file')->nullable()->after('footer_about');
                }
                if (!Schema::hasColumn('information', 'rera_number')) {
                    $table->string('rera_number')->nullable()->after('brochure_file');
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('amenities');
        Schema::dropIfExists('blogs');
        Schema::dropIfExists('page_seos');
        Schema::dropIfExists('residences');
    }
};
