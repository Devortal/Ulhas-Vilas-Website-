<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pickup_points', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255)->unique();
            $table->timestamps();
        });

        Schema::create('package_pickup_prices', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('package_id');
            $table->unsignedBigInteger('pickup_point_id');
            $table->string('price', 100)->nullable();
            $table->string('offer_price', 100)->nullable();
            $table->timestamps();

            $table->foreign('package_id')
                ->references('id')
                ->on('packages')
                ->onDelete('cascade');

            $table->foreign('pickup_point_id')
                ->references('id')
                ->on('pickup_points')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('package_pickup_prices');
        Schema::dropIfExists('pickup_points');
    }
};
