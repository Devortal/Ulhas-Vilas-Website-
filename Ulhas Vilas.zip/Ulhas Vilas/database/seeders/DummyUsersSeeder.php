<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DummyUsersSeeder extends Seeder
{
    public function run(): void
    {
        $batchSize = 500;
        $totalUsers = 2000;
        $now = date('Y-m-d h:i A');

        for ($i = 1; $i <= $totalUsers; $i += $batchSize) {
            $usersData = [];
            $emails = [];
            $startCount = $i;
            $endCount = min($i + $batchSize - 1, $totalUsers);

            for ($j = $startCount; $j <= $endCount; $j++) {
                $mobile = '99990' . str_pad($j, 5, '0', STR_PAD_LEFT);
                $email = 'dummyuser' . $j . '@example.com';
                $emails[] = $email;

                $usersData[] = [
                    'user_type' => 'B2C',
                    'is_verified' => 'true',
                    'status' => '1',
                    'otp' => '123456',
                    'name' => 'Dummy User ' . $j,
                    'mobile' => $mobile,
                    'email' => $email,
                    'password' => '',
                    'logout_status' => 'true',
                    'created_at' => $now,
                    'updated_at' => $now,
                    'notified_nonverified' => 0,
                ];
            }

            // Insert users in batch
            DB::table('users')->insert($usersData);

            // Fetch these inserted users to map their IDs to app_tokens
            $insertedUsers = DB::table('users')
                ->whereIn('email', $emails)
                ->select('id')
                ->get();

            $tokensData = [];
            foreach ($insertedUsers as $user) {
                $tokensData[] = [
                    'userid' => $user->id,
                    'token' => 'dummy_fcm_token_' . Str::random(50) . '_' . $user->id,
                    'date' => date('Y-m-d'),
                    'time' => date('h:i A'),
                    'status' => 'true',
                ];
            }

            // Insert tokens in batch
            DB::table('app_token')->insert($tokensData);
        }
    }
}
