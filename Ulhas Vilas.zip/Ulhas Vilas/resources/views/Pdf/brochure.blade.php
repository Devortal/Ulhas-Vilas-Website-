<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>The Ulhas Vilas — Architectural Brochure & Floor Plans</title>
    <style>
        @page {
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #0c1c2e;
            background: #ffffff;
            -webkit-print-color-adjust: exact;
        }
        .page {
            width: 100%;
            height: 100%;
            page-break-after: always;
            position: relative;
            box-sizing: border-box;
        }
        .cover-page {
            background: #071524;
            color: #ffffff;
            padding: 70px 55px;
            text-align: center;
        }
        .gold-pill {
            display: inline-block;
            border: 1px solid #cca43b;
            background: rgba(204, 164, 59, 0.15);
            color: #f1d37a;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 25px;
        }
        .brand-title {
            font-size: 34px;
            letter-spacing: 4px;
            font-weight: 800;
            text-transform: uppercase;
            margin: 0 0 10px 0;
            color: #ffffff;
        }
        .brand-sub {
            font-size: 14px;
            color: #cca43b;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            margin: 0 0 40px 0;
        }
        .divider {
            width: 80px;
            height: 2px;
            background: #cca43b;
            margin: 0 auto 40px auto;
        }
        .cover-desc {
            font-size: 14px;
            line-height: 1.8;
            color: #cbd5e1;
            max-width: 500px;
            margin: 0 auto 50px auto;
        }
        .cover-features {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .cover-features td {
            padding: 15px;
            text-align: center;
            border: 1px solid rgba(204, 164, 59, 0.3);
            background: rgba(255, 255, 255, 0.03);
            color: #ffffff;
            width: 33.33%;
        }
        .feature-num {
            font-size: 20px;
            font-weight: bold;
            color: #f1d37a;
            margin-bottom: 5px;
        }
        .feature-lbl {
            font-size: 11px;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: #94a3b8;
        }
        .content-page {
            padding: 50px 50px;
            background: #ffffff;
        }
        .sec-head {
            font-size: 11px;
            color: #cca43b;
            letter-spacing: 2px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        .sec-title {
            font-size: 22px;
            color: #071524;
            font-weight: bold;
            margin: 0 0 20px 0;
            border-bottom: 2px solid #071524;
            padding-bottom: 8px;
        }
        .res-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .res-table th {
            background: #071524;
            color: #ffffff;
            font-size: 11px;
            letter-spacing: 1px;
            text-transform: uppercase;
            padding: 10px 14px;
            text-align: left;
        }
        .res-table td {
            padding: 12px 14px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 12px;
            color: #334155;
        }
        .res-table tr:nth-child(even) td {
            background: #f8fafc;
        }
        .tag-gold {
            background: #fef3c7;
            color: #92400e;
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 10.5px;
        }
        .amenities-grid {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .amenities-grid td {
            width: 50%;
            padding: 12px 14px;
            border: 1px solid #e2e8f0;
            background: #f8fafc;
            font-size: 12px;
            color: #1e293b;
        }
        .amenity-title {
            font-weight: bold;
            color: #071524;
            margin-bottom: 3px;
        }
        .footer-strip {
            position: absolute;
            bottom: 25px;
            left: 50px;
            right: 50px;
            font-size: 10px;
            color: #94a3b8;
            border-top: 1px solid #e2e8f0;
            padding-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

    <!-- PAGE 1: COVER -->
    <div class="page cover-page">
        <div class="gold-pill">OFFICIAL ARCHITECTURAL PRESENTATION</div>
        <h1 class="brand-title">THE ULHAS VILAS</h1>
        <div class="brand-sub">Where Serenity Whispers Joy &bull; Himachal Pradesh</div>
        <div class="divider"></div>

        <p class="cover-desc">
            Perched gracefully in the pine-scented hills of Himachal Pradesh, The Ulhas Vilas is a private sanctuary where bespoke architecture meets nature in timeless elegance. Experience unparalleled luxury mountain living with panoramic valley vistas.
        </p>

        <table class="cover-features">
            <tr>
                <td>
                    <div class="feature-num">1 to 4 BHK</div>
                    <div class="feature-lbl">Luxury Mountain Residences</div>
                </td>
                <td>
                    <div class="feature-num">Panoramic</div>
                    <div class="feature-lbl">Valley &amp; Ridge Views</div>
                </td>
                <td>
                    <div class="feature-num">24/7 Concierge</div>
                    <div class="feature-lbl">White-Glove Hospitality</div>
                </td>
            </tr>
        </table>
    </div>

    <!-- PAGE 2: RESIDENCES & SPECIFICATIONS -->
    <div class="page content-page">
        <div class="sec-head">RESIDENTIAL PORTFOLIO</div>
        <h2 class="sec-title">Floor Plans &amp; Configurations</h2>

        <table class="res-table">
            <thead>
                <tr>
                    <th>Configuration</th>
                    <th>Deck &amp; Balcony</th>
                    <th>Key Highlights</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>1 BHK Luxury Villa</strong></td>
                    <td>Private Sunset Deck</td>
                    <td>Open-concept living, fireplace, Italian marble flooring</td>
                    <td><span class="tag-gold">Available</span></td>
                </tr>
                <tr>
                    <td><strong>2 BHK Executive Residence</strong></td>
                    <td>Dual Valley Balconies</td>
                    <td>Master ensuite, cedarwood finishes, modular kitchen</td>
                    <td><span class="tag-gold">Available</span></td>
                </tr>
                <tr>
                    <td><strong>3 BHK Grand Mountain Suite</strong></td>
                    <td>Wraparound Deck</td>
                    <td>Walk-in wardrobes, private jacuzzi, servant quarters</td>
                    <td><span class="tag-gold">Available</span></td>
                </tr>
                <tr>
                    <td><strong>4 BHK Royal Penthouse</strong></td>
                    <td>360° Ridge Terrace</td>
                    <td>Double-height ceilings, private elevator access, infinity deck</td>
                    <td><span class="tag-gold">Exclusive</span></td>
                </tr>
            </tbody>
        </table>

        <div class="sec-head" style="margin-top: 30px;">ESTATE HIGHLIGHTS</div>
        <h2 class="sec-title">Wellness &amp; Leisure Amenities</h2>

        <table class="amenities-grid">
            <tr>
                <td>
                    <div class="amenity-title">🌲 Pine Forest Meditation Trail</div>
                    Private landscaped walking trails nestled amidst cedar and pine groves.
                </td>
                <td>
                    <div class="amenity-title">🔥 Sunset Lounge &amp; Firepits</div>
                    Outdoor heated bonfire seating overlooking the twilight Himalayan valleys.
                </td>
            </tr>
            <tr>
                <td>
                    <div class="amenity-title">🏊 Temperature-Controlled Pool</div>
                    All-season indoor heated pool with glass walls and skyline vistas.
                </td>
                <td>
                    <div class="amenity-title">🍷 Clubhouse &amp; Private Dining</div>
                    Gourmet multi-cuisine restaurant, library lounge, and banquet facility.
                </td>
            </tr>
        </table>

        <div class="footer-strip">
            <strong>The Ulhas Vilas</strong> &bull; Shimla Highway, Himachal Pradesh &bull; RERA: HP/RERA/2024/001 &bull; 
            Official Website: {{ url('/') }}
        </div>
    </div>

</body>
</html>
