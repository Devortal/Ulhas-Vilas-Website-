@if (session()->get('admin_login'))
    @extends('Admin.layouts.master')
    @section('main-content')
        @php
            if (session()->has('admin_login')) {
                $data = session()->get('admin_login');

                $admin = $data->first();

                if ($admin && isset($admin->permissions) && isset($admin->user_type)) {
                    $data1 = $admin->permissions;
                    $data3 = $admin->user_type;

                    $allowed_str = $data1;
                    $allowed = explode(',', $allowed_str);
                } else {
                    return redirect()->route('login');
                }
            } else {
                return redirect()->route('login');
            }
        @endphp

        <style>
            .tilebox-one i {
                position: absolute;
                right: 0.6rem;
                font-size: 2rem;
                opacity: .3;
            }

            .tilebox-one {
                min-height: 176px;
                /* border: 2px solid #7dc00bc4; */
                /* background: #ffda9896; */
                /* border: 2px solid #7dc00b7d; */
                border: 2px solid #1c5a3c;
                background: #f9c05aab;
                display: flex;
                align-items: center;
                justify-content: center;
                text-align: center;
                transition: all 0.2s ease-in-out;
            }

            .text-muted {
                --ct-text-opacity: 1;
                color: #000000 !important;
            }

            .tilebox-one p {
                margin-bottom: 0;
                line-height: 1.4;
                color: black;
            }
        </style>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Dashboard</h4>
                        <div class="row">
                            @if (in_array('Manage User', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-user') }}" style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one" style="cursor:pointer;">
                                            <div class="card-body">
                                                <h6 class="text-muted text-uppercase mt-0">Total Users</h6>
                                                <!-- Flex container for icon + number -->
                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                    <i class="ri-group-fill text-muted" style="font-size: 30px;"></i>
                                                    <h2 class="m-b-20 mb-0 mt-2 text-dark"
                                                        style="font-size: 25px;font-weight:bold">{{ $totatuser ?? '0' }}
                                                    </h2>
                                                </div>
                                                <p class="mb-0" style="margin-top: 20px;">
                                                    Today Users:
                                                    <span class="text-success" style="font-size: 20px;">
                                                        {{ $todayuser ?? '0' }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif

                            {{-- @if (in_array('Manage Booking History', $allowed) || $allowed_str == 'all')
                        <div class="col-sm-3">
                            <a href="{{ url('admin-booking_history') }}" style="text-decoration:none; color:inherit;">
                                <div class="card tilebox-one" style="cursor:pointer;">
                                    <div class="card-body">
                                        <h6 class="text-muted text-uppercase mt-0">Total Bookings</h6>
                    
                                        <!-- icon + number side-by-side -->
                                        <div class="d-flex flex-column align-items-center justify-content-center">
                                            <!--<i class="ri-shopping-cart-line text-muted" style="font-size: 30px;"></i>-->
                                            <i class="ri-calendar-check-line text-muted" style="font-size: 30px;"></i>
                                            <h2 class="m-b-20 mb-0 text-dark" style="font-size: 25px;font-weight:bold">{{ $totatbookinghistory ?? '0' }}</h2>
                                        </div>
                                        
                                        <p class="mb-0" style="margin-top: 20px;">
                                            Today Bookings:
                                            <span class="text-success" style="font-size: 20px;">
                                                {{ $todaybookinghistory ?? '0' }}
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endif --}}

                            {{-- @if (in_array('Manage Donation History', $allowed) || $allowed_str == 'all')
                        <div class="col-sm-3">
                            <a href="{{ url('admin-donation_history') }}" style="text-decoration:none; color:inherit;">
                                <div class="card tilebox-one" style="cursor:pointer;">
                                    <div class="card-body">
                                        <h6 class="text-muted text-uppercase mt-0">Total Donations : &ensp; <span style="font-size:20px;color:#767cf5;">{{ $totatdonationhistory ?? '0' }}</span></h6>
                    
                                        <!-- icon + number side-by-side -->
                                        <div class="d-flex flex-column align-items-center justify-content-center" style="margin-top:5px">
                                            <!--<i class="ri-shopping-cart-line text-muted mt-2"></i>-->
                                            <i class="ri-hand-coin-fill text-muted mt-2"></i>
                                            <span class="text-dark" style="font-size: 25px;font-weight:bold">
                                                ₹{{ number_format($totatdonationamount ?? 0, 0, '.', ',') }}
                                            </span>
                                        </div>
                    
                                        <p class="mb-0">
                                            Today Donations:
                                            <span class="text-success" style="font-size: 20px;">
                                                {{ $todaydonationhistory ?? '0' }}
                                            </span><br>
                                            Today Donation Amount:
                                            <span class="text-primary" style="font-size: 17px;">
                                                ₹{{ number_format($totalpayamount ?? 0, 0, '.', ',') }}
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endif --}}

                            @if (in_array('Manage User', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-user?platform=android') }}"
                                        style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one" style="cursor:pointer;">
                                            <div class="card-body">
                                                <h6 class="text-muted text-uppercase mt-0">Total Android Users</h6>
                                                <!-- Flex container for icon + number -->
                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                    <i class="ri-group-fill text-muted" style="font-size: 30px;"></i>
                                                    <h2 class="m-b-20 mb-0 mt-2 text-dark"
                                                        style="font-size: 25px;font-weight:bold">
                                                        {{ $totalandroiduser ?? '0' }}</h2>
                                                </div>
                                                <p class="mb-0" style="margin-top: 20px;">
                                                    Today Android Users:
                                                    <span class="text-success" style="font-size: 20px;">
                                                        {{ $todayandroiduser ?? '0' }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif

                            @if (in_array('Manage User', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-user?platform=ios') }}"
                                        style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one" style="cursor:pointer;">
                                            <div class="card-body">
                                                <h6 class="text-muted text-uppercase mt-0">Total IOS Users</h6>
                                                <!-- Flex container for icon + number -->
                                                <div class="d-flex flex-column align-items-center justify-content-center">
                                                    <i class="ri-group-fill text-muted" style="font-size: 30px;"></i>
                                                    <h2 class="m-b-20 mb-0 mt-2 text-dark"
                                                        style="font-size: 25px;font-weight:bold">{{ $totaliosuser ?? '0' }}
                                                    </h2>
                                                </div>
                                                <p class="mb-0" style="margin-top: 20px;">
                                                    Today IOS Users:
                                                    <span class="text-success" style="font-size: 20px;">
                                                        {{ $todayiosuser ?? '0' }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif

                            @if (in_array('Manage Slider', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-slider') }}" style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one">
                                            <div class="card-body">
                                                <i class="ri-store-line float-end text-muted"></i>
                                                <h6 class="text-muted text-uppercase mt-0">Total Sliders</h6>
                                                <h2 class="m-b-20 text-dark" style="font-size: 25px;font-weight:bold">
                                                    {{ $totatslider ?? '0' }}</h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif

                            @if (in_array('Manage Gallery', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-gallery') }}" style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one">
                                            <div class="card-body">
                                                <i class="ri-product-hunt-line float-end text-muted"></i>
                                                <h6 class="text-muted text-uppercase mt-0">Total Gallery</h6>
                                                <h2 class="m-b-20 text-dark" style="font-size: 25px;font-weight:bold">
                                                    {{ $totatgallery ?? '0' }}</h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif

                            @if (in_array('Manage Notice', $allowed) || $allowed_str == 'all')
                                <div class="col-sm-3">
                                    <a href="{{ url('admin-notice') }}" style="text-decoration:none; color:inherit;">
                                        <div class="card tilebox-one">
                                            <div class="card-body">
                                                <i class="ri-shopping-cart-line float-end text-muted"></i>
                                                <h6 class="text-muted text-uppercase mt-0">Total Product</h6>
                                                <h2 class="m-b-20 text-dark" style="font-size: 25px;font-weight:bold">
                                                    {{ $totatnotice ?? '0' }}</h2>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- Check every 10 sec a new records add or not then reload -->
    @endsection
@else
    <script>
        location.href = "{{ url('/login') }}";
    </script>
@endif
