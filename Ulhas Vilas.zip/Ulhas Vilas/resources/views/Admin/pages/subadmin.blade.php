@if(Session::get('admin_login'))
    @foreach(session()->get('admin_login') as $adminlogin)
        @extends('Admin.layouts.master')
        @section('main-content')

            <!-- Chosen CSS -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css">


            <style>
                .error-text {
                    color: #dc3545;
                    font-size: 12px;
                    margin-top: 3px;
                    display: block;
                    font-weight: 500;
                    line-height: 1.2;
                }

                .form-control.is-invalid, .form-control-3d.is-invalid {
                    border-color: #dc3545 !important;
                    background-color: rgba(220, 53, 69, 0.05) !important;
                }

                /* Chosen Dropdown & Modal Overflow Scroll Fix */
                #AddSubadminModal .modal-content-3d {
                    overflow: visible !important;
                }

                #AddSubadminModal .modal-body-3d {
                    overflow: visible !important;
                    padding-bottom: 25px !important;
                }

                .chosen-container {
                    font-size: 13.5px;
                    position: relative;
                    display: inline-block;
                    vertical-align: middle;
                    width: 100% !important;
                }

                .chosen-container-multi .chosen-choices {
                    border: 1px solid #cbd5e1 !important;
                    border-radius: 10px !important;
                    background: #ffffff !important;
                    background-image: none !important;
                    min-height: 44px !important;
                    padding: 4px 8px !important;
                    box-shadow: none !important;
                    display: flex !important;
                    flex-wrap: wrap;
                    align-items: center;
                    gap: 4px;
                }

                .chosen-container-active .chosen-choices {
                    border-color: #0f172a !important;
                    box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.08) !important;
                }

                .chosen-container-multi .chosen-choices li.search-field {
                    margin: 0 !important;
                    padding: 0 !important;
                    flex-grow: 1;
                }

                .chosen-container-multi .chosen-choices li.search-field input[type="text"] {
                    font-family: inherit !important;
                    font-size: 13px !important;
                    color: #0f172a !important;
                    height: 32px !important;
                    padding: 0 6px !important;
                }

                .chosen-container-multi .chosen-choices li.search-choice {
                    background: #0f172a !important;
                    border: 1px solid #0f172a !important;
                    color: #ffffff !important;
                    border-radius: 6px !important;
                    padding: 5px 24px 5px 10px !important;
                    font-size: 12px !important;
                    font-weight: 500 !important;
                    line-height: 1.4 !important;
                    margin: 2px !important;
                    box-shadow: none !important;
                }

                .chosen-container-multi .chosen-choices li.search-choice .search-choice-close {
                    top: 6px !important;
                    right: 6px !important;
                    filter: invert(1);
                }

                .chosen-container .chosen-drop {
                    background: #ffffff !important;
                    border: 1px solid #cbd5e1 !important;
                    border-radius: 10px !important;
                    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.16) !important;
                    margin-top: 4px !important;
                    z-index: 1060 !important;
                    overflow: hidden !important;
                }

                .chosen-container .chosen-results {
                    max-height: 220px !important;
                    overflow-y: auto !important;
                    -webkit-overflow-scrolling: touch !important;
                    padding: 6px !important;
                    margin: 0 !important;
                }

                .chosen-container .chosen-results li {
                    padding: 9px 12px !important;
                    border-radius: 6px !important;
                    font-size: 13px !important;
                    font-weight: 500 !important;
                    color: #1e293b !important;
                    line-height: 1.4 !important;
                    transition: all 0.15s ease !important;
                }

                .chosen-container .chosen-results li.highlighted {
                    background: #0f172a !important;
                    color: #c5a059 !important;
                }

                .chosen-container .chosen-results li.result-selected {
                    color: #94a3b8 !important;
                    background: #f8fafc !important;
                }
            </style>

            <div class="container-fluid mt-2">
                <div class="row">
                    <div class="col-12">
                        <!-- Single Outer Main Card Container -->
                        <div class="card p-4 rounded-4 shadow-sm border-0 bg-white">

                            <!-- Subadmin Filter & Top Action Bar -->
                            <div class="filter-card-container mb-4">
                                <div class="row align-items-end g-3">
                                    <div class="col-xl-4 col-lg-5 col-md-6">
                                        <label class="filter-section-title">SEARCH SUBADMIN</label>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="search-input-pill flex-grow-1">
                                                <i class="bi bi-search"></i>
                                                <input type="text" class="search_contact" placeholder="Search subadmin name, mobile, email..." />
                                            </div>
                                            <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                                <i class="bi bi-file-earmark-excel-fill"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-xl-auto col-lg-auto col-md-auto">
                                        <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                            <i class="bi bi-arrow-counterclockwise"></i> Reset
                                        </button>
                                    </div>

                                    <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                                        <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddSubadminModal">
                                            <i class="bi bi-plus-lg me-1"></i> Add Subadmin
                                        </button>
                                    </div>
                                </div>
                            </div>


                            <!-- Subadmin Table Container -->
                            <div class="table-responsive-athlo mb-3">
                                <table id="donationTable" class="table table-athlo nowrap w-100">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ACTION</th>
                                            <th>STATUS</th>
                                            <th>USERNAME</th>
                                            <th>EMAIL</th>
                                            <th>MOBILE</th>
                                            <th>PASSWORD</th>
                                            <th>USER TYPE</th>
                                            <th>PERMISSIONS</th>
                                            <th>DATETIME</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination Start Here -->
                            <nav class="mt-2">
                                <ul id="pagination" class="pagination justify-content-center">
                                    <!-- Pagination links will be populated here -->
                                </ul>
                            </nav>
                            <!-- Pagination End Here -->

                        </div>
                    </div>
                </div>
            </div>


            <!-- Add Subadmin Modal -->
            <div class="modal fade" id="AddSubadminModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content modal-content-3d">

                        <div class="modal-header modal-header-3d">
                            <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-person-plus-fill me-2"></i>Add Subadmin</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body modal-body-3d p-4">
                            <form id="add_form" action="javascript:void(0);" method="post">
                                @csrf
                                <div class="row g-3">
                                    <div class="col-sm-6">
                                        <label class="form-label form-label-3d">Username <span class="text-danger">*</span></label>
                                        <input type="text" name="name" id="name" class="form-control form-control-3d" placeholder="Enter Username">
                                        <span id="name_error" class="error-text"></span>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label form-label-3d">Email <span class="text-danger">*</span></label>
                                        <input type="email" name="email" id="email" class="form-control form-control-3d" placeholder="Enter Email">
                                        <span id="email_error" class="error-text"></span>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label form-label-3d">Mobile <span class="text-danger">*</span></label>
                                        <input type="number" name="mobile" id="mobile"
                                            oninput="if(this.value.length > 10) this.value = this.value.slice(0, 10);"
                                            class="form-control form-control-3d" placeholder="Enter Mobile">
                                        <span id="mobile_error" class="error-text"></span>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label form-label-3d">Password <span class="text-danger">*</span></label>
                                        <input type="password" name="password" id="password" class="form-control form-control-3d"
                                            placeholder="Enter Password">
                                        <span id="password_error" class="error-text"></span>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label form-label-3d">Permissions <span class="text-danger">*</span></label>
                                        <select name="permissions[]" id="add_permissions" data-placeholder="Choose Permissions..."
                                            class="form-control chosen-select chosen" multiple="multiple">
                                            <option value="Manage Category">Manage Category</option>
                                            <option value="Manage Residences">Manage Residences</option>
                                            <option value="Amenities & Wellness">Amenities & Wellness</option>
                                            <option value="Contacts & Leads">Contacts & Leads</option>
                                            <option value="Manage Gallery">Manage Gallery</option>
                                            <option value="Manage Blogs">Manage Blogs</option>
                                            <option value="Guest Reviews">Guest Reviews</option>
                                            <option value="Manage FAQ">Manage FAQ</option>
                                            <option value="Newsletter Subscribers">Newsletter Subscribers</option>
                                            <option value="Website & SEO Settings">Website & SEO Settings</option>
                                        </select>
                                        <span id="permissions_error" class="error-text"></span>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                    <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Delete Modal -->
            <div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
                    <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
                        <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                            <div
                                style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                                <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                            </div>
                            <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
                        </div>
                        <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                            <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this record? This
                                action <strong>cannot be undone.</strong></p>
                        </div>
                        <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                            <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                                @csrf
                                <input type="hidden" name="id" id="delete_id" value="">
                                <button type="button" class="btn" data-bs-dismiss="modal"
                                    style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                                <button type="submit" class="btn btn_delete"
                                    style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes,
                                    Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Delete Modal -->



            <script>
                var currentPage = 1;
                var searchKeyword = '';

                $(document).ready(function() {
                    $('#add_permissions').chosen({
                        width: '100%',
                        placeholder_text_multiple: 'Choose Permissions...',
                        no_results_text: 'No matching permissions'
                    });

                    $('#AddSubadminModal').on('shown.bs.modal', function () {
                        $('#add_permissions').chosen({
                            width: '100%',
                            placeholder_text_multiple: 'Choose Permissions...',
                            no_results_text: 'No matching permissions'
                        }).trigger('chosen:updated');
                    });

                    $('#AddSubadminModal').on('show.bs.modal', function () {
                        $('#add_form')[0].reset();
                        $('.error-text').text('');
                        $('.form-control, .form-control-3d').removeClass('is-invalid is-valid');
                        $('#add_permissions').val([]).trigger('chosen:updated');
                        isMobileAvailable = true;
                    });

                    // Search input
                    $('.search_contact').keyup(function () {
                        searchKeyword = $(this).val();
                        if (searchKeyword.length >= 3) {
                            currentPage = 1;
                            showdata(currentPage, searchKeyword);
                        } else {
                            if (searchKeyword.length === 0) {
                                showdata(currentPage, '');
                            }
                        }
                    });

                    // Reset filter
                    $('#reset_filter').click(function() {
                        $('.search_contact').val('');
                        searchKeyword = '';
                        currentPage = 1;
                        showdata(1);
                    });

                    // Initial load
                    showdata(1);
                });

                function validateName() {
                    var name = $("#name").val();
                    if (!name || name.trim() === "") {
                        $("#name_error").text("Username required");
                        $("#name").addClass("is-invalid");
                        return false;
                    } else if (name.length < 3) {
                        $("#name_error").text("Username must be at least 3 characters");
                        $("#name").addClass("is-invalid");
                        return false;
                    } else {
                        $("#name_error").text("");
                        $("#name").removeClass("is-invalid");
                        return true;
                    }
                }

                function validateEmail() {
                    var email = $("#email").val();
                    var emailReg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!email || email.trim() === "") {
                        $("#email_error").text("Email required");
                        $("#email").addClass("is-invalid");
                        return false;
                    } else if (!emailReg.test(email)) {
                        $("#email_error").text("Please enter a valid email address");
                        $("#email").addClass("is-invalid");
                        return false;
                    } else {
                        $("#email_error").text("");
                        $("#email").removeClass("is-invalid");
                        return true;
                    }
                }

                var isMobileAvailable = true;
                var mobileCheckTimer = null;

                function validateMobile() {
                    var mobile = $("#mobile").val();
                    if (!mobile || String(mobile).trim() === "") {
                        $("#mobile_error").html("Mobile required").removeClass('text-success').addClass('text-danger');
                        $("#mobile").removeClass("is-valid").addClass("is-invalid");
                        isMobileAvailable = false;
                        return false;
                    } else if (String(mobile).length != 10) {
                        $("#mobile_error").html("Mobile number must be exactly 10 digits").removeClass('text-success').addClass('text-danger');
                        $("#mobile").removeClass("is-valid").addClass("is-invalid");
                        isMobileAvailable = false;
                        return false;
                    } else if (!isMobileAvailable) {
                        $("#mobile_error").html('<i class="bi bi-x-circle me-1"></i>Mobile number already exists').removeClass('text-success').addClass('text-danger');
                        $("#mobile").removeClass("is-valid").addClass("is-invalid");
                        return false;
                    } else {
                        $("#mobile_error").text("");
                        $("#mobile").removeClass("is-invalid");
                        return true;
                    }
                }

                function checkLiveMobile() {
                    var mobile = $("#mobile").val();
                    if (mobile && String(mobile).length === 10) {
                        $("#mobile_error").html('<span class="text-muted"><i class="spinner-border spinner-border-sm me-1" style="width:12px;height:12px;"></i> Checking mobile...</span>');

                        $.ajax({
                            url: "{{ url('/check_subadmin_mobile') }}",
                            type: "POST",
                            data: {
                                mobile: mobile,
                                _token: $('meta[name="csrf-token"]').attr('content')
                            },
                            dataType: "json",
                            success: function(response) {
                                if (response.exists) {
                                    isMobileAvailable = false;
                                    $("#mobile").removeClass("is-valid").addClass("is-invalid");
                                    $("#mobile_error").html('<i class="bi bi-x-circle me-1"></i>Mobile number already exists!').removeClass('text-success').addClass('text-danger');
                                } else {
                                    isMobileAvailable = true;
                                    $("#mobile").removeClass("is-invalid").addClass("is-valid");
                                    $("#mobile_error").html('<i class="bi bi-check-circle me-1"></i>Mobile number is available').removeClass('text-danger').addClass('text-success');
                                }
                            },
                            error: function() {
                                isMobileAvailable = true;
                            }
                        });
                    }
                }

                function validatePassword() {
                    var password = $("#password").val();
                    if (!password || password.trim() === "") {
                        $("#password_error").text("Password required");
                        $("#password").addClass("is-invalid");
                        return false;
                    } else {
                        $("#password_error").text("");
                        $("#password").removeClass("is-invalid");
                        return true;
                    }
                }

                function validatePermissions() {
                    var perms = $("#add_permissions").val();
                    if (!perms || perms.length === 0) {
                        $("#permissions_error").text("Please select at least one permission");
                        return false;
                    } else {
                        $("#permissions_error").text("");
                        return true;
                    }
                }

                $("#name").on("input", validateName);
                $("#email").on("input", validateEmail);
                $("#mobile").on("input keyup paste", function () {
                    var mobile = $(this).val();
                    if (mobile.length > 10) {
                        $(this).val(mobile.slice(0, 10));
                    }
                    clearTimeout(mobileCheckTimer);
                    if ($(this).val().length === 10) {
                        checkLiveMobile();
                    } else {
                        validateMobile();
                    }
                });
                $("#password").on("input", validatePassword);
                $("#add_permissions").on("change", validatePermissions);

                $("#add_form").submit(function (e) {
                    e.preventDefault();

                    var isNameValid = validateName();
                    var isEmailValid = validateEmail();
                    var isMobileValid = validateMobile();
                    var isPasswordValid = validatePassword();
                    var isPermsValid = validatePermissions();

                    if (!isNameValid || !isEmailValid || !isMobileValid || !isPasswordValid || !isPermsValid) {
                        return false;
                    }

                    $(".btn_submit").prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Please Wait...');
                    var formdata = new FormData(this);

                    $.ajax({
                        type: "POST",
                        url: "{{ url('/add_subadmin') }}",
                        data: formdata,
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        contentType: false,
                        cache: false,
                        processData: false,
                        dataType: "json",
                        success: function (data) {
                            $(".btn_submit").prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Submit');

                            if (data.success == 'success') {
                                document.getElementById("add_form").reset();
                                setTimeout(function() {
                                    $("#add_permissions").val([]).trigger("chosen:updated");
                                }, 100);
                                $("#AddSubadminModal").modal("hide");
                                showToast('Subadmin Added Successfully', 'success');
                                showdata(currentPage, searchKeyword);
                            } else if (data.success == 'error') {
                                if (data.errors) {
                                    if (data.errors.name) { $("#name_error").text(data.errors.name[0]); $("#name").addClass("is-invalid"); }
                                    if (data.errors.email) { $("#email_error").text(data.errors.email[0]); $("#email").addClass("is-invalid"); }
                                    if (data.errors.mobile) { $("#mobile_error").text(data.errors.mobile[0]); $("#mobile").addClass("is-invalid"); }
                                    if (data.errors.password) { $("#password_error").text(data.errors.password[0]); $("#password").addClass("is-invalid"); }
                                    if (data.errors.permissions) { $("#permissions_error").text(data.errors.permissions[0]); }
                                    var errorMessages = Object.values(data.errors).flat().join("<br>");
                                    showToast(errorMessages, 'error');
                                } else {
                                    showToast(data.message || "Something went wrong", 'error');
                                }
                            }
                        },
                        error: function (xhr) {
                            $(".btn_submit").prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Submit');
                            let errorMsg = "Something went wrong";
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                errorMsg = xhr.responseJSON.message;
                            }
                            showToast(errorMsg, 'error');
                        }
                    });
                });

                function showdata(page = 1, search = '') {
                    var search_data = search !== undefined && search !== null && search !== '' ? search : $(".search_contact").val();

                    $.ajax({
                        url: "{{ url('/show_subadmin') }}",
                        type: 'POST',
                        data: {
                            search: search_data,
                            page: page,
                        },
                        success: function (response) {
                            var tbody = $('#donationTable tbody');
                            var pagination = $('#pagination');
                            var result = response.data;

                            tbody.empty();
                            pagination.empty();

                            if (response.data && response.data.length > 0) {
                                currentPage = response.current_page;
                            } else {
                                if (page > 1) {
                                    showdata(page - 1, search_data);
                                    return;
                                }
                                currentPage = 1;
                            }

                            // Indexing 
                            var total_enquiries = response.total;
                            var per_page = response.per_page;
                            result = response.data;

                            result.forEach(function (data, index) {
                                var createdAtVal = formatDateTime(data.created_at);

                                tbody.append(`
                                    <tr>
                                        <td>${index + 1 + (response.current_page - 1) * response.per_page}</td>
                                        <td>
                                            <div class="d-flex justify-content-start gap-1">
                                                <a href="javascript:void(0);" class="btn-act-edit edit" title="Edit" data-id="${data.id}"><i class="bi bi-pencil-fill"></i></a>
                                                <a href="javascript:void(0);" class="btn-act-del delete" title="Delete" data-id="${data.id}"><i class="bi bi-trash3-fill"></i></a>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <label class="custom-switch">
                                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input StatusSwitch" value="${data.id}" ${data.status == 1 ? 'checked' : ''}>
                                                <span class="custom-switch-indicator"></span>
                                            </label>
                                        </td>
                                        <td class="fw-bold text-dark">${data.name ?? ''}</td>
                                        <td>${data.email ?? ''}</td>
                                        <td>${data.mobile ?? ''}</td>
                                        <td><code class="text-muted">${data.password ?? ''}</code></td>
                                        <td><span class="badge bg-primary-subtle text-primary border">${data.user_type ?? 'Subadmin'}</span></td>
                                        <td>${data.permissions ?? ''}</td>
                                        <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                                    </tr>
                                `);
                            });

                            // Function to handle the pagination links with ellipsis (1 2 ... 7 8)
                            function generatePaginationLinks(currentPage, lastPage, searchKeyword) {
                                let pagination = $('#pagination');
                                searchKeyword = searchKeyword || '';
                                pagination.html('');
                                if (currentPage > 3) {
                                    pagination.append(`
                                        <li class="page-item">
                                            <a class="page-link" href="javascript:void(0);" onclick="showdata(1, '${searchKeyword}')">1</a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="javascript:void(0);" onclick="showdata(2, '${searchKeyword}')">2</a>
                                        </li>
                                        <li class="page-item disabled"><a class="page-link">...</a></li>
                                    `);
                                }

                                // Show the current page and two pages before and after it
                                for (let i = Math.max(1, currentPage - 2); i <= Math.min(lastPage, currentPage + 2); i++) {
                                    pagination.append(`
                                        <li class="page-item ${i === currentPage ? 'active' : ''}">
                                            <a class="page-link" href="javascript:void(0);" onclick="showdata(${i}, '${searchKeyword}')">${i}</a>
                                        </li>
                                    `);
                                }

                                // Show the last two pages
                                if (currentPage < lastPage - 2) {
                                    pagination.append(`
                                        <li class="page-item disabled"><a class="page-link">...</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage - 1}, '${searchKeyword}')">${lastPage - 1}</a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage}, '${searchKeyword}')">${lastPage}</a>
                                        </li>
                                    `);
                                }
                            }

                            // Call this function where you handle pagination
                            if (response.last_page > 1) {
                                generatePaginationLinks(response.current_page, response.last_page);
                            }
                        }
                    });
                }

                // delete 
                $(document).on('click', '.delete', function () {
                    var id = $(this).data("id");
                    $("#delete_id").val(id);
                    $("#deletemodal").modal("show");
                });

                // delete form submit
                $("#delete_form").submit(function (e) {
                    $(".btn_delete").prop('disabled', true);
                    e.preventDefault();
                    var formData = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: "{{url('/delete_subadmin')}}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        cache: false,
                        encode: true,
                        success: function (data) {
                            $(".btn_delete").prop('disabled', false);
                            if (data.success == 'success') {
                                $("#deletemodal").modal("hide");
                                $("#delete_form")[0].reset();
                                showToast('Subadmin Deleted Successfully', 'success');
                                showdata(currentPage, searchKeyword);
                            } else {
                                showToast('Subadmin Not Deleted', 'error');
                            }
                        },
                        error: function (error) {
                            $(".btn_delete").prop("disabled", false);
                            showToast('Something Went Wrong!', 'error');
                        }
                    });
                });

                $(document).on('click', '.edit', function () {
                    var id = $(this).data('id');
                    var url = "/edit_subadmin/" + id;
                    window.location.href = url;
                });

                // export excel data from here 
                $('#exportButtonExcel').on('click', function () {
                    $.ajax({
                        url: "{{url('/export_to_excel')}}",
                        type: 'GET',
                        data: {
                            table_name: "admin",
                            search: searchKeyword
                        },
                        success: function (response) {
                            var result = JSON.parse(response);
                            if (result.data) {
                                // Create a new Workbook and Worksheet
                                var workbook = XLSX.utils.book_new();

                                // Remove anchor tags and their contents from the data
                                var cleanedData = result.data.map(function (row) {
                                    var cleanedRow = Object.assign({}, row);

                                    for (var key in cleanedRow) {
                                        if (cleanedRow.hasOwnProperty(key) && typeof cleanedRow[key] === 'string') {
                                            cleanedRow[key] = cleanedRow[key].replace(/<a\b[^>]*>(.*?)<\/a>/g, '');
                                        }
                                    }

                                    return cleanedRow;
                                });

                                // Convert the data to a worksheet
                                var worksheet = XLSX.utils.json_to_sheet(cleanedData);

                                // Add the Worksheet to the Workbook
                                XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

                                // Convert the Workbook to an Excel file
                                var excelData = XLSX.write(workbook, {
                                    bookType: 'xlsx',
                                    type: 'array'
                                });

                                // Save the Excel file as a Blob
                                var blob = new Blob([excelData], {
                                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                                });
                                saveAs(blob, 'Subadmin.xlsx');
                            }
                        }
                    });
                });
            </script>

        @endsection
    @endforeach
@else
    <script>
        location.href = "{{url('/login')}}";
    </script>
@endif