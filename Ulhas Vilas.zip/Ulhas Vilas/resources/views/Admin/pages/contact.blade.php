@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<style>
    .table-responsive-athlo {
        width: 100%;
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
    }
    .table-athlo {
        margin-bottom: 0 !important;
        width: 100%;
    }
    .table-athlo th {
        background-color: #f8fafc;
        color: #475569;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        padding: 12px 16px;
        border-bottom: 2px solid #e2e8f0;
        white-space: nowrap !important;
    }
    .table-athlo td {
        padding: 12px 16px;
        vertical-align: middle;
        color: #334155;
        font-size: 13px;
        white-space: nowrap;
    }
    .table-athlo td.td-wrap-message {
        white-space: normal !important;
        min-width: 280px !important;
        max-width: 420px !important;
        word-break: break-word !important;
        line-height: 1.5 !important;
        color: #334155 !important;
        font-size: 12.5px;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                <!-- Filter & Top Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="row align-items-end g-3">
                        <div class="col-xl-4 col-lg-4 col-md-5">
                            <label class="filter-section-title">SEARCH CONTACTS & INQUIRIES</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_contact" placeholder="Search by client name, mobile, email, residence..." />
                                </div>
                                <button type="button" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Created Date Range -->
                        <div class="col-xl-3 col-lg-3 col-md-5">
                            <label class="filter-section-title">CREATED DATE RANGE</label>
                            <div class="input-group">
                                <span class="input-group-text date-icon-box" id="open_date_picker"><i class="bi bi-calendar3"></i></span>
                                <input type="text" id="filter_date_range" class="form-control filter-date-pill" placeholder="Select Date Range..." readonly />
                            </div>
                        </div>

                        <!-- Reset Filter Button -->
                        <div class="col-xl-auto col-lg-auto col-md-auto">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Contacts & Leads Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="contactTable" class="table table-hover table-athlo align-middle">
                        <thead class="th-nowrap">
                            <tr>
                                <th>#</th>
                                <th>Full Name</th>
                                <th>Phone Number</th>
                                <th>Email Address</th>
                                <th style="min-width:180px;">Residence Name</th>
                                <th style="min-width:140px;">Category</th>
                                <th>Subject</th>
                                <th style="min-width:280px;">Message</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        var fpInstance = null;
        if (typeof flatpickr !== 'undefined') {
            fpInstance = flatpickr("#filter_date_range", {
                mode: "range",
                dateFormat: "Y-m-d",
                allowInput: false,
                onClose: function (selectedDates, dateStr, instance) {
                    currentContactPage = 1;
                    loadContacts(1);
                }
            });
        }

        $('#open_date_picker').click(function () {
            if (fpInstance) {
                fpInstance.open();
            }
        });

        var currentContactPage = 1;
        loadContacts(1);

        $('.search_contact').on('keyup', function () {
            currentContactPage = 1;
            loadContacts(1);
        });

        $('#reset_filter').on('click', function () {
            $('.search_contact').val('');
            if (fpInstance) {
                fpInstance.clear();
            }
            currentContactPage = 1;
            loadContacts(1);
        });

        function loadContacts(page) {
            var pageNum = page || currentContactPage || 1;
            var search = $(".search_contact").val();
            var date_data = $("#filter_date_range").val();

            $.ajax({
                url: "{{ url('/admin-contact') }}",
                type: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    search: search,
                    date: date_data,
                    page: pageNum,
                },
                success: function (res) {
                    var tbody = $('#contactTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentContactPage = res.current_page;
                        res.data.forEach(function (item, index) {
                            var subjectVal = item.subject || 'General Inquiry';
                            var createdAtVal = item.created_at ? formatDateTime(item.created_at) : (item.date || '-');
                            var updatedAtVal = item.updated_at ? formatDateTime(item.updated_at) : '-';

                            var resBadge = (item.residence_name && item.residence_name !== '-')
                                ? `<span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-building text-warning me-1"></i>${item.residence_name}</span>`
                                : `<span class="text-muted small">-</span>`;

                            var catBadge = (item.category_name && item.category_name !== '-')
                                ? `<span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-tag text-primary me-1"></i>${item.category_name}</span>`
                                : `<span class="text-muted small">-</span>`;

                            tbody.append(`
                                <tr>
                                    <td class="text-nowrap">${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td class="fw-bold text-dark text-nowrap">${item.name || '-'}</td>
                                    <td class="text-nowrap"><a href="tel:${item.mobile || ''}" class="text-dark fw-semibold text-decoration-none text-nowrap d-inline-flex align-items-center"><i class="bi bi-telephone-fill text-success me-1"></i>${item.mobile || '-'}</a></td>
                                    <td class="text-nowrap"><a href="mailto:${item.email || ''}" class="text-decoration-none text-nowrap d-inline-flex align-items-center" style="color:#334155; font-weight:500;"><i class="bi bi-envelope-fill text-primary me-1"></i>${item.email || '-'}</a></td>
                                    <td class="text-nowrap">${resBadge}</td>
                                    <td class="text-nowrap">${catBadge}</td>
                                    <td class="text-nowrap"><span class="badge bg-primary-subtle text-primary border px-2 py-1 text-nowrap"><i class="bi bi-chat-left-text me-1"></i>${subjectVal}</span></td>
                                    <td class="td-wrap-message">${item.message || '-'}</td>
                                    <td class="text-nowrap" style="font-size:12.5px;color:#475569;"><span class="badge bg-light text-dark border text-nowrap"><i class="bi bi-calendar-check me-1 text-primary"></i>${createdAtVal}</span></td>
                                    <td class="text-nowrap" style="font-size:12.5px;color:#475569;"><span class="badge bg-light text-dark border text-nowrap"><i class="bi bi-clock-history me-1 text-secondary"></i>${updatedAtVal}</span></td>
                                </tr>
                            `);
                        });
                    } else {
                        if (pageNum > 1) {
                            loadContacts(pageNum - 1);
                            return;
                        }
                        currentContactPage = 1;
                        tbody.append('<tr><td colspan="10" class="text-center py-4 text-muted">No contact messages found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link" href="javascript:void(0);" onclick="loadContacts(${p})">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }
        window.loadContacts = loadContacts;
    });
</script>

@endsection
@endif