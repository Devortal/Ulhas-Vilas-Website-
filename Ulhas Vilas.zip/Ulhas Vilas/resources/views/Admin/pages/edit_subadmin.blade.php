@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<!-- Tagify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
<!-- Chosen CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css">

<style>
    .error-text {
        color: #dc3545;
        font-size: 12px;
        margin-top: 3px;
        display: block;
        font-weight: 500;
        line-height: 1.2;
    }
    .form-control.is-invalid, .form-control-3d.is-invalid {
        border-color: #dc3545 !important;
        background-color: rgba(220, 53, 69, 0.05) !important;
    }
</style>

<div class="container-fluid mt-2">
    <div class="row">
        <div class="col-12">
            <!-- Single Outer Main Card Container -->
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white">
                <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom">
                    <h4 class="mb-0 fw-bold" style="color: #0f233a; font-family: 'Marcellus', serif; font-size: 20px;">
                        <i class="bi bi-person-gear me-2 text-warning"></i>Edit Subadmin
                    </h4>
                    <a href="{{ route('subadmin') }}" class="btn btn-secondary-3d px-3 py-1">
                        <i class="bi bi-arrow-left me-1"></i> Back to List
                    </a>
                </div>

                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        <form id="edit_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $edit_admin->id ?? '' }}">
                        
                            <div class="row g-3">
                                <div class="col-sm-6">
                                    <label for="edit_name" class="form-label form-label-3d">Username <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control form-control-3d" id="edit_name" value="{{ $edit_admin->name ?? '' }}">
                                    <span id="name_error" class="error-text"></span>
                                </div>
                        
                                 <div class="col-sm-6">
                                    <label for="edit_email" class="form-label form-label-3d">Email <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control form-control-3d" id="edit_email" value="{{ $edit_admin->email ?? '' }}">
                                    <span id="email_error" class="error-text"></span>
                                </div>
                                
                                <div class="col-sm-6">
                                    <label for="edit_mobile" class="form-label form-label-3d">Mobile <span class="text-danger">*</span></label>
                                    <input type="number" name="mobile" class="form-control form-control-3d" id="edit_mobile" oninput="if(this.value.length > 10) this.value = this.value.slice(0, 10);" value="{{ $edit_admin->mobile ?? '' }}">
                                    <span id="mobile_error" class="error-text"></span>
                                </div>
                                <div class="col-sm-6">
                                    <label for="edit_password" class="form-label form-label-3d">Password <span class="text-danger">*</span></label>
                                    <input type="text" name="password" class="form-control form-control-3d" id="edit_password" value="{{ $edit_admin->password ?? '' }}">
                                    <span id="password_error" class="error-text"></span>
                                </div>
                                
                                <div class="col-12">
    								<label class="form-label form-label-3d">Permissions <span class="text-danger">*</span></label>
    								<select required data-placeholder="Choose Permissions..." name="permissions[]" multiple class="chosen-select chosen form-control" id="edit_permissions">
    									<option value="Manage Category" {{ in_array('Manage Category', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Manage Category</option>
    									<option value="Manage Residences" {{ in_array('Manage Residences', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Packages', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Manage Residences</option>
    									<option value="Amenities & Wellness" {{ in_array('Amenities & Wellness', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Amenities', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Amenities & Wellness</option>
    									<option value="Contacts & Leads" {{ in_array('Contacts & Leads', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Contact', explode(',', $edit_admin->permissions ?? '')) || in_array('Contacts', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Contacts & Leads</option>
    									<option value="Manage Gallery" {{ in_array('Manage Gallery', explode(',', $edit_admin->permissions ?? '')) || in_array('Gallery', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Manage Gallery</option>
    									<option value="Manage Blogs" {{ in_array('Manage Blogs', explode(',', $edit_admin->permissions ?? '')) || in_array('Blogs', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Manage Blogs</option>
    									<option value="Guest Reviews" {{ in_array('Guest Reviews', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Reviews', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Testimonials', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Guest Reviews</option>
    									<option value="Manage FAQ" {{ in_array('Manage FAQ', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage FAQs', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Manage FAQ</option>
    									<option value="Newsletter Subscribers" {{ in_array('Newsletter Subscribers', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Newsletter', explode(',', $edit_admin->permissions ?? '')) || in_array('Newsletter', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Newsletter Subscribers</option>
    									<option value="Website & SEO Settings" {{ in_array('Website & SEO Settings', explode(',', $edit_admin->permissions ?? '')) || in_array('Website Settings', explode(',', $edit_admin->permissions ?? '')) || in_array('Manage Setting', explode(',', $edit_admin->permissions ?? '')) ? 'selected' : '' }}>Website & SEO Settings</option>
    								</select>
    								<span id="permissions_error" class="error-text"></span>
    							</div>
                                
                            </div>
                            
                        
                            <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                                <a href="{{ route('subadmin') }}" class="btn btn-secondary-3d">Cancel</a>
                                <button type="submit" class="btn btn-submit-3d btn_update"><i class="bi bi-check2-circle me-1"></i>Update Subadmin</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<script>

$(document).ready(function() {
    $('#edit_permissions').chosen({
        width: '100%',
        placeholder_text_multiple: 'Choose Permissions...',
        no_results_text: 'No matching permissions'
    });
});

function validateEditName() {
    var name = $("#edit_name").val();
    if(name.trim() === "") {
        $("#name_error").text("Username required");
        $("#edit_name").addClass("is-invalid");
        return false;
    } else if(name.length < 3) {
        $("#name_error").text("Username must be at least 3 characters");
        $("#edit_name").addClass("is-invalid");
        return false;
    } else {
        $("#name_error").text("");
        $("#edit_name").removeClass("is-invalid");
        return true;
    }
}

function validateEditEmail() {
    var email = $("#edit_email").val();
    var emailReg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(email.trim() === "") {
        $("#email_error").text("Email required");
        $("#edit_email").addClass("is-invalid");
        return false;
    } else if(!emailReg.test(email)) {
        $("#email_error").text("Please enter a valid email address");
        $("#edit_email").addClass("is-invalid");
        return false;
    } else {
        $("#email_error").text("");
        $("#edit_email").removeClass("is-invalid");
        return true;
    }
}

var isEditMobileAvailable = true;
var editMobileCheckTimer = null;

function validateEditMobile() {
    var mobile = $("#edit_mobile").val();
    if (!mobile || String(mobile).trim() === "") {
        $("#mobile_error").html("Mobile required").removeClass('text-success').addClass('text-danger');
        $("#edit_mobile").removeClass("is-valid").addClass("is-invalid");
        isEditMobileAvailable = false;
        return false;
    } else if (String(mobile).length != 10) {
        $("#mobile_error").html("Mobile number must be exactly 10 digits").removeClass('text-success').addClass('text-danger');
        $("#edit_mobile").removeClass("is-valid").addClass("is-invalid");
        isEditMobileAvailable = false;
        return false;
    } else if (!isEditMobileAvailable) {
        $("#mobile_error").html('<i class="bi bi-x-circle me-1"></i>Mobile number already exists').removeClass('text-success').addClass('text-danger');
        $("#edit_mobile").removeClass("is-valid").addClass("is-invalid");
        return false;
    } else {
        $("#mobile_error").text("");
        $("#edit_mobile").removeClass("is-invalid");
        return true;
    }
}

function checkLiveEditMobile() {
    var mobile = $("#edit_mobile").val();
    var id = $("input[name='id']").val();
    if (mobile && String(mobile).length === 10) {
        $("#mobile_error").html('<span class="text-muted"><i class="spinner-border spinner-border-sm me-1" style="width:12px;height:12px;"></i> Checking mobile...</span>');

        $.ajax({
            url: "{{ url('/check_subadmin_mobile') }}",
            type: "POST",
            data: {
                mobile: mobile,
                id: id,
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            dataType: "json",
            success: function(response) {
                if (response.exists) {
                    isEditMobileAvailable = false;
                    $("#edit_mobile").removeClass("is-valid").addClass("is-invalid");
                    $("#mobile_error").html('<i class="bi bi-x-circle me-1"></i>Mobile number already exists!').removeClass('text-success').addClass('text-danger');
                } else {
                    isEditMobileAvailable = true;
                    $("#edit_mobile").removeClass("is-invalid").addClass("is-valid");
                    $("#mobile_error").html('<i class="bi bi-check-circle me-1"></i>Mobile number is available').removeClass('text-danger').addClass('text-success');
                }
            },
            error: function() {
                isEditMobileAvailable = true;
            }
        });
    }
}

function validateEditPassword() {
    var password = $("#edit_password").val();
    if(!password || password.trim() === "") {
        $("#password_error").text("Password required");
        $("#edit_password").addClass("is-invalid");
        return false;
    } else {
        $("#password_error").text("");
        $("#edit_password").removeClass("is-invalid");
        return true;
    }
}

function validateEditPermissions() {
    var perms = $("#edit_permissions").val();
    if(!perms || perms.length === 0) {
        $("#permissions_error").text("Please select at least one permission");
        return false;
    } else {
        $("#permissions_error").text("");
        return true;
    }
}

$("#edit_name").on("input", validateEditName);
$("#edit_email").on("input", validateEditEmail);
$("#edit_mobile").on("input keyup paste", function () {
    var mobile = $(this).val();
    if (mobile.length > 10) {
        $(this).val(mobile.slice(0, 10));
    }
    clearTimeout(editMobileCheckTimer);
    if ($(this).val().length === 10) {
        checkLiveEditMobile();
    } else {
        validateEditMobile();
    }
});
$("#edit_password").on("input", validateEditPassword);
$("#edit_permissions").on("change", validateEditPermissions);

$("#edit_form").submit(function(e) {
    e.preventDefault();

    var isNameValid = validateEditName();
    var isEmailValid = validateEditEmail();
    var isMobileValid = validateEditMobile();
    var isPasswordValid = validateEditPassword();
    var isPermsValid = validateEditPermissions();

    if(!isNameValid || !isEmailValid || !isMobileValid || !isPasswordValid || !isPermsValid) {
        return false;
    }

    $(".btn_update").prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Updating...');
    var formData = new FormData(this);
    
    $.ajax({
        type: "POST",
        url: "{{ url('/update_subadmin') }}",
        data: formData,
        dataType: "json",
        contentType: false,
        processData: false,
        cache: false,
        success: function(data) {
            $(".btn_update").prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Update Subadmin');

            if (data.success == 'success') {
                showToast('Subadmin Updated Successfully', 'success');
                setTimeout(function() {
                    window.location.href = "{{ route('subadmin')}}";
                }, 1200);
            } else if (data.success == 'error') {
                if (data.errors) {
                    if (data.errors.name) { $("#name_error").text(data.errors.name[0]); $("#edit_name").addClass("is-invalid"); }
                    if (data.errors.email) { $("#email_error").text(data.errors.email[0]); $("#edit_email").addClass("is-invalid"); }
                    if (data.errors.mobile) { $("#mobile_error").text(data.errors.mobile[0]); $("#edit_mobile").addClass("is-invalid"); }
                    if (data.errors.password) { $("#password_error").text(data.errors.password[0]); $("#edit_password").addClass("is-invalid"); }
                    if (data.errors.permissions) { $("#permissions_error").text(data.errors.permissions[0]); }
                    var errorMessages = Object.values(data.errors).flat().join("\n");
                    showToast(errorMessages, 'error');
                } else {
                    showToast(data.message || "Update Failed!", 'error');
                }
            }
        },
        error: function(xhr) {
            $(".btn_update").prop('disabled', false).html('<i class="bi bi-check2-circle me-1"></i>Update Subadmin');
            let errorMsg = "Something went wrong";
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMsg = xhr.responseJSON.message;
            }
            showToast(errorMsg, 'error');
        }
    });
});
</script>

@endsection
@else
<script>
    location.href = "{{url('/login')}}";
</script>
@endif
