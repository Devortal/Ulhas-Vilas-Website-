@if(Session::get('admin_login'))
@foreach(session()->get('admin_login') as $adminlogin)
@extends('Admin.layouts.master')
@section('main-content')


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body" style="height:460px">
                    <div class="tab-content">
                        <div class="tab-pane show active" id="form-row-preview">
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-6">
                                    <form action="javascript:void(0);" method="post" id="add_form">
                                        @csrf
                                        <div class="row g-2">
                                            <input type="hidden" id="admin_id" name="admin_id" value="{{$adminlogin->id}}" />
                                            <div class="mb-3 col-md-12">
                                                <label for="eventInput1">Name</label>
                                                <input id="name" value="{{$adminlogin->name}}" class="form-control" placeholder="Name" type="text" name="name">
                                            </div>
                                            <div class="mb-3 col-md-12">
                                                <label for="eventInput2">Email Address</label>
                                                <input class="form-control" value="{{$adminlogin->email}}" type="text" id="email" name="email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="mb-3 col-md-12">
                                            <label for="eventInput3">Mobile No</label>
                                            <input type="number" value="{{$adminlogin->mobile}}" name="mobile" id="mobile" class="form-control" placeholder="Mobile">
                                        </div>
                                        <button type="submit" class="btn btn-primary">Update Profile</button>
                                    </form>
                                </div>
                                <div class="col-md-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>




<script>
    // category add here 
    $("#add_form").submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{url('/profile/admin')}}",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {
                    showToast('Profile updated successfully!', 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 800);
                } else {
                    showToast("Something went wrong", "error");
                }
            },
            error: function(err) {
                showToast("Something went wrong", "error");
            }
        });

    });
    // category end here
</script>
@endsection
@endforeach
@else
<script>
    location.href = "{{url('/login')}}";
</script>
@endif