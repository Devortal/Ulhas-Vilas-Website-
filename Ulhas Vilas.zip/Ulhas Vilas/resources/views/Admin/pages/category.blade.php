@if (Session::get('admin_login'))
    @foreach (session()->get('admin_login') as $adminlogin)
        @extends('Admin.layouts.master')
        @section('main-content')
        
            <div class="container-fluid mt-2">
                <div class="row">
                    <div class="col-12">
                        <!-- Single Outer Main Card Container -->
                        <div class="card p-4 rounded-4 shadow-sm border-0 bg-white">
                            <!-- AthloNext Single Balanced Filter Card Container -->
                            <div class="filter-card-container mb-4">
                                <div class="row align-items-end g-3">
                                    <!-- Search All Categories -->
                                    <div class="col-xl-4 col-lg-4 col-md-6">
                                        <label class="filter-section-title">SEARCH ALL CATEGORIES</label>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="search-input-pill flex-grow-1">
                                                <i class="bi bi-search"></i>
                                                <input type="text" class="search_contact" placeholder="Search category..." />
                                            </div>
                                            <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel / CSV">
                                                <i class="bi bi-file-earmark-excel-fill"></i>
                                            </a>
                                        </div>
                                    </div>

                                    <!-- Created Date Range -->
                                    <div class="col-xl-3 col-lg-3 col-md-6">
                                        <label class="filter-section-title">CREATED DATE RANGE</label>
                                        <div class="input-group">
                                            <span class="input-group-text date-icon-box" id="open_date_picker"><i class="bi bi-calendar3"></i></span>
                                            <input type="text" id="filter_date_range" class="form-control filter-date-pill" placeholder="Select Date Range..." readonly />
                                        </div>
                                    </div>

                                    <!-- Reset Button -->
                                    <div class="col-xl-auto col-lg-auto col-md-auto">
                                        <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                            <i class="bi bi-arrow-counterclockwise"></i> Reset
                                        </button>
                                    </div>

                                    <!-- Add Category Button -->
                                    <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                                        <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddCategoryModal">
                                            <i class="bi bi-plus-lg me-1"></i> Add Category
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- AthloNext Table Container Inside Same Main Card -->
                            <div class="table-responsive-athlo mb-3">
                                <table id="categoryTable" class="table table-athlo nowrap w-100">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ACTION</th>
                                            <th>STATUS</th>
                                            <th>CATEGORY NAME</th>
                                            <th>CREATED AT</th>
                                            <th>UPDATED AT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Pagination Start Here -->
                            <nav class="mt-2">
                                <ul id="pagination" class="pagination justify-content-center"></ul>
                            </nav>
                            <!-- Pagination End Here -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add Category Modal -->
            <div class="modal fade" id="AddCategoryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-content-3d">
                        <div class="modal-header modal-header-3d">
                            <h5 class="modal-title" id="exampleModalLabel"><i class="bi bi-folder-plus me-2"></i>Add Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-3d">
                            <form id="add_form" action="javascript:void(0);" method="post">
                                @csrf
                                <div class="mb-3">
                                    <label for="category_name" class="form-label form-label-3d">Category Name <span class="text-danger">*</span></label>
                                    <input type="text" name="category_name" class="form-control form-control-3d" id="category_name"
                                        placeholder="e.g. Luxury Villas" required>
                                </div>

                                <div class="d-flex justify-content-end gap-2 mt-4">
                                    <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Delete Modal -->
            <div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
                    <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
                        <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                            <div
                                style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                                <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                            </div>
                            <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
                        </div>
                        <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                            <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this
                                record? This action <strong>cannot be undone.</strong></p>
                        </div>
                        <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                            <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                                @csrf
                                <input type="hidden" name="id" id="delete_id" value="">
                                <button type="button" class="btn" data-bs-dismiss="modal"
                                    style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                                <button type="submit" class="btn btn_delete"
                                    style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes,
                                    Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Delete Modal -->
            <!-- Edit Modal -->
            <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-content-3d">
                        <div class="modal-header modal-header-3d">
                            <h5 class="modal-title" id="editModalLabel"><i class="bi bi-pencil-square me-2"></i>Edit Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-3d">
                            <form id="edit_form" action="javascript:void(0);" method="post">
                                @csrf
                                <input type="hidden" name="id" id="edit_id" value="">
                                <div class="mb-3">
                                    <label for="edit_category_name" class="form-label form-label-3d">Category Name <span class="text-danger">*</span></label>
                                    <input type="text" name="category_name" id="edit_category_name" value=""
                                        class="form-control form-control-3d" required>
                                </div>
                                <div class="d-flex justify-content-end gap-2 mt-4">
                                    <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-submit-3d btn_update"><i class="bi bi-check2-circle me-1"></i>Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Edit Modal -->





            <script>
                let currentPage = 1;
                var searchKeyword = '';

                $("#add_form").submit(function (e) {
                    e.preventDefault();

                    var category_name = $("#category_name").val();

                    if (!category_name) {
                        showToast('Category Name Required', 'error');
                        return;
                    }

                    $(".btn_submit").prop('disabled', true);

                    var formdata = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: "{{ url('/add_category') }}",
                        data: formdata,
                        contentType: false,
                        cache: false,
                        processData: false,
                        dataType: "json",
                        success: function (data) {
                            $(".btn_submit").prop('disabled', false);

                            if (data.success == 'success') {
                                $("#add_form")[0].reset();
                                $("#AddCategoryModal").modal("hide");
                                showToast('Category Added Successfully', 'success');
                                showdata(currentPage, searchKeyword);
                            } else {
                                showToast(data.message || "Category Not Added", 'error');
                            }
                        },
                        error: function (xhr) {
                            $(".btn_submit").prop('disabled', false);

                            let errorMsg = "Something went wrong";
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                errorMsg = xhr.responseJSON.message;
                            }

                            showToast(errorMsg, 'error');
                        }
                    });
                });

                // switch end here
                var fpInstance = null;

                $(document).ready(function () {
                    if (typeof flatpickr !== 'undefined') {
                        fpInstance = flatpickr("#filter_date_range", {
                            mode: "range",
                            dateFormat: "Y-m-d",
                            allowInput: false,
                            onClose: function (selectedDates, dateStr, instance) {
                                currentPage = 1;
                                showdata(currentPage);
                            }
                        });
                    }

                    $('#open_date_picker').click(function () {
                        if (fpInstance) {
                            fpInstance.open();
                        }
                    });

                    $('.search_contact').keyup(function () {
                        currentPage = 1;
                        showdata(currentPage);
                    });

                    $('#reset_filter').click(function () {
                        $('.search_contact').val('');
                        if (fpInstance) {
                            fpInstance.clear();
                        }
                        currentPage = 1;
                        showdata(currentPage);
                    });

                    showdata();
                });

                function showdata(page = 1) {
                    var search_data = $(".search_contact").val();
                    var date_data = $("#filter_date_range").val();

                    $.ajax({
                        url: "{{ url('/searchdata') }}",
                        type: 'POST',
                        data: {
                            search: search_data,
                            date: date_data,
                            page: page,
                        },
                        success: function (response) {
                            var tbody = $('#categoryTable tbody');
                            var pagination = $('#pagination');
                            tbody.empty();
                            pagination.empty();

                            if (response.data && response.data.length > 0) {
                                currentPage = response.current_page;
                            } else {
                                if (page > 1) {
                                    showdata(page - 1);
                                    return;
                                }
                                currentPage = 1;
                            }
                            var result = response.data;

                            result.forEach(function (data, index) {
                                var createdAtVal = formatDateTime(data.created_at || data.date);
                                var updatedAtVal = formatDateTime(data.updated_at);

                                tbody.append(`
                                                                             <tr>
                                                                                 <td>${index + 1 + (response.current_page - 1) * response.per_page}</td>
                                                                                 <td>
                                                                                      <div class="d-flex gap-1">
                                                                                          <a href="javascript:void(0);" class="btn-act-edit edit" title="Edit" data-category_name="${data.category_name}" data-id="${data.id}"><i class="bi bi-pencil-fill"></i></a>
                                                                                          <a class="btn-act-del delete" title="Delete" href="javascript:void(0);" data-id="${data.id}"><i class="bi bi-trash3-fill"></i></a>
                                                                                      </div>
                                                                                 </td>
                                                                                 <td class="text-center">
                                                                                     <label class="custom-switch">
                                                                                         <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input StatusSwitch" value="${data.id}" ${data.status == 1 ? 'checked' : ''}>
                                                                                         <span class="custom-switch-indicator"></span>
                                                                                     </label>
                                                                                 </td>
                                                                                 <td style="font-weight: 600;">${data.category_name}</td>
                                                                                 <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                                                                                 <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-arrow-repeat me-1 text-primary"></i>${updatedAtVal}</span></td>
                                                                             </tr>
                                                                        `);
                            });

                            function generatePaginationLinks(currentPage, lastPage, searchKeyword) {
                                let pagination = $('#pagination');
                                searchKeyword = searchKeyword || '';
                                pagination.html('');
                                if (currentPage > 3) {
                                    pagination.append(`
                                                                                    <li class="page-item">
                                                                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(1, '${searchKeyword}')">1</a>
                                                                                    </li>
                                                                                    <li class="page-item">
                                                                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(2, '${searchKeyword}'">2</a>
                                                                                    </li>
                                                                                    <li class="page-item disabled"><a class="page-link">...</a></li>
                                                                                `);
                                }

                                for (let i = Math.max(1, currentPage - 2); i <= Math.min(lastPage, currentPage +
                                    2); i++) {
                                    pagination.append(`
                                                                                    <li class="page-item ${i === currentPage ? 'active' : ''}">
                                                                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(${i}, '${searchKeyword}')">${i}</a>
                                                                                    </li>
                                                                                `);
                                }

                                if (currentPage < lastPage - 2) {
                                    pagination.append(`
                                                                                    <li class="page-item disabled"><a class="page-link">...</a></li>
                                                                                    <li class="page-item">
                                                                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage - 1}, '${searchKeyword}')">${lastPage - 1}</a>
                                                                                    </li>
                                                                                    <li class="page-item">
                                                                                        <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage}, '${searchKeyword}')">${lastPage}</a>
                                                                                    </li>
                                                                                `);
                                }
                            }

                            if (response.last_page > 1) {
                                generatePaginationLinks(response.current_page, response.last_page);
                            }

                        }
                    });
                }

                $(document).on('click', '.delete', function () {
                    var id = $(this).data("id");
                    $("#delete_id").val(id);
                    $("#deletemodal").modal("show");
                });

                $("#delete_form").submit(function (e) {
                    e.preventDefault();
                    $(".btn_delete").prop('disabled', true);

                    var formData = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: "{{ url('/delete_category') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        cache: false,
                        success: function (data) {
                            $(".btn_delete").prop('disabled', false);

                            if (data.success == 'success') {
                                $("#deletemodal").modal("hide");
                                $("#delete_form")[0].reset();
                                showToast('Category Deleted Successfully', 'success');
                                showdata(currentPage, searchKeyword);
                            } else {
                                showToast(data.message || "Category Not Deleted", 'error');
                            }
                        },
                        error: function (xhr) {
                            $(".btn_delete").prop("disabled", false);

                            let errorMsg = "Something went wrong";
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                errorMsg = xhr.responseJSON.message;
                            }

                            showToast(errorMsg, 'error');
                        }
                    });
                });

                $(document).on('click', '.edit', function () {
                    var id = $(this).data('id');
                    var category_name = $(this).data('category_name');

                    $("#edit_id").val(id);
                    $("#edit_category_name").val(category_name);
                    $("#editmodal").modal("show");
                });

                $("#edit_form").submit(function (e) {
                    e.preventDefault();
                    $(".btn_update").prop("disabled", true);

                    var formData = new FormData(this);
                    $.ajax({
                        type: "POST",
                        url: "{{ url('/update_category') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        cache: false,
                        success: function (data) {
                            $(".btn_update").prop("disabled", false);

                            if (data.success == 'success') {
                                $("#edit_form")[0].reset();
                                $("#editmodal").modal("hide");
                                showToast('Category Updated Successfully', 'success');
                                showdata(currentPage, searchKeyword);
                            } else {
                                showToast(data.message || "Category Not Updated", 'error');
                            }
                        },
                        error: function (xhr) {
                            $(".btn_update").prop('disabled', false);

                            let errorMsg = "Something went wrong";
                            if (xhr.responseJSON && xhr.responseJSON.message) {
                                errorMsg = xhr.responseJSON.message;
                            }

                            showToast(errorMsg, 'error');
                        }
                    });
                });

                $('#exportButtonExcel').on('click', function () {
                    $.ajax({
                        url: "{{ url('/export_to_excel') }}",
                        type: 'GET',
                        data: {
                            table_name: "categories",
                            search: searchKeyword,
                        },
                        success: function (response) {
                            var result = JSON.parse(response);
                            if (result.data) {
                                var workbook = XLSX.utils.book_new();

                                var cleanedData = result.data.map(function (row) {
                                    var cleanedRow = Object.assign({}, row);

                                    for (var key in cleanedRow) {
                                        if (cleanedRow.hasOwnProperty(key) && typeof cleanedRow[key] ===
                                            'string') {
                                            cleanedRow[key] = cleanedRow[key].replace(
                                                /<a\b[^>]>(.*?)<\/a>/g, '');
                                        }
                                    }

                                    return cleanedRow;
                                });

                                var worksheet = XLSX.utils.json_to_sheet(cleanedData);
                                XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

                                var excelData = XLSX.write(workbook, {
                                    bookType: 'xlsx',
                                    type: 'array'
                                });

                                var blob = new Blob([excelData], {
                                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                                });
                                saveAs(blob, 'Admission_enquiry.xlsx');
                            }
                        }
                    });
                });
            </script>
        @endsection
    @endforeach
@else
    <script>
        location.href = "{{ url('/login') }}";
    </script>
@endif