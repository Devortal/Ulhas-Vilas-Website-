@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<style>
    /* 🏷️ Premium Brand-Themed Tabs for Website & SEO */
    #settingsTabs {
        border-bottom: 2px solid #f1f5f9 !important;
        padding-bottom: 14px;
        flex-wrap: wrap;
        gap: 12px !important;
    }

    #settingsTabs .nav-item {
        margin: 0;
    }

    #settingsTabs .nav-link {
        color: #334155 !important;
        background-color: #ffffff !important;
        border: 1.5px solid #cbd5e1 !important;
        border-radius: 10px !important;
        padding: 9px 20px !important;
        font-size: 13.5px;
        font-weight: 600 !important;
        display: inline-flex;
        align-items: center;
        transition: all 0.22s ease-in-out;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }

    #settingsTabs .nav-link i {
        color: #d97706;
        font-size: 16px;
        transition: transform 0.2s ease, color 0.2s ease;
    }

    #settingsTabs .nav-link:hover {
        color: #0f172a !important;
        border-color: #ff8c00 !important;
        background-color: #fffaf0 !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(255, 140, 0, 0.15) !important;
    }

    #settingsTabs .nav-link:hover i {
        color: #ff8c00;
        transform: scale(1.12);
    }

    #settingsTabs .nav-link.active {
        color: #ffffff !important;
        background: linear-gradient(135deg, #ff8c00 0%, #e67e00 100%) !important;
        border-color: #ff8c00 !important;
        box-shadow: 0 5px 15px rgba(255, 140, 0, 0.38) !important;
        transform: translateY(-2px);
    }

    #settingsTabs .nav-link.active i {
        color: #ffffff !important;
        transform: scale(1.05);
    }

    /* 💻 Sleek Dark Code Editor Widget for Schema / Custom Scripts */
    .seo-code-editor-box {
        border: 1px solid #1e293b;
        border-radius: 12px;
        overflow: hidden;
        background: #0f172a;
        box-shadow: 0 4px 16px rgba(15, 23, 42, 0.08);
        transition: all 0.2s ease;
    }
    .seo-code-editor-box:focus-within {
        border-color: #ff8c00;
        box-shadow: 0 0 0 3px rgba(255, 140, 0, 0.18), 0 8px 24px rgba(15, 23, 42, 0.12);
    }
    .seo-code-editor-header {
        background: #1e293b;
        padding: 8px 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #334155;
    }
    .seo-code-editor-dots {
        display: flex;
        gap: 6px;
    }
    .seo-code-editor-dots span {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        display: inline-block;
    }
    .seo-code-editor-dots .dot-red { background: #ef4444; }
    .seo-code-editor-dots .dot-yellow { background: #f59e0b; }
    .seo-code-editor-dots .dot-green { background: #10b981; }
    .seo-code-editor-textarea {
        width: 100%;
        background: #090d16 !important;
        color: #7dd3fc !important;
        font-family: 'Fira Code', 'Consolas', 'Courier New', monospace !important;
        font-size: 13px !important;
        line-height: 1.65 !important;
        padding: 14px 16px !important;
        border: none !important;
        outline: none !important;
        resize: vertical;
        min-height: 160px;
        tab-size: 2;
        letter-spacing: 0.2px;
    }
    .seo-code-editor-textarea::placeholder {
        color: #475569 !important;
        font-style: italic;
    }
</style>

<div class="container-fluid mb-5 mt-3">
    <!-- Page Title -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h2 class="h3 mb-0 text-dark fw-bold" style="font-family:'Marcellus', serif;">The Ulhas Vilas — Website & SEO Configuration</h2>
            <p class="text-muted mb-0">Manage estate branding, brochure PDF upload, contact details, RERA compliance, and dynamic page-wise SEO.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    
                    <!-- Tabs Navigation -->
                    <ul class="nav nav-pills gap-2 mb-4 pb-2 border-bottom" id="settingsTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active px-4 py-2-5 rounded-3 fw-bold" id="branding-tab" data-bs-toggle="pill" data-bs-target="#branding" type="button" role="tab">
                                <i class="bi bi-award me-2"></i>Branding & Logos
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link px-4 py-2-5 rounded-3 fw-bold" id="brochure-tab" data-bs-toggle="pill" data-bs-target="#brochure" type="button" role="tab">
                                <i class="bi bi-file-earmark-pdf-fill me-2"></i>Master Brochure
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link px-4 py-2-5 rounded-3 fw-bold" id="contact-tab" data-bs-toggle="pill" data-bs-target="#contact" type="button" role="tab">
                                <i class="bi bi-telephone-inbound me-2"></i>Contact & RERA
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link px-4 py-2-5 rounded-3 fw-bold" id="seo-tab" data-bs-toggle="pill" data-bs-target="#seo" type="button" role="tab">
                                <i class="bi bi-globe me-2"></i>Dynamic Page SEO
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link px-4 py-2-5 rounded-3 fw-bold" id="social-tab" data-bs-toggle="pill" data-bs-target="#social" type="button" role="tab">
                                <i class="bi bi-share me-2"></i>Social Media
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link px-4 py-2-5 rounded-3 fw-bold" id="policies-tab" data-bs-toggle="pill" data-bs-target="#policies" type="button" role="tab">
                                <i class="bi bi-shield-check me-2"></i>Legal Policies
                            </button>
                        </li>
                    </ul>

                        <!-- Main Form Start -->
                        <form id="edit_website_form" action="{{ url('/update_website') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $result->id ?? 1 }}">

                            <!-- Tabs Content -->
                            <div class="tab-content" id="settingsTabsContent">
                                
                                <!-- 🟢 1. Branding & Logos -->
                                <div class="tab-pane fade show active" id="branding" role="tabpanel">
                                    <h5 class="fw-bold mb-4 text-dark"><i class="bi bi-award-fill text-success me-2"></i>Branding & Logos</h5>
                                    
                                    <div class="row g-4">
                                        <!-- Header Logo -->
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Header Brand Logo</label>
                                            <div class="p-3 border rounded-3 bg-light d-flex align-items-center gap-3">
                                                <img src="{{ !empty($result->header_logo) ? asset($result->header_logo) : asset('Admin/assets/images/ulhas_logo.png') }}" class="rounded-2 p-1 bg-white border" style="max-height:55px;" alt="Header Logo">
                                                <div>
                                                    <input type="file" name="header_logo" class="form-control form-control-sm" accept="image/*">
                                                    <span class="text-muted" style="font-size:11px;">Recommended: Transparent PNG / SVG</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Footer Logo -->
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Footer Brand Logo</label>
                                            <div class="p-3 border rounded-3 bg-light d-flex align-items-center gap-3">
                                                <img src="{{ !empty($result->footer_logo) ? asset($result->footer_logo) : asset('Admin/assets/images/ulhas_logo.png') }}" class="rounded-2 p-1 bg-white border" style="max-height:55px;" alt="Footer Logo">
                                                <div>
                                                    <input type="file" name="footer_logo" class="form-control form-control-sm" accept="image/*">
                                                    <span class="text-muted" style="font-size:11px;">Recommended: Transparent PNG / SVG</span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Footer About -->
                                        <div class="col-12">
                                            <label for="footer_about" class="form-label form-label-3d">Footer Short Brand Bio</label>
                                            <textarea name="footer_about" id="footer_about" class="form-control form-control-3d" rows="3">{{ $result->footer_about ?? 'Perched in the pine-scented hills of Himachal Pradesh — a private sanctuary where architecture meets nature in timeless elegance.' }}</textarea>
                                        </div>
                                    </div>
                                </div>

                                <!-- 🟢 2. Master Project Brochure -->
                                <div class="tab-pane fade" id="brochure" role="tabpanel">
                                    <div class="card border rounded-3 shadow-none bg-light-subtle mb-0">
                                        <div class="card-body p-4">
                                            @php
                                                $activeBrochurePath = !empty($result->brochure_file) && file_exists(public_path($result->brochure_file)) 
                                                    ? asset($result->brochure_file) 
                                                    : (file_exists(public_path('Website/assets/images/brochure.pdf')) ? asset('Website/assets/images/brochure.pdf') : asset('Admin/assets/images/brochure.pdf'));
                                                $activeBrochureExt = strtolower(pathinfo($activeBrochurePath, PATHINFO_EXTENSION)) ?: 'pdf';
                                                $isBrochureImg = in_array($activeBrochureExt, ['png', 'jpg', 'jpeg', 'webp', 'gif']);
                                                $isDynamicUploaded = !empty($result->brochure_file) && file_exists(public_path($result->brochure_file));
                                            @endphp
                                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 pb-3 border-bottom">
                                                <div>
                                                    <h5 class="fw-bold mb-1 text-dark d-flex align-items-center gap-2">
                                                        @if($isBrochureImg)
                                                            <i class="bi bi-file-earmark-image-fill text-primary fs-5"></i>
                                                        @else
                                                            <i class="bi bi-file-earmark-pdf-fill text-danger fs-5"></i>
                                                        @endif
                                                        <span>Master Project Brochure</span>
                                                        <span class="badge {{ $isDynamicUploaded ? 'bg-success' : 'bg-secondary' }} ms-1" style="font-size: 11px;">
                                                            {{ $isDynamicUploaded ? 'Custom Upload (' . strtoupper($activeBrochureExt) . ')' : 'Default PDF Active' }}
                                                        </span>
                                                    </h5>
                                                    <p class="text-muted small mb-0">Upload or replace the downloadable project brochure (PDF or Image) for website visitor inquiries.</p>
                                                </div>
                                                <a href="{{ $activeBrochurePath }}" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1-5 fw-semibold d-inline-flex align-items-center gap-1">
                                                    <i class="bi bi-box-arrow-up-right"></i> View Active Brochure ({{ strtoupper($activeBrochureExt) }})
                                                </a>
                                            </div>
                                            
                                            <div class="row g-4">
                                                <div class="col-md-7">
                                                    <label class="form-label form-label-3d">Upload Project Brochure File (PDF / Image)</label>
                                                    <input type="file" name="brochure_file" class="form-control form-control-3d bg-white" accept=".pdf,image/*">
                                                    <span class="text-muted d-block mt-2" style="font-size:12px;">
                                                        <i class="bi bi-info-circle me-1"></i>Allowed formats: PDF Document, JPG, PNG, WEBP (Max 25MB)
                                                    </span>
                                                </div>

                                                <div class="col-md-5">
                                                    <label class="form-label form-label-3d">Active Download File</label>
                                                    <div class="p-3 border rounded-3 bg-white d-flex align-items-center justify-content-between shadow-sm">
                                                        <div class="d-flex align-items-center gap-2 text-truncate">
                                                            @if($isBrochureImg)
                                                                <img src="{{ $activeBrochurePath }}" alt="Brochure Preview" class="rounded border" style="width: 38px; height: 38px; object-fit: cover;">
                                                            @else
                                                                <i class="bi bi-file-earmark-pdf-fill text-danger" style="font-size:26px;"></i>
                                                            @endif
                                                            <div class="text-truncate">
                                                                <span class="small fw-semibold text-dark text-truncate d-block">{{ basename($activeBrochurePath) }}</span>
                                                                <span class="text-muted" style="font-size: 11px;">Format: {{ strtoupper($activeBrochureExt) }}</span>
                                                            </div>
                                                        </div>
                                                        <a href="{{ $activeBrochurePath }}" target="_blank" class="btn btn-sm btn-light border px-2 py-1 ms-2" title="View Brochure">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- 🟢 2. Contact Details & RERA -->
                                <div class="tab-pane fade" id="contact" role="tabpanel">
                                    <h5 class="fw-bold mb-4 text-dark"><i class="bi bi-telephone-fill text-success me-2"></i>Contact Information & RERA Compliance</h5>
                                    
                                    <div class="row g-4">
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Concierge Phone / Mobile</label>
                                            <input type="text" name="mobile" class="form-control form-control-3d" placeholder="+91 98765 43210" value="{{ $result->mobile ?? '+91 98765 43210' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Enquiry Email Address</label>
                                            <input type="email" name="email" class="form-control form-control-3d" placeholder="enquiries@ulhasvilas.com" value="{{ $result->email ?? 'enquiries@ulhasvilas.com' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">RERA Registration Number</label>
                                            <input type="text" name="rera_number" class="form-control form-control-3d" placeholder="HP/RERA/2024/001" value="{{ $result->rera_number ?? 'HP/RERA/2024/001' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Office Hours / Concierge Availability</label>
                                            <input type="text" name="office_time" class="form-control form-control-3d" placeholder="24/7 White-glove Concierge Line" value="{{ $result->office_time ?? '24/7 White-glove Concierge Line' }}">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-3d">Physical Estate Address</label>
                                            <textarea name="address" class="form-control form-control-3d" rows="2">{{ $result->address ?? 'Shimla Highway, Himachal Pradesh, India' }}</textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-3d">Google Maps Embed / Location Link</label>
                                            <input type="text" name="map_link" class="form-control form-control-3d" value="{{ $result->map_link ?? '' }}">
                                        </div>
                                    </div>
                                </div>

                                <!-- 🟢 3. Dynamic Page SEO Settings -->
                                <div class="tab-pane fade" id="seo" role="tabpanel">
                                    <div class="d-flex align-items-center justify-content-between mb-3">
                                        <div>
                                            <h5 class="fw-bold mb-1 text-dark"><i class="bi bi-search text-primary me-2"></i>Dynamic Page SEO (Meta Titles & Descriptions)</h5>
                                            <p class="text-muted small mb-0">Control the exact browser title, search engine snippet description, and keywords for each page on the website.</p>
                                        </div>
                                    </div>

                                    @php
                                        $pageSeos = DB::table('page_seos')->get();
                                    @endphp

                                    <div class="accordion" id="seoAccordion">
                                        @foreach($pageSeos as $pIndex => $seo)
                                        <div class="accordion-item border rounded-3 mb-3 overflow-hidden shadow-sm">
                                            <h2 class="accordion-header" id="headingSeo{{ $seo->id }}">
                                                <button class="accordion-button {{ $pIndex == 0 ? '' : 'collapsed' }} fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeo{{ $seo->id }}">
                                                    <i class="bi bi-file-earmark-code me-2 text-success"></i> {{ $seo->page_name }} ({{ $seo->page_key }})
                                                </button>
                                            </h2>
                                            <div id="collapseSeo{{ $seo->id }}" class="accordion-collapse collapse {{ $pIndex == 0 ? 'show' : '' }}" data-bs-parent="#seoAccordion">
                                                <div class="accordion-body bg-light p-4">
                                                    <div class="row g-3">
                                                        <div class="col-12">
                                                            <label class="form-label form-label-3d">Page Meta Title <span class="text-danger">*</span></label>
                                                            <textarea name="seo_titles[{{ $seo->page_key }}]" class="form-control form-control-3d" rows="2" placeholder="Enter Page Meta Title...">{{ $seo->meta_title }}</textarea>
                                                        </div>
                                                        <div class="col-12">
                                                            <label class="form-label form-label-3d">Meta Description (Search Engine Snippet) <span class="text-danger">*</span></label>
                                                            <textarea name="seo_descriptions[{{ $seo->page_key }}]" class="form-control form-control-3d" rows="3" placeholder="Enter Meta Description for search results...">{{ $seo->meta_description }}</textarea>
                                                        </div>
                                                        <div class="col-12">
                                                            <label class="form-label form-label-3d">SEO Keywords (Comma Separated)</label>
                                                            <input type="text" name="seo_keywords[{{ $seo->page_key }}]" class="form-control form-control-3d" value="{{ $seo->meta_keywords }}" placeholder="e.g. luxury villas, shimla estate, real estate, himachal pradesh">
                                                        </div>
                                                        <div class="col-12">
                                                            <label class="form-label form-label-3d">Social Media Share Preview Image (OG Image / WhatsApp Thumbnail)</label>
                                                            <div class="d-flex align-items-center gap-3">
                                                                <input type="file" name="seo_og_images[{{ $seo->page_key }}]" class="form-control form-control-3d bg-white" accept="image/*">
                                                                @if(!empty($seo->og_image))
                                                                    <div class="d-flex align-items-center gap-2 border rounded-3 p-1 bg-white shadow-xs shrink-0" style="min-width: 140px;">
                                                                        <img src="{{ asset($seo->og_image) }}" alt="OG Preview" class="rounded" style="height: 38px; width: 38px; object-fit: cover;">
                                                                        <span class="small text-muted font-monospace" style="font-size:11px;">Current Image</span>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                            <small class="text-muted d-block mt-1" style="font-size:11.5px;">Upload PNG/JPG image (Recommended: 1200x630px). Saved in <code>public/storage/Admin/seo/</code>.</small>
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="d-flex align-items-center justify-content-between mb-2">
                                                                <label class="form-label form-label-3d mb-0">
                                                                    <i class="bi bi-code-square text-warning me-1"></i> Page Custom Script & Schema Markup (<span class="text-primary font-monospace">&lt;head&gt; / &lt;script&gt;</span>)
                                                                </label>
                                                                <span class="badge bg-dark-subtle text-dark border px-2 py-1 font-monospace" style="font-size:11px;">JSON-LD / JS / HTML</span>
                                                            </div>

                                                            <!-- Modern Dark Code Editor Box -->
                                                            <div class="seo-code-editor-box">
                                                                <div class="seo-code-editor-header">
                                                                    <div class="seo-code-editor-dots">
                                                                        <span class="dot-red"></span>
                                                                        <span class="dot-yellow"></span>
                                                                        <span class="dot-green"></span>
                                                                        <span class="text-secondary ms-2 font-monospace" style="font-size:11px;">{{ $seo->page_key }}_head_script.html</span>
                                                                    </div>
                                                                    <button type="button" class="btn btn-sm btn-outline-secondary text-light border-0 py-0 px-2" style="font-size:11px;" onclick="copyCode(this, 'seo_script_{{ $seo->page_key }}')">
                                                                        <i class="bi bi-clipboard me-1"></i> Copy
                                                                    </button>
                                                                </div>
                                                                <textarea id="seo_script_{{ $seo->page_key }}" name="seo_scripts[{{ $seo->page_key }}]" class="seo-code-editor-textarea" rows="6" spellcheck="false" placeholder="<!-- Paste your Schema JSON-LD, Google Tag (gtag), Meta Pixel or custom JavaScript/CSS here -->
<script type=&quot;application/ld+json&quot;>
{
  &quot;@context&quot;: &quot;https://schema.org&quot;,
  &quot;@type&quot;: &quot;WebPage&quot;,
  &quot;name&quot;: &quot;{{ $seo->page_name }}&quot;
}
</script>">{{ $seo->custom_script ?? '' }}</textarea>
                                                            </div>

                                                            <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
                                                                <small class="text-muted" style="font-size:11.5px;"><i class="bi bi-info-circle me-1"></i>Supports:</small>
                                                                <span class="badge bg-primary-subtle text-primary border border-primary-subtle" style="font-size:10.5px;">Schema JSON-LD</span>
                                                                <span class="badge bg-success-subtle text-success border border-success-subtle" style="font-size:10.5px;">Google Tag (gtag)</span>
                                                                <span class="badge bg-info-subtle text-info border border-info-subtle" style="font-size:10.5px;">Meta Pixel</span>
                                                                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle" style="font-size:10.5px;">Custom &lt;script&gt; / &lt;style&gt;</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>

                                <!-- 🟢 5. Social Media Links -->
                                <div class="tab-pane fade" id="social" role="tabpanel">
                                    <h5 class="fw-bold mb-4 text-dark"><i class="bi bi-share-fill text-info me-2"></i>Social Media Channels</h5>
                                    
                                    <div class="row g-4">
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Instagram Profile URL</label>
                                            <input type="url" name="instagram_link" class="form-control form-control-3d" placeholder="https://instagram.com/ulhasvilas" value="{{ $result->instagram_link ?? '' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">Facebook Page URL</label>
                                            <input type="url" name="facebook_link" class="form-control form-control-3d" placeholder="https://facebook.com/ulhasvilas" value="{{ $result->facebook_link ?? '' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">YouTube Channel URL</label>
                                            <input type="url" name="youtube_link" class="form-control form-control-3d" placeholder="https://youtube.com/@ulhasvilas" value="{{ $result->youtube_link ?? '' }}">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label form-label-3d">LinkedIn Page URL</label>
                                            <input type="url" name="linkedin_link" class="form-control form-control-3d" placeholder="https://linkedin.com/company/ulhasvilas" value="{{ $result->linkedin_link ?? '' }}">
                                        </div>
                                    </div>
                                </div>

                                <!-- 🟢 6. Legal Policies -->
                                <div class="tab-pane fade" id="policies" role="tabpanel">
                                    <h5 class="fw-bold mb-4 text-dark"><i class="bi bi-shield-check text-warning me-2"></i>Legal Policies & Compliance</h5>
                                    
                                    <div class="row g-4">
                                        <div class="col-12">
                                            <label class="form-label form-label-3d">Terms & Conditions</label>
                                            <textarea name="term_condition" class="form-control form-control-3d summernote">{{ $result->term_condition ?? '' }}</textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-3d">Privacy Policy</label>
                                            <textarea name="privacy_policy" class="form-control form-control-3d summernote">{{ $result->privacy_policy ?? '' }}</textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-3d">Disclaimer & RERA Compliance Notes</label>
                                            <textarea name="return_policy" class="form-control form-control-3d summernote">{{ $result->return_policy ?? '' }}</textarea>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <!-- Form Action Button -->
                            <div class="d-flex justify-content-end mt-4 pt-3 border-top">
                                <button type="submit" class="btn btn-submit-3d btn_save_website px-5 py-2">
                                    <i class="bi bi-check2-circle me-1"></i> Save Configuration
                                </button>
                            </div>
                        </form>
                        <!-- Form End -->

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function copyCode(btn, textareaId) {
            var textarea = document.getElementById(textareaId);
            if (!textarea) return;
            navigator.clipboard.writeText(textarea.value).then(function() {
                var $btn = $(btn);
                var origHtml = $btn.html();
                $btn.html('<i class="bi bi-check2 text-success me-1"></i> <span class="text-success fw-bold">Copied!</span>');
                setTimeout(function() {
                    $btn.html(origHtml);
                }, 2000);
            }).catch(function() {
                textarea.select();
                document.execCommand('copy');
                var $btn = $(btn);
                var origHtml = $btn.html();
                $btn.html('<i class="bi bi-check2 text-success me-1"></i> <span class="text-success fw-bold">Copied!</span>');
                setTimeout(function() {
                    $btn.html(origHtml);
                }, 2000);
            });
        }

        $(document).ready(function() {
            $('#edit_website_form').submit(function(e) {
                e.preventDefault();
                var btn = $('.btn_save_website');
                var origText = btn.html();
                btn.html('<span class="spinner-border spinner-border-sm me-2"></span> Saving...').prop('disabled', true);

                var formData = new FormData(this);
                $.ajax({
                    url: "{{ url('/update_website') }}",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(res) {
                        btn.html(origText).prop('disabled', false);
                        if (res.success === 'success') {
                            showToast('Website configuration updated successfully!', 'success');
                        } else {
                            showToast('Failed to update settings', 'error');
                        }
                    },
                    error: function() {
                        btn.html(origText).prop('disabled', false);
                        showToast('Error saving settings', 'error');
                    }
                });
            });
        });
    </script>
@endsection
@else
    <script>
        location.href = "{{url('/login')}}";
    </script>
@endif