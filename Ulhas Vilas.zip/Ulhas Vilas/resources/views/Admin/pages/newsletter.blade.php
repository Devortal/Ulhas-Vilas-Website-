@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<style>
    .table-responsive-athlo {
        width: 100%;
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
    }
    .table-athlo {
        margin-bottom: 0 !important;
        width: 100%;
    }
    .table-athlo th {
        background-color: #f8fafc;
        color: #475569;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        padding: 12px 16px;
        border-bottom: 2px solid #e2e8f0;
        white-space: nowrap !important;
    }
    .table-athlo td {
        padding: 12px 16px;
        vertical-align: middle;
        color: #334155;
        font-size: 13px;
        white-space: nowrap;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                <!-- Filter & Top Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="row align-items-end g-3">
                        <div class="col-xl-5 col-lg-6 col-md-7">
                            <label class="filter-section-title">SEARCH NEWSLETTER SUBSCRIBERS</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_newsletter" placeholder="Search by subscriber email..." />
                                </div>
                                <button type="button" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Reset Filter Button -->
                        <div class="col-xl-auto col-lg-auto col-md-auto">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Newsletter Subscribers Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="newsletterTable" class="table table-hover table-athlo align-middle">
                        <thead class="th-nowrap">
                            <tr>
                                <th>#</th>
                                <th>Subscriber Email</th>
                                <th>Subscribed At</th>
                                <th>Updated At</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
        <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
            <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                <div style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                    <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                </div>
                <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
            </div>
            <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this subscriber? This action <strong>cannot be undone.</strong></p>
            </div>
            <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                    @csrf
                    <input type="hidden" name="id" id="delete_id" value="">
                    <button type="button" class="btn" data-bs-dismiss="modal" style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                    <button type="submit" class="btn btn_delete" style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        var currentNewsletterPage = 1;
        loadNewsletters(1);

        $('.search_newsletter').on('keyup', function () {
            currentNewsletterPage = 1;
            loadNewsletters(1);
        });

        $('#reset_filter').on('click', function () {
            $('.search_newsletter').val('');
            currentNewsletterPage = 1;
            loadNewsletters(1);
        });

        function loadNewsletters(page) {
            var pageNum = page || currentNewsletterPage || 1;
            var search = $(".search_newsletter").val();

            $.ajax({
                url: "{{ url('/show_newsletter') }}",
                type: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    search: search,
                    page: pageNum,
                },
                success: function (res) {
                    var tbody = $('#newsletterTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentNewsletterPage = res.current_page;
                        res.data.forEach(function (item, index) {
                            var createdAtVal = item.created_at || '-';
                            var updatedAtVal = item.updated_at || '-';

                            tbody.append(`
                                <tr>
                                    <td class="text-nowrap">${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td class="text-nowrap">
                                        <a href="mailto:${item.email || ''}" class="text-decoration-none d-inline-flex align-items-center fw-semibold" style="color:#0f172a; font-size:13.5px;">
                                            <i class="bi bi-envelope-at-fill text-primary me-2 fs-5"></i>${item.email || '-'}
                                        </a>
                                    </td>
                                    <td class="text-nowrap" style="font-size:12.5px;color:#475569;">
                                        <span class="badge bg-light text-dark border text-nowrap"><i class="bi bi-calendar-check me-1 text-primary"></i>${createdAtVal}</span>
                                    </td>
                                    <td class="text-nowrap" style="font-size:12.5px;color:#475569;">
                                        <span class="badge bg-light text-dark border text-nowrap"><i class="bi bi-clock-history me-1 text-secondary"></i>${updatedAtVal}</span>
                                    </td>
                                    <td class="text-center text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-danger delete-subscriber-btn px-2 py-1" data-id="${item.id}" title="Delete Subscriber">
                                            <i class="bi bi-trash3-fill"></i>
                                        </button>
                                    </td>
                                </tr>
                            `);
                        });
                    } else {
                        if (pageNum > 1) {
                            loadNewsletters(pageNum - 1);
                            return;
                        }
                        currentNewsletterPage = 1;
                        tbody.append('<tr><td colspan="5" class="text-center py-4 text-muted">No newsletter subscribers found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link" href="javascript:void(0);" onclick="loadNewsletters(${p})">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }
        window.loadNewsletters = loadNewsletters;

        // Open Delete Confirmation Modal
        $(document).on('click', '.delete-subscriber-btn', function () {
            var subId = $(this).data('id');
            $('#delete_id').val(subId);
            $('#deletemodal').modal('show');
        });

        // Submit Delete Form
        $('#delete_form').submit(function (e) {
            e.preventDefault();
            $('.btn_delete').prop('disabled', true).text('Deleting...');

            var subId = $('#delete_id').val();

            $.ajax({
                url: "{{ url('/delete_newsletter') }}",
                type: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    id: subId
                },
                success: function (res) {
                    $('.btn_delete').prop('disabled', false).text('Yes, Delete');
                    $('#deletemodal').modal('hide');
                    $('#delete_form')[0].reset();

                    showToast('Subscriber deleted successfully!', 'success');
                    loadNewsletters(currentNewsletterPage);
                },
                error: function () {
                    $('.btn_delete').prop('disabled', false).text('Yes, Delete');
                    showToast('Error deleting subscriber.', 'error');
                }
            });
        });

        // Export to Excel / CSV
        $('#exportButtonExcel').on('click', function () {
            var search = $(".search_newsletter").val();
            var csv = [];
            var rows = document.querySelectorAll("#newsletterTable tr");
            
            for (var i = 0; i < rows.length; i++) {
                var row = [], cols = rows[i].querySelectorAll("td, th");
                for (var j = 0; j < cols.length - 1; j++) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').trim();
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
                csv.push(row.join(","));
            }
            var csvFile = new Blob([csv.join("\n")], {type: "text/csv"});
            var downloadLink = document.createElement("a");
            downloadLink.download = "newsletter_subscribers_" + new Date().toISOString().slice(0,10) + ".csv";
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        });
    });
</script>

@endsection
@endif
