@if(Session::get('admin_login'))
@foreach(session()->get('admin_login') as $adminlogin)
@extends('Admin.layouts.master')
@section('main-content')


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body" style="height:460px">
                    <div class="tab-content">
                        <div class="tab-pane show active" id="form-row-preview">
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-6">
                                    <form action="javascript:void(0);" method="post" id="add_form">
                                        @csrf
                                        <div class="row g-2">
                                            <input type="hidden" id="admin_id" name="admin_id" value="{{$adminlogin->id}}" />
                                            <div class="mb-3 col-md-12">
                                                <label for="eventInput1">Current Password</label>
                                                <input id="opass" class="form-control" placeholder="Current Password" type="password" name="opass" required="">
                                            </div>
                                            <div class="mb-3 col-md-12">
                                                <label for="eventInput2">New Password</label>
                                                <input class="form-control" type="password" id="npass" name="npass" placeholder="New Password" required="">
                                            </div>
                                        </div>
                                        <div class="mb-3 col-md-12">
                                            <label for="eventInput3">Confirm Password</label>
                                            <input type="password" name="cpass" id="cpass" class="form-control" placeholder="Confirm Password" required="">
                                        </div>
                                        <button type="submit" class="btn btn-primary">Change Password</button>
                                    </form>
                                </div>
                                <div class="col-md-3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
</div>




<script>
    // category add here 
    $("#add_form").submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{url('/changepassword/admin')}}",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {
                    showToast("Password Changed Successfully!", "success");
                    $("#add_form")[0].reset();
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else if (data.success == 'not_match') {
                    showToast("Password update failed", "error");
                } else if (data.success == 'opass_npass') {
                    showToast("New and Confirm Password do not match", "error");
                } else if (data.success == 'old_pass') {
                    showToast("Invalid Current Password", "error");
                } else {
                    showToast("Something went wrong", "error");
                }
            },
            error: function(err) {
                showToast("Invalid Current Password or Server Error", "error");
            }
        });

    });
    // category end here
</script>

@endsection
@endforeach
@else
<script>
    location.href = "{{url('/login')}}";
</script>
@endif