@if(Session::get('admin_login'))
@foreach(session()->get('admin_login') as $adminlogin)
@extends('Admin.layouts.master')
@section('main-content')


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <!-- <h4 class="header-title">Manage Category</h4> -->

                    <p class="text-muted font-14 d-flex justify-content-between">

                        <input type="text" class="form-control search_contact" style="width:40%;" placeholder="Search Here" pattern="\d*" title="Please enter only contact" />
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#AddSubCategoryModal">
                            Add SubCategory
                        </button>
                    </p>
                    <a href="javascript:void(0);" style="  width: max-content;" class="me-3" id="exportButtonExcel"><img width="30" height="30" src="https://img.icons8.com/color/30/export-excel.png" alt="ms-excel" /></a>


                    <div class="tab-content">
                        <div class="tab-pane show active" id="basic-datatable-preview">
                            <table id="myTable" class="table table-striped dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Action</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Category Name</th>
                                        <th scope="col">SubCategory Name</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Datetime</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination Start Here -->
                        <nav class="mt-2">
                            <ul id="pagination" class="pagination" style="display: flex;justify-content: center;">
                                <!-- Pagination links will be populated here -->
                            </ul>
                        </nav>
                        <!-- Pagination End Here -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="AddSubCategoryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Manage SubCategory</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="add_form" action="javascript:void(0);" enctype="multipart/form-data" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="">Select Category</label>
                        <select name="category_id" id="category_dropdown" class="form-control">
                            <option disabled="true" selected="true">Select Category</option>
                            @php
                            $categories = DB::table('categories')->get();
                            @endphp
                            @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->category_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">SubCategory Name</label>
                        <input type="text" name="subcategory_name" id="subcategory_name" class="form-control" placeholder="SubCategory Name">
                    </div>
                    <div class="form-group">
                        <label for="">SubCategory Image</label>
                        <input type="file" name="image" class="form-control" data-height="100" id="image">
                    </div>
                    <div style="text-align: right;">
                        <button type="submit" class="btn btn-primary btn_submit mt-2">Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
        <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
            <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                <div style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                    <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                </div>
                <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
            </div>
            <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this record? This action <strong>cannot be undone.</strong></p>
            </div>
            <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                <form id="delete_form" action="javascript:void(0);" method="post" style="display:contents;">
                    @csrf
                    <input type="hidden" name="id" id="delete_id" value="">
                    <button type="button" class="btn" data-bs-dismiss="modal" style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                    <button type="submit" class="btn btn_delete" style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes, Delete</button>
                </form>
            </div>

        </div>
    </div>
</div>
<!-- Delete Modal -->
<!-- Edit Modal -->
<div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit SubCategory</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="edit_form" action="javascript:void(0);" enctype="multipart/form-data" method="post">
                    @csrf
                    <div class="form-group">
                        <input type="hidden" name="id" id="edit_id" value="" class="form-control">
                        <label for="">Category Name</label>
                        <select name="category_id" class="form-control">
                            @php
                            $categories = DB::table('categories')->get();
                            @endphp
                            @foreach($categories as $category)
                            <option value="{{ $category->id }}" id="edit_category_name">{{ $category->category_name }}</option>
                            @endforeach
                        </select>
                    </div><br>
                    <div class="form-group">
                        <label for="">SubCategory Name</label>
                        <input type="text" name="edit_subcategory_name" id="edit_subcategory_name" value="" class="form-control">
                    </div><br>
                    <div class="form-group">
                        <img src="" id="edit_image" height="80px" width="80px">
                        <input type="file" name="image" id="edit_image" class="form-control">
                    </div>
                    <div class="d-flex justify-content-end mt-2">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                        <button class="float-right btn btn-primary btn_update">Update</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<!-- Edit Modal -->





<script>
    let currentPage = 1;
    var searchKeyword = '';
    $(document).ready(function() {
        $('.search_contact').keyup(function() {
            var searchKeyword = $(this).val();
            if (searchKeyword.length >= 3) {
                currentPage = 1;
                showdata(currentPage, searchKeyword);
            } else {
                showdata(currentPage);
            }
        });
        showdata();
    });

    // category add here 
    $("#add_form").submit(function(e) {
        e.preventDefault();

        var category_name = $("#category_dropdown").val();
        var subcategory_name = $("#subcategory_name").val();
        var image = $("#image").val();
        if (!category_name) {
            showToast('Category Name Required', 'error');
            return;
        }
        if (!subcategory_name) {
            showToast('SubCategory Name Required', 'error');
            return;
        }
        if (!image) {
            showToast('Image Required', 'error');
            return;
        }


        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{url('/add_subcategory')}}",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {
                    // Reset the form here
                    document.getElementById("add_form").reset();
                    $(".btn_submit").prop('disabled', false);
                    $("#AddSubCategoryModal").modal("hide");
                    showToast('SubCategory Added Successfully', 'success');
                    showdata(currentPage, searchKeyword);
                } else {
                    $(".btn_submit").prop("disabled", false);
                    showToast(data.message || "Category Not Added", 'error');
                }
            },
            error: function(err) {
                $(".btn_submit").prop("disabled", false);
                showToast("Something went wrong", 'error');
            }
        });

    });
    // category end here

    // Show data function here 
    function showdata(page = 1, search = '') {
        var search_data = search || $(".search_contact").val();
        // FormData For search Condition 
        var formData = new FormData();
        formData.append('search', search_data);
        formData.append('page', page);
        // end here 

        $.ajax({
            type: "POST",
            url: "{{url('show_subcategory')}}",
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            encode: true,
            success: function(response) {
                console.log(response);
                var tbody = $("#myTable tbody");
                var pagination = $('#pagination');
                tbody.html('');
                pagination.empty();
                if (response.data && response.data.length > 0) {
                    currentPage = response.current_page;
                } else {
                    if (page > 1) {
                        showdata(page - 1, searchKeyword);
                        return;
                    }
                    currentPage = 1;
                }
                var total_enquiries = response.total;
                var per_page = response.per_page;
                result = response.data;
                
                result.forEach(function(data, index) {
                    var createdAtVal = formatDateTime(data.created_at || data.date);
                    var imgSrc = data.image ? (data.image.startsWith('http') || data.image.startsWith('storage') ? data.image : '/' + data.image) : '/Admin/assets/images/ulhas_logo.png';

                    tbody.append(`<tr>
                        <td>${index + 1 + (response.current_page - 1) * response.per_page}</td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="javascript:void(0);" class="btn-act-edit edit" title="Edit" data-category_id="${data.category_id}" data-category_name="${data.category_name}" data-subcategory_name="${data.subcategory_name}" data-image="${data.image}" data-id="${data.id}"><i class="bi bi-pencil-fill"></i></a>
                                <a class="btn-act-del delete" title="Delete" href="javascript:void(0);" data-id="${data.id}"><i class="bi bi-trash3-fill"></i></a>
                            </div>
                        </td>
                        <td class="text-center">
                            <label class="custom-switch">
                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input StatusSwitch" value="${data.id}" ${data.status == 1 ? 'checked' : ''}>
                                <span class="custom-switch-indicator"></span>
                            </label>
                        </td>
                        <td>${data.category_name ?? ''}</td>
                        <td>${data.subcategory_name ?? ''}</td>
                        <td>
                            <div class="table-user">
                                <img src="${imgSrc}" alt="table-user" class="me-2 rounded" style="width:38px;height:38px;object-fit:cover;">
                            </div>
                        </td>
                        <td style="white-space: nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                    </tr>`);
                });

                // Function to handle the pagination links with ellipsis (1 2 ... 7 8)
                function generatePaginationLinks(currentPage, lastPage, searchKeyword) {
                    let pagination = $('#pagination');
                    searchKeyword = searchKeyword || '';
                    pagination.html('');
                    if (currentPage > 3) {
                        pagination.append(`
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(1, '${searchKeyword}')">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(2, '${searchKeyword}')">2</a>
                            </li>
                            <li class="page-item disabled"><a class="page-link">...</a></li>
                        `);
                    }

                    // Show the current page and two pages before and after it
                    for (let i = Math.max(1, currentPage - 2); i <= Math.min(lastPage, currentPage + 2); i++) {
                        pagination.append(`
                            <li class="page-item ${i === currentPage ? 'active' : ''}">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${i}, '${searchKeyword}')">${i}</a>
                            </li>
                        `);
                    }

                    // Show the last two pages
                    if (currentPage < lastPage - 2) {
                        pagination.append(`
                            <li class="page-item disabled"><a class="page-link">...</a></li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage - 1}, '${searchKeyword}')">${lastPage - 1}</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="javascript:void(0);" onclick="showdata(${lastPage}, '${searchKeyword}')">${lastPage}</a>
                            </li>
                        `);
                    }
                }

                // Call this function where you handle pagination
                if (response.last_page > 1) {
                    generatePaginationLinks(response.current_page, response.last_page);
                }

            },
            error: function(err) {

            }
        });
    }

    // delete 
    $(document).on('click', '.delete', function() {
        var id = $(this).data("id");
        $("#delete_id").val(id);
        $("#deletemodal").modal("show");
    });

    // delete here 
    $("#delete_form").submit(function(e) {
        $(".btn_delete").prop('disabled', true);
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "POST",
            url: "{{url('/delete_subcategory')}}",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {

                    $(".btn_delete").prop('disabled', false);
                    $("#deletemodal").modal("hide");
                    $("#delete_form")[0].reset();
                    showToast('SubCategory Deleted Successfully', 'success');

                    showdata(currentPage, searchKeyword);

                } else {
                    showToast(data.message || 'SubCategory Not Deleted', 'error');
                    $(".btn_delete").prop("disabled", false);
                }
            },
            error: function(error) {
                showToast('Something Went Wrong!', 'error');
                $(".btn_delete").prop("disabled", false);
            }
        });
    });

    // edit category modal 
    $(document).on('click', '.edit', function() {
        var id = $(this).data('id');
        var category_id = $(this).data('category_id');
        var category_name = $(this).data('category_name');
        var subcategory_name = $(this).data('subcategory_name');
        var image = $(this).data('image');
        // Get the select element
        $("#edit_id").val(id);
        $("#edit_category_name").val(category_id);
        $("#edit_category_name").text(category_name);
        $("#edit_subcategory_name").val(subcategory_name);
        $("#edit_image").attr('src', image);
        $("#editmodal").modal("show");

    });

    // update category 
    $("#edit_form").submit(function(e) {
        $(".btn_update").prop("disabled", true);
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "post",
            url: "{{url('/update_subcategory')}}",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            encode: true,
            success: function(data) {
                if (data.success == 'success') {

                    $(".btn_update").prop("disabled", false);
                    $("#edit_form")[0].reset();
                    $("#editmodal").modal("hide");
                    showToast('SubCategory Updated Successfully', 'success');
                    showdata(currentPage, searchKeyword);
                } else {
                    showToast(data.message || "SubCategory Not Updated!", "error");
                    $(".btn_update").prop('disabled', false);
                }
            },
            error: function(errResponse) {
                showToast("Something Went Wrong!", "error");
                $(".btn_update").prop('disabled', false);
            }
        });
    });
</script>
@endsection
@endforeach
@else
<script>
    location.href = "{{url('/login')}}";
</script>
@endif