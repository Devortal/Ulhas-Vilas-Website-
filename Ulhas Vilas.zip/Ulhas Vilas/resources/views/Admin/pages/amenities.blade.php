@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<div class="container-fluid mt-2">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white">
                <!-- Filter & Top Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="row align-items-end g-3">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <label class="filter-section-title">SEARCH AMENITIES & WELLNESS</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_amenity" placeholder="Search amenity name..." />
                                </div>
                                <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </a>
                            </div>
                        </div>

                        <div class="col-xl-auto col-lg-auto col-md-auto">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>

                        <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                            <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddAmenityModal">
                                <i class="bi bi-plus-lg me-1"></i> Add Amenity
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Amenities Data Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="amenityTable" class="table table-athlo nowrap w-100">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>ACTION</th>
                                <th>STATUS</th>
                                <th>IMAGE</th>
                                <th>AMENITY NAME</th>
                                <th>CREATED AT</th>
                                <th>UPDATED AT</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Add Amenity Modal -->
<div class="modal fade" id="AddAmenityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add Amenity & Wellness</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="add_amenity_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label form-label-3d">Amenity Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control form-control-3d" placeholder="e.g. Mountain Yoga Pavilion" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label form-label-3d">Amenity Image <span class="text-danger">*</span></label>
                            <input type="file" name="image" class="form-control form-control-3d" accept="image/*" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Save Amenity</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Amenity Modal -->
<div class="modal fade" id="EditAmenityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Amenity & Wellness</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="edit_amenity_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" id="edit_amenity_id">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label form-label-3d">Amenity Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="edit_amenity_name" class="form-control form-control-3d" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label form-label-3d">Amenity Image</label>
                            <input type="file" name="image" class="form-control form-control-3d" accept="image/*">
                            <div id="amenity_img_preview" class="mt-2"></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Update Amenity</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="delete_amenity_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:440px">
        <div class="modal-content border-0" style="border-radius:16px;overflow:hidden;">
            <div style="background:linear-gradient(135deg,#f5515f,#c0392b);padding:36px 28px 24px;text-align:center;">
                <div style="width:70px;height:70px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
                    <i class="bi bi-trash3-fill" style="font-size:30px;color:#fff;"></i>
                </div>
                <h5 style="color:#fff;font-weight:700;margin:0;font-size:19px;">Delete Confirmation</h5>
            </div>
            <div class="modal-body" style="padding:28px 28px 16px;text-align:center;">
                <p style="color:#555;font-size:15px;margin-bottom:0;">Are you sure you want to delete this amenity? This action <strong>cannot be undone.</strong></p>
            </div>
            <div style="padding:12px 28px 28px;display:flex;gap:12px;">
                <button type="button" class="btn" data-bs-dismiss="modal" style="flex:1;border:2px solid #dee2e6;border-radius:10px;font-weight:600;color:#666;background:#fff;padding:10px;">Cancel</button>
                <button type="button" class="btn btn-danger delete_amenity_confirm_btn" style="flex:1;background:linear-gradient(135deg,#f5515f,#c0392b);color:#fff;border:none;border-radius:10px;font-weight:600;padding:10px;">Yes, Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var currentAmenityPage = 1;
        loadAmenities(currentAmenityPage);

        $('.search_amenity').on('keyup', function() {
            currentAmenityPage = 1;
            loadAmenities(currentAmenityPage);
        });

        $('#reset_filter').on('click', function() {
            $('.search_amenity').val('');
            currentAmenityPage = 1;
            loadAmenities(currentAmenityPage);
        });

        function loadAmenities(page) {
            var search = $('.search_amenity').val();
            $.ajax({
                url: "{{ url('/show_amenities') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    page: page,
                    search: search
                },
                success: function(res) {
                    var tbody = $('#amenityTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentAmenityPage = res.current_page;
                        res.data.forEach(function(item, index) {
                            var img = item.image ? item.image : 'Admin/assets/images/sunsoliv.png';
                            var imgSrc = img.indexOf('http') === 0 ? img : (img.indexOf('/') === 0 ? img : '{{ asset('') }}' + img);
                            var createdAtVal = formatDateTime(item.created_at);
                            var updatedAtVal = formatDateTime(item.updated_at);
                            var itemJson = JSON.stringify(item).replace(/'/g, "&apos;");

                            tbody.append(`
                                <tr>
                                    <td>${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <button class="btn-act-edit edit_amenity_btn" data-json='${itemJson}' title="Edit"><i class="bi bi-pencil-fill"></i></button>
                                            <button class="btn-act-del delete_amenity_btn" data-id="${item.id}" title="Delete"><i class="bi bi-trash-fill"></i></button>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <label class="custom-switch m-0">
                                            <input type="checkbox" class="custom-switch-input AmenityStatusSwitch" data-id="${item.id}" ${item.status == 1 ? 'checked' : ''}>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </td>
                                    <td><a href="${imgSrc}" target="_blank"><img src="${imgSrc}" class="rounded-3 shadow-sm" style="width:46px;height:46px;object-fit:cover;"></a></td>
                                    <td style="font-weight:600;color:#222;">${item.name || item.title || '-'}</td>
                                    <td style="white-space:nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                                    <td style="white-space:nowrap;"><span class="badge bg-light text-dark border fw-normal" style="font-size: 12px; padding: 5px 9px;"><i class="bi bi-arrow-repeat me-1 text-primary"></i>${updatedAtVal}</span></td>
                                </tr>
                            `);
                        });
                    } else {
                        if (page > 1) {
                            loadAmenities(page - 1);
                            return;
                        }
                        currentAmenityPage = 1;
                        tbody.html('<tr><td colspan="7" class="text-center py-4 text-muted">No amenities found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link amenity-page-btn" href="javascript:void(0);" data-page="${p}">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }

        $(document).on('click', '.amenity-page-btn', function() {
            currentAmenityPage = $(this).data('page');
            loadAmenities(currentAmenityPage);
        });



        // Add Submit
        $('#add_amenity_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $(".btn_submit").prop('disabled', true);
            $.ajax({
                url: "{{ url('/add_amenity') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    $(".btn_submit").prop('disabled', false);
                    if (res.success === 'success') {
                        $('#AddAmenityModal').modal('hide');
                        $('#add_amenity_form')[0].reset();
                        showToast('Amenity added successfully!', 'success');
                        loadAmenities(currentAmenityPage);
                    } else {
                        showToast(res.message || 'Failed to add amenity', 'error');
                    }
                },
                error: function() {
                    $(".btn_submit").prop('disabled', false);
                    showToast('Something went wrong', 'error');
                }
            });
        });

        // Edit Trigger
        $(document).on('click', '.edit_amenity_btn', function() {
            var item = $(this).data('json');
            if (typeof item === 'string') {
                try { item = JSON.parse(item); } catch(e){}
            }
            $('#edit_amenity_id').val(item.id);
            $('#edit_amenity_name').val(item.name || item.title || '');

            if (item.image) {
                var imgSrc = (item.image.indexOf('http') === 0 || item.image.indexOf('storage') === 0) ? item.image : '/' + item.image;
                $('#amenity_img_preview').html('<div class="d-flex align-items-center gap-2"><img src="' + imgSrc + '" class="rounded-2 border" style="height:45px;width:45px;object-fit:cover;"><span class="small text-muted">Current Image</span></div>');
            } else {
                $('#amenity_img_preview').empty();
            }
            $('#EditAmenityModal').modal('show');
        });

        // Edit Submit
        $('#edit_amenity_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $(".btn_submit").prop('disabled', true);
            $.ajax({
                url: "{{ url('/update_amenity') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    $(".btn_submit").prop('disabled', false);
                    if (res.success === 'success') {
                        $('#EditAmenityModal').modal('hide');
                        showToast('Amenity updated successfully!', 'success');
                        loadAmenities(currentAmenityPage);
                    } else {
                        showToast(res.message || 'Failed to update amenity', 'error');
                    }
                },
                error: function() {
                    $(".btn_submit").prop('disabled', false);
                    showToast('Something went wrong', 'error');
                }
            });
        });

        // Delete Trigger
        var deleteAmenityId = null;
        $(document).on('click', '.delete_amenity_btn', function() {
            deleteAmenityId = $(this).data('id');
            $('#delete_amenity_modal').modal('show');
        });

        $('.delete_amenity_confirm_btn').click(function() {
            if (deleteAmenityId) {
                $.ajax({
                    url: "{{ url('/delete_amenity') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        id: deleteAmenityId
                    },
                    success: function() {
                        $('#delete_amenity_modal').modal('hide');
                        showToast('Amenity deleted successfully!', 'success');
                        loadAmenities(currentAmenityPage);
                    }
                });
            }
        });
    });
</script>

@endsection
@endif
