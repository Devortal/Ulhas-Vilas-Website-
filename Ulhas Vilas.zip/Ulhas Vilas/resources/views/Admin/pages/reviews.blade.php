@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                <!-- Filter & Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="row align-items-end g-3">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <label class="filter-section-title">SEARCH GUEST REVIEWS & TESTIMONIALS</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_review" placeholder="Search by name, role, impressions..." />
                                </div>
                                <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </a>
                            </div>
                        </div>

                        <!-- Reset Filter Button -->
                        <div class="col-xl-auto col-lg-auto col-md-auto">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>

                        <!-- Add Review Button -->
                        <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                            <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddReviewModal">
                                <i class="bi bi-plus-lg me-1"></i> Add Guest Review
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Reviews Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="reviewTable" class="table table-hover table-athlo align-middle">
                        <thead class="th-nowrap">
                            <tr>
                                <th>#</th>
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Client Photo</th>
                                <th>Client Name</th>
                                <th>Designation / Role</th>
                                <th>Review / Impressions</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Add Review Modal -->
<div class="modal fade" id="AddReviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-chat-heart me-2"></i>Add Guest Impression / Testimonial</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="add_review_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row g-3">
                        <input type="hidden" name="rating" value="5">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Client / Guest Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control form-control-3d" placeholder="e.g. Ishita Rao" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Designation / Role <span class="text-danger">*</span></label>
                            <input type="text" name="designation" class="form-control form-control-3d" placeholder="e.g. HOSPITALITY INVESTOR / PRIVATE RESIDENCE BUYER" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Client Photo</label>
                            <input type="file" name="image" class="form-control form-control-3d" accept="image/*">
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Testimonial Quote / Review Text <span class="text-danger">*</span></label>
                            <textarea name="feedback" class="form-control form-control-3d" rows="4" placeholder="e.g. The experience is exceptionally polished. From the living room views to the concierge follow-through..." required></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Save Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Review Modal -->
<div class="modal fade" id="EditReviewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Guest Impression</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="edit_review_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" id="edit_review_id">
                    <input type="hidden" name="rating" id="edit_review_rating" value="5">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Client / Guest Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="edit_review_name" class="form-control form-control-3d" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Designation / Role <span class="text-danger">*</span></label>
                            <input type="text" name="designation" id="edit_review_designation" class="form-control form-control-3d" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Client Photo</label>
                            <input type="file" name="image" class="form-control form-control-3d" accept="image/*">
                            <div id="edit_review_img_preview" class="mt-2"></div>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Testimonial Quote / Review Text <span class="text-danger">*</span></label>
                            <textarea name="feedback" id="edit_review_feedback" class="form-control form-control-3d" rows="4" required></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Update Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="delete_review_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:420px">
        <div class="modal-content modal-content-3d">
            <div class="modal-body p-4 text-center">
                <i class="bi bi-trash3 text-danger" style="font-size:40px;"></i>
                <h5 class="fw-bold mt-3 mb-2">Delete Review?</h5>
                <p class="text-muted small">Are you sure you want to delete this client testimonial?</p>
                <div class="d-flex justify-content-center gap-2 mt-4">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger rounded-3 px-4 delete_review_confirm_btn">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var currentReviewPage = 1;
        loadReviews(currentReviewPage);

        $('.search_review').on('keyup', function() {
            currentReviewPage = 1;
            loadReviews(currentReviewPage);
        });

        $('#reset_filter').on('click', function() {
            $('.search_review').val('');
            currentReviewPage = 1;
            loadReviews(currentReviewPage);
        });

        function loadReviews(page) {
            var search = $('.search_review').val();
            $.ajax({
                url: "{{ url('/show_review') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    page: page,
                    search: search
                },
                success: function(res) {
                    var tbody = $('#reviewTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentReviewPage = res.current_page;
                        res.data.forEach(function(item, index) {
                            var img = item.image ? item.image : 'Website/assets/images/client_1.jpg';
                            var imgSrc = img.indexOf('http') === 0 ? img : (img.indexOf('/') === 0 ? img : '/' + img);
                            var roleText = item.designation || item.city || 'Private Client';
                            var cleanJson = JSON.stringify(item).replace(/'/g, "&apos;");
                            var createdAtVal = formatDateTime(item.created_at);
                            var updatedAtVal = formatDateTime(item.updated_at || item.created_at);

                            tbody.append(`
                                <tr>
                                    <td>${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <button class="action-btn btn-act-edit edit_review_btn" data-json='${cleanJson}' title="Edit Review"><i class="bi bi-pencil-fill"></i></button>
                                            <button class="action-btn btn-act-del delete_review_btn" data-id="${item.id}" title="Delete Review"><i class="bi bi-trash-fill"></i></button>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <label class="custom-switch">
                                            <input type="checkbox" class="custom-switch-input StatusSwitch" value="${item.id}" ${item.status == 1 ? 'checked' : ''}>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </td>
                                    <td class="text-center"><img src="${imgSrc}" class="category-img" style="border-radius:50% !important;" alt="Guest Photo"></td>
                                    <td class="fw-bold text-dark">${item.name}</td>
                                    <td><span class="badge bg-warning-subtle text-dark border px-2 py-1">${roleText}</span></td>
                                    <td style="max-width:340px;white-space:normal;font-size:12.5px;color:#334155;"><em>"${item.feedback || '-'}"</em></td>
                                    <td style="font-size:12px;white-space:nowrap;"><span class="badge bg-light text-dark border"><i class="bi bi-clock me-1 text-success"></i>${createdAtVal}</span></td>
                                    <td style="font-size:12px;white-space:nowrap;"><span class="badge bg-light text-dark border"><i class="bi bi-clock-history me-1 text-primary"></i>${updatedAtVal}</span></td>
                                </tr>
                            `);
                        });
                    } else {
                        if (page > 1) {
                            loadReviews(page - 1);
                            return;
                        }
                        currentReviewPage = 1;
                        tbody.html('<tr><td colspan="9" class="text-center py-4 text-muted">No testimonials found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link" href="javascript:void(0);" onclick="loadReviews(${p})">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }
        window.loadReviews = loadReviews;

        // Add Submit
        $('#add_review_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                url: "{{ url('/add_review') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.success === 'success') {
                        $('#AddReviewModal').modal('hide');
                        $('#add_review_form')[0].reset();
                        showToast('Guest review added successfully!', 'success');
                        loadReviews(currentReviewPage);
                    } else {
                        showToast(res.message || 'Failed to add review', 'error');
                    }
                },
                error: function() {
                    showToast('Something went wrong', 'error');
                }
            });
        });

        // Edit Open
        $(document).on('click', '.edit_review_btn', function() {
            var item = $(this).data('json');
            $('#edit_review_id').val(item.id);
            $('#edit_review_name').val(item.name);
            $('#edit_review_designation').val(item.designation || item.city || '');
            $('#edit_review_rating').val(item.rating || '5');
            $('#edit_review_feedback').val(item.feedback);

            if (item.image) {
                var imgSrc = item.image.indexOf('http') === 0 ? item.image : (item.image.indexOf('/') === 0 ? item.image : '/' + item.image);
                $('#edit_review_img_preview').html('<img src="' + imgSrc + '" class="rounded-circle border" style="width:45px;height:45px;object-fit:cover;">');
            } else {
                $('#edit_review_img_preview').empty();
            }

            $('#EditReviewModal').modal('show');
        });

        // Edit Submit
        $('#edit_review_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                url: "{{ url('/update_review') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.success === 'success') {
                        $('#EditReviewModal').modal('hide');
                        showToast('Guest review updated successfully!', 'success');
                        loadReviews(currentReviewPage);
                    } else {
                        showToast(res.message || 'Failed to update review', 'error');
                    }
                },
                error: function() {
                    showToast('Something went wrong', 'error');
                }
            });
        });



        // Delete Open
        var deleteReviewId = null;
        $(document).on('click', '.delete_review_btn', function() {
            deleteReviewId = $(this).data('id');
            $('#delete_review_modal').modal('show');
        });

        $('.delete_review_confirm_btn').on('click', function() {
            if (!deleteReviewId) return;
            $.ajax({
                url: "{{ url('/delete_review') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: deleteReviewId
                },
                success: function(res) {
                    $('#delete_review_modal').modal('hide');
                    if (res.success === 'success') {
                        showToast('Guest review deleted successfully!', 'success');
                        loadReviews(currentReviewPage);
                    } else {
                        showToast(res.message || 'Failed to delete review', 'error');
                    }
                }
            });
        });
    });
</script>

@endsection
@endif
