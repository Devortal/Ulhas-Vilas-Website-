@if(Session::get('admin_login'))
@extends('Admin.layouts.master')
@section('main-content')

<style>
    /* Summernote BS5 Modal Integration & Dropdown Fixes */
    .note-editor.note-frame {
        border: 1px solid #dcdacb !important;
        border-radius: 12px !important;
        background: #ffffff !important;
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.03);
    }
    .note-toolbar {
        background: #f8fafc !important;
        border-bottom: 1px solid #e2e8f0 !important;
        border-top-left-radius: 12px !important;
        border-top-right-radius: 12px !important;
        padding: 6px 8px !important;
    }
    .note-btn {
        background: #ffffff !important;
        border: 1px solid #cbd5e1 !important;
        color: #334155 !important;
        border-radius: 6px !important;
        padding: 4px 8px !important;
        font-size: 13px !important;
    }
    .note-btn:hover {
        background: #f1f5f9 !important;
        color: #0f172a !important;
    }
    .note-dropdown-menu, .note-editor .dropdown-menu {
        z-index: 1065 !important;
        max-height: 280px;
        overflow-y: auto;
        border-radius: 8px !important;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important;
        border: 1px solid #e2e8f0 !important;
    }
    .note-dropdown-menu .dropdown-item, .note-editor .dropdown-menu a {
        padding: 6px 14px !important;
        font-size: 13px !important;
        color: #334155 !important;
    }
    .note-dropdown-menu .dropdown-item:hover, .note-editor .dropdown-menu a:hover {
        background: #CCA43B !important;
        color: #ffffff !important;
    }
    .note-color .dropdown-menu {
        min-width: 320px !important;
        padding: 10px !important;
    }
    .note-modal {
        z-index: 1070 !important;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card p-4 rounded-4 shadow-sm border-0 bg-white mt-3">
                <!-- Filter & Top Action Bar -->
                <div class="filter-card-container mb-4">
                    <div class="row align-items-end g-3">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <label class="filter-section-title">SEARCH BLOGS & ARTICLES</label>
                            <div class="d-flex align-items-center gap-2">
                                <div class="search-input-pill flex-grow-1">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="search_blog" placeholder="Search blog title, category, summary..." />
                                </div>
                                <a href="javascript:void(0);" id="exportButtonExcel" class="btn-excel-icon-pill" title="Export Excel">
                                    <i class="bi bi-file-earmark-excel-fill"></i>
                                </a>
                            </div>
                        </div>

                        <div class="col-xl-auto col-lg-auto col-md-auto">
                            <button type="button" id="reset_filter" class="btn-reset-filter" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i> Reset
                            </button>
                        </div>

                        <div class="col-xl-auto col-lg-auto col-md-auto ms-auto">
                            <button type="button" class="btn-add-primary-pill" data-bs-toggle="modal" data-bs-target="#AddBlogModal">
                                <i class="bi bi-plus-lg me-1"></i> Write New Article
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Blogs Data Table -->
                <div class="table-responsive-athlo mb-3">
                    <table id="blogTable" class="table table-hover table-athlo align-middle">
                        <thead class="th-nowrap">
                            <tr>
                                <th>#</th>
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Image</th>
                                <th>Blog Date</th>
                                <th>Category</th>
                                <th style="min-width: 200px;">Article Title</th>
                                <th style="min-width: 250px;">Short Summary</th>
                                <th style="min-width: 160px;">Description</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav class="mt-2">
                    <ul id="pagination" class="pagination justify-content-center"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<!-- Add Blog Modal -->
<div class="modal fade" id="AddBlogModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-newspaper me-2"></i>Publish Editorial Blog / Story</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="add_blog_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Article Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control form-control-3d" placeholder="e.g. The Art of Mountain Architecture: Building for Permanence" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Blog Category <span class="text-danger">*</span></label>
                            <select name="category" class="form-select form-control-3d" required>
                                <option value="" selected="true" disabled="true">Select Blog Category</option>
                                <option value="Architecture">Architecture</option>
                                <option value="Apartment">Apartment</option>
                                <option value="Villa">Villa</option>
                                <option value="Real Estate Investment">Real Estate Investment</option>
                                <option value="Mountain Living">Mountain Living</option>
                                <option value="Wellness & Nature">Wellness & Nature</option>
                                <option value="Estate Updates">Estate Updates</option>
                                <option value="Interior & Design">Interior & Design</option>
                                <option value="Lifestyle & Culture">Lifestyle & Culture</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Publish / Event Date <span class="text-danger">*</span></label>
                            <input type="date" name="blog_date" class="form-control form-control-3d" value="{{ date('Y-m-d') }}" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Image</label>
                            <input type="file" name="image" class="form-control form-control-3d" accept="image/*">
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Short Summary</label>
                            <textarea name="short_description" class="form-control form-control-3d" rows="2" placeholder="Brief overview for cards and blog listings..."></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Full Article Description</label>
                            <textarea name="description" id="add_blog_description" class="form-control form-control-3d summernote" rows="8"></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Publish Article</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Blog Modal -->
<div class="modal fade" id="EditBlogModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Editorial Blog</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <form id="edit_blog_form" action="javascript:void(0);" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" id="edit_blog_id">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Article Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="edit_blog_title" class="form-control form-control-3d" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Blog Category <span class="text-danger">*</span></label>
                            <select name="category" id="edit_blog_category" class="form-select form-control-3d" required>
                                <option value="" selected="true" disabled="true">Select Blog Category</option>
                                <option value="Architecture">Architecture</option>
                                <option value="Apartment">Apartment</option>
                                <option value="Villa">Villa</option>
                                <option value="Real Estate Investment">Real Estate Investment</option>
                                <option value="Mountain Living">Mountain Living</option>
                                <option value="Wellness & Nature">Wellness & Nature</option>
                                <option value="Estate Updates">Estate Updates</option>
                                <option value="Interior & Design">Interior & Design</option>
                                <option value="Lifestyle & Culture">Lifestyle & Culture</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Publish / Event Date <span class="text-danger">*</span></label>
                            <input type="date" name="blog_date" id="edit_blog_date" class="form-control form-control-3d" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label form-label-3d">Image</label>
                            <div class="d-flex align-items-center gap-3">
                                <input type="file" name="image" class="form-control form-control-3d flex-grow-1" accept="image/*">
                                <div id="blog_img_preview"></div>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Short Summary</label>
                            <textarea name="short_description" id="edit_blog_short_description" class="form-control form-control-3d" rows="2"></textarea>
                        </div>

                        <div class="col-12">
                            <label class="form-label form-label-3d">Full Article Description</label>
                            <textarea name="description" id="edit_blog_description" class="form-control form-control-3d summernote" rows="8"></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-submit-3d btn_submit"><i class="bi bi-check2-circle me-1"></i>Update Article</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="delete_blog_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:420px">
        <div class="modal-content modal-content-3d">
            <div class="modal-body p-4 text-center">
                <i class="bi bi-trash3 text-danger" style="font-size:40px;"></i>
                <h5 class="fw-bold mt-3 mb-2">Delete Article?</h5>
                <p class="text-muted small">Are you sure you want to delete this blog post?</p>
                <div class="d-flex justify-content-center gap-2 mt-4">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger rounded-3 px-4 delete_blog_confirm_btn">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- View Blog Full Description Modal -->
<div class="modal fade" id="ViewBlogDescriptionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-3d">
            <div class="modal-header modal-header-3d">
                <h5 class="modal-title"><i class="bi bi-file-earmark-richtext me-2 text-primary"></i>Full Blog Description</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-3d p-4">
                <h6 class="fw-bold text-dark mb-3" id="blogDescModalSubtitle"></h6>
                <div class="p-3 bg-light rounded-3 border text-secondary shadow-inner" id="blogDescModalBody" style="max-height: 480px; overflow-y: auto; line-height: 1.7; font-size: 14px;"></div>
            </div>
            <div class="modal-footer modal-footer-3d">
                <button type="button" class="btn btn-secondary-3d" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var currentBlogPage = 1;
        loadBlogs(currentBlogPage);

        $('.search_blog').on('keyup', function() {
            currentBlogPage = 1;
            loadBlogs(currentBlogPage);
        });

        $('#reset_filter').on('click', function() {
            $('.search_blog').val('');
            currentBlogPage = 1;
            loadBlogs(currentBlogPage);
        });

        function loadBlogs(page) {
            var search = $('.search_blog').val();
            $.ajax({
                url: "{{ url('/show_blogs') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    page: page,
                    search: search
                },
                success: function(res) {
                    var tbody = $('#blogTable tbody');
                    var pagination = $('#pagination');
                    tbody.empty();
                    pagination.empty();

                    if (res.data && res.data.length > 0) {
                        currentBlogPage = res.current_page;
                        res.data.forEach(function(item, index) {
                            var img = item.image ? item.image : 'Admin/assets/images/ulhas_logo.png';
                            var imgSrc = img.indexOf('http') === 0 ? img : (img.indexOf('/') === 0 ? img : '/' + img);
                            var cleanJson = JSON.stringify(item).replace(/'/g, "&apos;");
                            var createdAtVal = formatDateTime(item.created_at);
                            var updatedAtVal = formatDateTime(item.updated_at);
                            var catBadge = item.category ? `<span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-tag-fill me-1 text-warning"></i>${item.category}</span>` : `<span class="badge bg-light text-muted border px-2 py-1">Architecture</span>`;
                            var blogDateBadge = item.blog_date ? `<span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-calendar3 me-1 text-primary"></i>${item.blog_date}</span>` : '-';

                            var descContent = item.description || item.content || '';
                            var descBtn = descContent 
                                ? `<button type="button" class="btn btn-sm btn-light border rounded-pill px-2.5 py-1 view-blog-desc-btn text-nowrap" data-title="${item.title.replace(/"/g, '&quot;')}" data-content="${encodeURIComponent(descContent)}" title="Click to view full description"><i class="bi bi-file-earmark-richtext text-primary me-1"></i>View Story</button>` 
                                : `<span class="text-muted small">-</span>`;

                            tbody.append(`
                                <tr>
                                    <td>${index + 1 + (res.current_page - 1) * res.per_page}</td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <button class="action-btn btn-act-edit edit_blog_btn" data-json='${cleanJson}' title="Edit Article"><i class="bi bi-pencil-fill"></i></button>
                                            <button class="action-btn btn-act-del delete_blog_btn" data-id="${item.id}" title="Delete Article"><i class="bi bi-trash-fill"></i></button>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <label class="custom-switch">
                                            <input type="checkbox" class="custom-switch-input StatusSwitch" value="${item.id}" ${item.status == 1 ? 'checked' : ''}>
                                            <span class="custom-switch-indicator"></span>
                                        </label>
                                    </td>
                                    <td class="text-center"><img src="${imgSrc}" class="category-img" alt="Blog Thumb" style="width:50px;height:40px;object-fit:cover;border-radius:6px;"></td>
                                    <td style="white-space:nowrap;">${blogDateBadge}</td>
                                    <td>${catBadge}</td>
                                    <td class="fw-bold text-dark" style="min-width:200px;max-width:300px;white-space:normal;line-height:1.4;">${item.title}</td>
                                    <td style="min-width:250px;max-width:350px;font-size:13px;color:#64748b;white-space:normal;line-height:1.45;">${item.short_description || '-'}</td>
                                    <td class="text-nowrap">${descBtn}</td>
                                    <td style="font-size:12px;white-space:nowrap;"><span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-calendar-plus me-1 text-primary"></i>${createdAtVal}</span></td>
                                    <td style="font-size:12px;white-space:nowrap;"><span class="badge bg-light text-dark border px-2 py-1"><i class="bi bi-clock-history me-1 text-success"></i>${updatedAtVal}</span></td>
                                </tr>
                            `);
                        });
                    } else {
                        if (page > 1) {
                            loadBlogs(page - 1);
                            return;
                        }
                        currentBlogPage = 1;
                        tbody.html('<tr><td colspan="11" class="text-center py-4 text-muted">No articles found.</td></tr>');
                    }

                    // Render pagination
                    if (res.last_page > 1) {
                        for (var p = 1; p <= res.last_page; p++) {
                            var activeClass = p === res.current_page ? 'active' : '';
                            pagination.append(`
                                <li class="page-item ${activeClass}">
                                    <a class="page-link" href="javascript:void(0);" onclick="loadBlogs(${p})">${p}</a>
                                </li>
                            `);
                        }
                    }
                }
            });
        }
        window.loadBlogs = loadBlogs;



        function initSummernote() {
            if ($.fn.summernote) {
                $('.summernote').each(function() {
                    if (!$(this).next().hasClass('note-editor')) {
                        $(this).summernote({
                            height: 280,
                            dialogsInBody: true,
                            placeholder: 'Write the complete editorial article description here...',
                            toolbar: [
                                ['style', ['style', 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
                                ['fontname', ['fontname']],
                                ['fontsize', ['fontsize']],
                                ['color', ['color']],
                                ['para', ['ul', 'ol', 'paragraph', 'height']],
                                ['table', ['table']],
                                ['insert', ['link', 'picture', 'video', 'hr']],
                                ['view', ['fullscreen', 'codeview', 'help']]
                            ],
                            fontNames: [
                                'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 
                                'Georgia', 'Helvetica', 'Impact', 'Lucida Grande', 
                                'Marcellus', 'Outfit', 'Playfair Display', 'Poppins', 
                                'Roboto', 'Times New Roman', 'Trebuchet MS', 'Verdana'
                            ],
                            fontNamesIgnoreCheck: ['Marcellus', 'Outfit', 'Playfair Display', 'Poppins', 'Roboto', 'Georgia'],
                            fontSizes: ['8', '9', '10', '11', '12', '13', '14', '15', '16', '18', '20', '22', '24', '28', '32', '36', '48', '64']
                        });
                    }
                });
            }
        }
        initSummernote();

        $('#AddBlogModal').on('shown.bs.modal', function () {
            initSummernote();
        });

        $('#EditBlogModal').on('shown.bs.modal', function () {
            initSummernote();
        });

        // Add Submit
        $('#add_blog_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            if ($('#add_blog_description').length && $.fn.summernote) {
                formData.set('description', $('#add_blog_description').summernote('code'));
            }
            $('.btn_submit').prop('disabled', true);
            $.ajax({
                url: "{{ url('/add_blog') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    $('.btn_submit').prop('disabled', false);
                    if (res.success === 'success') {
                        $('#AddBlogModal').modal('hide');
                        $('#add_blog_form')[0].reset();
                        if ($('#add_blog_description').length && $.fn.summernote) {
                            $('#add_blog_description').summernote('code', '');
                        }
                        showToast('Article published successfully!', 'success');
                        loadBlogs(currentBlogPage);
                    } else {
                        showToast(res.message || 'Failed to publish', 'error');
                    }
                },
                error: function() {
                    $('.btn_submit').prop('disabled', false);
                    showToast('Something went wrong', 'error');
                }
            });
        });

        // Edit Open
        $(document).on('click', '.edit_blog_btn', function() {
            var item = $(this).data('json');
            $('#edit_blog_id').val(item.id);
            $('#edit_blog_title').val(item.title);
            
            var catVal = (item.category || '').toString().trim();
            if (catVal) {
                var found = false;
                $('#edit_blog_category option').each(function() {
                    if ($(this).val().toLowerCase() === catVal.toLowerCase()) {
                        $(this).prop('selected', true);
                        $('#edit_blog_category').val($(this).val());
                        found = true;
                        return false;
                    }
                });
                if (!found) {
                    $('#edit_blog_category').append(`<option value="${catVal}" selected="true">${catVal}</option>`);
                    $('#edit_blog_category').val(catVal);
                }
            } else {
                $('#edit_blog_category').val('');
            }

            $('#edit_blog_date').val(item.blog_date || '');
            $('#edit_blog_short_description').val(item.short_description || '');
            
            initSummernote();
            var desc = item.description || item.content || '';
            if ($('#edit_blog_description').length && $.fn.summernote) {
                $('#edit_blog_description').summernote('code', desc);
            } else {
                $('#edit_blog_description').val(desc);
            }

            if (item.image) {
                var imgSrc = item.image.indexOf('http') === 0 ? item.image : (item.image.indexOf('/') === 0 ? item.image : '/' + item.image);
                $('#edit_blog_img_preview').html('<img src="' + imgSrc + '" class="rounded-3 border" style="width:70px;height:50px;object-fit:cover;">');
            } else {
                $('#blog_img_preview').empty();
            }

            $('#EditBlogModal').modal('show');
        });

        // Edit Submit
        $('#edit_blog_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            if ($('#edit_blog_description').length && $.fn.summernote) {
                formData.set('description', $('#edit_blog_description').summernote('code'));
            }
            $('.btn_submit').prop('disabled', true);
            $.ajax({
                url: "{{ url('/update_blog') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    $('.btn_submit').prop('disabled', false);
                    if (res.success === 'success') {
                        $('#EditBlogModal').modal('hide');
                        showToast('Article updated successfully!', 'success');
                        loadBlogs(currentBlogPage);
                    } else {
                        showToast(res.message || 'Failed to update', 'error');
                    }
                },
                error: function() {
                    $('.btn_submit').prop('disabled', false);
                    showToast('Something went wrong', 'error');
                }
            });
        });

        // View Full Description Modal
        $(document).on('click', '.view-blog-desc-btn', function() {
            var title = $(this).data('title');
            var rawContent = $(this).data('content');
            var content = rawContent ? decodeURIComponent(rawContent) : '<p class="text-muted fst-italic">No description provided.</p>';
            
            $('#blogDescModalSubtitle').html('<i class="bi bi-journal-text me-1 text-primary"></i> ' + title);
            $('#blogDescModalBody').html(content);
            $('#ViewBlogDescriptionModal').modal('show');
        });

        // Delete Open
        var deleteBlogId = null;
        $(document).on('click', '.delete_blog_btn', function() {
            deleteBlogId = $(this).data('id');
            $('#delete_blog_modal').modal('show');
        });

        $('.delete_blog_confirm_btn').on('click', function() {
            if (!deleteBlogId) return;
            $.ajax({
                url: "{{ url('/delete_blog') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: deleteBlogId
                },
                success: function(res) {
                    $('#delete_blog_modal').modal('hide');
                    if (res.success === 'success') {
                        showToast('Article deleted successfully!', 'success');
                        loadBlogs(currentBlogPage);
                    } else {
                        showToast(res.message || 'Failed to delete', 'error');
                    }
                }
            });
        });
    });
</script>

@endsection
@endif
