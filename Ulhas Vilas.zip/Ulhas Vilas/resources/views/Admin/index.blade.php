@if (session()->get('admin_login'))
    @extends('Admin.layouts.master')
    @section('main-content')
        @php
            if (session()->has('admin_login')) {
                $data = session()->get('admin_login');
                $admin = is_iterable($data) ? (is_object(collect($data)->first()) ? collect($data)->first() : (object)collect($data)->first()) : null;
                if (!$admin) {
                    return redirect()->route('login');
                }
                $data1 = $admin->permissions ?? 'all';
                $data3 = $admin->user_type ?? 'admin';
                $allowed_str = $data1;
                $allowed = explode(',', $allowed_str);
            } else {
                return redirect()->route('login');
            }
        @endphp

        <style>
            .dashboard-card-grid {
                --bs-gutter-x: 1.25rem;
                --bs-gutter-y: 1.25rem;
            }

            /* Unified Clean Luxury Estate Cards */
            .dash-luxury-card {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 18px;
                padding: 22px 20px;
                color: #0f172a;
                text-decoration: none !important;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                min-height: 165px;
                position: relative;
                overflow: hidden;
                box-shadow: 0 4px 14px rgba(0, 0, 0, 0.04);
                transition: all 0.25s ease;
                font-family: 'Outfit', sans-serif;
            }

            .dash-luxury-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #dfb746, #cca43b);
            }

            .dash-luxury-card:hover {
                transform: translateY(-4px);
                border-color: #cca43b;
                box-shadow: 0 12px 28px rgba(204, 164, 59, 0.2);
            }

            .card-icon-box {
                width: 44px;
                height: 44px;
                border-radius: 12px;
                background: linear-gradient(135deg, #0f233a, #163252);
                border: 1px solid rgba(204, 164, 59, 0.3);
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
                color: #dfb746;
                margin-bottom: 12px;
                transition: all 0.25s ease;
                box-shadow: 0 3px 8px rgba(15, 35, 58, 0.2);
            }

            .dash-luxury-card:hover .card-icon-box {
                transform: scale(1.08);
                color: #0b1a2b;
                background: linear-gradient(135deg, #dfb746, #cca43b);
                border-color: #dfb746;
            }

            .dash-card-title {
                font-family: 'Outfit', sans-serif;
                font-size: 11.5px;
                font-weight: 700;
                letter-spacing: 0.8px;
                text-transform: uppercase;
                color: #475569;
                margin-bottom: 4px;
            }

            .dash-card-count {
                font-size: 34px;
                font-weight: 700;
                color: #0f233a;
                line-height: 1.1;
                margin-bottom: 6px;
                font-family: 'Outfit', 'Sora', sans-serif;
            }

            .dash-card-sub {
                font-family: 'Outfit', sans-serif;
                font-size: 12.5px;
                color: #334155;
                font-weight: 500;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .dash-card-sub::before {
                content: '';
                display: inline-block;
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #cca43b;
                flex-shrink: 0;
            }

            /* Dashboard Hero Buttons */
            .btn-dash-hero {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                padding: 9px 18px;
                border-radius: 10px;
                font-family: 'Outfit', sans-serif;
                font-size: 13.5px;
                font-weight: 600;
                white-space: nowrap;
                text-decoration: none !important;
                transition: all 0.22s ease;
                min-height: 40px;
            }

            .btn-dash-hero-gold {
                background: linear-gradient(135deg, #dfb746 0%, #cca43b 100%);
                color: #0b1a2b !important;
                border: 1px solid #dfb746;
                box-shadow: 0 4px 14px rgba(204, 164, 59, 0.35);
            }

            .btn-dash-hero-gold:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 18px rgba(204, 164, 59, 0.45);
                color: #000000 !important;
            }

            .btn-dash-hero-glass {
                background: rgba(255, 255, 255, 0.08);
                border: 1.5px solid rgba(204, 164, 59, 0.45);
                color: #ffffff !important;
            }

            .btn-dash-hero-glass i {
                color: #dfb746;
                font-size: 15px;
            }

            .btn-dash-hero-glass:hover {
                background: rgba(204, 164, 59, 0.2);
                border-color: #dfb746;
                color: #ffffff !important;
                transform: translateY(-2px);
            }

            /* Quick Action Shortcut Cards */
            .quick-action-link {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                padding: 16px 20px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                text-decoration: none !important;
                color: #1e293b;
                font-weight: 600;
                font-family: 'Outfit', sans-serif;
                font-size: 13.5px;
                transition: all 0.25s ease;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            }

            .quick-action-link:hover {
                border-color: #cca43b;
                background: #fdfaf3;
                color: #0b1a2b;
                transform: translateY(-2px);
                box-shadow: 0 6px 16px rgba(204, 164, 59, 0.15);
            }

            .quick-action-link i.action-icon {
                font-size: 20px;
                color: #cca43b;
                margin-right: 10px;
            }

            .quick-action-link i.arrow-icon {
                font-size: 18px;
                color: #94a3b8;
                transition: transform 0.2s ease;
            }

            .quick-action-link:hover i.arrow-icon {
                transform: translateX(3px);
                color: #cca43b;
            }
        </style>

        <div class="container-fluid py-3">
            
            <!-- 1. Header Welcome Banner -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card border-0 rounded-4 p-4 shadow-sm" style="background: linear-gradient(135deg, #0f233a 0%, #163252 60%, #0d2238 100%); border-left: 5px solid #cca43b !important;">
                        <div class="d-lg-flex align-items-center justify-content-between gap-3">
                            <div class="pe-lg-3">
                                <span class="badge px-3 py-1 rounded-pill fw-bold text-uppercase mb-2" style="background:rgba(204, 164, 59, 0.2); color:#dfb746; font-size:11px; letter-spacing:1px; border:1px solid rgba(204, 164, 59, 0.35); font-family:'Outfit', sans-serif;">
                                    <i class="ri-shield-check-fill me-1"></i> Estate Administration Console
                                </span>
                                <h2 class="text-white fw-bold mb-1" style="font-family:'Marcellus', 'Cinzel', serif; letter-spacing:0.8px;">The Ulhas Vilas Dashboard</h2>
                                <p class="text-white-50 mb-0" style="font-family:'Outfit', sans-serif; font-size:13.5px; font-weight:400;">Real-time management for residences, visual gallery, editorial blogs, FAQs, guest reviews, and client inquiries.</p>
                            </div>
                            <div class="mt-3 mt-lg-0 d-flex flex-sm-row flex-column align-items-stretch align-items-sm-center gap-2 flex-shrink-0">
                                @if (($data3 ?? '') == 'admin' || in_array('Manage Residences', $allowed) || in_array('Manage Packages', $allowed) || ($allowed_str ?? '') == 'all')
                                <a href="{{ url('/admin-residence') }}" class="btn-dash-hero btn-dash-hero-gold">
                                    <i class="ri-add-circle-line"></i> <span>Add Residence</span>
                                </a>
                                @endif

                                @if (($data3 ?? '') == 'admin' || in_array('Contacts & Leads', $allowed) || in_array('Manage Contact', $allowed) || in_array('Contacts', $allowed) || ($allowed_str ?? '') == 'all')
                                <a href="{{ url('/admin-contact') }}" class="btn-dash-hero btn-dash-hero-glass">
                                    <i class="ri-contacts-book-2-line"></i> <span>View Leads</span>
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Statistics & Overview Cards (Exact Sidebar Order) -->
            <div class="row g-3 mb-4">
                
                <!-- 1. Manage Subadmin -->
                @if (($data3 ?? '') == 'admin' || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-subadmin') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-team-line"></i>
                            </div>
                            <div class="dash-card-title">Manage Subadmins</div>
                            <div class="dash-card-count">{{ $subadmins_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Active Admin Staff
                        </div>
                    </a>
                </div>
                @endif

                <!-- 2. Manage Category -->
                @if (($data3 ?? '') == 'admin' || in_array('Manage Category', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-category') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-folder-settings-line"></i>
                            </div>
                            <div class="dash-card-title">Manage Categories</div>
                            <div class="dash-card-count">{{ $categories_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Residence Classifications
                        </div>
                    </a>
                </div>
                @endif

                <!-- 3. Manage Residences -->
                @if (($data3 ?? '') == 'admin' || in_array('Manage Residences', $allowed) || in_array('Manage Packages', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-residence') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-home-8-line"></i>
                            </div>
                            <div class="dash-card-title">Manage Residences</div>
                            <div class="dash-card-count">{{ $residences_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            1-4 BHK Suites & Villas
                        </div>
                    </a>
                </div>
                @endif

                <!-- 4. Amenities & Wellness -->
                @if (($data3 ?? '') == 'admin' || in_array('Amenities & Wellness', $allowed) || in_array('Manage Amenities', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-amenities') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-sparkling-2-line"></i>
                            </div>
                            <div class="dash-card-title">Amenities & Wellness</div>
                            <div class="dash-card-count">{{ $amenities_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Luxury Features & Facilities
                        </div>
                    </a>
                </div>
                @endif

                <!-- 5. Contacts & Leads -->
                @if (($data3 ?? '') == 'admin' || in_array('Contacts & Leads', $allowed) || in_array('Manage Contact', $allowed) || in_array('Contacts', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-contact') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-mail-star-line"></i>
                            </div>
                            <div class="dash-card-title">Contacts & Leads</div>
                            <div class="dash-card-count">{{ $enquiries_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Brochure & Inquiries
                        </div>
                    </a>
                </div>
                @endif

                <!-- 6. Manage Gallery -->
                @if (($data3 ?? '') == 'admin' || in_array('Manage Gallery', $allowed) || in_array('Gallery', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-gallery') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-image-2-line"></i>
                            </div>
                            <div class="dash-card-title">Manage Gallery</div>
                            <div class="dash-card-count">{{ $galleries_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Luxury Visual Media
                        </div>
                    </a>
                </div>
                @endif

                <!-- 7. Manage Blogs -->
                @if (($data3 ?? '') == 'admin' || in_array('Manage Blogs', $allowed) || in_array('Blogs', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-blogs') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-article-line"></i>
                            </div>
                            <div class="dash-card-title">Manage Blogs</div>
                            <div class="dash-card-count">{{ $blogs_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Published Articles
                        </div>
                    </a>
                </div>
                @endif

                <!-- 8. Guest Reviews -->
                @if (($data3 ?? '') == 'admin' || in_array('Guest Reviews', $allowed) || in_array('Manage Reviews', $allowed) || in_array('Manage Testimonials', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-review') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-star-smile-line"></i>
                            </div>
                            <div class="dash-card-title">Guest Reviews</div>
                            <div class="dash-card-count">{{ $reviews_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Verified Guest Testimonials
                        </div>
                    </a>
                </div>
                @endif

                <!-- 9. Manage FAQs -->
                @if (($data3 ?? '') == 'admin' || in_array('Manage FAQ', $allowed) || in_array('Manage FAQs', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-faq') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-questionnaire-line"></i>
                            </div>
                            <div class="dash-card-title">Manage FAQs</div>
                            <div class="dash-card-count">{{ $faqs_count ?? 0 }}</div>
                        </div>
                        <div class="dash-card-sub">
                            Questions & Answers
                        </div>
                    </a>
                </div>
                @endif

                <!-- 10. Website & SEO Settings -->
                @if (($data3 ?? '') == 'admin' || in_array('Website & SEO Settings', $allowed) || in_array('Website Settings', $allowed) || in_array('Manage Setting', $allowed) || ($allowed_str ?? '') == 'all')
                <div class="col-xxl-3 col-xl-4 col-md-6 col-12">
                    <a href="{{ url('/admin-website') }}" class="dash-luxury-card h-100">
                        <div>
                            <div class="card-icon-box">
                                <i class="ri-settings-4-line"></i>
                            </div>
                            <div class="dash-card-title">Website & SEO Settings</div>
                            <div class="dash-card-count" style="font-size: 26px; padding-top: 4px;">Config</div>
                        </div>
                        <div class="dash-card-sub">
                            Brand & Dynamic SEO
                        </div>
                    </a>
                </div>
                @endif

            </div>

        </div>

    @endsection
@else
    <script>
        window.location.href = "{{ url('/login') }}";
    </script>
@endif
