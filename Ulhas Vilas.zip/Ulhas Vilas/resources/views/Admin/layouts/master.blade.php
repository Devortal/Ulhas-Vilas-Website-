@php
    if (session()->has('admin_login')) {
        $data = session()->get('admin_login');
        $admin = $data->first();

        if ($admin && isset($admin->permissions) && isset($admin->user_type)) {
            $data1 = $admin->permissions;
            $data3 = $admin->user_type;

            $allowed_str = $data1;
            $allowed = explode(',', $allowed_str);
        } else {
            return redirect()->route('login');
        }
        $info = DB::table('information')->first();
    } else {
        return redirect()->route('login');
    }
@endphp

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>The Ulhas Vilas — Estate Administration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="The Ulhas Vilas Luxury Estates Admin Portal" name="description" />
    
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{ asset('Admin/assets/images/ulhas_logo.png') }}">

    <!-- Google Fonts: Outfit, Sora, Marcellus & Playfair Display (Matching Website Typography) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Marcellus&family=Outfit:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Vendor CSS -->
    <link href="{{ asset('Admin/assets/vendor/daterangepicker/daterangepicker.css') }}" rel="stylesheet" type="text/css">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
    <link href="{{ asset('Admin/assets/css/app-saas.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />
    <link href="{{ asset('Admin/assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.4/css/dataTables.dataTables.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/themes/default.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css" />

    <!-- 🏛️ The Ulhas Vilas Clean Custom Admin Stylesheet -->
    <link rel="stylesheet" href="{{ asset('Admin/assets/css/custom-admin.css') }}">

    <!-- jQuery JS (Global) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
    <script src="{{ asset('Admin/assets/vendor/daterangepicker/moment.min.js') }}"></script>
    <script src="{{ asset('Admin/assets/vendor/daterangepicker/daterangepicker.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="{{ asset('Admin/assets/js/hyper-config.js') }}"></script>
</head>

<body>
    <!-- Begin page -->
    <div class="wrapper">
        <!-- ========== Topbar Start ========== -->
        <div class="navbar-custom">
            <div class="topbar container-fluid">
                <div class="d-flex align-items-center gap-lg-2 gap-1">
                    <!-- Sidebar Menu Toggle Button -->
                    <button class="button-toggle-menu">
                        <i class="mdi mdi-menu"></i>
                    </button>
                    <!-- Topbar Title -->
                    <div class="topbar-brand-title">
                        <h4 class="mb-0 topbar-brand-heading">Ulhas Vilas — Architectural Refinement & Luxury Estates</h4>
                    </div>
                </div>
                <ul class="topbar-menu d-flex align-items-center gap-3">
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle arrow-none nav-user" data-bs-toggle="dropdown" href="#"
                            role="button" aria-haspopup="false" aria-expanded="false">
                            <div class="d-flex align-items-center gap-2">
                                <span class="account-user-avatar">
                                    <img src="{{ asset('Admin/assets/images/ulhas_logo.png') }}" alt="user-image">
                                </span>
                                <div class="d-none d-md-flex flex-column text-start">
                                    <span class="user-name fw-bold" style="color:#0f172a;font-size:13px;">Admin</span>
                                    <span class="user-role" style="font-size:11px;color:#64748b;">Estate Portal</span>
                                </div>
                                <i class="mdi mdi-chevron-down user-chevron ms-1"></i>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated profile-dropdown">
                            <div class="dropdown-header noti-title">
                                <h6 class="text-overflow m-0">Welcome !</h6>
                            </div>
                            <a href="{{ url('/admin-profile') }}" class="dropdown-item">
                                <i class="mdi mdi-account-circle me-1 text-success"></i>
                                <span>My Account</span>
                            </a>
                            <a href="{{ url('/changepassword') }}" class="dropdown-item">
                                <i class="mdi mdi-lock text-success"></i>
                                <span>Change Password</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item logout_btn">
                                <i class="mdi mdi-logout me-1 text-danger"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ========== Topbar End ========== -->

        <!-- Mobile Sidebar Overlay -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu" id="leftSidebar">
            <!-- Brand Logo Header -->
            <a href="{{ url('/admin-dashboard') }}" class="logo logo-light">
                <span class="logo-lg">
                    <div class="sidebar-brand-wrapper">
                        <img src="{{ asset('Admin/assets/images/ulhas_logo.png') }}" alt="Ulhas Vilas" class="sidebar-brand-icon">
                        <span class="sidebar-brand-text">The Ulhas Vilas</span>
                    </div>
                </span>
                <span class="logo-sm">
                    <img src="{{ asset('Admin/assets/images/ulhas_logo.png') }}" alt="Ulhas Vilas" class="sidebar-logo-sm-img">
                </span>
            </a>

            <!-- Sidebar -->
            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <!--- Sidemenu -->
                <ul class="side-nav">
                    <li class="side-nav-item mt-1">
                        <a href="{{ url('/admin-dashboard') }}" class="side-nav-link {{ Request::is('admin-dashboard*') ? 'active' : '' }}">
                            <i class="uil uil-dashboard"></i>
                            <span> Dashboard </span>
                        </a>
                    </li>

                    @if ($data3 == 'admin' || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-subadmin') }}" class="side-nav-link {{ Request::is('admin-subadmin*') || Request::is('edit_subadmin*') ? 'active' : '' }}">
                            <i class="uil uil-users-alt"></i>
                            <span> Manage Subadmin </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Manage Category', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-category') }}" class="side-nav-link {{ Request::is('admin-category*') ? 'active' : '' }}">
                            <i class="uil uil-list-ul"></i>
                            <span> Manage Category </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Manage Residences', $allowed) || in_array('Manage Packages', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-residence') }}" class="side-nav-link {{ Request::is('admin-residence*') ? 'active' : '' }}">
                            <i class="uil uil-home-alt"></i>
                            <span> Manage Residences </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Amenities & Wellness', $allowed) || in_array('Manage Amenities', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-amenities') }}" class="side-nav-link {{ Request::is('admin-amenities*') ? 'active' : '' }}">
                            <i class="uil uil-flower"></i>
                            <span> Amenities & Wellness </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Contacts & Leads', $allowed) || in_array('Manage Contact', $allowed) || in_array('Contacts', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-contact') }}" class="side-nav-link {{ Request::is('admin-contact*') ? 'active' : '' }}">
                            <i class="uil uil-envelope"></i>
                            <span> Contacts & Leads </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Manage Gallery', $allowed) || in_array('Gallery', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-gallery') }}" class="side-nav-link {{ Request::is('admin-gallery*') ? 'active' : '' }}">
                            <i class="uil uil-scenery"></i>
                            <span> Manage Gallery </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Manage Blogs', $allowed) || in_array('Blogs', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-blogs') }}" class="side-nav-link {{ Request::is('admin-blogs*') ? 'active' : '' }}">
                            <i class="uil uil-newspaper"></i>
                            <span> Manage Blogs </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Guest Reviews', $allowed) || in_array('Manage Reviews', $allowed) || in_array('Manage Testimonials', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-review') }}" class="side-nav-link {{ Request::is('admin-review*') ? 'active' : '' }}">
                            <i class="uil uil-comment-alt-heart"></i>
                            <span> Guest Reviews </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Manage FAQ', $allowed) || in_array('Manage FAQs', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-faq') }}" class="side-nav-link {{ Request::is('admin-faq*') ? 'active' : '' }}">
                            <i class="uil uil-question-circle"></i>
                            <span> Manage FAQ </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Newsletter Subscribers', $allowed) || in_array('Manage Newsletter', $allowed) || in_array('Newsletter', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-newsletter') }}" class="side-nav-link {{ Request::is('admin-newsletter*') ? 'active' : '' }}">
                            <i class="uil uil-newspaper"></i>
                            <span> Newsletter Subscribers </span>
                        </a>
                    </li>
                    @endif

                    @if ($data3 == 'admin' || in_array('Website & SEO Settings', $allowed) || in_array('Website Settings', $allowed) || in_array('Manage Setting', $allowed) || $allowed_str == 'all')
                    <li class="side-nav-item">
                        <a href="{{ url('/admin-website') }}" class="side-nav-link {{ Request::is('admin-website*') ? 'active' : '' }}">
                            <i class="uil uil-cog"></i>
                            <span> Website & SEO Settings </span>
                        </a>
                    </li>
                    @endif

                    <br><br><br>
                </ul>
                <!--- End Sidemenu -->
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- ========== Left Sidebar End ========== -->

        <div class="content-page">
            <div class="content">
                <!-- Start Content-->
                @yield('main-content')
            </div>

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6" style="font-weight: 600;color:#0d1e16;font-size:14px">
                            <strong>
                                <script>
                                    document.write(new Date().getFullYear())
                                </script> © The Ulhas Vilas Estates. All Rights Reserved.
                            </strong>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end Footer -->
        </div>
    </div>
    <!-- END wrapper -->

    <!-- Logout Modal -->
    <div class="modal fade" id="LogoutModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content modal-content-3d">
                <div class="modal-header modal-header-3d">
                    <h5 class="modal-title" id="staticBackdropLabel">Log Out</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4 text-center">
                    <i class="bi bi-box-arrow-right text-danger" style="font-size:42px;"></i>
                    <p class="mt-3 mb-0" style="font-size:16px;font-weight:600;color:#1e293b;">Are you sure you want to log out of the admin console?</p>
                </div>
                <div class="modal-footer border-top-0 pt-0 pb-3 justify-content-center">
                    <button type="button" class="btn btn-light px-4 rounded-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="{{ url('admin-logout') }}" class="btn btn-danger px-4 rounded-3 fw-bold">Yes, Log Out</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor Scripts -->
    <script src="{{ asset('Admin/assets/js/vendor.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js"></script>
    <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <script src="{{ asset('Admin/assets/js/app.min.js') }}"></script>

    <!-- 🏛️ The Ulhas Vilas Custom JS Utilities -->
    <script src="{{ asset('Admin/assets/js/custom-admin.js') }}"></script>
</body>

</html>