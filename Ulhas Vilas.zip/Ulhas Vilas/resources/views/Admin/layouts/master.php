@php
    if (session()->has('admin_login')) {
        $data = session()->get('admin_login');
        $admin = $data->first();

        if ($admin && isset($admin->permissions) && isset($admin->user_type)) {
            $data1 = $admin->permissions;
            $data3 = $admin->user_type;

            $allowed_str = $data1;
            $allowed = explode(',', $allowed_str);
        } else {
            return redirect()->route('login');
        }
        $info = DB::table('information')->first();
    } else {
        return redirect()->route('login');
    }
@endphp

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Sunsoliv &#8211; Just Sun , Soil &amp; Life</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sunsoliv" name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}">
    <!-- Daterangepicker css -->
    <link href="{{ asset('Admin/assets/vendor/daterangepicker/daterangepicker.css') }}" rel="stylesheet"
        type="text/css">
    <!-- Vector Map css -->
    <link href="{{ asset('Admin/assets/vendor/jsvectormap/css/jsvectormap.min.css') }}" rel="stylesheet"
        type="text/css">
    <!-- Theme Config Js -->
    <script src="{{ asset('Admin/assets/js/hyper-config.js') }}"></script>
    <!-- App css -->
    <link href="{{ asset('Admin/assets/css/app-saas.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />
    <!-- Icons css -->
    <link href="{{ asset('Admin/assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.css"
        integrity="sha512-MpdEaY2YQ3EokN6lCD6bnWMl5Gwk7RjBbpKLovlrH6X+DRokrPRAF3zQJl1hZUiLXfo2e9MrOt+udOnHCAmi5w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.4/css/dataTables.dataTables.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" />

    <!-- Summernote Start Here -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs5.min.css" rel="stylesheet">
    <!-- Summernote End Here -->
    <!-- Tagify CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <style>
        /* Custom Toast Notification */
        #toast-container-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .toast-custom {
            min-width: 280px;
            max-width: 360px;
            padding: 14px 18px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
            animation: slideInRight 0.3s ease;
            font-size: 14px;
            font-weight: 500;
            color: #fff;
        }

        .toast-custom.toast-error {
            background: linear-gradient(135deg, #f5515f, #c0392b);
        }

        .toast-custom.toast-success {
            background: linear-gradient(135deg, #11998e, #38ef7d);
            color: #fff;
        }

        .toast-custom.toast-warning {
            background: linear-gradient(135deg, #f7971e, #ffd200);
            color: #fff;
        }

        .toast-custom .toast-icon {
            font-size: 20px;
            flex-shrink: 0;
        }

        .toast-custom .toast-msg {
            flex: 1;
            line-height: 1.4;
        }

        .toast-custom .toast-close {
            cursor: pointer;
            font-size: 18px;
            opacity: 0.8;
            flex-shrink: 0;
        }

        .toast-custom .toast-close:hover {
            opacity: 1;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(110%);
                opacity: 0;
            }

            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }

            to {
                transform: translateX(110%);
                opacity: 0;
            }
        }
    </style>


    <style>
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 30px;
        }

        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .custom-switch-indicator {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: red;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .custom-switch-indicator:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 0px;
            bottom: 5px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked+.custom-switch-indicator {
            background-color: #1cc88a;
        }

        input:checked+.custom-switch-indicator:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .custom-switch-indicator {
            border-radius: 34px;
        }

        .custom-switch-indicator:before {
            border-radius: 50%;
        }
    </style>
    <style>
        .tilebox-one {
            min-height: 160px;
            /* sab cards same height */
            display: flex;
            align-items: center;
            /* vertical centering */
            justify-content: center;
            text-align: center;
            transition: all 0.2s ease-in-out;
        }

        .tilebox-one .card-body {
            padding: 20px 15px;
        }

        .tilebox-one:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }

        .tilebox-one h2 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .tilebox-one p {
            margin-bottom: 0;
            line-height: 1.4;
        }

        /* Standardized Table Styling for All Pages */
        .table {
            background-color: #ffffff !important;
        }

        .table thead th {
            background-color: #ffffff !important;
            color: #334e6f !important;
            font-size: 11px !important;
            font-weight: 800 !important;
            text-transform: uppercase !important;
            letter-spacing: 0.5px !important;
            padding: 12px 10px !important;
            border-bottom: 2px solid #ebebeb !important;
            white-space: nowrap !important;
        }

        .table tbody td {
            vertical-align: middle !important;
            font-size: 13px !important;
            color: #444 !important;
            padding: 10px 10px !important;
            border-bottom: 1px solid #f1f3f5 !important;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, .01) !important;
        }

        .table-hover tbody tr:hover {
            background-color: #fdfdfd !important;
        }

        /* 🏛️ Global Design System (Sunsoliv Admin) */

        /* 1. Header Card (Top Section) */
        .top-section-card {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #ebebeb;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            margin-bottom: 20px;
        }

        .top-section-card .row {
            margin-left: -5px;
            margin-right: -5px;
        }

        .top-section-card [class*="col-"] {
            padding-left: 5px;
            padding-right: 5px;
        }

        .filter-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #777;
            margin-bottom: 5px;
            display: block;
            letter-spacing: 0.5px;
        }

        /* 2. Interactive Components */
        .search-box-wrapper {
            position: relative;
            max-width: 350px;
            width: 100%;
        }

        .search-box-wrapper i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            z-index: 5;
        }

        .form-control-custom,
        .form-select-custom {
            height: 42px !important;
            border-radius: 8px !important;
            border: 1.5px solid #ebebeb !important;
            font-size: 14px !important;
            color: #444;
        }

        .search-box-wrapper .form-control-custom {
            padding-left: 35px !important;
        }

        /* 3. Statistics & Status Pills */
        .stat-pill {
            background: #f0fdf4;
            border: 1px solid #dcfce7;
            color: #166534;
            padding: 0 10px;
            border-radius: 8px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
            font-size: 13px;
            height: 42px;
            width: fit-content;
            min-width: 45px;
            justify-content: center;
        }

        .stat-pill .count {
            background: #166534;
            color: #fff;
            padding: 1px 6px;
            border-radius: 4px;
            font-size: 11px;
        }

        .stat-pill.verified {
            background: #eff6ff;
            border-color: #dbeafe;
            color: #1e40af;
        }

        .stat-pill.verified .count {
            background: #1e40af;
        }

        .stat-pill.not-verified {
            background: #fff7ed;
            border-color: #ffedd5;
            color: #9a3412;
        }

        .stat-pill.not-verified .count {
            background: #9a3412;
        }

        .order-id-pill {
            font-family: 'Monospaced', monospace;
            background: #f1f3f5;
            padding: 3px 8px;
            border-radius: 4px;
            color: #495057;
            font-weight: 600;
            font-size: 12px;
            border: 1px solid #dee2e6;
        }

        /* 4. Buttons */
        .btn-filter-submit,
        .btn-reset,
        .btn-standard {
            height: 42px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 600;
            padding: 0 15px;
        }

        .btn-filter-submit {
            background-color: #2d8a55;
            color: #fff !important;
            border: none;
        }

        .btn-filter-submit:hover {
            background-color: #236b42 !important;
        }

        .btn-reset {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            width: 42px;
            padding: 0;
        }

        .btn-reset:hover {
            background-color: #ef4444 !important;
            color: #fff !important;
        }

        /* 5. Table Actions */
        .action-btn-table {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 6px;
            transition: all 0.2s;
            font-size: 14px;
            border: none;
        }

        .btn-edit-table {
            background: #fff7ed;
            color: #c2410c;
            border: 1px solid #ffedd5;
        }

        .btn-edit-table:hover {
            background: #c2410c;
            color: #fff;
        }

        .btn-delete-table {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fee2e2;
        }

        .btn-delete-table:hover {
            background: #991b1b;
            color: #fff;
        }

        .btn-view-order {
            background: #fff;
            border: 1.5px solid #2d8a55;
            color: #2d8a55;
            border-radius: 30px;
            padding: 4px 15px;
            font-weight: 700;
            font-size: 12px;
            transition: all 0.3s;
        }

        .btn-view-order:hover {
            background: #2d8a55;
            color: #fff;
        }

        /* 6. Utility */
        .dt-nowrap {
            white-space: nowrap !important;
        }

        /* 📅 Standardized Date Filter UI */
        .input-group-date-filter {
            max-width: 380px;
            /* Precise width as requested */
        }

        .input-group-text-to {
            background-color: #f1f3f7 !important;
            border: 1.5px solid #ebebeb !important;
            border-left: none !important;
            border-right: none !important;
            color: #6c757d !important;
            font-size: 10px !important;
            font-weight: 700 !important;
            text-transform: lowercase;
            padding: 0 10px !important;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 35px;
        }

        .input-date-custom {
            border-radius: 8px !important;
        }

        .input-group>.input-date-custom:first-child {
            border-top-right-radius: 0 !important;
            border-bottom-right-radius: 0 !important;
        }

        .input-group>.input-date-custom:last-child {
            border-top-left-radius: 0 !important;
            border-bottom-left-radius: 0 !important;
        }
    </style>

    <!-- In Mobile View search date filter -->
    <style>
        /* 📱 Mobile Responsive Layout */
        @media (max-width: 768px) {
            .top-section {
                flex-direction: column !important;
                align-items: stretch !important;
            }

            .search-section {
                flex-direction: column !important;
                align-items: stretch !important;
            }

            .search_contact {
                width: 100% !important;
                margin-bottom: 10px;
            }

            #exportButtonExcel {
                align-self: flex-start;
                margin-bottom: 10px;
            }

            #totalAmountBtn {
                width: 100%;
                margin-bottom: 15px;
            }

            .filter-section {
                flex-direction: column !important;
                align-items: stretch !important;
            }

            .filter-section label {
                margin-bottom: 5px;
            }

            .filter-section .input-group {
                width: 100% !important;
                margin-bottom: 10px;
            }

            #resetFilters {
                width: 100%;
            }
        }
    </style>

    <style>
        /* Common Responsive Layout (same for all top sections) */
        @media (max-width: 768px) {
            .top-section {
                flex-direction: column !important;
                align-items: stretch !important;
            }

            .search-section {
                flex-direction: column !important;
                align-items: stretch !important;
            }

            .search_contact {
                width: 100% !important;
                margin-bottom: 10px;
            }

            #exportButtonExcel {
                align-self: flex-start;
                margin-bottom: 10px;
            }

            .add-btn {
                width: 100%;
            }
        }
    </style>

    <style>
        .btn-primary,
        .btn-primary:hover,
        .btn-primary:focus,
        .btn-primary:active,
        .btn-primary:not(:disabled):not(.disabled):active {
            background: #e59e20 !important;
            background-color: #e59e20 !important;
            border: none !important;
            border-color: #e59e20 !important;
            color: #fff !important;
            box-shadow: none !important;
        }
    </style>
    <style>
        .topbar {
            position: relative;
        }

        .topbar-title {
            position: absolute;
            left: 20%;
            transform: translateX(-50%);
            margin: 0;
            font-weight: bold;
            font-size: 18px;
            color: black;
            white-space: nowrap;
        }

        @media (max-width: 768px) {
            .topbar-title {
                left: 50%;
                transform: translateX(-50%);
                font-size: 13px;
                max-width: 70%;
                text-align: center;
            }
        }

        /* Admin Theme Css Change - Optimized for Logo Visibility */
        .leftside-menu {
            z-index: 1000;
            bottom: 0;
            top: 0;
            position: fixed;
            width: var(--ct-leftbar-width);
            min-width: var(--ct-leftbar-width);
            padding-bottom: calc(var(--ct-footer-height) + .75rem);
            /* Switched from Green to Professional Dark Slate for better logo contrast */
            background: linear-gradient(180deg, #1a232f 0%, #151b26 100%);
            -webkit-box-shadow: 3px 0 15px rgba(0, 0, 0, 0.2);
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.2);
            border-right: 1px solid rgba(255, 255, 255, 0.05);
            -webkit-transition: all .25s ease-in-out;
            transition: all .25s ease-in-out;
        }

        .side-nav .side-nav-link {
            display: block;
            list-style: none;
            position: relative;
            white-space: nowrap;
            color: #94a3b8;
            /* Muted Slate */
            font-family: inherit;
            -webkit-transition: all .25s ease-in-out;
            transition: all .25s ease-in-out;
            font-size: var(--ct-menu-item-font-size);
            padding: var(--ct-menu-item-padding-y) var(--ct-menu-item-padding-x);
            border-radius: 6px;
            margin: 2px 8px;
        }

        .side-nav .side-nav-link:hover {
            color: #ffffff !important;
            background: rgba(255, 255, 255, 0.08) !important;
        }

        .side-nav .side-nav-link.active,
        .side-nav-item.active>.side-nav-link {
            color: #ffffff !important;
            background: #2d8a55 !important;
            /* Brand Green for Active State */
            box-shadow: 0 4px 8px rgba(45, 138, 85, 0.3);
        }

        .side-nav .side-nav-link i {
            color: #2d8a55;
            /* Accent Green */
            font-size: 18px;
            margin-right: 8px;
            vertical-align: middle;
        }

        .side-nav .side-nav-link:hover i,
        .side-nav .side-nav-link.active i,
        .side-nav-item.active>.side-nav-link i {
            color: #ffffff !important;
        }

        /* Logo area in sidebar - Enhanced Visibility */
        .leftside-menu .logo {
            display: block;
            text-align: center;
            padding: 20px 10px;
            margin-bottom: 5px;
            background: rgba(255, 255, 255, 0.03);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .leftside-menu .logo img {
            max-width: 90%;
            height: auto;
            object-fit: contain;
            /* Suble drop shadow to make the green text readable if needed */
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
            transition: all 0.3s ease;
            background: #fff;
            /* White capsule for the logo background */
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .leftside-menu .logo-lg img {
            max-height: 90px;
        }

        .leftside-menu .logo-sm img {
            max-height: 40px;
            padding: 5px;
            border-radius: 50%;
        }

        /* Sidebar second level */
        .side-nav-second-level li a {
            color: #a5d6a7 !important;
            padding: 6px 20px 6px 40px;
            display: block;
            transition: all .2s;
        }

        .side-nav-second-level li a:hover {
            color: #ffffff !important;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
        }

        /* Mobile overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        .sidebar-overlay.show {
            display: block;
        }

        @media (max-width: 768px) {
            .leftside-menu {
                transform: translateX(-100%);
                z-index: 1050;
                transition: transform .3s ease;
            }

            .leftside-menu.mobile-open {
                transform: translateX(0);
            }

            .content-page {
                margin-left: 0 !important;
            }
        }

        .content {
            padding-top: 20px !important;
        }

        .navbar-custom {
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
    </style>
</head>

<body>
    <!-- Begin page -->
    <div class="wrapper">
        <!-- ========== Topbar Start ========== -->
        <div class="navbar-custom">
            <div class="topbar container-fluid">
                <div class="d-flex align-items-center gap-lg-2 gap-1">
                    <!-- Topbar Brand Logo -->
                    <div class="logo-topbar">
                        <!-- Logo light -->
                        <a href="#" class="logo-light">
                            <span class="logo-lg">
                                {{-- <img src="{{ asset('Admin/assets/images/sunsoliv.png') }}" alt="logo"> --}}
                            </span>
                            <span class="logo-sm">
                                {{-- <img src="{{ asset('Admin/assets/images/sunsoliv.png') }}" alt="small logo">
                                --}}
                            </span>
                        </a>
                        <!-- Logo Dark -->
                        <a href="#" class="logo-dark">
                            <span class="logo-lg">
                                {{-- <img src="{{ asset('Admin/assets/images/sunsoliv.png') }}" alt="dark logo">
                                --}}
                            </span>
                            <span class="logo-sm">
                                {{-- <img src="{{ asset('Admin/assets/images/sunsoliv.png') }}" alt="small logo">
                                --}}
                            </span>
                        </a>
                    </div>
                    <!-- Sidebar Menu Toggle Button -->
                    <button class="button-toggle-menu">
                        <i class="mdi mdi-menu"></i>
                    </button>
                    <!-- Horizontal Menu Toggle Button -->
                    <button class="navbar-toggle" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </button>
                    <!-- Topbar Search Form -->
                    <p class="topbar-title">Sunsoliv &#8211; Just Sun , Soil &amp; Life</p>
                </div>
                <ul class="topbar-menu d-flex align-items-center gap-3">
                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle arrow-none nav-user px-2" data-bs-toggle="dropdown" href="#"
                            role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="account-user-avatar">
                                <img src="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}"
                                    alt="user-image" width="32" class="rounded-circle">
                            </span>
                            <span class="d-lg-flex flex-column gap-1 d-none">
                                <h5 class="my-0">Profile</h5>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated profile-dropdown">
                            <!-- item -->
                            <div class=" dropdown-header noti-title">
                                <h6 class="text-overflow m-0">Welcome !</h6>
                            </div>

                            <!-- item -->
                            <a href="{{ url('/admin-profile') }}" class="dropdown-item">
                                <i class="mdi mdi-account-circle me-1"></i>
                                <span>My Account</span>
                            </a>
                            <a href="{{ url('/changepassword') }}" class="dropdown-item">
                                <i class="mdi mdi-lock"></i>
                                <span>Change Password</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item logout_btn">
                                <i class="mdi mdi-logout me-1"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ========== Topbar End ========== -->

        <!-- Mobile Sidebar Overlay -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu" id="leftSidebar">
            <!-- Brand Logo Light -->
            <a href="{{ url('/admin-dashboard') }}" class="logo logo-light">
                <span class="logo-lg mt-2">
                    <img src="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}" alt="logo">
                </span>
                <span class="logo-sm">
                    <img src="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}" alt="small logo">
                </span>
            </a>

            <!-- Brand Logo Dark -->
            <a href="{{ url('/admin-dashboard') }}" class="logo logo-dark">
                <span class="logo-lg">
                    <img src="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}" alt="dark logo">
                </span>
                <span class="logo-sm">
                    <img src="{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}" alt="small logo">
                </span>
            </a>
            <!-- Sidebar Hover Menu Toggle Button -->
            <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
                <i class="ri-checkbox-blank-circle-line align-middle"></i>
            </div>

            <!-- Full Sidebar Menu Close Button -->
            <div class="button-close-fullsidebar">
                <i class="ri-close-fill align-middle"></i>
            </div>

            <!-- Sidebar -->
            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <!-- Admin Subadmin Start Here -->
                @if ($data3 == 'admin')
                    <!--- Sidemenu -->
                    <ul class="side-nav">
                        <li class="side-nav-item">
                            <a href="{{ url('/admin-dashboard') }}" class="side-nav-link">
                                <i class="uil uil-dashboard"></i>
                                <span> Dashboard </span>
                            </a>
                        </li>

                        <!-- Manage Notification Start Here -->
                        <li class="side-nav-item">
                            <a href="{{ url('/admin-notification') }}" class="side-nav-link">
                                <i class="uil uil-bell"></i>
                                <span> Manage Notification </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-subadmin') }}" class="side-nav-link">
                                <i class="uil uil-user-check"></i>
                                <span> Manage Subadmin </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-user') }}" class="side-nav-link">
                                <i class="uil uil-users-alt"></i>
                                <span> Manage User </span>
                            </a>
                        </li>

                        <!-- Manage Order Start Here -->
                        <li class="side-nav-item">
                            <a href="{{ url('/admin-order') }}" class="side-nav-link">
                                <i class="uil uil-package"></i>
                                <span>Manage Order</span>
                            </a>
                        </li>
                        <!-- Manage Order End Here -->

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-get-quotes') }}" class="side-nav-link">
                                <i class="uil uil-clipboard-notes"></i>
                                <span>Manage Get Quotes</span>
                            </a>
                        </li>


                        <li class="side-nav-item">
                            <a href="{{ url('/admin-category') }}" class="side-nav-link">
                                <i class="uil uil-list-ul"></i>
                                <span> Manage Category </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-product-type') }}" class="side-nav-link">
                                <i class="uil uil-tag-alt"></i>
                                <span> Manage Product Type </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-product') }}" class="side-nav-link">
                                <i class="uil uil-box"></i>
                                <span> Manage Product</span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-coupon') }}" class="side-nav-link">
                                <i class="uil uil-ticket"></i>
                                <span> Manage Coupon</span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-banner') }}" class="side-nav-link">
                                <i class="uil uil-image"></i>
                                <span> Manage Banner</span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-gallery') }}" class="side-nav-link">
                                <i class="uil uil-image"></i>
                                <span> Manage Gallery</span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-faq') }}" class="side-nav-link">
                                <i class="uil uil-question-circle"></i>
                                <span> Manage Faq</span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-contact') }}" class="side-nav-link">
                                <i class="uil uil-envelope"></i>
                                <span> Manage Contact </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-newsletter') }}" class="side-nav-link">
                                <i class="uil uil-envelope-alt"></i>
                                <span> Manage Newsletter </span>
                            </a>
                        </li>

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-website') }}" class="side-nav-link">
                                <i class="uil uil-cog"></i>
                                <span>Manage Setting</span>
                            </a>
                        </li>




                        <!-- Manage Applive Start Here -->
                        {{-- <li class="side-nav-item">
                            <a href="{{ url('/admin-applive') }}" class="side-nav-link">
                                <i class="uil uil-users-alt"></i>
                                <span> Manage Applive </span>
                            </a>
                        </li> --}}
                        <!-- Manage Applive End Here -->


                        <br><br><br><br>
                    </ul>
                    <!--- End Sidemenu -->
                @else
                    <!--- Sidemenu -->
                    <ul class="side-nav">

                        <li class="side-nav-item">
                            <a href="{{ url('/admin-dashboard') }}" class="side-nav-link">
                                <i class="uil uil-dashboard"></i>
                                <span> Dashboard </span>
                            </a>
                        </li>

                        @if (in_array('Manage Notification', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-notification') }}" class="side-nav-link">
                                    <i class="uil uil-bell"></i>
                                    <span>Manage Notification</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage User', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-user') }}" class="side-nav-link">
                                    <i class="uil uil-users-alt"></i>
                                    <span>Manage User</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Order', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-order') }}" class="side-nav-link">
                                    <i class="uil uil-package"></i>
                                    <span>Manage Order</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Order', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-get-quotes') }}" class="side-nav-link">
                                    <i class="uil uil-clipboard-notes"></i>
                                    <span>Manage Get Quotes</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Category', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-category') }}" class="side-nav-link">
                                    <i class="uil uil-list-ul"></i>
                                    <span>Manage Category</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Product Type', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-product-type') }}" class="side-nav-link">
                                    <i class="uil uil-tag-alt"></i>
                                    <span>Manage Product Type</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Product', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-product') }}" class="side-nav-link">
                                    <i class="uil uil-box"></i>
                                    <span>Manage Product</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Coupon', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-coupon') }}" class="side-nav-link">
                                    <i class="uil uil-ticket"></i>
                                    <span>Manage Coupon</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Banner', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-banner') }}" class="side-nav-link">
                                    <i class="uil uil-image"></i>
                                    <span>Manage Banner</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Gallery', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-gallery') }}" class="side-nav-link">
                                    <i class="uil uil-image"></i>
                                    <span>Manage Gallery</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Faq', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-faq') }}" class="side-nav-link">
                                    <i class="uil uil-question-circle"></i>
                                    <span>Manage Faq</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Contact', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-contact') }}" class="side-nav-link">
                                    <i class="uil uil-envelope"></i>
                                    <span>Manage Contact</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Newsletter', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-newsletter') }}" class="side-nav-link">
                                    <i class="uil uil-envelope-alt"></i>
                                    <span>Manage Newsletter</span>
                                </a>
                            </li>
                        @endif

                        @if (in_array('Manage Setting', $allowed) || $allowed_str == 'all')
                            <li class="side-nav-item">
                                <a href="{{ url('/admin-website') }}" class="side-nav-link">
                                    <i class="uil uil-cog"></i>
                                    <span>Manage Setting</span>
                                </a>
                            </li>
                        @endif

                    </ul>
                    <!--- End Sidemenu -->
                @endif
                <!-- Admin Subadmin End Here -->

                <div class="clearfix"></div>
            </div>
        </div>
        <!-- ========== Left Sidebar End ========== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                @yield('main-content')
                <!-- container -->

            </div>
            <!-- content -->

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6" style="font-weight: 600;color:black;font-size:17px">
                            <strong>
                                <script>
                                    document.write(new Date().getFullYear())
                                </script> © Sunsoliv &#8211; Just Sun , Soil &amp; Life
                            </strong>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end Footer -->
        </div>
    </div>
    <!-- END wrapper -->


    <!-- Modal -->
    <div class="modal fade" id="LogoutModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Logout</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-center" style="font-size:18px;">Are you sure you want to log out?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="{{ url('admin-logout') }}" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!--************** -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js"
        integrity="sha512-JnjG+Wt53GspUQXQhc+c4j8SBERsgJAoHeehagKHlxQN+MtCCmFDghX9/AcbkkNRZptyZU4zC8utK59M5L45Iw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Vendor js -->
    <script src="{{ asset('Admin/assets/js/vendor.min.js') }}"></script>
    <!-- Daterangepicker js -->
    <script src="{{ asset('Admin/assets/vendor/daterangepicker/moment.min.js') }}"></script>
    <script src="{{ asset('Admin/assets/vendor/daterangepicker/daterangepicker.js') }}"></script>
    <!-- Apex Charts js -->
    <script src="{{ asset('Admin/assets/vendor/apexcharts/apexcharts.min.js') }}"></script>
    <!-- Vector Map Js -->
    <script src="{{ asset('Admin/assets/vendor/jsvectormap/js/jsvectormap.min.js') }}"></script>
    <script src="{{ asset('Admin/assets/vendor/jsvectormap/maps/world-merc.js') }}"></script>
    <script src="{{ asset('Admin/assets/vendor/jsvectormap/maps/world.js') }}"></script>
    <!-- Dashboard App js -->
    <script src="{{ asset('Admin/assets/js/pages/demo.dashboard.js') }}"></script>
    <!-- App js -->
    <script src="{{ asset('Admin/assets/js/app.min.js') }}"></script>

    <!-- Summernote Start Here -->
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs5.min.js"></script>
    <!-- Summernote End Here -->
    <!-- Tagify JS -->
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
    <script>
        $(".logout_btn").click(function () {
            $("#LogoutModal").modal("show");
        });

        // Mobile sidebar toggle
        $(".button-toggle-menu").on('click', function () {
            $('#leftSidebar').toggleClass('mobile-open');
            $('#sidebarOverlay').toggleClass('show');
        });
        $('#sidebarOverlay').on('click', function () {
            $('#leftSidebar').removeClass('mobile-open');
            $(this).removeClass('show');
        });

        $(document).ready(function () {
            // Auto-highlight sidebar menu
            var currentUrl = window.location.pathname;
            $('.side-nav-link, .side-nav-second-level a').each(function () {
                var menuUrl = new URL(this.href).pathname;

                if (menuUrl === currentUrl || (currentUrl === '/' && menuUrl === '/admin-dashboard')) {
                    $(this).addClass('active');
                    $(this).closest('li').addClass('menuitem-active');

                    // Handle Parent highlighting & expansion
                    var parentCollapse = $(this).closest('.collapse');
                    if (parentCollapse.length > 0) {
                        parentCollapse.addClass('show');
                        let parentLink = parentCollapse.prev('.side-nav-link');
                        parentLink.addClass('active').attr('aria-expanded', 'true');
                        parentLink.closest('.side-nav-item').addClass('menuitem-active');
                    }
                }
            });

            $('.summernote').summernote({
                height: 200
            });
        });

        // Global Toast Function
        if (!document.getElementById('toast-container-custom')) {
            var tc = document.createElement('div');
            tc.id = 'toast-container-custom';
            document.body.appendChild(tc);
        }
        function showToast(message, type) {
            type = type || 'error';
            var icons = { error: 'bi-x-circle-fill', success: 'bi-check-circle-fill', warning: 'bi-exclamation-triangle-fill' };
            var icon = icons[type] || icons.error;
            var id = 'toast-' + Date.now();
            var html = '<div class="toast-custom toast-' + type + '" id="' + id + '">'
                + '<i class="bi ' + icon + ' toast-icon"></i>'
                + '<span class="toast-msg">' + message + '</span>'
                + '<span class="toast-close" onclick="removeToast(\'' + id + '\')">&#x2715;</span>'
                + '</div>';
            document.getElementById('toast-container-custom').insertAdjacentHTML('beforeend', html);
            setTimeout(function () { removeToast(id); }, 3500);
        }
        function removeToast(id) {
            var el = document.getElementById(id);
            if (el) {
                el.style.animation = 'slideOutRight 0.3s ease forwards';
                setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 300);
            }
        }
    </script>
    <style>
        /* Modern Sidebar Active State Fixes */
        .side-nav-second-level li.menuitem-active a.active {
            color: #fff !important;
            font-weight: 700 !important;
            background: rgba(255, 255, 255, 0.15) !important;
            border-radius: 4px;
            margin: 2px 10px 2px 15px !important;
            padding-left: 15px !important;
        }

        .side-nav-second-level li a {
            transition: all 0.3s;
        }

        .side-nav-second-level li a:hover {
            color: #fff !important;
            padding-left: 15px !important;
        }
    </style>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js"></script>

    <script>
        // Firebase Configuration
        const firebaseConfig = {
            apiKey: "AIzaSyCi3-PNQwTrBrYGz8icjzUVYsyzopZBRiE",
            authDomain: "sunsoliv-ba089.firebaseapp.com",
            projectId: "sunsoliv-ba089",
            storageBucket: "sunsoliv-ba089.firebasestorage.app",
            messagingSenderId: "200072450575",
            appId: "1:200072450575:web:948cdd7088d41ee63cc97a"
        };

        firebase.initializeApp(firebaseConfig);
        const messaging = firebase.messaging();

        // Register service worker and fetch FCM token
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/firebase-messaging-sw.js')
                .then((registration) => {
                    messaging.getToken({
                        serviceWorkerRegistration: registration
                    }).then((currentToken) => {
                        if (currentToken) {
                            console.log("FCM Token Generated: ", currentToken);
                            $.ajax({
                                url: "/save-admin-fcm-token",
                                method: "POST",
                                data: {
                                    _token: "{{ csrf_token() }}",
                                    fcm_token: currentToken
                                }
                            });
                        }
                    }).catch((err) => {
                        console.warn('Could not get FCM token: ', err);
                    });
                });
        }

        const alertAudio = new Audio('/order_ring.mp3');

        $(document).ready(function() {
            alertAudio.volume = 0;
            let playPromise = alertAudio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    alertAudio.pause();
                    alertAudio.currentTime = 0;
                    alertAudio.volume = 1;
                }).catch(error => {
                    alertAudio.volume = 1;
                    Swal.fire({
                        title: 'Enable Notifications 🔔',
                        text: "Please click 'Enable' to activate real-time order alerts and sounds.",
                        icon: 'info',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        confirmButtonText: 'Enable Now',
                        confirmButtonColor: '#24764c'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            if ("Notification" in window && Notification.permission !== "granted" && Notification.permission !== "denied") {
                                Notification.requestPermission();
                            }
                            alertAudio.volume = 0.01;
                            alertAudio.play().then(() => {
                                setTimeout(() => {
                                    alertAudio.pause();
                                    alertAudio.currentTime = 0;
                                    alertAudio.volume = 1.0;
                                }, 50);
                            }).catch(e => console.warn('Silent audio unlock failed: ', e));
                        }
                    });
                });
            }
            
            // Fallback for Service Worker messaging
            if (navigator.serviceWorker) {
                navigator.serviceWorker.addEventListener('message', function(event) {
                    if (event.data && event.data.type === 'NEW_ORDER') {
                        startOrderPolling();
                    } else if (event.data && event.data.type === 'ACKNOWLEDGE_ORDERS') {
                        if (typeof window.acknowledgeOrders === 'function') {
                            window.acknowledgeOrders();
                            window.location.href = "{{ url('/admin-order') }}";
                        }
                    }
                });
            }
            
            // Guarantee synchronous user gesture for Notification API
            document.addEventListener('click', function requestNotif() {
                if ("Notification" in window && Notification.permission === "default") {
                    Notification.requestPermission();
                }
                document.removeEventListener('click', requestNotif);
            }, { once: true });
            startOrderPolling();
        });

        messaging.onMessage((payload) => {
            console.log('Received foreground message: ', payload);
            if (typeof alertify !== 'undefined') {
                alertify.set('notifier', 'position', 'top-right');
                alertify.success("🎉 " + payload.notification.title + ": " + payload.notification.body);
            }
            alertAudio.currentTime = 0;
            alertAudio.play().catch(e => console.warn('Audio playback blocked: ', e));
            if (typeof showdata === 'function') {
                showdata(window.currentPage || 1);
            }
        });

        let latestOrderId = localStorage.getItem('last_acknowledged_order_id');
        latestOrderId = latestOrderId ? parseInt(latestOrderId) : null;

        function fetchAndCheckOrders() {
            if (latestOrderId === null) return;
            $.ajax({
                url: "{{ url('/admin-show_order') }}",
                type: 'POST',
                data: {
                    _token: "{{ csrf_token() }}",
                    page: 1
                },
                success: function (response) {
                    if (response.data && response.data.length > 0) {
                        let currentHighestId = window.pendingMaxOrderId || latestOrderId;
                        let newOrders = response.data.filter(order => 
                            order.id > currentHighestId && 
                            order.pay_status === 'success' && 
                            (order.order_status === 'confirmed' || order.order_status === 'success')
                        );

                        let maxId = Math.max(...response.data.map(o => o.id));
                        if (maxId > latestOrderId) {
                            window.pendingMaxOrderId = maxId;
                        }

                        if (newOrders.length > 0) {
                            window.unacknowledgedOrders = window.unacknowledgedOrders || [];
                            newOrders.forEach(no => {
                                if (!window.unacknowledgedOrders.find(uo => uo.id === no.id)) {
                                    window.unacknowledgedOrders.push(no);
                                }
                            });

                            if (window.unacknowledgedOrders.length > 0) {
                                alertAudio.currentTime = 0;
                                alertAudio.loop = true;
                                alertAudio.play().catch(e => console.warn('Audio playback blocked: ', e));

                                let swalTitle = window.unacknowledgedOrders.length === 1 ? 'New Order Received!' : `${window.unacknowledgedOrders.length} New Orders!`;
                                
                                let orderListHtml = '';
                                window.unacknowledgedOrders.sort((a, b) => b.id - a.id);
                                window.unacknowledgedOrders.forEach(order => {
                                    let orderId = order.razorpay_order_id ?? order.id;
                                    let viewUrl = `{{ url('/admin-order') }}`;
                                    orderListHtml += `
                                        <a href="${viewUrl}" onclick="window.acknowledgeOrders()" class="order-item-card">
                                            <div style="display: flex; align-items: center; gap: 10px;">
                                                <div style="background: #ffeaea; color: #e23744; padding: 6px 10px; border-radius: 6px; font-weight: bold; font-size: 13px;">
                                                    #${orderId}
                                                </div>
                                            </div>
                                            <div style="font-weight: 700; font-size: 16px; color: #1a1a1a;">
                                                ₹${order.pay_amount} <i class="fa fa-chevron-right" style="font-size: 12px; color: #ccc; margin-left: 8px;"></i>
                                            </div>
                                        </a>
                                    `;
                                });

                                let desktopTitle = '';
                                let desktopBody = '';
                                if (window.unacknowledgedOrders.length === 1) {
                                    let order = window.unacknowledgedOrders[0];
                                    let orderId = order.razorpay_order_id ?? order.id;
                                    desktopTitle = `🚨 New Order: #${orderId}`;
                                    desktopBody = `💰 Amount: ₹${order.pay_amount} | Status: Success\nTap here to manage this order.`;
                                } else {
                                    desktopTitle = `🚨 ${window.unacknowledgedOrders.length} New Orders Received!`;
                                    desktopBody = window.unacknowledgedOrders.map(order => {
                                        let orderId = order.razorpay_order_id ?? order.id;
                                        return `🔹 #${orderId} (₹${order.pay_amount})`;
                                    }).join('\n');
                                    desktopBody += `\n👉 Tap to view & manage all`;
                                }

                                // Desktop Push Notification
                                if ("Notification" in window) {
                                    if (Notification.permission === "granted") {
                                        let notifOptions = {
                                            body: desktopBody,
                                            icon: "{{ asset($info->header_logo ?? 'Admin/assets/images/sunsoliv.png') }}",
                                            requireInteraction: true,
                                            vibrate: [200, 100, 200, 100, 200, 100, 200],
                                            data: {
                                                url: "{{ url('/admin-order') }}"
                                            }
                                        };
                                        if (navigator.serviceWorker) {
                                            navigator.serviceWorker.getRegistration().then(function(reg) {
                                                if (reg) {
                                                    reg.showNotification(desktopTitle, notifOptions);
                                                } else {
                                                    let desktopNotif = new Notification(desktopTitle, notifOptions);
                                                    desktopNotif.onclick = function() {
                                                        window.acknowledgeOrders();
                                                        window.focus();
                                                        window.location.href = "{{ url('/admin-order') }}";
                                                    };
                                                }
                                            }).catch(function(e) {
                                                let desktopNotif = new Notification(desktopTitle, notifOptions);
                                                desktopNotif.onclick = function() {
                                                    window.acknowledgeOrders();
                                                    window.focus();
                                                    window.location.href = "{{ url('/admin-order') }}";
                                                };
                                            });
                                        } else {
                                            let desktopNotif = new Notification(desktopTitle, notifOptions);
                                            desktopNotif.onclick = function() {
                                                window.acknowledgeOrders();
                                                window.focus();
                                                window.location.href = "{{ url('/admin-order') }}";
                                            };
                                        }
                                    } else if (Notification.permission === "default") {
                                        Notification.requestPermission();
                                    }
                                }

                                window.acknowledgeOrders = function() {
                                    window.unacknowledgedOrders = [];
                                    if (window.pendingMaxOrderId) {
                                        localStorage.setItem('last_acknowledged_order_id', window.pendingMaxOrderId);
                                        latestOrderId = window.pendingMaxOrderId;
                                    }
                                    alertAudio.pause();
                                    alertAudio.currentTime = 0;
                                    alertAudio.loop = false;
                                    Swal.close();
                                };

                                Swal.fire({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: true,
                                    confirmButtonText: 'Acknowledge Orders',
                                    customClass: { confirmButton: 'modern-toast-btn', popup: 'swal2-toast-modern' },
                                    allowOutsideClick: false,
                                    allowEscapeKey: false,
                                    backdrop: false,
                                    width: '450px',
                                    html: `
                                        <style>
                                            .modern-toast-btn { 
                                                background: #e23744 !important; 
                                                color: white !important; 
                                                font-size: 15px !important; 
                                                padding: 12px 24px !important; 
                                                border-radius: 8px !important;
                                                font-weight: 600 !important; 
                                                width: 100%; 
                                                margin-top: 15px; 
                                                border: none !important;
                                                box-shadow: 0 4px 12px rgba(226, 55, 68, 0.2);
                                            }
                                            .swal2-toast-modern {
                                                background: #ffffff !important;
                                                box-shadow: 0 8px 30px rgba(0,0,0,0.12) !important;
                                                border-radius: 12px !important;
                                                padding: 20px !important;
                                                border: 1px solid #f0f0f0 !important;
                                            }
                                            .order-item-card {
                                                background: #ffffff;
                                                border: 1px solid #eaeaea;
                                                border-left: 4px solid #e23744;
                                                padding: 12px 16px;
                                                margin-bottom: 10px;
                                                border-radius: 8px;
                                                display: flex;
                                                justify-content: space-between;
                                                align-items: center;
                                                text-decoration: none;
                                                cursor: pointer;
                                                transition: all 0.2s ease;
                                                box-shadow: 0 2px 4px rgba(0,0,0,0.02);
                                            }
                                            .order-item-card:hover {
                                                background: #fdfdfd;
                                                border-color: #e23744;
                                                transform: translateY(-1px);
                                                box-shadow: 0 4px 8px rgba(226,55,68,0.1);
                                            }
                                        </style>
                                        <div style="text-align: left;">
                                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
                                                <div style="background: linear-gradient(135deg, #e23744, #ff5252); border-radius: 50%; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(226,55,68,0.3);">
                                                    <i class="fas fa-bell" style="color: white; font-size: 20px;"></i>
                                                </div>
                                                <div>
                                                    <h3 style="color: #1a1a1a; margin: 0; font-size: 18px; font-weight: 700;">${swalTitle}</h3>
                                                    <p style="margin: 3px 0 0 0; color: #777; font-size: 13px;">Action required to mute alarm</p>
                                                </div>
                                            </div>
                                            <div style="margin-top: 10px; max-height: 250px; overflow-y: auto; padding-right: 5px;">
                                                ${orderListHtml}
                                            </div>
                                        </div>
                                    `
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.acknowledgeOrders();
                                    }
                                });

                                if (typeof showdata === 'function') {
                                    showdata(window.currentPage || 1);
                                }
                            }
                        }
                    }
                }
            });
        }

        // Initialize Web Worker for unthrottled background polling
        const orderWorker = new Worker("{{ asset('order-worker.js') }}");
        orderWorker.onmessage = function(e) {
            if (e.data === 'tick') {
                fetchAndCheckOrders();
            }
        };

        function startOrderPolling() {
            if (latestOrderId === null) {
                $.ajax({
                    url: "{{ url('/admin-show_order') }}",
                    type: 'POST',
                    data: {
                        _token: "{{ csrf_token() }}",
                        page: 1
                    },
                    success: function (response) {
                        if (response.data && response.data.length > 0) {
                            latestOrderId = response.data[0].id;
                            localStorage.setItem('last_acknowledged_order_id', latestOrderId);
                        } else {
                            latestOrderId = 0;
                            localStorage.setItem('last_acknowledged_order_id', 0);
                        }
                    }
                });
            } else {
                fetchAndCheckOrders();
            }

            orderWorker.postMessage('start');
        }
    </script>
</body>

</html>