<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>The Ulhas Vilas — Estate Administration Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="The Ulhas Vilas Luxury Estates Admin Portal - Himachal Pradesh" name="description" />

    <!-- App Favicon -->
    <link rel="shortcut icon" href="{{ asset('Admin/assets/images/ulhas_logo.png') }}">

    <!-- Google Fonts: Cinzel, Playfair Display & Plus Jakarta Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,500&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Remix Icons & Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        :root {
            --brand-bg: #07150f;
            --brand-forest: #143525;
            --brand-card-top: #152f22;
            --brand-card-bot: #0d1e16;
            --brand-gold-bright: #ebd08d;
            --brand-gold: #c5a059;
            --brand-gold-dark: #967433;
            --text-light: #ffffff;
            --text-sub: #cbd5e1;
            --text-muted: #64748b;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        html, body {
            height: 100vh;
            max-height: 100vh;
            width: 100vw;
            background-color: var(--brand-bg);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden !important;
            position: relative;
        }

        /* Ambient Glowing Background & Dotted Grid */
        .ambient-glow-top {
            position: fixed;
            top: -15%;
            left: 30%;
            width: 650px;
            height: 450px;
            background: radial-gradient(circle, rgba(35, 120, 72, 0.28) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
        }

        .ambient-glow-bottom {
            position: fixed;
            bottom: -20%;
            right: 25%;
            width: 600px;
            height: 450px;
            background: radial-gradient(circle, rgba(197, 160, 89, 0.18) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
        }

        .bg-dots {
            position: fixed;
            inset: 0;
            background-image: radial-gradient(rgba(197, 160, 89, 0.18) 1.2px, transparent 1.2px);
            background-size: 28px 28px;
            pointer-events: none;
            z-index: 0;
            opacity: 0.85;
        }

        /* Main Container - Compact Fit without scroll */
        .auth-container {
            width: 100%;
            max-width: 960px;
            padding: 12px 16px;
            position: relative;
            z-index: 10;
            margin: auto;
        }

        /* Outer Glowing Frame */
        .card-frame {
            position: relative;
            border-radius: 26px;
            padding: 1.5px;
            background: linear-gradient(145deg, rgba(235, 208, 141, 0.8) 0%, rgba(35, 120, 72, 0.5) 45%, rgba(197, 160, 89, 0.4) 100%);
            box-shadow: 
                0 30px 70px -15px rgba(0, 0, 0, 0.85),
                0 0 45px rgba(197, 160, 89, 0.15);
            animation: cardEntrance 0.5s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Split Inner Container */
        .auth-card-split {
            background: linear-gradient(180deg, #132a1f 0%, #0c1c14 100%);
            border-radius: 24.5px;
            display: flex;
            overflow: hidden;
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            max-height: calc(100vh - 40px);
        }

        /* =========================================================================
           LEFT SIDE: Content & Villa Highlights Showcase
           ========================================================================= */
        .showcase-pane {
            flex: 1.1;
            padding: 32px 34px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            background: 
                linear-gradient(180deg, rgba(14, 34, 25, 0.88) 0%, rgba(7, 19, 14, 0.95) 100%),
                url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80') center/cover no-repeat;
            border-right: 1px solid rgba(197, 160, 89, 0.22);
        }

        .showcase-badge {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            background: rgba(7, 19, 14, 0.75);
            border: 1px solid rgba(197, 160, 89, 0.4);
            border-radius: 50px;
            padding: 5px 12px;
            font-size: 0.72rem;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--brand-gold-bright);
            font-weight: 700;
            backdrop-filter: blur(8px);
            width: fit-content;
        }

        .showcase-badge .pulse-dot {
            width: 6px;
            height: 6px;
            background-color: #10b981;
            border-radius: 50%;
            box-shadow: 0 0 8px #10b981;
            animation: pulseGlow 2s infinite;
        }

        .showcase-content {
            margin: auto 0 16px 0;
            position: relative;
            z-index: 2;
        }

        .showcase-title {
            font-family: 'Cinzel', serif;
            font-size: 1.7rem;
            font-weight: 700;
            line-height: 1.22;
            color: #ffffff;
            margin-bottom: 8px;
            letter-spacing: 0.5px;
        }

        .showcase-title span {
            background: linear-gradient(135deg, #ffffff 20%, var(--brand-gold-bright) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .showcase-desc {
            font-size: 0.86rem;
            color: #cbd5e1;
            line-height: 1.5;
            margin-bottom: 18px;
            font-weight: 400;
        }

        /* 2x2 Feature Grid */
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .feature-pill {
            background: rgba(12, 30, 22, 0.75);
            border: 1px solid rgba(197, 160, 89, 0.25);
            border-radius: 12px;
            padding: 10px 12px;
            display: flex;
            align-items: center;
            gap: 9px;
            transition: all 0.25s ease;
            backdrop-filter: blur(10px);
        }

        .feature-pill:hover {
            border-color: var(--brand-gold);
            background: rgba(18, 42, 31, 0.9);
            transform: translateY(-2px);
        }

        .feature-icon {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            background: linear-gradient(135deg, rgba(197, 160, 89, 0.25), rgba(35, 120, 72, 0.2));
            border: 1px solid rgba(197, 160, 89, 0.35);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--brand-gold-bright);
            font-size: 1rem;
            flex-shrink: 0;
        }

        .feature-text h6 {
            margin: 0;
            font-size: 0.78rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
        }

        .feature-text span {
            font-size: 0.68rem;
            color: var(--text-muted);
        }

        .showcase-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 12px;
            font-size: 0.74rem;
            color: #94a3b8;
        }

        /* =========================================================================
           RIGHT SIDE: Exact Luxury Login Form Pattern
           ========================================================================= */
        .form-pane {
            flex: 1;
            padding: 32px 32px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            text-align: center;
        }

        /* Logo & Brand Header */
        .logo-wrapper {
            margin: 0 auto 6px auto;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .logo-wrapper img {
            height: 52px;
            width: auto;
            max-width: 100%;
            object-fit: contain;
            filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.5));
            transition: transform 0.3s ease;
        }

        .logo-wrapper:hover img {
            transform: scale(1.05);
        }

        .brand-heading {
            font-family: 'Cinzel', serif;
            font-size: 1.35rem;
            font-weight: 700;
            color: #ffffff;
            letter-spacing: 0.5px;
            margin-top: 6px;
            margin-bottom: 2px;
        }

        .brand-subline {
            font-size: 0.7rem;
            color: var(--brand-gold);
            letter-spacing: 1.8px;
            text-transform: uppercase;
            font-weight: 700;
            margin-bottom: 18px;
            display: block;
        }

        /* Form Controls */
        .form-group {
            margin-bottom: 14px;
            text-align: left;
        }

        .form-label {
            font-size: 0.76rem;
            font-weight: 600;
            color: #cbd5e1;
            margin-bottom: 5px;
            display: block;
            letter-spacing: 0.3px;
        }

        .input-relative {
            position: relative;
            display: flex;
            align-items: center;
        }

        .input-icon-left {
            position: absolute;
            left: 16px;
            font-size: 1.1rem;
            color: var(--brand-gold);
            pointer-events: none;
            z-index: 5;
            transition: color 0.25s ease;
        }

        .form-control-custom {
            width: 100%;
            height: 46px;
            background: rgba(8, 20, 15, 0.7);
            border: 1.5px solid rgba(197, 160, 89, 0.32);
            border-radius: 12px;
            padding: 8px 16px 8px 46px;
            font-size: 0.88rem;
            color: #ffffff;
            font-weight: 500;
            transition: all 0.25s ease;
            outline: none;
        }

        .form-control-custom::placeholder {
            color: #64748b;
            font-weight: 400;
        }

        .form-control-custom:focus {
            border-color: var(--brand-gold-bright);
            background: rgba(12, 28, 20, 0.95);
            box-shadow: 0 0 0 3px rgba(197, 160, 89, 0.22);
            color: #ffffff;
        }

        .input-relative:focus-within .input-icon-left {
            color: var(--brand-gold-bright);
        }

        .password-toggle-btn {
            position: absolute;
            right: 14px;
            background: transparent;
            border: none;
            color: #64748b;
            cursor: pointer;
            font-size: 1.15rem;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s ease;
            z-index: 5;
        }

        .password-toggle-btn:hover {
            color: var(--brand-gold-bright);
        }

        /* Options Row */
        .options-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
            font-size: 0.74rem;
            color: #94a3b8;
        }

        .remember-checkbox {
            display: flex;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            user-select: none;
        }

        .remember-checkbox input {
            accent-color: var(--brand-gold);
            width: 14px;
            height: 14px;
            cursor: pointer;
        }

        .badge-live-session {
            color: var(--brand-gold);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* Glowing Submit Button */
        .btn-submit {
            width: 100%;
            height: 48px;
            background: linear-gradient(135deg, #dfba73 0%, #c5a059 50%, #9f7a37 100%);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            color: #07130e;
            font-weight: 800;
            font-size: 0.94rem;
            letter-spacing: 0.4px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
            box-shadow: 
                0 8px 24px rgba(197, 160, 89, 0.45),
                inset 0 1px 1px rgba(255, 255, 255, 0.4);
            transition: all 0.25s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, #f5da98 0%, #d6ad5c 50%, #ae843a 100%);
            transform: translateY(-2px);
            box-shadow: 
                0 12px 28px rgba(197, 160, 89, 0.6),
                inset 0 1px 1px rgba(255, 255, 255, 0.6);
            color: #040d09;
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-submit i {
            font-size: 1.1rem;
            transition: transform 0.25s ease;
        }

        .btn-submit:hover i {
            transform: translateX(4px);
        }

        /* Portal Footer */
        .portal-footer-tag {
            font-size: 0.72rem;
            color: #64748b;
            margin-top: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .portal-footer-tag i {
            color: var(--brand-gold);
        }

        @keyframes cardEntrance {
            from {
                opacity: 0;
                transform: translateY(16px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes pulseGlow {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.4; transform: scale(0.8); }
        }

        /* Responsive */
        @media (max-width: 860px) {
            .auth-card-split {
                flex-direction: column;
            }
            .showcase-pane {
                display: none;
            }
            .form-pane {
                padding: 28px 20px;
            }
        }
    </style>
</head>

<body>

    <!-- Ambient Gradient Atmosphere -->
    <div class="ambient-glow-top"></div>
    <div class="ambient-glow-bottom"></div>
    <div class="bg-dots"></div>

    <div class="auth-container">
        <div class="card-frame">
            <div class="auth-card-split">
                
                <!-- =========================================================
                     LEFT SIDE: Attractive Villa Residence Content Showcase
                     ========================================================= -->
                <div class="showcase-pane">
                    
                    <div class="showcase-badge">
                        <span class="pulse-dot"></span>
                        <span>The Ulhas Vilas • HP</span>
                    </div>

                    <div class="showcase-content">
                        <h2 class="showcase-title">
                            Architectural Living & <span>Mountain Estates</span>
                        </h2>
                        <p class="showcase-desc">
                            A private sanctuary of bespoke 1 to 4 BHK luxury residences and duplexes nestled in the serene pines of Himachal Pradesh.
                        </p>

                        <!-- Feature 2x2 Grid -->
                        <div class="feature-grid">
                            <div class="feature-pill">
                                <div class="feature-icon"><i class="ri-home-8-line"></i></div>
                                <div class="feature-text">
                                    <h6>1 - 4 BHK Villas</h6>
                                    <span>Private Duplexes</span>
                                </div>
                            </div>

                            <div class="feature-pill">
                                <div class="feature-icon"><i class="ri-shield-star-line"></i></div>
                                <div class="feature-text">
                                    <h6>RERA Certified</h6>
                                    <span>Freehold Titles</span>
                                </div>
                            </div>

                            <div class="feature-pill">
                                <div class="feature-icon"><i class="ri-drop-line"></i></div>
                                <div class="feature-text">
                                    <h6>Thermal Spa</h6>
                                    <span>Infinity Pool</span>
                                </div>
                            </div>

                            <div class="feature-pill">
                                <div class="feature-icon"><i class="ri-landscape-line"></i></div>
                                <div class="feature-text">
                                    <h6>360° Vistas</h6>
                                    <span>Forest Panoramas</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="showcase-footer">
                        <span><i class="ri-map-pin-2-fill text-warning me-1"></i> Himachal Pradesh</span>
                        <span><i class="ri-lock-2-fill text-warning me-1"></i> 256-Bit SSL</span>
                    </div>

                </div>

                <!-- =========================================================
                     RIGHT SIDE: Exact Pattern Login Form
                     ========================================================= -->
                <div class="form-pane">
                    
                    <!-- Logo & Brand Header -->
                    <div class="logo-wrapper">
                        <img src="{{ asset('Admin/assets/images/ulhas_logo.png') }}" alt="The Ulhas Vilas">
                    </div>
                    <h1 class="brand-heading">The Ulhas Vilas</h1>
                    <span class="brand-subline">ESTATE ADMINISTRATION PORTAL</span>

                    <!-- Login Form -->
                    <form id="formAuthentication" method="post" action="javascript:void(0);">
                        @csrf

                        <!-- Username / Email Field -->
                        <div class="form-group">
                            <label for="email" class="form-label">Username / Email Address</label>
                            <div class="input-relative">
                                <i class="ri-user-3-line input-icon-left"></i>
                                <input type="text" class="form-control-custom" name="email" id="email"
                                    placeholder="Enter admin username or email" required autocomplete="username">
                            </div>
                        </div>

                        <!-- Password Field -->
                        <div class="form-group">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-relative">
                                <i class="ri-lock-2-line input-icon-left"></i>
                                <input type="password" class="form-control-custom" name="password" id="password"
                                    placeholder="Enter your secret password" required autocomplete="current-password">
                                <button type="button" class="password-toggle-btn" onclick="togglePassword()" aria-label="Toggle password visibility">
                                    <i class="ri-eye-off-line" id="eyeIcon"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Options Row -->
                        <div class="options-row">
                            <label class="remember-checkbox">
                                <input type="checkbox" id="rememberMe" checked>
                                <span>Remember me</span>
                            </label>
                            <span class="badge-live-session">
                                <i class="ri-shield-check-line"></i> Secure Console
                            </span>
                        </div>

                        <!-- Glowing Golden Button Matching Screenshot -->
                        <button class="btn-submit btn-login" type="submit">
                            <span>Sign In to Estate Dashboard</span>
                            <i class="ri-arrow-right-line"></i>
                        </button>
                    </form>

                    <!-- Footer Tag -->
                    <div class="portal-footer-tag">
                        <i class="ri-shield-check-line"></i> Secure Management Console • Himachal Pradesh
                    </div>

                </div>

            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.classList.remove('ri-eye-off-line');
                eyeIcon.classList.add('ri-eye-line');
            } else {
                passwordInput.type = 'password';
                eyeIcon.classList.remove('ri-eye-line');
                eyeIcon.classList.add('ri-eye-off-line');
            }
        }

        $(document).ready(function () {
            $("#formAuthentication").submit(function (e) {
                e.preventDefault();

                const btn = $(this).find('.btn-login');
                const originalHtml = btn.html();
                
                btn.html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Authenticating...');
                btn.prop('disabled', true);

                var formdata = new FormData(this);
                $.ajax({
                    type: "post",
                    url: "{{ url('/admin-login') }}",
                    data: formdata,
                    contentType: false,
                    processData: false,
                    cache: false,
                    dataType: 'json',
                    encode: true,
                    success: function (data) {
                        if (data.success === '1') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Access Granted',
                                text: 'Welcome back to The Ulhas Vilas.',
                                timer: 1000,
                                showConfirmButton: false,
                                background: '#132a1f',
                                color: '#ebd08d',
                                iconColor: '#c5a059'
                            });
                            setTimeout(function() {
                                window.location.href = "{{ url('/admin-dashboard') }}";
                            }, 900);
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Access Denied',
                                text: 'Invalid username or password.',
                                confirmButtonColor: '#c5a059',
                                background: '#132a1f',
                                color: '#ffffff',
                                iconColor: '#ef4444'
                            });
                            btn.html(originalHtml);
                            btn.prop('disabled', false);
                        }
                    },
                    error: function (err) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Something went wrong. Please try again.',
                            confirmButtonColor: '#c5a059',
                            background: '#132a1f',
                            color: '#ffffff',
                            iconColor: '#ef4444'
                        });
                        btn.html(originalHtml);
                        btn.prop('disabled', false);
                    }
                });
            });
        });
    </script>
</body>

</html>