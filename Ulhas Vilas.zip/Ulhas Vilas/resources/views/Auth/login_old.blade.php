<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Chaarvi Tour and Travel | Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Chaarvi Tour and Travel admin login" name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <!-- Theme Config Js -->
    <script src="{{ asset('Admin/assets/js/hyper-config.js') }}"></script>
    <!-- App css -->
    <link href="{{ asset('Admin/assets/css/app-saas.min.css') }}" rel="stylesheet" type="text/css" id="app-style" />
    <!-- Icons css -->
    <link href="{{ asset('Admin/assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />

    <style>
        :root {
            --chaarvi-blue: #123b63;
            --chaarvi-teal: #168a8a;
        }

        body.authentication-bg {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background:
                radial-gradient(circle at top left,
                    rgba(12, 135, 80, 0.12),
                    rgba(229, 158, 32, 0.10)),
                #f4f7f5;
        }

        .auth-overlay-svg {
            position: absolute;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            opacity: 0.35;
        }

        .account-pages {
            position: relative;
            z-index: 1;
            width: 100%;
        }

        .auth-card {
            border: 0;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 18px 45px rgba(15, 23, 42, 0.16);
            background: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(12px);
        }

        .auth-card-header {
            background: linear-gradient(135deg,
                    rgba(12, 135, 80, 0.14),
                    rgba(229, 158, 32, 0.22));
            padding: 24px 28px 16px;
            text-align: center;
        }

        .auth-logo-circle {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 20%, #fca60e80, #0c875085);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 14px;
            box-shadow: 0 10px 26px rgba(12, 135, 80, 0.45);
            overflow: hidden;
        }

        .auth-logo-circle .auth-logo-img {
            max-width: 78%;
            max-height: 78%;
            object-fit: contain;
            display: block;
        }

        .auth-title {
            font-weight: 700;
            color: #063824;
            margin-bottom: 4px;
        }

        .auth-subtitle {
            font-size: 0.9rem;
            color: #6b7280;
        }

        .auth-card-body {
            padding: 24px 28px 28px;
        }

        .form-label {
            font-weight: 500;
            font-size: 0.9rem;
            color: #4b5563;
        }

        .form-control {
            border-radius: 10px;
            border-color: #e5e7eb;
            padding: 0.6rem 0.9rem;
            font-size: 0.95rem;
        }

        .form-control:focus {
            border-color: var(--chaarvi-teal);
            box-shadow: 0 0 0 0.15rem rgba(12, 135, 80, 0.3);
        }

        .input-group-text {
            border-radius: 0 10px 10px 0;
            border-color: #e5e7eb;
            cursor: pointer;
            background: #f9fafb;
        }

        .btn-primary {
            border-radius: 999px;
            padding: 0.65rem 1.5rem;
            font-weight: 600;
            border: none;
            background-image: linear-gradient(135deg,
                    var(--chaarvi-blue),
                    var(--chaarvi-teal));
            box-shadow: 0 10px 25px rgba(12, 135, 80, 0.55);
        }

        .btn-primary:hover {
            filter: brightness(0.96);
            box-shadow: 0 12px 30px rgba(12, 135, 80, 0.75);
        }

        .footer-alt {
            font-size: 0.85rem;
            color: #6b7280;
        }

        @media (max-width: 576px) {
            .auth-card-header {
                padding: 20px 20px 12px;
            }

            .auth-card-body {
                padding: 20px;
            }

            .auth-title {
                font-size: 1.2rem;
            }
        }
    </style>
</head>

<body class="authentication-bg position-relative">
    <!-- Soft radial SVG background -->
    <div class="auth-overlay-svg">
        <svg xmlns='http://www.w3.org/2000/svg' width='100%' height='100%' viewBox='0 0 800 800'>
            <g fill-opacity='0.18'>
                <circle style="fill: rgba(12, 135, 80, 0.05);" cx='400' cy='400' r='600' />
                <circle style="fill: rgba(12, 135, 80, 0.10);" cx='400' cy='400' r='500' />
                <circle style="fill: rgba(229, 158, 32, 0.16);" cx='400' cy='400' r='320' />
                <circle style="fill: rgba(12, 135, 80, 0.20);" cx='400' cy='400' r='220' />
                <circle style="fill: rgba(229, 158, 32, 0.3);" cx='400' cy='400' r='120' />
            </g>
        </svg>
    </div>

    <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5 position-relative">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-4 col-lg-5 col-md-7">
                    <div class="card auth-card">

                        <!-- Header -->
                        <div class="auth-card-header">
                            <div class="auth-logo-circle">
                                <img src="{{ asset('Website/assets/images/logo/chaarvi_logo.png') }}" alt="Chaarvi Tour and Travel logo"
                                    class="auth-logo-img">
                            </div>

                            <h4 class="auth-title">Admin Login</h4>
                            <p class="auth-subtitle mb-0">
                                Chaarvi Tour and Travel
                            </p>
                        </div>

                        <!-- Body -->
                        <div class="card-body auth-card-body">
                            <form id="formAuthentication" method="post" action="javascript:void(0);">
                                @csrf
                                <div class="mb-3">
                                    <label for="email" class="form-label">Username</label>
                                    <input class="form-control" type="email" name="email" id="email"
                                        placeholder="Username">
                                </div>

                                <div class="mb-2">
                                    <label for="password" class="form-label">Password</label>
                                    <div class="input-group input-group-merge">
                                        <input type="password" name="password" id="password" class="form-control"
                                            placeholder="Password">
                                        <div class="input-group-text" data-password="false">
                                            <span class="password-eye"></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-0 text-center">
                                    <button class="btn btn-primary w-100" type="submit">
                                        Log In
                                    </button>
                                </div>
                            </form>
                        </div> <!-- end card-body -->
                    </div>
                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <footer class="footer footer-alt text-center mt-2 mb-3">
        <script>
            document.write(new Date().getFullYear());
        </script>
        © Partners Advertising Pvt. Ltd.
    </footer>

    <!-- Vendor js -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="{{ asset('Admin/assets/js/vendor.min.js') }}"></script>
    <script src="{{ asset('Admin/assets/js/app.min.js') }}"></script>

    <script>
        $(document).ready(function () {
            $("#formAuthentication").submit(function (e) {
                e.preventDefault();
                var formdata = new FormData(this);
                $.ajax({
                    type: "post",
                    url: "{{ url('/admin-login') }}",
                    data: formdata,
                    contentType: false,
                    processData: false,
                    cache: false,
                    dataType: 'json',
                    encode: true,
                    success: function (data) {
                        if (data.success === '1') {
                            swal("Login Successfully", "Redirect to Dashboard", "success");
                            location.href = "{{ '/admin-dashboard' }}";
                        } else {
                            swal("Credential failed", "Please Login First", "error");
                            location.href = "{{ '/login' }}";
                        }
                    },
                    error: function (err) { }
                });
            });
        });
    </script>
</body>

</html>