<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<script>
  // Reveal on scroll (no library)
  const els = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting){
        e.target.classList.add('show');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.15 });

  els.forEach(el => io.observe(el));
</script>






<!--------------------------LOGIN------------------>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const loginForm = document.getElementById('loginForm');

        if (loginForm) {
            loginForm.addEventListener('submit', function (e) {
                e.preventDefault();

                // Replace this with actual submit if backend is ready:
                // this.submit();

                window.location.href = "/";
            });
        }
    });
</script>





<!----------------------SIGNUP------------------>
<script>
    const togglePassword = document.getElementById('togglePassword');
    const password = document.getElementById('password');

    if (togglePassword && password) {
        togglePassword.addEventListener('click', function () {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.innerHTML = type === 'password'
                ? '<i class="fa-solid fa-eye"></i>'
                : '<i class="fa-solid fa-eye-slash"></i>';
        });
    }

    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    const confirmPassword = document.getElementById('confirmPassword');

    if (toggleConfirmPassword && confirmPassword) {
        toggleConfirmPassword.addEventListener('click', function () {
            const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
            confirmPassword.setAttribute('type', type);
            this.innerHTML = type === 'password'
                ? '<i class="fa-solid fa-eye"></i>'
                : '<i class="fa-solid fa-eye-slash"></i>';
        });
    }
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const verifyOtpBtn = document.getElementById('verifyOtpBtn');
        const otpStep = document.getElementById('otpStep');
        const detailsStep = document.getElementById('detailsStep');

        if (verifyOtpBtn && otpStep && detailsStep) {
            verifyOtpBtn.addEventListener('click', function () {
                // Backend OTP verification ke baad hi isko show karna hoga.
                // Abhi layout/demo ke liye directly next step show kar rahe hain.
                otpStep.style.display = 'none';
                detailsStep.style.display = 'block';
            });
        }
    });
</script>


<!-----------------------------CHECKOUT---------------------------------->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const paymentOptions = document.querySelectorAll('.payment-option');
    paymentOptions.forEach(option => {
        option.addEventListener('click', function () {
            paymentOptions.forEach(item => item.classList.remove('active'));
            this.classList.add('active');
            const radio = this.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });
    });

    const subtotal = 4296;
    const shipping = 99;
    const tax = 180;

    const couponInput = document.getElementById('couponInput');
    const applyCouponBtn = document.getElementById('applyCouponBtn');
    const discountAmount = document.getElementById('discountAmount');
    const totalAmount = document.getElementById('totalAmount');
    const couponMessage = document.getElementById('couponMessage');

    function formatINR(amount) {
        return '₹' + amount;
    }

    if (applyCouponBtn) {
        applyCouponBtn.addEventListener('click', function () {
            const code = couponInput.value.trim().toUpperCase();
            let discount = 0;

            if (code === 'SAVE300') {
                discount = 300;
                if (couponMessage) {
                    couponMessage.style.display = 'flex';
                    couponMessage.querySelector('span').textContent = 'Coupon SAVE300 applied successfully.';
                }
            } else if (code === 'NATURE100') {
                discount = 100;
                if (couponMessage) {
                    couponMessage.style.display = 'flex';
                    couponMessage.querySelector('span').textContent = 'Coupon NATURE100 applied successfully.';
                }
            } else if (code === '') {
                discount = 0;
                if (couponMessage) couponMessage.style.display = 'none';
            } else {
                discount = 0;
                if (couponMessage) {
                    couponMessage.style.display = 'flex';
                    couponMessage.querySelector('span').textContent = 'Invalid coupon code.';
                }
            }

            const total = subtotal - discount + shipping + tax;

            if (discountAmount) discountAmount.textContent = '- ' + formatINR(discount);
            if (totalAmount) totalAmount.textContent = formatINR(total);
        });
    }
});
</script>






<!------------------------------CONTACT US------------------------>

<script>
    const cpForm = document.getElementById('cpForm');
    if (cpForm) {
        cpForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const toast = document.getElementById('cpToast');
            if (toast) toast.classList.add('show');
            this.reset();
            if (toast) setTimeout(() => toast.classList.remove('show'), 4000);
        });
    }
</script>

<!----------------------------------------ABOUT US ------------------------->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId && targetId !== '#') {
                    const target = document.querySelector(targetId);
                    if (target) {
                        e.preventDefault();
                        target.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            });
        });
    });
</script>

<!----------------------------------PRODUCTS--------------------------------------->

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const searchInput = document.getElementById('productSearch');
        const categoryFilter = document.getElementById('categoryFilter');
        const sortFilter = document.getElementById('sortFilter');
        const productGrid = document.getElementById('productGrid');
        if (!productGrid) return;
        const productCards = Array.from(productGrid.querySelectorAll('.pr-card'));
        const exploreBtn = document.getElementById('exploreProductsBtn');

        function filterProducts() {
            const searchValue = searchInput.value.trim().toLowerCase();
            const categoryValue = categoryFilter.value;

            productCards.forEach(function(card) {
                const name = card.dataset.name.toLowerCase();
                const category = card.dataset.category.toLowerCase();

                const matchesSearch = name.includes(searchValue);
                const matchesCategory = categoryValue === 'all' || category === categoryValue;

                if (matchesSearch && matchesCategory) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        }

        function sortProducts() {
            const sortValue = sortFilter.value;
            const cards = Array.from(productGrid.querySelectorAll('.pr-card'));

            cards.sort(function(a, b) {
                const nameA = a.dataset.name.toLowerCase();
                const nameB = b.dataset.name.toLowerCase();
                const priceA = parseInt(a.dataset.price, 10);
                const priceB = parseInt(b.dataset.price, 10);

                if (sortValue === 'name-asc') return nameA.localeCompare(nameB);
                if (sortValue === 'name-desc') return nameB.localeCompare(nameA);
                if (sortValue === 'price-low') return priceA - priceB;
                if (sortValue === 'price-high') return priceB - priceA;
                return 0;
            });

            cards.forEach(function(card) {
                productGrid.appendChild(card);
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', filterProducts);
        }

        if (categoryFilter) {
            categoryFilter.addEventListener('change', filterProducts);
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', function() {
                sortProducts();
                filterProducts();
            });
        }

        if (exploreBtn) {
            exploreBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.getElementById('all-products');
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        }

        document.querySelectorAll('.pr-wishlist').forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                this.classList.toggle('active');

                const icon = this.querySelector('i');
                if (this.classList.contains('active')) {
                    icon.classList.remove('fa-regular');
                    icon.classList.add('fa-solid');
                } else {
                    icon.classList.remove('fa-solid');
                    icon.classList.add('fa-regular');
                }
            });
        });
    });
</script>
