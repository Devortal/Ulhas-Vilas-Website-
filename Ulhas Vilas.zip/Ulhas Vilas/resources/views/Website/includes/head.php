@php
    $info = DB::table('information')->first();
    $categories = DB::table('categories')->where('status', 1)->orderBy('id', 'desc')->get();
    $cartCount = 0;
    $wishlistCount = 0;
    $quoteCount = 0;

    $isLoggedIn = false;
    if (Session()->has('user_login') && Session()->has('user_login_time')) {
        $loginTime = Session()->get('user_login_time');
        $timeoutMinutes = 1051200; // 2 years
        $now = \Carbon\Carbon::now('Asia/Kolkata')->timestamp;

        if (($now - $loginTime) <= ($timeoutMinutes * 60)) {
            $isLoggedIn = true;
        } else {
            Session()->forget('user_login');
            Session()->forget('user_login_time');
        }
    }

    if ($isLoggedIn) {
        $user = Session()->get('user_login');
        $userId = is_array($user) ? ($user[0]->id ?? null) : ($user->id ?? null);

        if ($userId) {
            $cartCount = DB::table('carts')->where('user_id', $userId)->where('status', 'false')->count();
            $wishlistCount = DB::table('tbl_wishlist')->where('user_id', $userId)->where('status', 'false')->count();
            $quoteCount = DB::table('get_quotes')->where('user_id', $userId)->count();
        }
    }
    $userType = 'B2C';
    if ($isLoggedIn) {
        $userData = is_array($user) ? $user[0] : $user;
        $userType = $userData->user_type ?? 'B2C';
    }
@endphp
<style>
    .site-topbar {
        background-color: #02060f !important;
        color: #d1d5db !important;
        border-bottom: 1px solid #1f2937 !important;
    }
    .site-header {
        position: -webkit-sticky !important;
        position: sticky !important;
        top: 0 !important;
        z-index: 1000 !important;
        background-color: rgba(5, 12, 24, 0.98) !important;
        backdrop-filter: blur(8px) !important;
        -webkit-backdrop-filter: blur(8px) !important;
    }
    .site-logo-img {
        width: 46px !important;
        height: 46px !important;
        max-width: 46px !important;
        max-height: 46px !important;
        border-radius: 50% !important;
        border: 1.5px solid #cca43b !important;
        object-fit: cover !important;
        display: block !important;
    }
</style>

<!-- TOP INFO BAR -->
<div class="site-topbar hidden md:block text-gray-300 text-xs font-sora py-1.5">
    <div class="max-w-7xl mx-auto px-4 md:px-8 flex flex-col md:flex-row justify-between items-center gap-3">
        <!-- Socials (Follow Us text removed, icons render dynamically if link exists in DB) -->
        <div class="flex items-center gap-2.5">
            @if(!empty($info) && !empty($info->facebook_link))
                <a href="{{ $info->facebook_link }}" target="_blank" class="w-8 h-8 rounded-full bg-gray-800 hover:bg-gold hover:text-navy-dark flex items-center justify-center transition duration-300" title="Facebook">
                    <i class="fa-brands fa-facebook-f text-xs"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->instagram_link))
                <a href="{{ $info->instagram_link }}" target="_blank" class="w-8 h-8 rounded-full bg-gray-800 hover:bg-gold hover:text-navy-dark flex items-center justify-center transition duration-300" title="Instagram">
                    <i class="fa-brands fa-instagram text-xs"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->twitter_link))
                <a href="{{ $info->twitter_link }}" target="_blank" class="w-8 h-8 rounded-full bg-gray-800 hover:bg-gold hover:text-navy-dark flex items-center justify-center transition duration-300" title="X (Twitter)">
                    <i class="fa-brands fa-x-twitter text-xs"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->youtube_link))
                <a href="{{ $info->youtube_link }}" target="_blank" class="w-8 h-8 rounded-full bg-gray-800 hover:bg-gold hover:text-navy-dark flex items-center justify-center transition duration-300" title="YouTube">
                    <i class="fa-brands fa-youtube text-xs"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->linkedin_link))
                <a href="{{ $info->linkedin_link }}" target="_blank" class="w-8 h-8 rounded-full bg-gray-800 hover:bg-gold hover:text-navy-dark flex items-center justify-center transition duration-300" title="LinkedIn">
                    <i class="fa-brands fa-linkedin-in text-xs"></i>
                </a>
            @endif
        </div>

        <!-- Contact Links (Dynamic from DB) -->
        <div class="flex flex-wrap justify-center items-center gap-4 md:gap-6 text-gray-300 font-medium">
            @if(!empty($info) && !empty($info->mobile))
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="flex items-center gap-2 hover:text-gold transition duration-300">
                    <i class="fa-solid fa-phone text-gold text-xs"></i>
                    <span>{{ $info->mobile }}</span>
                </a>
            @endif
            @if(!empty($info) && !empty($info->email))
                <a href="mailto:{{ $info->email }}" class="flex items-center gap-2 hover:text-gold transition duration-300">
                    <i class="fa-solid fa-envelope text-gold text-xs"></i>
                    <span>{{ $info->email }}</span>
                </a>
            @endif
            @if(!empty($info) && !empty($info->address))
                <div class="flex items-center gap-2 text-gray-400">
                    <i class="fa-solid fa-location-dot text-gold text-xs"></i>
                    <span class="truncate max-w-[280px]">{{ str_replace(["\r\n", "\n", "\r"], ' ', $info->address) }}</span>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- MAIN NAVIGATION HEADER -->
<header id="mainHeader" class="site-header text-white w-full border-b border-gray-800 font-sora transition-all duration-300 shadow-md">
    <div class="max-w-7xl mx-auto px-4 md:px-8 py-2 flex items-center justify-between">
        
        <!-- Logo (Dynamic from DB) -->
        <a href="/" class="flex items-center gap-3">
            <img src="{{ (!empty($info) && !empty($info->header_logo)) ? asset($info->header_logo) : ((!empty($info) && !empty($info->footer_logo)) ? asset($info->footer_logo) : asset('Website/assets/images/logo/chaarvi_logo.png')) }}" alt="Chaarvi Tours" class="site-logo-img">
        </a>

        <!-- Desktop Menu -->
        <nav class="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium">
            <a href="/" class="{{ Request::is('/') ? 'text-gold border-b-2 border-gold font-bold' : 'text-gray-300 hover:text-gold hover:border-b-2 hover:border-gold' }} pb-1 transition duration-300">Home</a>
            <a href="/about-us" class="{{ Request::is('about-us*') ? 'text-gold border-b-2 border-gold font-bold' : 'text-gray-300 hover:text-gold hover:border-b-2 hover:border-gold' }} pb-1 transition duration-300">About Us</a>
            <a href="/packages" class="{{ (Request::is('packages*') || Request::is('destination*') || Request::is('product*')) ? 'text-gold border-b-2 border-gold font-bold' : 'text-gray-300 hover:text-gold hover:border-b-2 hover:border-gold' }} pb-1 transition duration-300">Destinations</a>
            <a href="/gallery" class="{{ Request::is('gallery*') ? 'text-gold border-b-2 border-gold font-bold' : 'text-gray-300 hover:text-gold hover:border-b-2 hover:border-gold' }} pb-1 transition duration-300">Gallery</a>
            <a href="/contact-us" class="{{ Request::is('contact-us*') ? 'text-gold border-b-2 border-gold font-bold' : 'text-gray-300 hover:text-gold hover:border-b-2 hover:border-gold' }} pb-1 transition duration-300">Contact Us</a>
        </nav>

        <!-- Right Side CTA / Phone (Dynamic from DB) -->
        <div class="hidden lg:flex items-center gap-5">
            @if(!empty($info) && !empty($info->mobile))
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-full bg-gold bg-opacity-20 flex items-center justify-center text-gold">
                        <i class="fa-solid fa-phone-volume text-base"></i>
                    </div>
                    <div class="flex flex-col justify-center">
                        <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="block text-sm font-bold text-white hover:underline leading-tight">{{ $info->mobile }}</a>
                        <span class="block text-[9px] text-gray-400 font-medium leading-tight mt-0.5">Call us anytime</span>
                    </div>
                </div>
            @endif
            
            <a href="/contact-us?book=now" class="bg-gold hover:bg-gold-dark text-white border border-gold font-bold text-sm px-4 py-2 rounded-lg flex items-center gap-2 shadow-lg hover:shadow-gold/20 transform hover:-translate-y-0.5 transition duration-300">
                <i class="fa-regular fa-calendar-check text-base"></i>
                <span>Book Now</span>
            </a>
        </div>

        <!-- Mobile Menu Burger Button -->
        <div class="flex items-center gap-3 md:hidden">
            <a href="/contact-us?book=now" class="bg-gold text-navy text-xs font-bold px-2.5 py-1.5 rounded flex items-center gap-1">
                <i class="fa-regular fa-calendar-check text-xs"></i>
                <span>Book</span>
            </a>
            <button id="hamburgerBtn" class="text-gray-300 hover:text-gold focus:outline-none flex items-center">
                <i class="fa-solid fa-bars text-xl"></i>
            </button>
        </div>
    </div>

    <!-- Mobile Navigation Drawer -->
    <div id="mobileDrawer" class="hidden md:hidden bg-navy border-t border-gray-800 text-gray-300 font-sora">
        <div class="px-4 py-4 space-y-3 flex flex-col">
            <a href="/" class="{{ Request::is('/') ? 'text-gold font-bold' : 'text-gray-300 hover:text-gold' }} py-2 border-b border-gray-800">Home</a>
            <a href="/about-us" class="{{ Request::is('about-us*') ? 'text-gold font-bold' : 'text-gray-300 hover:text-gold' }} py-2 border-b border-gray-800">About Us</a>
            <a href="/packages" class="{{ (Request::is('packages*') || Request::is('destination*') || Request::is('product*')) ? 'text-gold font-bold' : 'text-gray-300 hover:text-gold' }} py-2 border-b border-gray-800">Destinations</a>
            <a href="/gallery" class="{{ Request::is('gallery*') ? 'text-gold font-bold' : 'text-gray-300 hover:text-gold' }} py-2 border-b border-gray-800">Gallery</a>
            <a href="/contact-us" class="{{ Request::is('contact-us*') ? 'text-gold font-bold' : 'text-gray-300 hover:text-gold' }} py-2 hover:text-gold">Contact Us</a>
            <div class="pt-4 border-t border-gray-800 flex items-center gap-3">
                <i class="fa-solid fa-phone text-gold"></i>
                <a href="tel:+919876543210" class="text-gold font-bold text-sm">+91 98765 43210</a>
            </div>
        </div>
    </div>
</header>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Hamburger Drawer Toggle
        var burger = document.getElementById('hamburgerBtn');
        var drawer = document.getElementById('mobileDrawer');
        if (burger && drawer) {
            burger.addEventListener('click', function() {
                drawer.classList.toggle('hidden');
                var icon = burger.querySelector('i');
                icon.className = drawer.classList.contains('hidden')
                    ? 'fa-solid fa-bars text-xl'
                    : 'fa-solid fa-xmark text-xl';
            });
        }
    });
</script>

