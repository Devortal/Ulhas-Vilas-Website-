@php
    $info = DB::table('information')->first();
    $footerCategories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'desc')->get();
@endphp

<!-- Site Footer -->
<footer class="bg-[#02060f] text-gray-300 font-sora pt-12 pb-8 border-t border-gray-900 relative overflow-hidden">
    <!-- Decorative background elements -->
    <div class="absolute top-0 left-0 w-64 h-64 bg-gold opacity-5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gold opacity-5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        <!-- CTA Bar (Call To Action) -->
        <div class="relative rounded-3xl overflow-hidden p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 mb-16 shadow-2xl bg-[#050c18] border border-gray-800/30">
            <!-- Mountain/pine forest backdrop image with gradient overlay -->
            <div class="absolute inset-y-0 right-0 w-full md:w-1/2 bg-cover bg-right opacity-15 pointer-events-none mix-blend-screen" style="background-image: url('https://images.unsplash.com/photo-1473448912268-2022ce9509d8?q=80&w=800');"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-[#050c18] via-[#050c18]/90 to-transparent pointer-events-none"></div>
            
            <div class="flex flex-col md:flex-row items-center gap-5 relative z-10 text-center md:text-left">
                <!-- Flight Graphic (Dotted path + plane) -->
                <div class="w-20 h-10 relative flex-shrink-0 hidden sm:block">
                    <!-- Dotted path -->
                    <svg class="w-full h-full text-gold/60" viewBox="0 0 80 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 32 C 25 32, 45 18, 65 10" stroke="currentColor" stroke-dasharray="3 3" stroke-width="1.5" fill="none"/>
                    </svg>
                    <!-- Plane icon at the end of the trail -->
                    <div class="absolute right-1 top-0.5 text-gold -rotate-45">
                        <i class="fa-solid fa-car-side text-xl"></i>
                    </div>
                </div>

                <div>
                    <h3 class="font-outfit text-2xl md:text-3xl font-extrabold text-white">
                        Ready to Start <span class="text-gold">Your Journey?</span>
                    </h3>
                    <p class="text-xs md:text-sm text-gray-400 mt-2 font-normal">
                        Explore the beauty of Himachal Pradesh with our expertly curated tour packages.
                    </p>
                </div>
            </div>
            
            <!-- Button -->
            <div class="relative z-10 flex-shrink-0 w-full md:w-auto">
                <a href="/contact" class="footer-plan-trip-btn w-full md:w-auto inline-flex items-center justify-center gap-2 bg-[#cca43b] hover:bg-[#b5891e] text-white font-bold text-sm px-6 py-3.5 rounded-xl transition duration-300 shadow-lg shadow-gold/20 transform hover:-translate-y-0.5" style="color: #ffffff !important;">
                    <span style="color: #ffffff !important;">Plan Your Trip</span>
                    <i class="fa-solid fa-arrow-right text-xs" style="color: #ffffff !important;"></i>
                </a>
            </div>
        </div>

        <!-- Main Footer Grid (Divided by borders on desktop) -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <!-- Brand Column -->
            <div class="space-y-4 lg:border-r lg:border-gray-800/50 lg:pr-8">
                <a href="/" class="inline-block">
                    <img src="{{ (!empty($info) && !empty($info->header_logo)) ? asset($info->header_logo) : ((!empty($info) && !empty($info->footer_logo)) ? asset($info->footer_logo) : asset('Website/assets/images/logo/chaarvi_logo.png')) }}" alt="Chaarvi Tours & Travels" class="max-h-16 w-auto object-contain">
                </a>
                <p class="text-xs md:text-sm text-gray-400 leading-relaxed pt-2 font-normal">
                    {{ (!empty($info) && !empty($info->footer_about)) ? $info->footer_about : 'Chaarvi Tours & Travels is your trusted partner for exploring the beauty of Himachal Pradesh and beyond.' }}
                </p>
                <!-- Social Links (Only render if link is provided in DB) -->
                <div class="flex items-center gap-4 pt-2">
                    @if(!empty($info) && !empty($info->facebook_link))
                        <a href="{{ $info->facebook_link }}" target="_blank" class="text-gray-400 hover:text-white transition duration-200" title="Facebook">
                            <i class="fa-brands fa-facebook-f text-base"></i>
                        </a>
                    @endif
                    @if(!empty($info) && !empty($info->instagram_link))
                        <a href="{{ $info->instagram_link }}" target="_blank" class="text-gray-400 hover:text-white transition duration-200" title="Instagram">
                            <i class="fa-brands fa-instagram text-base"></i>
                        </a>
                    @endif
                    @if(!empty($info) && !empty($info->twitter_link))
                        <a href="{{ $info->twitter_link }}" target="_blank" class="text-gray-400 hover:text-white transition duration-200" title="X (Twitter)">
                            <i class="fa-brands fa-x-twitter text-base"></i>
                        </a>
                    @endif
                    @if(!empty($info) && !empty($info->youtube_link))
                        <a href="{{ $info->youtube_link }}" target="_blank" class="text-gray-400 hover:text-white transition duration-200" title="YouTube">
                            <i class="fa-brands fa-youtube text-base"></i>
                        </a>
                    @endif
                    @if(!empty($info) && !empty($info->linkedin_link))
                        <a href="{{ $info->linkedin_link }}" target="_blank" class="text-gray-400 hover:text-white transition duration-200" title="LinkedIn">
                            <i class="fa-brands fa-linkedin-in text-base"></i>
                        </a>
                    @endif
                </div>
            </div>

            <!-- Quick Links Column (Services removed) -->
            <div class="space-y-4 lg:pl-8 lg:border-r lg:border-gray-800/50 lg:pr-8">
                <h4 class="text-base font-bold text-white font-outfit">Quick Links</h4>
                <ul class="space-y-2 text-sm text-gray-400 font-normal">
                    <li><a href="/" class="hover:text-gold transition duration-200">Home</a></li>
                    <li><a href="/about" class="hover:text-gold transition duration-200">About Us</a></li>
                    <li><a href="/packages" class="hover:text-gold transition duration-200">Destinations</a></li>
                    <li><a href="/gallery" class="hover:text-gold transition duration-200">Gallery</a></li>
                    <li><a href="/contact" class="hover:text-gold transition duration-200">Contact Us</a></li>
                </ul>
            </div>

            <!-- Services Column (Dynamic Categories from DB) -->
            <div class="space-y-4 lg:pl-8 lg:border-r lg:border-gray-800/50 lg:pr-8">
                <h4 class="text-base font-bold text-white font-outfit">Our Services</h4>
                <ul class="space-y-2 text-sm text-gray-400 font-normal">
                    @if(!empty($footerCategories) && count($footerCategories) > 0)
                        @foreach($footerCategories as $fCat)
                            <li><a href="/packages?category_id={{ $fCat->id }}" class="hover:text-gold transition duration-200">{{ $fCat->category_name }}</a></li>
                        @endforeach
                    @else
                        <li><a href="/packages" class="hover:text-gold transition duration-200">Tour Packages</a></li>
                    @endif
                </ul>
            </div>

            <!-- Contact Info Column (Dynamic from information table) -->
            <div class="space-y-4 lg:pl-8">
                <h4 class="text-base font-bold text-white font-outfit">Contact Info</h4>
                <ul class="space-y-3 text-sm text-gray-400 font-normal">
                    @if(!empty($info) && !empty($info->mobile))
                        <li class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full border border-gold/45 bg-transparent flex items-center justify-center text-gold flex-shrink-0">
                                <i class="fa-solid fa-phone text-xs"></i>
                            </div>
                            <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="hover:text-gold transition duration-200 text-sm font-medium text-gray-300 leading-none">{{ $info->mobile }}</a>
                        </li>
                    @endif
                    @if(!empty($info) && !empty($info->email))
                        <li class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full border border-gold/45 bg-transparent flex items-center justify-center text-gold flex-shrink-0">
                                <i class="fa-solid fa-envelope text-xs"></i>
                            </div>
                            <a href="mailto:{{ $info->email }}" class="hover:text-gold transition duration-200 text-sm font-medium text-gray-300 leading-none font-semibold">{{ $info->email }}</a>
                        </li>
                    @endif
                    @if(!empty($info) && !empty($info->address))
                        <li class="flex items-start gap-3">
                            <div class="w-8 h-8 rounded-full border border-gold/45 bg-transparent flex items-center justify-center text-gold flex-shrink-0 mt-0.5">
                                <i class="fa-solid fa-location-dot text-xs"></i>
                            </div>
                            <span class="leading-relaxed text-white text-xs" style="color: #ffffff !important;">{!! nl2br(e($info->address)) !!}</span>
                        </li>
                    @endif
                </ul>
            </div>
        </div>

        <!-- Bottom Copyright Strip -->
        <div class="pt-8 border-t border-gray-900 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400 font-normal pl-4 sm:pl-2">
            <p class="pl-2 sm:pl-0">© 2023 - 2026 <a href="https://brainket.com/" target="_blank" rel="noopener noreferrer" class="hover:text-[#cca43b] text-white font-semibold transition duration-200">BrainKet Technology</a> | All Rights Reserved</p>
        </div>
    </div>

    <!-- Back to Top Button -->
    <button id="backToTopBtn" class="fixed right-6 bottom-6 w-10 h-10 rounded-full bg-gold text-navy shadow-lg flex items-center justify-center hover:bg-gold-dark hover:text-white transition duration-300 z-50 translate-y-20 opacity-0">
        <i class="fa-solid fa-arrow-up text-lg"></i>
    </button>
</footer>

<!-- ── GLOBAL FLOATING ELEMENTS (all pages) ── -->
<style>
    /* WhatsApp Float */
    .g-wa-float {
        position: fixed;
        bottom: 24px;
        left: 24px;
        background-color: #25d366;
        color: #fff;
        width: 54px;
        height: 54px;
        border-radius: 50%;
        box-shadow: 0 4px 15px rgba(37,211,102,0.4);
        z-index: 999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s cubic-bezier(0.16,1,0.3,1);
        cursor: pointer;
        text-decoration: none;
    }
    .g-wa-float:hover {
        background-color: #128c7e;
        transform: scale(1.08) translateY(-3px);
        box-shadow: 0 8px 25px rgba(18,140,126,0.5);
    }
    .g-wa-pulse {
        position: absolute;
        width: 100%; height: 100%;
        background-color: rgba(37,211,102,0.4);
        border-radius: 50%;
        z-index: -1;
        animation: waGlow 2s infinite;
    }
    @keyframes waGlow {
        0%   { transform: scale(1);   opacity: 0.8; }
        50%  { transform: scale(1.3); opacity: 0.3; }
        100% { transform: scale(1.6); opacity: 0;   }
    }
    .g-wa-tooltip {
        position: absolute;
        left: 68px;
        background-color: #050c18;
        color: #fff;
        padding: 8px 16px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
        opacity: 0;
        transform: translateX(-10px);
        visibility: hidden;
        transition: all 0.3s cubic-bezier(0.16,1,0.3,1);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 6px;
        border: 1px solid rgba(255,255,255,0.05);
    }
    .g-wa-float:hover .g-wa-tooltip {
        opacity: 1;
        transform: translateX(0);
        visibility: visible;
    }

    /* Enquiry Now fixed side tab */
    .g-enquiry-btn {
        position: fixed;
        right: 0;
        top: 50%;
        transform: translateY(-50%) rotate(180deg);
        writing-mode: vertical-rl;
        text-orientation: mixed;
        z-index: 999;
        white-space: nowrap;
        background: #cca43b;
        color: #fff;
        padding: 24px 14px;
        border-radius: 14px 0 0 14px;
        font-weight: 700;
        font-size: 9.5px;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        cursor: pointer;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 4px 25px rgba(0,0,0,0.15);
        border-left: 1px solid rgba(255,255,255,0.2);
        border-top: 1px solid rgba(255,255,255,0.2);
        border-bottom: 1px solid rgba(255,255,255,0.2);
        transition: background 0.25s ease;
        text-decoration: none;
        font-family: 'Outfit', 'DM Sans', sans-serif;
    }
    .g-enquiry-btn:hover {
        background: #b08b2d;
    }
    .g-enquiry-btn i {
        font-size: 9.5px;
    }
</style>

<!-- WhatsApp Float Button -->
<a href="https://wa.me/{{ preg_replace('/\D/', '', optional(DB::table('information')->first())->mobile ?? '919876543210') }}?text=Hi!%20I'm%20interested%20in%20Himachal%20tour%20packages."
   target="_blank"
   class="g-wa-float"
   title="Chat on WhatsApp">
    <div class="g-wa-pulse"></div>
    <i class="fa-brands fa-whatsapp text-2xl"></i>
    <div class="g-wa-tooltip">
        <span class="w-1.5 h-1.5 rounded-full bg-[#25d366] animate-ping"></span>
        Chat with our travel expert!
    </div>
</a>

<!-- Enquiry Now / Destinations Side Tab -->
@if(request()->is('about*'))
    <a href="{{ url('/packages') }}"
       class="g-enquiry-btn"
       title="Explore Destinations">
        <i class="fa-solid fa-compass"></i>
        <span>DESTINATIONS</span>
    </a>
@else
    <a href="javascript:void(0);"
       id="globalEnquiryBtn"
       class="g-enquiry-btn"
       title="Quick Enquiry">
        <i class="fa-solid fa-paper-plane"></i>
        <span>Enquiry Now</span>
    </a>
    <script>
        document.getElementById('globalEnquiryBtn').addEventListener('click', function() {
            if (typeof openEnquiryModal === 'function') {
                openEnquiryModal();
            } else {
                window.location.href = '/?enquire=1';
            }
        });
    </script>
@endif


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const backToTopBtn = document.getElementById('backToTopBtn');

        if(backToTopBtn) {
            window.addEventListener('scroll', function() {
                if (window.scrollY > 300) {
                    backToTopBtn.classList.remove('translate-y-20', 'opacity-0');
                    backToTopBtn.classList.add('translate-y-0', 'opacity-100');
                } else {
                    backToTopBtn.classList.remove('translate-y-0', 'opacity-100');
                    backToTopBtn.classList.add('translate-y-20', 'opacity-0');
                }
            });

            backToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }
    });
</script>

</body>
</html>
