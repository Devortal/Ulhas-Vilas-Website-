@php
    $info = DB::table('information')->first();
    $categories = DB::table('categories')->where('status', 1)->orderBy('id', 'desc')->get();
@endphp

<style>
    a.header-book-now-btn:hover,
    a.header-book-now-btn:hover span,
    a.header-book-now-btn:hover i {
        color: #ffffff !important;
    }
</style>

@php
    $cartCount = 0;
    $wishlistCount = 0;
    $quoteCount = 0;

    $isLoggedIn = false;
    if (Session()->has('user_login') && Session()->has('user_login_time')) {
        $loginTime = Session()->get('user_login_time');
        $timeoutMinutes = 1051200; // 2 years
        $now = \Carbon\Carbon::now('Asia/Kolkata')->timestamp;

        if (($now - $loginTime) <= ($timeoutMinutes * 60)) {
            $isLoggedIn = true;
        } else {
            Session()->forget('user_login');
            Session()->forget('user_login_time');
        }
    }

    if ($isLoggedIn) {
        $user = Session()->get('user_login');
        $userId = is_array($user) ? ($user[0]->id ?? null) : ($user->id ?? null);

        if ($userId) {
            $cartCount = DB::table('carts')->where('user_id', $userId)->where('status', 'false')->count();
            $wishlistCount = DB::table('tbl_wishlist')->where('user_id', $userId)->where('status', 'false')->count();
            $quoteCount = DB::table('get_quotes')->where('user_id', $userId)->count();
        }
    }
    $userType = 'B2C';
    if ($isLoggedIn) {
        $userData = is_array($user) ? $user[0] : $user;
        $userType = $userData->user_type ?? 'B2C';
    }
@endphp

<style>
    .site-topbar {
        background-color: #030710 !important;
        color: #d1d5db !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        transition: all 0.3s ease-in-out;
    }
    .site-header {
        position: -webkit-sticky !important;
        position: sticky !important;
        top: 0 !important;
        z-index: 1000 !important;
        background-color: #ffffff !important;
        color: #1e293b !important;
        transition: background-color 0.35s ease, color 0.35s ease, border-color 0.35s ease, box-shadow 0.35s ease !important;
        border-bottom: 1px solid #e2e8f0;
    }
    .site-logo-img {
        max-height: 70px !important;
        width: auto !important;
        object-fit: contain !important;
        display: block !important;
        transition: max-height 0.3s ease !important;
    }
    .site-header.header-scrolled .site-logo-img {
        max-height: 70px !important;
    }
    @media (max-width: 767px) {
        .site-logo-img,
        .site-header.header-scrolled .site-logo-img {
            max-height: 48px !important;
        }
    }
    .site-header .nav-link {
        color: #1e293b;
        padding-bottom: 4px;
        border-bottom: 2.5px solid transparent;
        transition: color 0.3s ease, border-color 0.3s ease;
    }
    .site-header .nav-link:hover {
        color: #cca43b !important;
        border-bottom: 2.5px solid #cca43b !important;
    }
    .site-header .nav-link.active-link {
        color: #cca43b !important;
        border-bottom: 2.5px solid #cca43b !important;
        font-weight: 700 !important;
    }
    .site-header .phone-cta-card {
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        transition: background-color 0.3s ease, border-color 0.3s ease;
    }
    .site-header .phone-cta-num {
        color: #0f172a;
        transition: color 0.3s ease;
    }
    .site-header .phone-cta-sub {
        color: #64748b;
        transition: color 0.3s ease;
    }
    .site-header #hamburgerBtn {
        color: #0f172a;
        transition: color 0.3s ease;
    }

    /* SCROLLED STATE (DARK MODE ACTIVE ON SCROLL) */
    .site-header.header-scrolled {
        background-color: rgba(5, 12, 24, 0.98) !important;
        backdrop-filter: blur(12px) !important;
        -webkit-backdrop-filter: blur(12px) !important;
        box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.6) !important;
        border-bottom: 2px solid #cca43b !important;
    }
    .site-header.header-scrolled .nav-link:not(.active-link) {
        color: #f8fafc !important;
    }
    .site-header.header-scrolled .nav-link:hover {
        color: #cca43b !important;
        border-bottom: 2.5px solid #cca43b !important;
    }
    .site-header.header-scrolled .phone-cta-card {
        background-color: rgba(255, 255, 255, 0.08) !important;
        border-color: rgba(255, 255, 255, 0.15) !important;
    }
    .site-header.header-scrolled .phone-cta-num {
        color: #ffffff !important;
    }
    .site-header.header-scrolled .phone-cta-sub {
        color: rgba(254, 243, 199, 0.7) !important;
    }
    .site-header.header-scrolled #hamburgerBtn {
        color: #ffffff !important;
    }

    /* Mobile Drawer Custom Styles */
    #mobileDrawer {
        background-color: #070e1b !important;
    }
    #mobileDrawer a.mobile-nav-link {
        color: #f1f5f9 !important;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 16px;
        border-radius: 12px;
        transition: all 0.25s ease;
    }
    #mobileDrawer a.mobile-nav-link:hover {
        color: #cca43b !important;
        background-color: rgba(255, 255, 255, 0.05) !important;
    }
    #mobileDrawer a.mobile-nav-link.active-nav-link {
        color: #cca43b !important;
        background-color: rgba(204, 164, 59, 0.12) !important;
        border-left: 4px solid #cca43b !important;
        font-weight: 700 !important;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
    }
    #mobileDrawer a.mobile-nav-link:focus {
        outline: none !important;
        box-shadow: none !important;
    }
    #mobileDrawer .mobile-contact-card {
        background-color: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
    }
</style>

<!-- TOP INFO BAR (BLACK/DARK MIDNIGHT BAR) -->
<div id="siteTopbar" class="site-topbar hidden md:block text-gray-300 text-xs font-sora py-1.5">
    <div class="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
        <!-- Left: Social Icons ONLY -->
        <div class="flex items-center gap-2">
            @if(!empty($info) && !empty($info->facebook_link))
                <a href="{{ $info->facebook_link }}" target="_blank" class="w-6 h-6 rounded-full bg-white/10 hover:bg-[#cca43b] text-gray-200 hover:text-slate-950 flex items-center justify-center transition duration-300" title="Facebook">
                    <i class="fa-brands fa-facebook-f text-[11px]"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->instagram_link))
                <a href="{{ $info->instagram_link }}" target="_blank" class="w-6 h-6 rounded-full bg-white/10 hover:bg-[#cca43b] text-gray-200 hover:text-slate-950 flex items-center justify-center transition duration-300" title="Instagram">
                    <i class="fa-brands fa-instagram text-[11px]"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->twitter_link))
                <a href="{{ $info->twitter_link }}" target="_blank" class="w-6 h-6 rounded-full bg-white/10 hover:bg-[#cca43b] text-gray-200 hover:text-slate-950 flex items-center justify-center transition duration-300" title="X (Twitter)">
                    <i class="fa-brands fa-x-twitter text-[11px]"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->youtube_link))
                <a href="{{ $info->youtube_link }}" target="_blank" class="w-6 h-6 rounded-full bg-white/10 hover:bg-[#cca43b] text-gray-200 hover:text-slate-950 flex items-center justify-center transition duration-300" title="YouTube">
                    <i class="fa-brands fa-youtube text-[11px]"></i>
                </a>
            @endif
            @if(!empty($info) && !empty($info->linkedin_link))
                <a href="{{ $info->linkedin_link }}" target="_blank" class="w-6 h-6 rounded-full bg-white/10 hover:bg-[#cca43b] text-gray-200 hover:text-slate-950 flex items-center justify-center transition duration-300" title="LinkedIn">
                    <i class="fa-brands fa-linkedin-in text-[11px]"></i>
                </a>
            @endif
        </div>

        <!-- Right: Email, Mobile, Address -->
        <div class="flex items-center gap-3 lg:gap-4 text-gray-300 font-medium">
            @if(!empty($info) && !empty($info->email))
                <a href="mailto:{{ $info->email }}" class="flex items-center gap-1.5 hover:text-[#cca43b] transition duration-300">
                    <i class="fa-solid fa-envelope text-[#cca43b] text-xs"></i>
                    <span>{{ $info->email }}</span>
                </a>
            @endif

            @if(!empty($info) && !empty($info->email) && !empty($info->mobile))
                <span class="text-slate-600">|</span>
            @endif

            @if(!empty($info) && !empty($info->mobile))
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="flex items-center gap-1.5 hover:text-[#cca43b] transition duration-300">
                    <i class="fa-solid fa-phone text-[#cca43b] text-xs"></i>
                    <span>{{ $info->mobile }}</span>
                </a>
            @endif

            @if(!empty($info) && !empty($info->address))
                @if(!empty($info->email) || !empty($info->mobile))
                    <span class="text-slate-600">|</span>
                @endif
                <div class="flex items-center gap-1.5 text-gray-300">
                    <i class="fa-solid fa-location-dot text-[#cca43b] text-xs"></i>
                    <span class="truncate max-w-[240px] lg:max-w-[340px]">{{ str_replace(["\r\n", "\n", "\r"], ' ', $info->address) }}</span>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- MAIN NAVIGATION HEADER -->
<header id="mainHeader" class="site-header w-full font-sora">
    <div id="headerInner" class="max-w-7xl mx-auto px-4 md:px-8 py-2 flex items-center justify-between transition-all duration-300">
        
        <!-- Logo -->
        <a href="/" class="flex items-center shrink-0">
            <img src="{{ (!empty($info) && !empty($info->header_logo)) ? asset($info->header_logo) : ((!empty($info) && !empty($info->footer_logo)) ? asset($info->footer_logo) : asset('Website/assets/images/logo/chaarvi_logo.png')) }}" alt="Chaarvi Tours" class="site-logo-img">
        </a>

        <!-- Desktop Navigation Links -->
        <nav class="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-semibold">
            <a href="/" class="nav-link {{ Request::is('/') ? 'active-link' : '' }}">Home</a>
            <a href="/about" class="nav-link {{ (Request::is('about*') || Request::is('about-us*')) ? 'active-link' : '' }}">About Us</a>
            <a href="/packages" class="nav-link {{ (Request::is('packages*') || Request::is('destination*') || Request::is('product*')) ? 'active-link' : '' }}">Destinations</a>
            <a href="/gallery" class="nav-link {{ Request::is('gallery*') ? 'active-link' : '' }}">Gallery</a>
            <a href="/contact" class="nav-link {{ (Request::is('contact*') || Request::is('contact-us*')) ? 'active-link' : '' }}">Contact Us</a>
        </nav>

        <!-- Right Side CTA / Phone -->
        <div class="hidden lg:flex items-center gap-4">
            @if(!empty($info) && !empty($info->mobile))
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="phone-cta-card flex items-center gap-3 group px-3.5 py-1.5 rounded-full transition duration-300">
                    <div class="w-8 h-8 rounded-full bg-[#cca43b]/20 text-[#cca43b] flex items-center justify-center group-hover:bg-[#cca43b] group-hover:text-slate-950 transition duration-300 shadow-xs shrink-0">
                        <i class="fa-solid fa-phone-volume text-xs"></i>
                    </div>
                    <div class="flex flex-col justify-center text-left">
                        <span class="phone-cta-num block text-xs font-bold leading-tight transition duration-300">{{ $info->mobile }}</span>
                        <span class="phone-cta-sub block text-[10px] font-medium leading-tight mt-0.5">Call us anytime</span>
                    </div>
                </a>
            @endif
            
            <a href="{{ url('/packages') }}" class="header-book-now-btn bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#102a43] hover:to-[#050c18] text-slate-950 hover:text-white font-bold text-sm px-6 py-2 rounded-full flex items-center gap-2 shadow-md shadow-[#cca43b]/25 transform hover:-translate-y-0.5 transition duration-300 shrink-0">
                <i class="fa-regular fa-calendar-check text-base text-slate-950"></i>
                <span class="text-slate-950">Book Now</span>
            </a>
        </div>

        <!-- Mobile Controls -->
        <div class="flex items-center gap-3 md:hidden">
            <a href="{{ url('/packages') }}" class="header-book-now-btn bg-gold text-white text-[13px] font-bold px-5 py-2 rounded-full flex items-center gap-1.5 shadow-md hover:bg-navy transition duration-300">
                <i class="fa-regular fa-calendar-check text-xs"></i>
                <span>Book Now</span>
            </a>
            <button id="hamburgerBtn" class="focus:outline-none p-1 transition duration-300">
                <i class="fa-solid fa-bars text-xl"></i>
            </button>
        </div>
    </div>

    <!-- Mobile Navigation Drawer -->
    <!-- Mobile Navigation Drawer -->
    <div id="mobileDrawer" class="hidden md:hidden text-white font-sora shadow-2xl">
        <div class="px-6 py-5 space-y-2.5 flex flex-col">
            
            <a href="/" class="mobile-nav-link {{ Request::is('/') ? 'active-nav-link' : '' }}">
                <i class="fa-solid fa-house text-sm shrink-0"></i>
                <span>Home</span>
            </a>
            
            <a href="/about" class="mobile-nav-link {{ (Request::is('about*') || Request::is('about-us*')) ? 'active-nav-link' : '' }}">
                <i class="fa-solid fa-circle-info text-sm shrink-0"></i>
                <span>About Us</span>
            </a>
            
            <a href="/packages" class="mobile-nav-link {{ (Request::is('packages*') || Request::is('destination*') || Request::is('product*')) ? 'active-nav-link' : '' }}">
                <i class="fa-solid fa-map-location-dot text-sm shrink-0"></i>
                <span>Destinations</span>
            </a>
            
            <a href="/gallery" class="mobile-nav-link {{ Request::is('gallery*') ? 'active-nav-link' : '' }}">
                <i class="fa-solid fa-images text-sm shrink-0"></i>
                <span>Gallery</span>
            </a>
            
            <a href="/contact" class="mobile-nav-link {{ (Request::is('contact*') || Request::is('contact-us*')) ? 'active-nav-link' : '' }}">
                <i class="fa-solid fa-envelope-open-text text-sm shrink-0"></i>
                <span>Contact Us</span>
            </a>
            
            <!-- Divider -->
            <div class="my-4 border-t border-gray-800/60"></div>
            
            <!-- Quick Contact info card -->
            <div class="mobile-contact-card rounded-2xl p-4 space-y-3.5">
                <span class="text-[10px] uppercase tracking-wider text-[#cca43b] font-bold">Quick Contact</span>
                
                @if(!empty($info) && !empty($info->mobile))
                    <a href="tel:{{ preg_replace('/[^0-9+]/', '', $info->mobile) }}" class="flex items-center gap-3 text-sm text-gray-200 hover:text-[#cca43b] transition duration-200 focus:outline-none">
                        <div class="w-7 h-7 rounded-lg bg-[#cca43b]/10 flex items-center justify-center text-[#cca43b] shrink-0">
                            <i class="fa-solid fa-phone text-xs"></i>
                        </div>
                        <span class="font-bold tracking-wide">{{ $info->mobile }}</span>
                    </a>
                @endif
                
                @if(!empty($info) && !empty($info->email))
                    <a href="mailto:{{ $info->email }}" class="flex items-center gap-3 text-xs text-gray-300 hover:text-[#cca43b] transition duration-200 focus:outline-none">
                        <div class="w-7 h-7 rounded-lg bg-[#cca43b]/10 flex items-center justify-center text-[#cca43b] shrink-0">
                            <i class="fa-solid fa-envelope text-xs"></i>
                        </div>
                        <span class="truncate">{{ $info->email }}</span>
                    </a>
                @endif
            </div>
        </div>
    </div>
</header>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mobile Drawer Toggle
        var burger = document.getElementById('hamburgerBtn');
        var drawer = document.getElementById('mobileDrawer');
        if (burger && drawer) {
            burger.addEventListener('click', function() {
                drawer.classList.toggle('hidden');
                var icon = burger.querySelector('i');
                if (icon) {
                    icon.className = drawer.classList.contains('hidden')
                        ? 'fa-solid fa-bars text-xl'
                        : 'fa-solid fa-xmark text-xl';
                }
            });
        }

        // Sticky Header scroll styling
        var header = document.getElementById('mainHeader');
        function handleScroll() {
            if (window.scrollY > 40) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        }
        window.addEventListener('scroll', handleScroll);
        handleScroll();
    });
</script>

