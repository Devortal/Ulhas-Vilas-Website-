<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Site Icon / Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('Images/ulhas-logo.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('Images/ulhas-logo.png') }}">

   

@php
    // 🔄 Auto-Detect SEO if not passed by controller
    if (empty($seo) || !is_array($seo)) {
        $curPath = trim(request()->path(), '/');
        $resolvedKey = empty($curPath) || $curPath === '/' ? 'home' : explode('/', $curPath)[0];
        $possibleKeys = [$resolvedKey];
        if (str_starts_with($resolvedKey, 'residence')) $possibleKeys = ['residences', 'residence'];
        if (str_starts_with($resolvedKey, 'about')) $possibleKeys = ['about', 'about_us'];
        if (str_starts_with($resolvedKey, 'amenit')) $possibleKeys = ['amenities', 'amenity'];
        if (str_starts_with($resolvedKey, 'gallery')) $possibleKeys = ['gallery', 'galleries'];
        if (str_starts_with($resolvedKey, 'blog')) $possibleKeys = ['blogs', 'blog'];
        if (str_starts_with($resolvedKey, 'faq')) $possibleKeys = ['faqs', 'faq'];
        if (str_starts_with($resolvedKey, 'contact')) $possibleKeys = ['contact', 'contact_us'];

        $dbSeo = DB::table('page_seos')->whereIn('page_key', $possibleKeys)->first();
        $seo = [
            'meta_title' => (!empty($dbSeo) && !empty($dbSeo->meta_title)) ? $dbSeo->meta_title : 'The Ulhas Vilas — Architectural Refinement & Luxury Estates',
            'meta_description' => (!empty($dbSeo) && !empty($dbSeo->meta_description)) ? $dbSeo->meta_description : 'Discover The Ulhas Vilas in Himachal Pradesh. Luxury architectural estates, 1-4 BHK bespoke villas, private suites, and world-class wellness.',
            'meta_keywords' => (!empty($dbSeo) && !empty($dbSeo->meta_keywords)) ? $dbSeo->meta_keywords : 'The Ulhas Vilas, luxury villas, Himachal Pradesh real estate, luxury estates, mountain villas, holiday homes',
            'og_image' => (!empty($dbSeo) && !empty($dbSeo->og_image)) ? (filter_var($dbSeo->og_image, FILTER_VALIDATE_URL) ? $dbSeo->og_image : asset($dbSeo->og_image)) : asset('Admin/assets/images/ulhas_logo.png'),
            'custom_script' => (!empty($dbSeo) && !empty($dbSeo->custom_script)) ? $dbSeo->custom_script : '',
        ];
    }
@endphp

    <!-- 1️⃣ Meta Title -->
    <title>{{ $seo['meta_title'] }}</title>

    <!-- 2️⃣ Meta Description -->
    <meta name="description" content="{{ $seo['meta_description'] }}">

    <!-- 3️⃣ Meta Keywords -->
    @if(!empty($seo['meta_keywords']))
    <meta name="keywords" content="{{ $seo['meta_keywords'] }}">
    @endif

     <!-- 5️⃣ Custom Script / Google Tag / Meta Pixel / Schema Markup -->
    @if(!empty($seo['custom_script']))
        {!! $seo['custom_script'] !!}
    @endif

    <!-- 4️⃣ Open Graph / WhatsApp / Facebook / Twitter Share Preview Image -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="{{ $seo['meta_title'] }}">
    <meta property="og:description" content="{{ $seo['meta_description'] }}">
    <meta property="og:image" content="{{ $seo['og_image'] }}">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $seo['meta_title'] }}">
    <meta name="twitter:description" content="{{ $seo['meta_description'] }}">
    <meta name="twitter:image" content="{{ $seo['og_image'] }}">

   

    <link rel="icon" type="image/png" href="{{ asset('Admin/assets/images/ulhas_logo.png') }}">
    <!-- Preconnect for performance -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">

    <!-- External Assets -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
    <style>
        /* Prevent Flash of Unstyled Content (FOUC) before Tailwind CSS loads */
        .hidden {
            display: none !important;
        }
        @media (min-width: 640px) {
            .sm\:hidden { display: none !important; }
            .sm\:flex { display: flex !important; }
            .sm\:block { display: block !important; }
        }
        @media (min-width: 768px) {
            .md\:hidden { display: none !important; }
            .md\:flex { display: flex !important; }
            .md\:block { display: block !important; }
            .md\:grid { display: grid !important; }
        }
        @media (min-width: 1024px) {
            .lg\:hidden { display: none !important; }
            .lg\:flex { display: flex !important; }
            .lg\:block { display: block !important; }
            .lg\:grid { display: grid !important; }
        }
        @media (min-width: 1280px) {
            .xl\:hidden { display: none !important; }
            .xl\:flex { display: flex !important; }
            .xl\:block { display: block !important; }
            .xl\:grid { display: grid !important; }
        }

        .alertify-notifier .ajs-message {
            border-radius: 14px !important;
            font-family: 'Sora', 'Outfit', sans-serif !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2) !important;
            padding: 12px 20px !important;
            border: 1px solid rgba(255,255,255,0.1) !important;
        }
        .alertify-notifier .ajs-message.ajs-success {
            background: #064e3b !important;
            color: #ffffff !important;
            border-color: #10b981 !important;
        }
        .alertify-notifier .ajs-message.ajs-error {
            background: #7f1d1d !important;
            color: #ffffff !important;
            border-color: #ef4444 !important;
        }
    </style>
    <script>
        if (typeof alertify !== 'undefined') {
            alertify.set('notifier', 'position', 'top-right');
            alertify.set('notifier', 'delay', 4);
        }
        window.showAppNotification = function(type, message) {
            if (typeof alertify !== 'undefined') {
                alertify.set('notifier', 'position', 'top-right');
                alertify.set('notifier', 'delay', 5);
                if (type === 'success') {
                    alertify.success('<i class="fa-solid fa-circle-check text-base mr-1"></i> ' + message);
                } else {
                    alertify.error('<i class="fa-solid fa-circle-exclamation text-base mr-1"></i> ' + message);
                }
            } else {
                var toast = document.createElement('div');
                toast.style.cssText = 'position:fixed;top:28px;right:28px;z-index:9999999;padding:14px 22px;border-radius:16px;color:#fff;font-weight:700;font-size:13px;box-shadow:0 12px 35px rgba(0,0,0,0.35);font-family:sans-serif;transition:all 0.3s cubic-bezier(0.16,1,0.3,1);display:flex;align-items:center;gap:10px;transform:translateY(-10px);opacity:0;';
                if (type === 'success') {
                    toast.style.background = 'linear-gradient(135deg, #050c18 0%, #102a43 100%)';
                    toast.style.border = '2px solid #cca43b';
                    toast.style.color = '#cca43b';
                    toast.innerHTML = '<i class="fa-solid fa-circle-check text-lg text-[#cca43b]"></i> <span style="color:#ffffff">' + message + '</span>';
                } else {
                    toast.style.background = 'linear-gradient(135deg, #450a0a 0%, #7f1d1d 100%)';
                    toast.style.border = '2px solid #f87171';
                    toast.style.color = '#ffffff';
                    toast.innerHTML = '<i class="fa-solid fa-circle-exclamation text-lg text-red-300"></i> <span>' + message + '</span>';
                }
                document.body.appendChild(toast);
                requestAnimationFrame(function() {
                    toast.style.opacity = '1';
                    toast.style.transform = 'translateY(0)';
                });
                setTimeout(function(){
                    toast.style.opacity = '0';
                    toast.style.transform = 'translateY(-10px)';
                    setTimeout(function(){ toast.remove(); }, 300);
                }, 4500);
            }
        };
    </script>

    <!-- Tailwind CSS Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        gold: {
                            light: '#f3d078',
                            DEFAULT: '#cca43b', // primary gold accent
                            dark: '#b5891e',
                        },
                        navy: {
                            light: '#0e1e38',
                            DEFAULT: '#050c18', // primary dark theme background
                            dark: '#02060f',
                        }
                    },
                    fontFamily: {
                        sora: ['Sora', 'sans-serif'],
                        playfair: ['Playfair Display', 'serif'],
                        outfit: ['Outfit', 'sans-serif'],
                        caveat: ['Caveat', 'cursive'],
                        dmsans: ['DM Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;700&family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Outfit:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Poppins:wght@300;400;500;600;700&family=Roboto+Mono:wght@400;500;700&family=Sora:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
    
    
    body, h1,h2,h3,h4,h5,h6,p,span,a,button,input{
        font-family: 'Sora', 'Outfit', 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    /* Force load Google Fonts on helper utility classes */
    .font-sora {
        font-family: 'Sora', sans-serif !important;
    }
    .font-outfit {
        font-family: 'Outfit', sans-serif !important;
    }
    .font-caveat {
        font-family: 'Caveat', cursive !important;
    }
    section span.font-caveat {
        display: block !important;
        width: 100% !important;
        margin-bottom: 6px !important;
    }
    .swiper-slide span.font-caveat {
        display: inline-block !important;
        width: auto !important;
        margin-bottom: 0 !important;
    }
    .font-playfair {
        font-family: 'Playfair Display', serif !important;
    }
    .font-dmsans {
        font-family: 'DM Sans', sans-serif !important;
    }

    /* Why Choose Us Cards Premium Styling Overrides */
    #why-choose-us .grid > div .bg-white {
        border: 1px solid rgba(204, 164, 59, 0.15) !important;
        box-shadow: 0 4px 20px -2px rgba(5, 12, 24, 0.04) !important;
        border-radius: 20px !important;
        padding: 24px !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    
    #why-choose-us .grid > div:hover .bg-white {
        transform: translateY(-5px) !important;
        border-color: rgba(204, 164, 59, 0.4) !important;
        box-shadow: 0 20px 35px -5px rgba(204, 164, 59, 0.12) !important;
    }
    
    #why-choose-us .grid > div .bg-white span {
        font-size: 11px !important;
        font-weight: 700 !important;
        letter-spacing: 0.12em !important;
        text-transform: uppercase !important;
        color: #b5891e !important;
    }
    
    #why-choose-us .grid > div .bg-white h3 {
        font-size: 17px !important;
        font-weight: 800 !important;
        color: #050c18 !important;
        margin-top: 6px !important;
        margin-bottom: 8px !important;
        line-height: 1.35 !important;
    }
    
    #why-choose-us .grid > div .bg-white p {
        font-size: 13.5px !important;
        color: #4b5563 !important;
        line-height: 1.6 !important;
    }

    /* Media query adjustments for card text on mobile */
    @media (max-width: 768px) {
        #why-choose-us .grid > div .bg-white {
            padding: 20px !important;
        }
        #why-choose-us .grid > div .bg-white h3 {
            font-size: 15px !important;
        }
        #why-choose-us .grid > div .bg-white p {
            font-size: 12.5px !important;
        }
    }

    /* Responsive Font & Spacing Adjustments for Desktop & Mobile */
    html {
        font-size: 16px; /* Base font size */
    }

    /* Global Section Paddings Override to reduce massive empty spaces on all screens */
    .py-24 {
        padding-top: 4.5rem !important;
        padding-bottom: 4.5rem !important;
    }
    .py-20, .md\:py-20 {
        padding-top: 3.5rem !important;
        padding-bottom: 3.5rem !important;
    }
    .py-16, .md\:py-16 {
        padding-top: 2.5rem !important;
        padding-bottom: 2.5rem !important;
    }
    .py-14, .md\:py-14 {
        padding-top: 2.25rem !important;
        padding-bottom: 2.25rem !important;
    }
    .py-12, .md\:py-12 {
        padding-top: 2rem !important;
        padding-bottom: 2rem !important;
    }
    .pt-16 { padding-top: 2.5rem !important; }
    .pb-16 { padding-bottom: 2.5rem !important; }
    .pt-12 { padding-top: 2rem !important; }
    .pb-12 { padding-bottom: 2rem !important; }
    .pt-14 { padding-top: 2.25rem !important; }
    .pb-14 { padding-bottom: 2.25rem !important; }
    
    /* Global heading bottom gap reduction */
    .mb-12, .md\:mb-12 {
        margin-bottom: 1.5rem !important; /* 24px instead of 48px */
    }
    .mb-10, .md\:mb-10 {
        margin-bottom: 1.25rem !important; /* 20px instead of 40px */
    }

    @media (max-width: 1024px) {
        html {
            font-size: 15px; /* Slightly scale down for smaller laptops/tablets */
        }
        /* Scale down section paddings on laptops to prevent oversized gaps */
        .py-24 {
            padding-top: 4.5rem !important;
            padding-bottom: 4.5rem !important;
        }
        .py-20, .md\:py-20 {
            padding-top: 4rem !important;
            padding-bottom: 4rem !important;
        }
        .py-16, .md\:py-16 {
            padding-top: 3rem !important;
            padding-bottom: 3rem !important;
        }
        .py-14, .md\:py-14 {
            padding-top: 2.5rem !important;
            padding-bottom: 2.5rem !important;
        }
        .py-12, .md\:py-12 {
            padding-top: 2.25rem !important;
            padding-bottom: 2.25rem !important;
        }
        .mb-16 { margin-bottom: 2.5rem !important; }
        .mb-12 { margin-bottom: 2rem !important; }
    }

    @media (max-width: 768px) {
        html {
            font-size: 14px; /* Scale down base font size for mobile mode */
        }
        
        /* Make small text more readable on mobile and prevent overly tiny text */
        .text-\[11px\], .text-\[12px\], .text-\[12\.5px\], .text-\[13px\] {
            font-size: 12px !important;
            letter-spacing: 0.01em !important;
        }
        
        .text-\[14px\], .text-\[15px\] {
            font-size: 14px !important;
        }
        
        /* Heading responsive line height and padding tweaks */
        h1, h2, h3 {
            letter-spacing: -0.01em !important;
        }

        /* Scale down section paddings on mobile to reduce massive gaps */
        .py-24, .md\:py-24 {
            padding-top: 3rem !important; /* 48px instead of 96px */
            padding-bottom: 3rem !important;
        }
        .py-20, .md\:py-20 {
            padding-top: 2.5rem !important; /* 40px instead of 80px */
            padding-bottom: 2.5rem !important;
        }
        .py-16, .md\:py-16 {
            padding-top: 2rem !important; /* 32px instead of 64px */
            padding-bottom: 2rem !important;
        }
        .py-14, .md\:py-14 {
            padding-top: 1.75rem !important; /* 28px instead of 56px */
            padding-bottom: 1.75rem !important;
        }
        .py-12, .md\:py-12 {
            padding-top: 1.5rem !important; /* 24px instead of 48px */
            padding-bottom: 1.5rem !important;
        }
        
        .pt-16 { padding-top: 2rem !important; }
        .pb-16 { padding-bottom: 2rem !important; }
        .pt-12 { padding-top: 1.5rem !important; }
        .pb-12 { padding-bottom: 1.5rem !important; }
        .pt-14 { padding-top: 1.75rem !important; }
        .pb-14 { padding-bottom: 1.75rem !important; }
        .pt-8 { padding-top: 1rem !important; }
        .pb-8 { padding-bottom: 1rem !important; }
        .pt-6 { padding-top: 0.75rem !important; }
        .pb-6 { padding-bottom: 0.75rem !important; }
        
        /* Spacing margins (negative margins and gap spacing) */
        .mb-16 { margin-bottom: 1.5rem !important; }
        .mb-12 { margin-bottom: 1.25rem !important; }
        .mb-10 { margin-bottom: 1rem !important; }
        .mb-8 { margin-bottom: 0.75rem !important; }
        .mt-16 { margin-top: 1.5rem !important; }
        .mt-12 { margin-top: 1.25rem !important; }
        .mt-10 { margin-top: 1rem !important; }
    }

    /* Primary Section Headings with Double Lines (like the user requested) */
    section h2.font-outfit {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 16px !important;
        position: relative;
    }

    section h2.font-outfit::before,
    section h2.font-outfit::after {
        content: "" !important;
        display: inline-block !important;
        width: 60px !important; /* Length of the double lines */
        height: 5px !important; /* Height of the double lines stack */
        background: linear-gradient(to bottom, 
            #050c18 0px, #050c18 1.5px, 
            transparent 1.5px, transparent 3.5px, 
            #cca43b 3.5px, #cca43b 5px
        ) !important;
        vertical-align: middle !important;
        flex-shrink: 0 !important;
    }

    @media (max-width: 768px) {
        section h2.font-outfit::before,
        section h2.font-outfit::after {
            width: 32px !important; /* Shorter lines on mobile screen to prevent text wrapping */
        }
    }

    /* Hide description paragraphs under section titles */
    section h2.font-outfit + p,
    section h2.font-outfit ~ p {
        display: none !important;
    }

    /* Hide old bottom indicator lines under h2 titles, even if separated by p */
    section h2.font-outfit + div.bg-gold,
    section h2.font-outfit + div[class*="bg-gold"],
    section h2.font-outfit + div[class*="w-14"],
    section h2.font-outfit + div[class*="w-16"],
    section h2.font-outfit ~ div.bg-gold,
    section h2.font-outfit ~ div[class*="bg-gold"],
    section h2.font-outfit ~ div[class*="w-14"],
    section h2.font-outfit ~ div[class*="w-16"] {
        display: none !important;
    }

    /* Reset side-lines and restore description layouts for sub-headings nested inside grid columns or flex boxes (like FAQ page) */
    section .grid h2.font-outfit,
    section [class*="col-span"] h2.font-outfit,
    section .about-copy h2.font-outfit {
        display: block !important;
    }
    section .grid h2.font-outfit::before,
    section .grid h2.font-outfit::after,
    section [class*="col-span"] h2.font-outfit::before,
    section [class*="col-span"] h2.font-outfit::after,
    section .about-copy h2.font-outfit::before,
    section .about-copy h2.font-outfit::after {
        content: none !important;
    }
    section .grid h2.font-outfit + p,
    section .grid h2.font-outfit ~ p,
    section [class*="col-span"] h2.font-outfit + p,
    section [class*="col-span"] h2.font-outfit ~ p,
    section .about-copy h2.font-outfit + p,
    section .about-copy h2.font-outfit ~ p {
        display: block !important;
    }

    /* Swiper Pagination custom styles */
    .hero-pagination .swiper-pagination-bullet-active {
        width: 1.5rem !important;
        background-color: #cca43b !important;
        opacity: 1 !important;
        border-radius: 9999px !important;
    }
    .packages-pagination .swiper-pagination-bullet-active {
        width: 1.5rem !important;
        background-color: #cca43b !important;
        opacity: 1 !important;
        border-radius: 9999px !important;
    }
    .testimonial-pagination .swiper-pagination-bullet-active {
        width: 1.5rem !important;
        background-color: #cca43b !important;
        opacity: 1 !important;
        border-radius: 9999px !important;
    }
        /* ==================== AESTHETIC UPGRADES FOR PREMIUM FEEL (CUSTOM HUMAN DESIGN) ==================== */
    
    /* Why Travel With Us Section: Radially Blended Gradient Background & Cards Glow */
    section.font-outfit.bg-\[\#FDFBF7\] {
        background: radial-gradient(circle at 10% 20%, rgba(253, 251, 247, 1) 0%, rgba(250, 245, 235, 1) 90.1%) !important;
        border-color: rgba(204, 164, 59, 0.12) !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white {
        border: 1px solid rgba(204, 164, 59, 0.12) !important;
        box-shadow: 0 10px 30px -10px rgba(5, 12, 24, 0.04) !important;
        border-radius: 24px !important;
        padding: 24px !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white:hover {
        transform: translateY(-6px) !important;
        border-color: rgba(204, 164, 59, 0.35) !important;
        background: linear-gradient(to bottom, #ffffff, #fdfbf7) !important;
        box-shadow: 0 20px 40px -10px rgba(204, 164, 59, 0.12) !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white .w-12 {
        border-radius: 14px !important;
        background-color: rgba(204, 164, 59, 0.08) !important;
        border-color: rgba(204, 164, 59, 0.15) !important;
        color: #b5891e !important;
        transition: all 0.3s ease !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white:hover .w-12 {
        background-color: #cca43b !important;
        color: #ffffff !important;
        box-shadow: 0 8px 16px -2px rgba(204, 164, 59, 0.3) !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white h3 {
        font-size: 16px !important;
        font-weight: 800 !important;
        color: #050c18 !important;
        line-height: 1.3 !important;
        margin-top: 10px !important;
    }
    
    section.font-outfit.bg-\[\#FDFBF7\] .group.bg-white p {
        font-size: 13px !important;
        color: #4b5563 !important;
        line-height: 1.55 !important;
    }

    /* Premium Category Filter Tabs inside Featured Packages Section */
    .category-tab-btn {
        font-family: 'Sora', sans-serif !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.06em !important;
        padding: 10px 24px !important;
        border-radius: 9999px !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 4px 12px -2px rgba(5, 12, 24, 0.02) !important;
    }

    /* Inactive style */
    .category-tab-btn.bg-white,
    .category-tab-btn:not(.bg-gold) {
        background-color: #ffffff !important;
        border-color: #e2e8f0 !important;
        color: #4b5563 !important;
    }
    
    .category-tab-btn.bg-white:hover,
    .category-tab-btn:not(.bg-gold):hover {
        border-color: #cca43b !important;
        color: #cca43b !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 16px -4px rgba(204, 164, 59, 0.15) !important;
    }

    /* Active style */
    .category-tab-btn.bg-gold {
        background: linear-gradient(135deg, #cca43b, #b5891e) !important;
        border-color: #b5891e !important;
        color: #ffffff !important;
        box-shadow: 0 10px 20px -5px rgba(204, 164, 59, 0.35) !important;
    }

    /* Primary CTA Buttons Override for a high-end feel */
    a.bg-\[\#cca43b\], button.bg-\[\#cca43b\], .btn-gold {
        background: linear-gradient(135deg, #cca43b, #b5891e) !important;
        border: none !important;
        box-shadow: 0 8px 20px -4px rgba(204, 164, 59, 0.3) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    a.bg-\[\#cca43b\]:hover, button.bg-\[\#cca43b\]:hover, .btn-gold:hover {
        background: linear-gradient(135deg, #b5891e, #9c7314) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 12px 24px -4px rgba(204, 164, 59, 0.45) !important;
    }

    /* Category Cards - Gold Glow on Hover */
    .swiper-slide a.group > div {
        border: 4px solid #ffffff !important;
        box-shadow: 0 12px 30px -4px rgba(5, 12, 24, 0.08) !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .swiper-slide a.group:hover > div {
        border-color: #cca43b !important;
        box-shadow: 0 20px 40px -8px rgba(204, 164, 59, 0.22) !important;
        transform: translateY(-4px) !important;
    }

    /* Destination Slides - Premium Zoom & Gold Glow on Hover */
    .dest-slide {
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        box-shadow: 0 15px 35px -5px rgba(5, 12, 24, 0.12) !important;
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .dest-slide:hover {
        transform: scale(1.03) translateY(-4px) !important;
        box-shadow: 0 25px 50px -10px rgba(5, 12, 24, 0.25) !important;
        border-color: rgba(204, 164, 59, 0.4) !important;
    }
    .dest-slide img {
        transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .dest-slide:hover img {
        transform: scale(1.08) !important;
    }
    .dest-slide h3 {
        transition: color 0.3s ease !important;
    }
    .dest-slide:hover h3 {
        color: #cca43b !important;
    }

    /* Premium Package Cards Overrides */
    .package-card-item {
        border: 1px solid rgba(5, 12, 24, 0.05) !important;
        box-shadow: 0 6px 20px -2px rgba(5, 12, 24, 0.03) !important;
        border-radius: 24px !important;
        background-color: #ffffff !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .package-card-item:hover {
        transform: translateY(-6px) !important;
        border-color: rgba(204, 164, 59, 0.25) !important;
        box-shadow: 0 25px 45px -10px rgba(5, 12, 24, 0.08) !important;
    }
    .package-card-item h3 {
        color: #050c18 !important;
        font-weight: 800 !important;
        transition: color 0.3s ease !important;
    }
    .package-card-item:hover h3 {
        color: #cca43b !important;
    }

    :root {
        /* Primary Brand Palette */
        --brand-green: #2d8a56;
        --brand-orange: #FF7A00;
        --green: #2d8a56;
        --gold: #e59e20;
        --orange: #FF7A00;
        --red: #E11414;
        --soft: #fbf7ef;
        
        /* Grayscale & Text */
        --text-dark: #1a3c2a;
        --text: #2b2b2b;
        --muted: #8a8a8a;
        --ink: #1a3c2a;
        --white: #ffffff;
        
        /* Legacy / Special Colors */
        --g1: #1a5c3a;
        --g2: #2d8a56;
        --g3: #4eb87a;
        --g4: #a8e6bf;
        --g5: #e8f8ee;
        
        /* Interactive / UI States */
        --nature-1: #1f6b45;
        --nature-2: #2f8f5b;
        --nature-3: #79c98c;
        --nature-4: #eaf7ee;
        --nature-5: #f7fcf8;
        --warning: #f4a825;
        --danger: #dc3545;
        --line: rgba(78, 184, 122, 0.18);
        --card-bg: rgba(255, 255, 255, 0.85);
        
        /* Elevation */
        --shadow-soft: 0 8px 40px rgba(26, 92, 58, 0.10);
        --shadow-med: 0 20px 70px rgba(26, 92, 58, 0.15);
        --shadow: 0 20px 60px rgba(21, 50, 36, 0.10);
        --radius: 24px;
    }

    /* Hide input number spinners in Chrome, Safari, Edge, Opera, and Firefox */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    input[type=number] {
        -moz-appearance: textfield;
    }

    /* Customize Add to Cart & View Cart buttons to Green theme color */
    .btn-cart,
    .pc-cart,
    .add-cart-btn,
    .view-cart-btn {
        background: #1a5c3a !important;
        color: #ffffff !important;
        border: none !important;
    }
    
    /* Hover state for buttons */
    .btn-cart:hover,
    .pc-cart:hover,
    .add-cart-btn:hover,
    .view-cart-btn:hover {
        background: #14452b !important;
        color: #ffffff !important;
    }
    
    /* Text color for quantity box numbers and buttons */
    .qty-inp,
    .shop-qty-inp,
    .qty-btn,
    .shop-qty-btn {
        color: #1a5c3a !important;
    }

    /* Quantity box structure override to ensure white background and light border */
    .qty-box,
    .shop-qty-box {
        background: #ffffff !important;
        background-color: #ffffff !important;
        border: 1px solid #e2e8f0 !important;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }

    html, body {
        width: 100%;
        max-width: 100%;
        overflow-x: clip;
        margin: 0;
        padding: 0;
        font-family: 'Sora', 'Outfit', 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: var(--text);
        background: #fff;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
    }

        /* TOP BAR */
        .topbar {
            background: var(--green);
            font-size: 14px;
            font-weight: 500;
        }

        .s-header2 {
            position: relative;
            z-index: 1000;
            background: var(--soft);
            border-bottom: 1px solid #f1f1f1;
        }

        /* ROW 1 */
        .headRow1 {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding-top: 10px;
            flex-wrap: wrap;
        }

        .brandLogo {
            height: 70px;
            width: auto;
            object-fit: contain;
        }

        .infoRow {
            display: flex;
            gap: 26px;
            align-items: center;
            flex-wrap: wrap;
        }

        .infoItem {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            min-width: 180px;
        }

        .infoItem i {
            color: var(--green);
            font-size: 22px;
            margin-top: 2px;
        }

        .infoTitle {
            font-weight: 700;
            color: var(--text);
            font-size: 14px;
            line-height: 1.1;
        }

        .infoSub {
            font-size: 13px;
            color: #7a7a7a;
        }

        .floatingNav {
            margin-top: -6px !important;
            margin-bottom: -50px !important;
            position: relative;
            z-index: 1100;
            background: #fff;
            border-radius: 999px;
            padding: 10px 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transform: translateY(16px);
        }

        .leftIcons {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .roundBtn {
            height: 44px;
            width: 44px;
            border-radius: 999px;
            border: 1px solid #e8e8e8;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 2px 2px 2px 2px #f2f2f2;
        }

        .roundBtn i {
            font-size: 20px;
            color: var(--green);
        }

        .midNav {
            display: flex;
            gap: 26px;
            align-items: center;
            justify-content: center;
            flex: 1;
        }

        .navA {
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            color: var(--text);
            padding: 8px 0;
            white-space: nowrap;
        }

        .navA:hover,
        .navA.active {
            color: var(--green);
        }

        .ctaBtn {
            text-decoration: none;
            color: #fff;
            font-weight: 700;
            font-size: 14px;
            padding: 12px 22px;
            border-radius: 999px;
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(90deg, var(--green), var(--gold));
            white-space: nowrap;
        }

        .ctaBtn i {
            font-size: 18px;
        }

        /* HERO (BANNER) */
        .heroWrap {
            position: relative;
            z-index: 1;

            /* JS sets exact -50% of floatingNav height */
            margin-top: var(--heroOverlap, -60px);
            padding-top: calc(var(--heroOverlap, -60px) * -1);
        }

        .heroImg {
            height: 750px;
            width: 100%;
            object-fit: cover;
        }

        /* DROPDOWN ON TOP + OPEN ABOVE (with dropup) */
        .floatingNav .dropdown-menu {
            z-index: 5000 !important;
        }

        /* RESPONSIVE */
        @media (max-width: 992px) {
            .midNav {
                display: none;
            }

            /* later replace with offcanvas */
            .infoItem {
                min-width: unset;
            }
        }

        .site-footer {
            position: relative;
            color: #e8f5e9;
            background: #244515;
            overflow: hidden;
        }

        /* MAIN FOOTER */
        .footer-main {
            padding: 80px 0 60px;
            background:
                radial-gradient(circle at top center, #3f7d1c 0%, transparent 60%),
                #244515;
        }

        /* BRAND */
        .footer-logo {
            height: 52px;
            margin-bottom: 20px;
            margin-top: 20px;

        }

        .footer-text {
            font-size: 15px;
            line-height: 1.7;
            max-width: 320px;
            margin-bottom: 20px;
        }

        /* SOCIAL */
        .footer-social {
            display: flex;
            gap: 12px;
        }

        .footer-social a {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #2f5d1a;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #c8e6c9;
            font-size: 16px;
        }

        .footer-social a:hover {
            background: #5fa624;
            color: #fff;
        }

        /* TITLES */
        .footer-title {
            font-size: 18px;
            margin-bottom: 18px;
            position: relative;
        }

        .footer-title::after {
            content: "";
            display: inline-block;
            width: 14px;
            height: 3px;
            background: #fbc02d;
            margin-left: 10px;
            vertical-align: middle;
        }

        /* LINKS */
        .footer-links,
        .footer-contact {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 12px;
        }

        .footer-links a {
            color: #c8e6c9;
            text-decoration: none;
        }

        .footer-links a:hover {
            color: #fff;
        }

        /* CONTACT */
        .footer-phone {
            margin-top: 15px;
            font-weight: 600;
            font-size: 18px;
        }

        .footer-email {
            margin-top: 8px;
            color: #b7e4b0;
        }

        /* GALLERY */
        .footer-gallery {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }

        .footer-gallery img {
            width: 100%;
            border-radius: 8px;
            object-fit: cover;
        }

        /* BOTTOM BAR */
        .footer-bottom {
            background: #1b370f;
            padding: 18px 0;
            font-size: 14px;
            color: #b7e4b0;
        }

        .footer-bottom-links a {
            color: #b7e4b0;
            text-decoration: none;
        }

        .footer-bottom-links span {
            margin: 0 8px;
        }

        /* BACK TO TOP */
        .back-to-top {
            position: fixed;
            right: 24px;
            bottom: 24px;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: #5fa624;
            border: none;
            color: #fff;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 999;
        }

        .back-to-top:hover {
            background: #76c93a;
        }

        /* Reveal on scroll animation */
        .reveal {
            opacity: 0;
            transform: translateY(18px);
            transition: opacity .6s ease, transform .6s ease;
        }

        .reveal.show {
            opacity: 1;
            transform: translateY(0);
        }

        .reveal.delay-1 {
            transition-delay: .06s;
        }

        .reveal.delay-2 {
            transition-delay: .12s;
        }

        .reveal.delay-3 {
            transition-delay: .18s;
        }

        .reveal.delay-4 {
            transition-delay: .24s;
        }



        .p-sec {
            padding: 40px;
            0;
            background: #fff;
        }

        .gap-3 {
            gap: 0.6rem !important;
        }

        /* Header */
        .p-title {
            font-weight: 700;
            font-size: 42px;
            color: var(--green);
            letter-spacing: -1px;
            margin: 0;
            line-height: 1;
        }

        .p-pill {
            background: var(--orange);
            color: #fff;
            padding: 6px 10px;
            border-radius: 24px;
            margin-top: 7px;
            font-weight: 600;
            font-size: 14px;
        }

        .p-viewall {
            background: var(--green);
            border: 0;
            color: #fff;
            padding: 12px 18px;
            border-radius: 24px;
            font-weight: 600;
            text-decoration: none;
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .p-viewall:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 32px rgba(0, 0, 0, .15);
        }

        /* Card */
        .p-card {
            position: relative;
            border: 0;
            border-radius: 22px;
            overflow: hidden;
            height: 100%;
            padding: 18px;
            background:
                linear-gradient(135deg, rgba(123, 190, 59, .10), rgba(255, 122, 0, .08)),
                #ffffff;
            box-shadow:
                0 18px 40px rgba(0, 0, 0, .10),
                0 1px 0 rgba(255, 255, 255, .7) inset;
            transform: translateY(0);
            transition: transform .25s ease, box-shadow .25s ease, filter .25s ease;
        }

        .p-card:hover {
            transform: translateY(-10px);

            filter: saturate(1.05);
        }

        .catalog-wrap {
            padding: 78px 10px 70px;
            margin-bottom: 10px;
        }

        .d-flex {
            display: flex !important;
            margin-bottom: 0px;
        }

        /* Decorative blobs for more color */
        .p-card::before {
            content: "";
            position: absolute;
            width: 220px;
            height: 220px;
            border-radius: 999px;
            background: radial-gradient(circle at 30% 30%, rgba(123, 190, 59, .25), transparent 60%);
            top: -90px;
            left: -80px;
            pointer-events: none;
        }

        .p-card::after {
            content: "";
            position: absolute;
            width: 240px;
            height: 240px;
            border-radius: 999px;
            background: radial-gradient(circle at 60% 50%, rgba(255, 122, 0, .20), transparent 60%);
            bottom: -120px;
            right: -120px;
            pointer-events: none;
        }

        /* Discount circle ABOVE image */
        .p-off {
            position: absolute;
            top: 13px;
            right: 14px;
            width: 60px;
            height: 60px;
            border-radius: 999px;
            background: #fff;
            border: 4px solid var(--orange);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-size: 13px;
            font-weight: 600;
            color: var(--orange);
            line-height: 1.05;
            z-index: 5;
            box-shadow: 0 10px 24px rgba(0, 0, 0, .12);
            transform: translateY(0);
            transition: transform .25s ease;
        }

        .p-card:hover .p-off {
            transform: translateY(-3px) rotate(-2deg);
        }

        /* Image wrap */
        .p-imgwrap {
            margin-top: 15px;
            /* gives space for badge to feel above image */
            border-radius: 18px;
            background: rgba(255, 255, 255, .6);
            padding: 14px;
            overflow: hidden;
            box-shadow: 0 10px 22px rgba(0, 0, 0, .06);
        }

        .p-img {
            width: 100%;
            height: 210px;
            object-fit: cover;
            border-radius: 14px;
            transform: scale(1);
            transition: transform .35s ease;
        }

        .p-card:hover .p-img {
            transform: scale(1.06);
        }

        /* Text */
        .p-name {
            margin: 16px 0 8px;
            font-size: 19px;
            font-weight: 600;
            color: var(--ink);
        }

        .p-stars {
            color: #f7b500;
            letter-spacing: 1px;
            margin-bottom: 6px;
        }

        .p-price {
            display: flex;
            gap: 12px;
            align-items: baseline;
            margin: 8px 0 12px;
        }

        .p-now {
            color: var(--red);
            font-weight: 600;
            font-size: 20px;
        }

        .p-old {
            color: #a7a7a7;
            text-decoration: line-through;
            font-weight: 600;
            font-size: 18px;
        }

        /* Buttons */
        .p-actions {
            display: flex;
            gap: 12px;
            margin-top: 10px;
            align-items: center;
        }

        .p-cart {
            flex: 1;
            background: var(--green);
            border: 0;
            color: #fff;
            padding: 12px 14px;
            border-radius: 24px;
            font-weight: 600;
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .p-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 34px rgba(0, 0, 0, .16);
        }

        .p-wish {
            width: 54px;
            height: 54px;
            border-radius: 16px;
            border: 0;
            background: rgba(255, 255, 255, .75);
            box-shadow: 0 10px 20px rgba(0, 0, 0, .08);
            font-size: 22px;
            color: #222;
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .p-wish:hover {
            transform: translateY(-2px);
            box-shadow: 0 16px 30px rgba(0, 0, 0, .14);
        }

        * Filters bar */ .filters {
            margin-top: 26px;
            background: linear-gradient(180deg, rgba(12, 122, 67, .06), rgba(255, 255, 255, .8));
            border-radius: 18px;
            padding: 14px;
            box-shadow: 0 16px 40px rgba(0, 0, 0, .06);
            border: 1px solid rgba(12, 122, 67, .08);
        }

        .filters .form-control,
        .filters .form-select {
            border-radius: 14px;
            border: 1px solid rgba(0, 0, 0, .08);
            padding: 12px 12px;
            box-shadow: none;
        }

        .filters .form-control:focus,
        .filters .form-select:focus {
            border-color: rgba(12, 122, 67, .35);
            box-shadow: 0 0 0 .2rem rgba(12, 122, 67, .12);
        }

        /* Pagination */
        .page-link {
            border-radius: 14px !important;
            border: 1px solid rgba(0, 0, 0, .08);
            color: var(--green);
            font-weight: 600;
            padding: 10px 14px;
        }

        .page-item.active .page-link {
            background: var(--green);
            border-color: var(--green);
            color: #fff;
        }

        .ctaBtn:hover {
            background: linear-gradient(90deg, var(--gold), var(--green));
            /* Reverse the gradient on hover */
            color: #fff;
            /* Ensures text color stays white */
            transform: scale(1.05);
            /* Slightly increase the size of the button */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Add shadow on hover */
        }


        .topProductsSlider .swiper-button-next,
        .topProductsSlider .swiper-button-prev {
            width: 42px;
            height: 42px;
            background: #fff;
            border-radius: 50%;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.12);
            color: #111;
        }

        .topProductsSlider .swiper-button-next:after,
        .topProductsSlider .swiper-button-prev:after {
            font-size: 16px;
            font-weight: bold;
        }

        .topProductsSlider .swiper-pagination-bullet {
            background: #111;
            opacity: 0.4;
        }

        .topProductsSlider .swiper-pagination-bullet-active {
            opacity: 1;
        }

        .swiper-pagination-bullets {
            display: none;
        }


        .deal-sec,
        .trust-sec,
        .combo-sec,
        .review-sec {
            padding: 70px 0;
        }

        .deal-box {
            background: linear-gradient(135deg, #234018, #4b7a2f);
            border-radius: 30px;
            padding: 50px;
            color: #fff;
            overflow: hidden;
        }

        .deal-tag {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 30px;
            background: rgba(255, 255, 255, 0.14);
            border: 1px solid rgba(255, 255, 255, 0.18);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 18px;
        }

        .deal-content h2 {
            font-size: 42px;
            font-weight: 700;
            line-height: 1.2;
            margin-bottom: 16px;
        }

        .deal-content p {
            font-size: 16px;
            line-height: 1.8;
            opacity: .95;
            margin-bottom: 20px;
        }

        .deal-points {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 24px;
        }

        .deal-points span {
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .deal-btns {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .deal-btn-primary,
        .deal-btn-outline {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 160px;
            padding: 14px 22px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
        }

        .deal-btn-primary {
            background: #fff;
            color: #234018;
        }

        .deal-btn-outline {
            border: 1px solid rgba(255, 255, 255, 0.35);
            color: #fff;
        }

        .deal-main-img {
            max-height: 340px;
            width: 100%;
            object-fit: cover;
            border-radius: 24px;
            box-shadow: 0 14px 40px rgba(0, 0, 0, .2);
        }

        .trust-head {
            margin-bottom: 35px;
        }

        .trust-sub {
            max-width: 700px;
            margin: 10px auto 0;
            font-size: 16px;
            color: #667063;
        }

        .trust-card {
            background: #fff;
            border: 1px solid #e7ecd9;
            border-radius: 24px;
            padding: 28px 22px;
            text-align: center;
            height: 100%;
            box-shadow: 0 8px 28px rgba(34, 51, 22, 0.04);
            transition: .3s ease;
        }

        .trust-card:hover {
            transform: translateY(-6px);
        }

        .trust-icon {
            width: 66px;
            height: 66px;
            margin: 0 auto 18px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #edf6e7, #dceccf);
            color: #295019;
            font-size: 24px;
        }

        .trust-card h5 {
            font-size: 21px;
            font-weight: 700;
            color: #23311f;
            margin-bottom: 10px;
        }

        .trust-card p {
            margin: 0;
            font-size: 15px;
            line-height: 1.7;
            color: #677264;
        }

        .combo-left p {
            font-size: 16px;
            color: #667063;
            line-height: 1.8;
            margin-top: 14px;
            margin-bottom: 18px;
        }

        .combo-list {
            list-style: none;
            padding: 0;
            margin: 0 0 24px;
        }

        .combo-list li {
            font-size: 15px;
            color: #2a3a22;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .combo-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0b7a45, #4f7c33);
            color: #fff;
            text-decoration: none;
            padding: 14px 22px;
            border-radius: 24px;
            font-weight: 700;
        }

        .combo-mini-card {
            background: #fff;
            border: 1px solid #e7ecd9;
            border-radius: 22px;
            padding: 18px;
            text-align: center;
            height: 100%;
            box-shadow: 0 8px 24px rgba(34, 51, 22, 0.04);
        }

        .combo-mini-card img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 18px;
            margin-bottom: 14px;
        }

        .combo-mini-card h6 {
            font-size: 19px;
            font-weight: 700;
            color: #23311f;
            margin-bottom: 6px;
        }

        .combo-mini-card p {
            margin: 0;
            color: #6a7468;
            font-size: 14px;
        }

        .review-sec {
            background: #f8fbf4;
        }

        .review-sub {
            font-size: 16px;
            color: #677264;
            max-width: 720px;
            margin: 10px auto 0;
        }

        .review-card {
            background: #fff;
            border: 1px solid #e7ecd9;
            border-radius: 24px;
            padding: 28px;
            height: 100%;
            box-shadow: 0 8px 30px rgba(34, 51, 22, 0.05);
        }

        .review-stars {
            color: #f6b01e;
            font-size: 18px;
            margin-bottom: 14px;
        }

        .review-card p {
            font-size: 15px;
            line-height: 1.8;
            color: #677264;
            margin-bottom: 18px;
            min-height: 82px;
        }

        .review-card h6 {
            font-size: 18px;
            font-weight: 700;
            color: #23311f;
            margin-bottom: 4px;
        }

        .review-card span {
            font-size: 14px;
            color: #7a8477;
        }

        .reviewSlider {
            padding-bottom: 40px;
        }

        .review-pagination .swiper-pagination-bullet {
            background: #244319;
        }

        @media (max-width: 991px) {
            .deal-box {
                padding: 30px 24px;
            }

            .deal-content h2 {
                font-size: 32px;
            }
        }

        @media (max-width: 767px) {
            .deal-content h2 {
                font-size: 28px;
            }

            .combo-mini-card img {
                height: 180px;
            }
            
            .brandLogo {
            height: 40px;
            width: auto;
            object-fit: contain;
        }
        }









        /********************************SIGNUP PAGE************************************/
        :root {
            --nature-1: #1f6b45;
            --nature-2: #2f8f5b;
            --nature-3: #79c98c;
            --nature-4: #eaf7ee;
            --nature-5: #f7fcf8;
            --text-dark: #153224;
            --text-muted: #5e7568;
            --white: #ffffff;
            --danger: #dc3545;
            --shadow: 0 20px 60px rgba(21, 50, 36, 0.12);
            --radius: 24px;
        }

        body {
            background: linear-gradient(180deg, #f7fcf8 0%, #eef8f1 100%);
        }

        .signup-page {
            position: relative;
            overflow: hidden;
            min-height: 100vh;
            padding: 90px 0;
            background:
                radial-gradient(circle at top left, rgba(121, 201, 140, 0.22), transparent 28%),
                radial-gradient(circle at bottom right, rgba(47, 143, 91, 0.18), transparent 24%),
                linear-gradient(135deg, #f6fbf7 0%, #edf8f0 45%, #f9fdf9 100%);
        }

        .signup-page::before,
        .signup-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            filter: blur(10px);
            z-index: 0;
        }

        .signup-page::before {
            width: 320px;
            height: 320px;
            top: -90px;
            left: -80px;
            background: rgba(121, 201, 140, 0.22);
        }

        .signup-page::after {
            width: 280px;
            height: 280px;
            bottom: -80px;
            right: -60px;
            background: rgba(31, 107, 69, 0.12);
        }

        .signup-wrap {
            position: relative;
            z-index: 2;
        }

        .signup-box {
            background: rgba(255, 255, 255, 0.82);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .signup-left {
            position: relative;
            padding: 55px 45px;
            background:
                linear-gradient(180deg, rgba(20, 64, 40, 0.30), rgba(20, 64, 40, 0.45)),
                url("{{ asset('Website/assets/images/mustard-banner.jpg') }}") center/cover no-repeat;
            min-height: 100%;
            display: flex;
            align-items: flex-end;
        }

        .signup-left::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                radial-gradient(circle at top right, rgba(121, 201, 140, 0.35), transparent 30%),
                radial-gradient(circle at bottom left, rgba(255, 255, 255, 0.12), transparent 25%);
        }

        .signup-left-content {
            position: relative;
            z-index: 2;
            color: #fff;
            max-width: 420px;
        }

        .signup-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.14);
            border: 1px solid rgba(255, 255, 255, 0.18);
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 18px;
            backdrop-filter: blur(6px);
        }

        .signup-left-content h2 {
            font-size: 40px;
            line-height: 1.15;
            font-weight: 800;
            margin-bottom: 16px;
        }

        .signup-left-content p {
            font-size: 16px;
            line-height: 1.8;
            color: rgba(255, 255, 255, 0.92);
            margin-bottom: 0;
        }

        .signup-right {
            padding: 55px 42px;
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.92), rgba(249, 253, 250, 0.96));
        }

        .brand-mini {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 22px;
        }

        .brand-leaf {
            width: 48px;
            height: 48px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--nature-2), var(--nature-3));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 22px;
            box-shadow: 0 12px 30px rgba(47, 143, 91, 0.22);
        }

        .brand-mini h5 {
            margin: 0;
            color: var(--text-dark);
            font-size: 20px;
            font-weight: 800;
        }

        .brand-mini span {
            color: var(--text-muted);
            font-size: 13px;
        }

        .signup-title {
            font-size: 34px;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 8px;
        }

        .signup-subtitle {
            color: var(--text-muted);
            font-size: 15px;
            margin-bottom: 28px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap i {
            position: absolute;
            top: 50%;
            left: 16px;
            transform: translateY(-50%);
            color: #6f8a7a;
            font-size: 15px;
        }

        .form-control {
            height: 56px;
            border-radius: 16px;
            padding: 12px 16px 12px 46px;
            border: 1px solid #d9eadc;
            background: #fbfefc;
            color: var(--text-dark);
            font-size: 15px;
            transition: all .3s ease;
            box-shadow: none !important;
        }

        .form-control:focus {
            border-color: var(--nature-2);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(47, 143, 91, 0.10) !important;
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 16px;
            transform: translateY(-50%);
            border: none;
            background: none;
            color: #6f8a7a;
            font-size: 15px;
            cursor: pointer;
            padding: 0;
        }

        .signup-btn {
            width: 100%;
            height: 56px;
            border: none;
            border-radius: 32px;
            background: linear-gradient(135deg, var(--nature-1), var(--nature-2));
            color: #fff;
            font-size: 16px;
            font-weight: 800;
            letter-spacing: .2px;
            transition: all .35s ease;
            box-shadow: 0 15px 35px rgba(31, 107, 69, 0.22);
            margin-top: 8px;
        }

        .signup-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 18px 38px rgba(31, 107, 69, 0.28);
        }

        .login-text {
            text-align: center;
            margin-top: 22px;
            font-size: 14px;
            color: var(--text-muted);
        }

        .login-text a {
            color: var(--nature-1);
            font-weight: 800;
            text-decoration: none;
        }

        .alert {
            border-radius: 14px;
            font-size: 14px;
        }

        .invalid-feedback {
            display: block;
            font-size: 13px;
        }

        @media (max-width: 991px) {
            .signup-left {
                min-height: 320px;
                padding: 35px 25px;
            }

            .signup-right {
                padding: 38px 24px;
            }

            .signup-left-content h2 {
                font-size: 30px;
            }

            .signup-title {
                font-size: 28px;
            }
        }

        @media (max-width: 575px) {
            .signup-page {
                padding: 60px 0;
            }

            .signup-left-content h2 {
                font-size: 26px;
            }
        }



        /***********************CART************************/


        /*********************************TRACK ORDER *************************************/
        :root {
            --nature-1: #1f6b45;
            --nature-2: #2f8f5b;
            --nature-3: #79c98c;
            --nature-4: #eaf7ee;
            --nature-5: #f7fcf8;
            --text-dark: #153224;
            --text-muted: #5e7568;
            --white: #ffffff;
            --danger: #dc3545;
            --warning: #f4a825;
            --line: #dceadf;
            --shadow: 0 20px 60px rgba(21, 50, 36, 0.10);
            --radius: 24px;
        }

        body {
            background: linear-gradient(180deg, #f7fcf8 0%, #eef8f1 100%);
        }

        .track-page {
            position: relative;
            overflow: hidden;
            min-height: 10vh;
            padding: 70px 0 90px;
            background:
                radial-gradient(circle at top left, rgba(121, 201, 140, 0.18), transparent 28%),
                radial-gradient(circle at bottom right, rgba(47, 143, 91, 0.15), transparent 24%),
                linear-gradient(135deg, #f6fbf7 0%, #edf8f0 45%, #f9fdf9 100%);
        }

        .track-page::before,
        .track-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            filter: blur(10px);
            z-index: 0;
        }

        .track-page::before {
            width: 320px;
            height: 320px;
            top: -90px;
            left: -80px;
            background: rgba(121, 201, 140, 0.18);
        }

        .track-page::after {
            width: 260px;
            height: 260px;
            bottom: -70px;
            right: -50px;
            background: rgba(31, 107, 69, 0.10);
        }

        .track-wrap {
            position: relative;
            z-index: 2;
        }

        .track-top {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }

        .track-titlebox small {
            display: inline-block;
            color: var(--nature-2);
            font-weight: 600 !important;
            letter-spacing: .4px;
            margin-bottom: 10px;
            font-size: 15px;
            background: #edf5e8;
            border: 0px solid #0b7a45;
            padding: 8px 14px;
            border-radius: 24px;
            font-family:outfit;
        }

        .track-titlebox h1 {
            margin: 0;
            color: var(--text-dark);
            font-size: 64px !important;
            font-weight: 800;
        }

        .track-titlebox p {
            margin: 10px 0 0;
            color: var(--text-muted);
            font-size: 15px;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 18px;
            border-radius: 999px;
            text-decoration: none;
            font-weight: 700;
            color: var(--nature-1);
            background: #fff;
            border: 1px solid #d8e8dc;
            transition: all .3s ease;
            box-shadow: 0 10px 24px rgba(31, 107, 69, 0.06);
        }

        .back-btn:hover {
            color: #fff;
            background: var(--nature-1);
            border-color: var(--nature-1);
        }

        .info-card,
        .map-card,
        .timeline-card,
        .side-card,
        .product-card {
            background: rgba(255, 255, 255, 0.86);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.7);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .info-card,
        .timeline-card,
        .map-card,
        .product-card {
            padding: 24px;
        }

        .side-card {
            padding: 22px;
            position: sticky;
            top: 110px;
        }

        .hero-status {
            display: grid;
            grid-template-columns: 1.2fr .8fr;
            gap: 22px;
        }

        .status-panel {
            padding: 26px;
            border-radius: 22px;
            background: linear-gradient(135deg, rgba(31, 107, 69, 0.95), rgba(47, 143, 91, 0.88));
            color: #fff;
            position: relative;
            overflow: hidden;
        }

        .status-panel::before {
            content: "";
            position: absolute;
            width: 180px;
            height: 180px;
            right: -40px;
            top: -40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .status-panel small {
            display: inline-block;
            font-size: 13px;
            font-weight: 700;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.14);
            margin-bottom: 14px;
        }

        .status-panel h2 {
            margin: 0 0 10px;
            font-size: 34px;
            font-weight: 800;
            position: relative;
            z-index: 2;
        }

        .status-panel p {
            margin: 0;
            font-size: 15px;
            color: rgba(255, 255, 255, 0.92);
            position: relative;
            z-index: 2;
        }

        .eta-panel {
            padding: 26px;
            border-radius: 22px;
            background: linear-gradient(180deg, #ffffff, #f6fbf7);
            border: 1px solid #dceadf;
        }

        .eta-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 18px;
        }

        .eta-top h4 {
            margin: 0;
            color: var(--text-dark);
            font-size: 20px;
            font-weight: 800;
        }

        .eta-badge {
            font-size: 12px;
            font-weight: 700;
            color: var(--nature-1);
            background: var(--nature-4);
            border: 1px solid #dbeee0;
            padding: 8px 12px;
            border-radius: 999px;
        }

        .eta-time {
            font-size: 38px;
            line-height: 1;
            font-weight: 800;
            color: var(--nature-1);
            margin-bottom: 10px;
        }

        .eta-panel p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .grid-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-top: 22px;
        }

        .stat-box {
            padding: 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
            text-align: center;
        }

        .stat-box i {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(31, 107, 69, 0.10), rgba(47, 143, 91, 0.15));
            color: var(--nature-1);
            font-size: 18px;
            margin-bottom: 12px;
        }

        .stat-box h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 16px;
            font-weight: 800;
        }

        .stat-box p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 20px;
        }

        .section-head h3 {
            margin: 0;
            color: var(--text-dark);
            font-size: 24px;
            font-weight: 800;
        }

        .section-head span {
            font-size: 13px;
            font-weight: 700;
            color: var(--nature-1);
            background: var(--nature-4);
            border: 1px solid #dbeee0;
            padding: 8px 12px;
            border-radius: 999px;
        }

        .route-box {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 16px;
            align-items: center;
            margin-bottom: 18px;
        }

        .route-point {
            padding: 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .route-point small {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .route-point h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 18px;
            font-weight: 800;
        }

        .route-point p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .route-arrow {
            width: 58px;
            height: 58px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--nature-1), var(--nature-2));
            color: #fff;
            font-size: 20px;
            box-shadow: 0 14px 30px rgba(31, 107, 69, 0.16);
        }

        .fake-map {
            min-height: 260px;
            border-radius: 22px;
            position: relative;
            overflow: hidden;
            border: 1px solid #dceadf;
            background:
                linear-gradient(0deg, rgba(255, 255, 255, .75), rgba(255, 255, 255, .75)),
                url("{{ asset('Website/assets/images/hb4.jpg') }}") center/cover no-repeat;
        }

        .fake-map::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                linear-gradient(90deg, rgba(31, 107, 69, 0.10) 1px, transparent 1px),
                linear-gradient(rgba(31, 107, 69, 0.10) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: .25;
        }

        .map-route {
            position: absolute;
            left: 12%;
            top: 65%;
            width: 70%;
            height: 6px;
            background: repeating-linear-gradient(90deg,
                    var(--nature-1),
                    var(--nature-1) 20px,
                    rgba(31, 107, 69, .3) 20px,
                    rgba(31, 107, 69, .3) 32px);
            border-radius: 999px;
            transform: rotate(-18deg);
            box-shadow: 0 8px 25px rgba(31, 107, 69, .15);
        }

        .map-pin {
            position: absolute;
            width: 58px;
            height: 58px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 20px;
            box-shadow: 0 14px 30px rgba(31, 107, 69, .18);
        }

        .map-pin.start {
            left: 10%;
            top: 60%;
            background: linear-gradient(135deg, #1f6b45, #2f8f5b);
        }

        .map-pin.middle {
            left: 46%;
            top: 40%;
            background: linear-gradient(135deg, #e8a525, #f4bd43);
        }

        .map-pin.end {
            right: 12%;
            top: 22%;
            background: linear-gradient(135deg, #2f8f5b, #79c98c);
        }

        .map-label {
            position: absolute;
            background: #fff;
            border: 1px solid #dceadf;
            border-radius: 14px;
            padding: 8px 12px;
            font-size: 13px;
            font-weight: 700;
            color: var(--text-dark);
            box-shadow: 0 10px 24px rgba(31, 107, 69, .08);
        }

        .map-label.label-1 {
            left: 8%;
            top: 78%;
        }

        .map-label.label-2 {
            left: 42%;
            top: 57%;
        }

        .map-label.label-3 {
            right: 8%;
            top: 12%;
        }

        .timeline {
            position: relative;
            margin-left: 12px;
            padding-left: 26px;
        }

        .timeline::before {
            content: "";
            position: absolute;
            left: 7px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(180deg, var(--nature-2), rgba(47, 143, 91, .15));
            border-radius: 999px;
        }

        .timeline-item {
            position: relative;
            padding-bottom: 24px;
        }

        .timeline-item:last-child {
            padding-bottom: 0;
        }

        .timeline-dot {
            position: absolute;
            left: -26px;
            top: 2px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #d8ebe0;
            border: 4px solid #fff;
            box-shadow: 0 0 0 2px #d8ebe0;
        }

        .timeline-item.active .timeline-dot {
            background: var(--nature-1);
            box-shadow: 0 0 0 2px rgba(31, 107, 69, .3);
        }

        .timeline-item.current .timeline-dot {
            background: var(--warning);
            box-shadow: 0 0 0 2px rgba(244, 168, 37, .35);
        }

        .timeline-content {
            padding: 16px 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .timeline-content small {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .timeline-content h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 17px;
            font-weight: 800;
        }

        .timeline-content p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .delivery-person {
            display: flex;
            gap: 14px;
            align-items: center;
            margin-bottom: 18px;
            padding: 16px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .delivery-avatar {
            width: 64px;
            height: 64px;
            border-radius: 18px;
            background: linear-gradient(135deg, var(--nature-1), var(--nature-3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 800;
        }

        .delivery-person h5 {
            margin: 0 0 5px;
            color: var(--text-dark);
            font-size: 18px;
            font-weight: 800;
        }

        .delivery-person p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .contact-btns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 14px;
        }

        .contact-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            height: 48px;
            border-radius: 24px !important;
            text-decoration: none;
            font-weight: 800;
            transition: all .3s ease;
        }

        .call-btn {
            background: #fff;
            color: var(--nature-1);
            border: 1px solid var(--nature-1);
        }

        .call-btn:hover {
            background: var(--nature-1);
            color: #fff;
        }

        .support-btn {
            background: linear-gradient(135deg, var(--nature-1), var(--nature-2));
            color: #fff;
            border: 1px solid transparent;
            box-shadow: 0 12px 26px rgba(31, 107, 69, .16);
            border-radius: 24px !important;
        }

        .support-btn:hover {
            transform: translateY(-2px);
            color: #fff;
        }

        .detail-list {
            display: grid;
            gap: 12px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid var(--line);
            font-size: 14px;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-row span {
            color: var(--text-muted);
        }

        .detail-row strong {
            color: var(--text-dark);
            text-align: right;
        }

        .mini-product {
            display: flex;
            gap: 12px;
            padding: 14px 0;
            border-bottom: 1px solid var(--line);
        }

        .mini-product:last-child {
            border-bottom: none;
        }

        .mini-product img {
            width: 64px;
            height: 64px;
            border-radius: 14px;
            object-fit: cover;
            border: 1px solid #e3efe6;
            background: #f7fcf8;
        }

        .mini-product h6 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 15px;
            font-weight: 800;
        }

        .mini-product p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .help-note {
            margin-top: 18px;
            padding: 14px 16px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(121, 201, 140, 0.12), rgba(47, 143, 91, 0.08));
            color: var(--nature-1);
            font-size: 14px;
            font-weight: 700;
            border: 1px solid #dceee1;
        }

        @media (max-width: 1199px) {
            .grid-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 991px) {
            .hero-status {
                grid-template-columns: 1fr;
            }

            .side-card {
                position: static;
                margin-top: 24px;
            }

            .track-titlebox h1 {
                font-size: 34px;
            }
        }

        @media (max-width: 767px) {
            .track-titlebox h1 {
                font-size: 42px !important;
            }

            .info-card,
            .map-card,
            .timeline-card,
            .product-card,
            .side-card {
                padding: 18px;
            }

            .route-box {
                grid-template-columns: 1fr;
            }

            .route-arrow {
                margin: 0 auto;
                transform: rotate(90deg);
            }

            .grid-stats {
                grid-template-columns: 1fr;
            }

            .contact-btns {
                grid-template-columns: 1fr;
            }

            .eta-time {
                font-size: 32px;
            }
        }

        /*****************************CHECKOUT************************/

        .checkout-page {
            padding: 60px 0;
            background: linear-gradient(180deg, #f7fcf8 0%, #eef8f1 100%);
        }

        .checkout-page::before,
        .checkout-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            filter: blur(10px);
            z-index: 0;
        }

        .checkout-page::before {
            width: 320px;
            height: 320px;
            top: -90px;
            left: -80px;
            background: rgba(121, 201, 140, 0.18);
        }

        .checkout-page::after {
            width: 260px;
            height: 260px;
            bottom: -70px;
            right: -50px;
        }



        .checkout-wrap {
            position: relative;

        }

        .checkout-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }

        .checkout-titlebox small {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
            color: #24764c;
            background: #edf4e4;
            border: 0px solid #0b7a45;
            padding: 8px 14px;
            border-radius: 30px;
            margin-bottom: 12px;
            font-weight: 600;
        }

        .checkout-titlebox h1 {
            font-size: 54px;
            line-height: 1.2;
            margin: 10px 0 8px;
            color: #1f2a1a;
            font-weight: 700;
        }

        .checkout-titlebox p {
            margin: 0;
            color: #667085;
            font-size: 15px;
            max-width: 640px;
        }

        .continue-shopping {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            background: #ffffff;
            color: #2e4b21;
            border: 1px solid #dfe6d3;
            border-radius: 32px !important;
            padding: 12px 18px;
            font-weight: 600;
            transition: all .3s ease;
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.04);
        }

        .continue-shopping:hover {
            background: #2e4b21;
            color: #fff;
        }

        .cart-card,
        .summary-card {
            background: #fff;
            border-radius: 24px;
            padding: 28px;
            border: 1px solid #e7ecdf;
            box-shadow: 0 14px 35px rgba(16, 24, 40, 0.05);
        }

        .cart-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
            margin-bottom: 24px;
            padding-bottom: 18px;
            border-bottom: 1px solid #eef1ea;
        }

        .cart-head h3,
        .summary-card h3 {
            margin: 0;
            font-size: 24px;
            color: #1f2a1a;
            font-weight: 700;
        }

        .cart-head span {
            color: #6b7280;
            font-size: 14px;
        }

        .address-preview {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            padding: 18px;
            border: 1px solid #e4eadb;
            background: #fbfcf8;
            border-radius: 18px;
            margin-bottom: 18px;
            flex-wrap: wrap;
        }

        .address-preview h5 {
            margin: 0 0 8px;
            font-size: 17px;
            font-weight: 700;
            color: #1f2a1a;
        }

        .address-preview p {
            margin: 0;
            color: #667085;
            font-size: 14px;
            line-height: 1.7;
        }

        .change-address-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            background: #24764c;
            color: #fff;
            border-radius: 24px;
            padding: 10px 16px;
            font-size: 14px;
            font-weight: 600;
            height: fit-content;
        }

        .change-address-btn:hover {
            color: #fff;
            background: #1f3516;
        }

        .payment-option {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            border: 1px solid #e4eadb;
            background: #fbfcf8;
            border-radius: 16px;
            padding: 16px 18px;
            margin-bottom: 14px;
            transition: all .25s ease;
            cursor: pointer;
        }

        .payment-option.active {
            border-color: #89a36a;
            background: #f4f9ee;
        }

        .payment-option-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .payment-option input {
            accent-color: #2e4b21;
            width: 18px;
            height: 18px;
            margin-top: 0;
        }

        .payment-option h6 {
            margin: 0;
            font-size: 15px;
            font-weight: 600;
            color: #1f2a1a;
        }

        .payment-option p {
            margin: 2px 0 0;
            font-size: 13px;
            color: #6b7280;
        }

        .delivery-note {
            margin-top: 16px;
            padding: 14px 16px;
            border-radius: 14px;
            background: #fbfcf8;
            border: 1px solid #edf1e7;
            color: #667085;
            font-size: 14px;
        }

        .order-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 0;
            border-bottom: 1px solid #eef1ea;
        }

        .order-item:last-of-type {
            border-bottom: 0;
            padding-bottom: 0;
        }

        .cart-thumb {
            width: 100px;
            min-width: 74px;
            height: 100px;
            border-radius: 16px;
            overflow: hidden;
            background: #f5f7f1;
            border: 1px solid #edf1e7;
        }

        .cart-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-info {
            flex: 1;
            min-width: 0;
        }

        .cart-info h4 {
            margin: 0 0 5px;
            font-size: 20px;
            font-weight: 700;
            color: #1f2a1a;
        }

        .cart-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 4px;
        }

        .cart-meta span {
            display: inline-flex;
            align-items: center;
            padding: 5px 10px;
            border-radius: 30px;
            background: #f4f7ef;
            color: #637252;
            font-size: 12px;
            font-weight: 600;
        }

        .price-box {
            text-align: right;
        }

        .price {
            font-size: 17px;
            font-weight: 700;
            color: #1f2a1a;
        }

        .coupon-box {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 22px 0 6px;
        }

        .coupon-input {
            flex: 1;
            height: 52px;
            border: 1px solid #dfe6d3;
            background: #fbfcf8;
            border-radius: 24px;
            padding: 0 16px;
            font-size: 15px;
            outline: none;
        }

        .coupon-input:focus {
            border-color: #89a36a;
            background: #fff;
            box-shadow: 0 0 0 4px rgba(137, 163, 106, 0.12);
        }

        .coupon-btn,
        .place-order-btn {
            border: 0;
            outline: none;
            border-radius: 32px;
            font-weight: 600;
            transition: all .25s ease;
        }

        .coupon-btn {
            height: 52px;
            padding: 0 18px;
            background: #24764c;
            color: #fff;
            white-space: nowrap;
        }

        .coupon-btn:hover {
            background: #1f3516;
        }

        .summary-line {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 11px 0;
            font-size: 15px;
            color: #475467;
        }

        .summary-line strong {
            color: #1f2a1a;
            font-size: 15px;
        }

        .summary-line.total {
            margin-top: 6px;
            padding-top: 18px;
            border-top: 1px solid #eef1ea;
            font-size: 18px;
        }

        .summary-line.total strong {
            font-size: 22px;
            color: #2e4b21;
        }

        .summary-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 12px;
            margin-bottom: 8px;
            padding: 12px 14px;
            border-radius: 14px;
            background: #f4f9ee;
            color: #476635;
            font-size: 14px;
            font-weight: 600;
        }

        .place-order-btn {
            width: 100%;
            height: 56px;
            margin-top: 16px;
            background: linear-gradient(135deg, #24764c, #247222);
            color: #fff;
            border-radius: 32px;
            font-size: 20px;
            box-shadow: 0 12px 25px rgba(46, 75, 33, 0.22);
        }

        .place-order-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 16px 30px rgba(46, 75, 33, 0.28);
        }

        .secure-note {
            margin-top: 16px;
            font-size: 13px;
            color: #667085;
            text-align: center;
        }

        @media (max-width: 991.98px) {
            .checkout-page {
                padding: 40px 0;
            }

            .checkout-titlebox h1 {
                font-size: 30px;
            }

            .cart-card,
            .summary-card {
                padding: 22px;
            }
        }

        @media (max-width: 767.98px) {
            .checkout-top {
                margin-bottom: 20px;
            }

            .checkout-titlebox h1 {
                font-size: 26px;
            }

            .cart-card,
            .summary-card {
                padding: 18px;
                border-radius: 18px;
            }

            .coupon-box {
                flex-direction: column;
            }

            .coupon-btn {
                width: 100%;
            }

            .order-item {
                align-items: flex-start;
            }

            .price-box {
                min-width: 70px;
            }
        }
    </style>


    <style>
        body {
            background: #f0f9f3;
        }

        /* ─── PAGE WRAPPER ─── */
        .cp-page {
            position: relative;
            overflow: hidden;
            min-height: 100vh;
            padding: 80px 0 100px;
        }

        /* ─── DECORATIVE BG ─── */
        .cp-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .cp-bg::before {
            content: '';
            position: absolute;
            width: 700px;
            height: 700px;
            top: -200px;
            left: -200px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.22) 0%, transparent 70%);
            animation: drift 14s ease-in-out infinite alternate;
        }

        .cp-bg::after {
            content: '';
            position: absolute;
            width: 500px;
            height: 500px;
            bottom: -150px;
            right: -100px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(26, 92, 58, 0.14) 0%, transparent 70%);
            animation: drift2 18s ease-in-out infinite alternate;
        }

        .cp-orb {
            position: absolute;
            width: 300px;
            height: 300px;
            top: 50%;
            right: 10%;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(168, 230, 191, 0.18) 0%, transparent 70%);
            animation: drift3 22s ease-in-out infinite alternate;
        }

        @keyframes drift {
            from {
                transform: translate(0, 0) scale(1);
            }

            to {
                transform: translate(40px, 50px) scale(1.08);
            }
        }

        @keyframes drift2 {
            from {
                transform: translate(0, 0) scale(1);
            }

            to {
                transform: translate(-30px, -40px) scale(1.05);
            }
        }

        @keyframes drift3 {
            from {
                transform: translate(0, 0);
            }

            to {
                transform: translate(20px, -30px);
            }
        }

        /* leaf dots pattern */
        .cp-dots {
            position: absolute;
            inset: 0;
            background-image:
                radial-gradient(circle, rgba(78, 184, 122, 0.15) 1.5px, transparent 1.5px);
            background-size: 38px 38px;
            opacity: 0.5;
        }

        /* ─── CONTAINER ─── */
        .cp-wrap {
            position: relative;
            z-index: 2;
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* ─── HERO STRIP ─── */
        .cp-hero {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 70px;
            gap: 30px;
        }

        .cp-hero-text {
            max-width: 560px;
        }

        .cp-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: var(--g2);
            background: rgba(78, 184, 122, 0.12);
            border: 1px solid rgba(78, 184, 122, 0.25);
            padding: 6px 16px;
            border-radius: 100px;
            margin-bottom: 22px;
            animation: fadeUp 0.6s ease both;
        }

        .cp-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(42px, 6vw, 72px);
            font-weight: 900;
            line-height: 1.08;
            color: var(--ink);
            animation: fadeUp 0.7s 0.1s ease both;
        }

        .cp-hero h1 span {
            color: var(--g2);
            position: relative;
            display: inline-block;
        }

        .cp-hero h1 span::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -4px;
            width: 100%;
            height: 4px;
            border-radius: 4px;
            background: linear-gradient(90deg, var(--g3), var(--g4));
            transform: scaleX(0);
            transform-origin: left;
            animation: lineReveal 0.6s 0.7s ease forwards;
        }

        @keyframes lineReveal {
            to {
                transform: scaleX(1);
            }
        }

        .cp-hero p {
            margin-top: 20px;
            font-size: 17px;
            line-height: 1.75;
            color: var(--muted);
            max-width: 480px;
            animation: fadeUp 0.7s 0.2s ease both;
        }

        .cp-hero-badge {
            flex-shrink: 0;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
            box-shadow: 0 30px 80px rgba(26, 92, 58, 0.3);
            animation: popIn 0.7s 0.4s ease both;
            position: relative;
            overflow: hidden;
        }

        .cp-hero-badge::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.15), transparent);
            border-radius: 50%;
        }

        .cp-hero-badge i {
            font-size: 48px;
            opacity: 0.9;
        }

        .cp-hero-badge span {
            font-family: 'outfit', serif;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-top: 8px;
            text-transform: uppercase;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(24px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes popIn {
            from {
                opacity: 0;
                transform: scale(0.75);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        /* ─── TWO-COLUMN GRID ─── */
        .cp-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            align-items: start;
        }

        /* ─── FORM CARD ─── */
        .cp-form-card {
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            border-radius: 28px;
            padding: 44px 40px;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.7);
            animation: fadeUp 0.7s 0.3s ease both;
        }

        .cp-form-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: 26px;
            color: var(--ink);
            margin-bottom: 28px;
        }

        .cp-form-card h2 span {
            color: var(--g2);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .fgroup {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 18px;
        }

        .fgroup label {
            font-size: 12.5px;
            font-weight: 600;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            color: var(--muted);
        }

        .finput-wrap {
            position: relative;
        }

        .finput-wrap i {
            position: absolute;
            top: 50%;
            left: 16px;
            transform: translateY(-50%);
            color: var(--g3);
            font-size: 16px;
            transition: color 0.3s;
        }

        .finput-wrap.textarea-wrap i {
            top: 17px;
            transform: none;
        }

        .finput {
            width: 100%;
            height: 50px;
            border: 1.5px solid var(--line);
            border-radius: 14px;
            background: rgba(240, 249, 243, 0.6);
            padding: 0 16px 0 44px;
            font-family: 'DM Sans', sans-serif;
            font-size: 15px;
            color: var(--ink);
            transition: all 0.3s ease;
            outline: none;
        }

        textarea.finput {
            height: 110px;
            padding-top: 14px;
            resize: none;
        }

        .finput:focus {
            border-color: var(--g2);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(45, 138, 86, 0.10);
        }

        .finput:focus+i,
        .finput:focus~i {
            color: var(--g2);
        }

        .finput-wrap:focus-within i {
            color: var(--g2);
        }

        .cp-select-wrap {
            position: relative;
        }

        .cp-select-wrap::after {
            content: '\f078';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--g3);
            font-size: 12px;
            pointer-events: none;
        }

        .finput.select-field {
            appearance: none;
            cursor: pointer;
        }

        .cp-submit {
            width: 100%;
            height: 54px;
            border: none;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--g1) 0%, var(--g2) 60%, var(--g3) 100%);
            color: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 16px;
            font-weight: 600;
            letter-spacing: 0.4px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.35s ease;
            box-shadow: 0 12px 40px rgba(26, 92, 58, 0.28);
            margin-top: 6px;
        }

        .cp-submit::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.12), transparent);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .cp-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 18px 50px rgba(26, 92, 58, 0.35);
        }

        .cp-submit:hover::before {
            opacity: 1;
        }

        .cp-submit:active {
            transform: translateY(0);
        }

        .cp-submit i {
            margin-right: 8px;
        }

        /* ─── RIGHT COLUMN ─── */
        .cp-right {
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        /* ─── INFO CARDS ─── */
        .cp-info-card {
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            border-radius: 22px;
            padding: 28px 28px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.7);
            display: flex;
            align-items: flex-start;
            gap: 20px;
            transition: transform 0.35s ease, box-shadow 0.35s ease;
            animation: fadeUp 0.7s ease both;
        }

        .cp-info-card:nth-child(1) {
            animation-delay: 0.35s;
        }

        .cp-info-card:nth-child(2) {
            animation-delay: 0.45s;
        }

        .cp-info-card:nth-child(3) {
            animation-delay: 0.55s;
        }

        .cp-info-card:hover {
            transform: translateX(8px);
            box-shadow: var(--shadow-med);
        }

        .cp-info-icon {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: #e59e20;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 20px;
            flex-shrink: 0;
            box-shadow: 0 8px 24px rgba(26, 92, 58, 0.22);
        }

        .cp-info-body {}

        .cp-info-body h5 {
            font-size: 15px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 6px;
        }

        .cp-info-body p,
        .cp-info-body a {
            font-size: 14.5px;
            color: var(--muted);
            line-height: 1.65;
            text-decoration: none;
        }

        .cp-info-body a:hover {
            color: var(--g2);
        }

        /* ─── SOCIAL STRIP ─── */
        .cp-social-card {
            background: linear-gradient(135deg, var(--g1), var(--g2));
            border-radius: 22px;
            padding: 28px 28px;
            color: #fff;
            box-shadow: 0 20px 60px rgba(26, 92, 58, 0.25);
            animation: fadeUp 0.7s 0.65s ease both;
        }

        .cp-social-card h5 {
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 18px;
            opacity: 0.9;
            letter-spacing: 0.5px;
        }

        .cp-socials {
            display: flex;
            gap: 14px;
        }

        .cp-social-btn {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 17px;
            text-decoration: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(8px);
        }

        .cp-social-btn:hover {
            background: rgba(255, 255, 255, 0.28);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            color: #fff;
        }

        /* ─── HOURS ─── */
        .cp-hours-card {
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            border-radius: 22px;
            padding: 28px 28px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.7);
            animation: fadeUp 0.7s 0.75s ease both;
        }

        .cp-hours-card h5 {
            font-size: 15px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cp-hours-card h5 i {
            color: var(--g2);
        }

        .cp-hours-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 9px 0;
            border-bottom: 1px solid var(--line);
            font-size: 14px;
        }

        .cp-hours-row:last-child {
            border-bottom: none;
        }

        .cp-hours-row .day {
            color: var(--muted);
            font-weight: 500;
        }

        .cp-hours-row .time {
            color: var(--ink);
            font-weight: 600;
        }

        .cp-hours-row .badge-open {
            background: rgba(78, 184, 122, 0.15);
            color: var(--g2);
            font-size: 11px;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 100px;
            border: 1px solid rgba(78, 184, 122, 0.25);
        }

        .cp-hours-row .badge-closed {
            background: rgba(220, 53, 69, 0.08);
            color: #c0392b;
            font-size: 11px;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 100px;
        }

        /* ─── MAP + TEAM SECTIONS ─── */
        .cp-bottom {
            margin-top: 30px;
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
        }

        .cp-map-card {
            background: var(--card-bg);
            border-radius: 28px;
            overflow: hidden;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.7);
            animation: fadeUp 0.7s 0.5s ease both;
        }

        .cp-map-header {
            padding: 22px 28px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .cp-map-header i {
            color: var(--g2);
            font-size: 20px;
        }

        .cp-map-header h4 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--ink);
        }

        .cp-map-card iframe {
            width: 100%;
            height: 260px;
            border: none;
            display: block;
        }

        /* ─── TEAM ─── */
        .cp-team-card {
            background: var(--card-bg);
            border-radius: 28px;
            padding: 28px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.7);
            animation: fadeUp 0.7s 0.6s ease both;
        }

        .cp-team-card h4 {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--ink);
            margin-bottom: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cp-team-card h4 i {
            color: var(--g2);
        }

        .cp-team-list {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .cp-member {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 14px 16px;
            border-radius: 16px;
            background: var(--g5);
            border: 1px solid var(--line);
            transition: all 0.3s ease;
        }

        .cp-member:hover {
            background: #fff;
            box-shadow: var(--shadow-soft);
            transform: translateX(5px);
        }

        .cp-member-avatar {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            object-fit: cover;
            border: 2.5px solid var(--g3);
            flex-shrink: 0;
        }

        .cp-member-avatar-placeholder {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: #e59e20;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
            flex-shrink: 0;
            border: 2.5px solid #e59e20;
        }

        .cp-member-info h6 {
            font-size: 15px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 3px;
        }

        .cp-member-info span {
            font-size: 13px;
            color: var(--muted);
        }

        .cp-member-contact {
            margin-left: auto;
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: rgba(45, 138, 86, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--g2);
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
            text-decoration: none;
        }

        .cp-member-contact:hover {
            background: var(--g2);
            color: #fff;
        }

        /* ─── SUCCESS TOAST ─── */
        .cp-toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: linear-gradient(135deg, var(--g1), var(--g2));
            color: #fff;
            padding: 16px 24px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 15px;
            font-weight: 500;
            box-shadow: 0 20px 60px rgba(26, 92, 58, 0.3);
            z-index: 9999;
            transform: translateX(200%);
            transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .cp-toast.show {
            transform: translateX(0);
        }

        .cp-toast i {
            font-size: 20px;
        }

        /* ─── RESPONSIVE ─── */
        @media (max-width: 991px) {

            .cp-grid,
            .cp-bottom {
                grid-template-columns: 1fr;
            }

            .cp-hero {
                flex-direction: column;
                text-align: center;
            }

            .cp-hero p {
                margin: 16px auto 0;
            }

            .cp-hero-badge {
                display: none;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 575px) {
            .cp-form-card {
                padding: 28px 20px;
            }

            .cp-hero h1 {
                font-size: 38px;
            }

            .cp-page {
                padding: 60px 0 10px
            }
        }
    </style>
    <style>
        :root {
            --g1: #1a5c3a;
            --g2: #2d8a56;
            --g3: #4eb87a;
            --g4: #a8e6bf;
            --g5: #eef8f1;

            --a1: #e59e20;
            --a2: #c98510;
            --a3: #fff3da;

            --ink: #0f2a1a;
            --muted: #5c7463;
            --white: #ffffff;
            --line: rgba(41, 120, 74, 0.12);
            --card: rgba(255, 255, 255, 0.90);

            --shadow-sm: 0 10px 30px rgba(18, 64, 38, 0.08);
            --shadow-md: 0 18px 50px rgba(18, 64, 38, 0.12);
            --shadow-lg: 0 26px 80px rgba(18, 64, 38, 0.16);
            --radius-xl:24px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: #f4faf6;
            color: var(--ink);
            overflow-x: clip;
        }

        .login-page {
            position: relative;
            padding: 100px 0 90px;
            overflow: hidden;
        }

        .login-page::before,
        .login-page::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
        }

        .login-page::before {
            width: 520px;
            height: 520px;
            top: -180px;
            left: -120px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.18) 0%, transparent 72%);
        }

        .login-page::after {
            width: 420px;
            height: 420px;
            right: -90px;
            bottom: -120px;
            background: radial-gradient(circle, rgba(229, 158, 32, 0.10) 0%, transparent 72%);
        }

        .login-wrap {
            position: relative;
            z-index: 2;
        }

        .login-box {
            background: var(--card);
            border: 1px solid rgba(255, 255, 255, 0.92);
            border-radius: 34px;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            position: relative;
        }

        .login-left {
            min-height: 100%;
            height: 100%;
            padding: 48px 42px;
            background: linear-gradient(135deg, rgba(26, 92, 58, 0.72) 0%, rgba(45, 138, 86, 0.58) 100%),
                url('{{ asset("Website/assets/images/169840.jpg") }}') center center/cover no-repeat;
            color: #fff;
            position: relative;
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .login-left-content {
            position: relative;
            z-index: 2;
            max-width: 460px;
        }

        .login-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 9px 18px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.18);
            color: #fff;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 22px;
        }

        .login-left h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(34px, 4vw, 56px);
            line-height: 1.08;
            font-weight: 900;
            margin-bottom: 16px;
            color: #fff;
        }

        .login-left h2 span {
            color: #ffd27d;
            font-style: italic;
        }

        .login-left p {
            font-size: 16px;
            line-height: 1.9;
            color: rgba(255, 255, 255, 0.84);
            margin-bottom: 26px;
        }

        .login-highlights {
            display: grid;
            gap: 12px;
        }

        .login-highlight {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 16px;
            background: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.12);
        }

        .login-highlight i {
            color: #e29c1f;
            margin-top: 3px;
        }

        .login-highlight span {
            font-size: 14px;
            line-height: 1.7;
            color: #3a3a3a;
        }

        .login-right {
            padding: 42px 36px;
            background: linear-gradient(180deg, rgba(238, 248, 241, 0.55) 0%, rgba(255, 255, 255, 0.98) 100%);
            min-height: 100%;
        }

        .brand-mini {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 22px;
        }

        .brand-leaf {
            width: 48px;
            height: 48px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 18px;
            box-shadow: 0 12px 24px rgba(229, 158, 32, 0.22);
            flex-shrink: 0;
        }

        .brand-mini h5 {
            margin: 0;
            font-size: 18px;
            font-weight: 800;
            color: var(--ink);
        }

        .brand-mini span {
            display: block;
            font-size: 13px;
            color: var(--muted);
            margin-top: 2px;
        }

        .login-title {
            font-family: 'Playfair Display', serif;
            font-size: 34px;
            line-height: 1.15;
            font-weight: 900;
            color: var(--ink);
            margin-bottom: 8px;
        }

        .login-subtitle {
            color: var(--muted);
            font-size: 15px;
            line-height: 1.8;
            margin-bottom: 26px;
        }

        .login-step {
            padding: 18px 18px 14px;
            border: 1px solid rgba(78, 184, 122, 0.16);
            background: #fff;
            border-radius: 22px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 18px;
        }

        .step-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            font-weight: 600;
            color: var(--g2);
            margin-bottom: 18px;
        }

        .step-title .step-no {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            flex-shrink: 0;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 700;
            color: var(--ink);
        }

        .input-wrap {
            position: relative;
        }

        .input-wrap>i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--g2);
            font-size: 14px;
            z-index: 2;
        }

        .form-control {
            width: 100%;
            height: 54px;
            border-radius: 14px;
            border: 1px solid rgba(78, 184, 122, 0.18);
            background: #fff;
            padding: 0 16px 0 44px;
            font-size: 14.5px;
            color: var(--ink);
            outline: none;
            transition: .25s ease;
            box-shadow: none;
        }

        .form-control:focus {
            border-color: rgba(45, 138, 86, 0.42);
            box-shadow: 0 0 0 4px rgba(78, 184, 122, 0.10);
        }

        .otp-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }

        .otp-link {
            font-size: 14px;
            font-weight: 600;
            color: var(--a2);
            text-decoration: none;
        }

        .otp-link:hover {
            color: var(--a2);
            text-decoration: underline;
        }

        .login-btn {
            width: 100%;
            height: 56px;
            border: none;
            border-radius: 16px;
            background: #e29c1f;
            color: #fff;
            font-size: 15px;
            font-weight: 700;
            box-shadow: 0 14px 34px rgba(229, 158, 32, 0.24);
            transition: .3s ease;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 18px 40px rgba(229, 158, 32, 0.32);
        }

        .verify-btn {
            margin-top: 6px;
        }

        .login-text {
            margin-top: 18px;
            text-align: center;
            font-size: 14px;
            color: var(--muted);
        }

        .login-text a {
            color: var(--g2);
            font-weight: 700;
            text-decoration: none;
        }

        .login-text a:hover {
            text-decoration: underline;
        }

        .helper-note {
            margin-top: 10px;
            text-align: center;
            font-size: 12.5px;
            color: var(--muted);
        }

        @media (max-width: 991px) {
            .login-left {
                padding: 34px 28px;
            }

            .login-right {
                padding: 34px 26px;
            }
        }

        @media (max-width: 767px) {
            .login-page {
                padding: 30px 0 60px;
            }

            .login-box {
                border-radius: 24px;
            }

            .login-left,
            .login-right {
                padding: 24px 18px;
            }

            .login-left h2 {
                font-size: 34px;
            }

            .login-title {
                font-size: 28px;
            }

            .login-step {
                padding: 16px 14px 12px;
                border-radius: 18px;
            }
        }
    </style>

    <style>
        .ab-page {
            position: relative;
            z-index: 2;
        }

        img {
            display: block;
        }

        a {
            text-decoration: none;
        }

        .ab-page {
            position: relative;
            z-index: 2;
        }

        .ab-wrap {
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 24px;
            margin-top: 30px;
        }

        .ab-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .ab-bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(4px);
        }

        .ab-bg-blob:nth-child(1) {
            width: 680px;
            height: 680px;
            top: -230px;
            left: -180px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.18) 0%, transparent 70%);
        }

        .ab-bg-blob:nth-child(2) {
            width: 520px;
            height: 520px;
            right: -120px;
            bottom: -120px;
            background: radial-gradient(circle, rgba(229, 158, 32, 0.10) 0%, transparent 72%);
        }

        .ab-bg-blob:nth-child(3) {
            width: 360px;
            height: 360px;
            top: 38%;
            left: 56%;
            background: radial-gradient(circle, rgba(168, 230, 191, 0.16) 0%, transparent 72%);
        }

        .ab-bg-dots {
            position: absolute;
            inset: 0;
            opacity: .45;
            background-image: radial-gradient(circle, rgba(78, 184, 122, 0.10) 1.4px, transparent 1.4px);
            background-size: 34px 34px;
        }

        .ab-breadcrumb {
            padding: 26px 0 10px;
        }

        .ab-breadcrumb-box {
            background: var(--card);
            border: 1px solid rgba(255, 255, 255, 0.9);
            box-shadow: var(--shadow-sm);
            border-radius: 18px;
            padding: 16px 22px;
            color: var(--muted);
            font-size: 14px;
        }

        .ab-breadcrumb-box a {
            color: var(--g2);
            font-weight: 600;
        }

        .ab-card {
            background: var(--card);
            border: 1px solid rgba(255, 255, 255, 0.92);
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
        }



        .ab-section {
            padding: 42px 0 0;
        }

        .ab-section-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2.4px;
            text-transform: uppercase;
            color: var(--g2);
            margin-bottom: 12px;
        }

        .ab-center-head {
            text-align: center;
            margin-bottom: 28px;
        }

        .ab-center-head h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 50px);
            line-height: 1.14;
            font-weight: 900;
            color: var(--ink);
            margin-bottom: 12px;
        }

        .ab-center-head p {
            max-width: 760px;
            margin: 0 auto;
            font-size: 15.5px;
            line-height: 1.85;
            color: var(--muted);
        }

        .btn-primary-theme,
        .btn-outline-theme {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 15px 28px;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 700;
            transition: .3s ease;
        }

        .btn-primary-theme {
            background: #2d8a56;
            color: #fff;
            border: none;
            box-shadow: 0 14px 34px rgba(229, 158, 32, 0.24);
        }

        .btn-primary-theme:hover {
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 18px 40px rgba(229, 158, 32, 0.32);
        }

        .btn-outline-theme {
            background: #fff;
            color: var(--a2);
            border: 2px solid rgba(229, 158, 32, 0.28);
        }

        .btn-outline-theme:hover {
            background: var(--a3);
            color: var(--a2);
            transform: translateY(-2px);
        }

        /* HERO */
        .ab-hero {
            padding: 20px 0 12px;
            padding-top: 50px;
        }

        .ab-hero-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.08fr) minmax(340px, .92fr);
            gap: 28px;
            align-items: stretch;
        }

        .ab-hero-left,
        .ab-hero-right {
            min-width: 0;
        }

        .ab-hero-left {
            padding: 46px 42px;
        }

        .ab-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(78, 184, 122, 0.12);
            color: var(--g2);
            border: 1px solid rgba(78, 184, 122, 0.22);
            padding: 9px 18px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 22px;
        }

        .ab-hero-left h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(40px, 5vw, 70px);
            line-height: 1.02;
            font-weight: 900;
            margin-bottom: 18px;
            max-width: 700px;
        }

        .ab-hero-left h1 em {
            color: var(--g2);
            font-style: italic;
        }

        .ab-hero-left p {
            max-width: 720px;
            font-size: 16px;
            line-height: 1.9;
            color: var(--muted);
            margin-bottom: 24px;
        }

        .ab-hero-points {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 26px;
        }

        .ab-chip {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: #fff;
            color: var(--g1);
            border: 1px solid rgba(78, 184, 122, 0.16);
            border-radius: 14px;
            box-shadow: var(--shadow-sm);
            font-size: 14px;
            font-weight: 600;
        }

        .ab-chip i {
            color: #0e7e48;
        }

        .ab-hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
        }

        .ab-hero-right {
            padding: 24px;
            background: linear-gradient(180deg, rgba(238, 248, 241, 0.96) 0%, rgba(255, 255, 255, 0.98) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .ab-hero-visual {
            width: 100%;
            max-width: 430px;
            position: relative;
        }

        .ab-hero-image {
            border-radius: 30px;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            position: relative;
        }

        .ab-hero-image img {
            width: 100%;
            height: 520px;
            object-fit: cover;
        }

        .ab-hero-image::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(16, 60, 35, 0.50) 0%, transparent 56%);
        }

        .ab-hero-label {
            position: absolute;
            left: 22px;
            bottom: 20px;
            z-index: 2;
            color: #fff;
        }

        .ab-hero-label span {
            display: block;
            font-size: 11px;
            letter-spacing: 2px;
            text-transform: uppercase;
            opacity: .84;
            margin-bottom: 5px;
        }

        .ab-hero-label strong {
            font-family: 'Playfair Display', serif;
            font-size: 25px;
            line-height: 1.18;
            font-weight: 800;
        }

        .ab-floating-card {
            position: absolute;
            background: #fff;
            border-radius: 18px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255, 255, 255, 0.95);
        }

        .ab-floating-thumb {
            top: 20px;
            right: -10px;
            width: 110px;
            height: 110px;
            overflow: hidden;
            padding: 6px;
        }

        .ab-floating-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 14px;
        }

        .ab-floating-badge {
            left: -6px;
            bottom: 28px;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
        }

        .ab-floating-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--a1), var(--a2));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .ab-floating-badge .lbl {
            font-size: 11px;
            color: var(--muted);
            font-weight: 500;
        }

        .ab-floating-badge .val {
            font-size: 18px;
            line-height: 1;
            margin-top: 2px;
            font-weight: 800;
            color: var(--ink);
        }

        /* STATS */
        .ab-stats {
            padding: 18px 0 0;
        }

        .ab-stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
        }

        .ab-stat-box {
            padding: 28px 22px;
            text-align: center;
        }

        .ab-stat-num {
            font-family: 'Playfair Display', serif;
            font-size: 44px;
            line-height: 1;
            font-weight: 900;
            color: #0e7e48;
            margin-bottom: 8px;
        }

        .ab-stat-num span {
            color: var(--a1);
        }

        .ab-stat-label {
            font-size: 14px;
            color: var(--muted);
            font-weight: 600;
        }

        /* STORY */
        .ab-story-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 28px;
            align-items: center;
        }

        .ab-story-text {
            padding: 36px 32px;
        }

        .ab-story-text h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 46px);
            line-height: 1.15;
            font-weight: 900;
            margin-bottom: 14px;
        }

        .ab-story-text p {
            font-size: 15.5px;
            line-height: 1.88;
            color: var(--muted);
        }

        .ab-story-text p+p {
            margin-top: 14px;
        }

        .ab-story-points {
            list-style: none;
            margin-top: 24px;
            display: grid;
            gap: 14px;
        }

        .ab-story-points li {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            color: var(--muted);
            line-height: 1.75;
            font-size: 14.5px;

        }

        .ab-story-points li i {
            width: 28px;
            height: 28px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            margin-top: 2px;
        }

        .ab-story-visual {
            padding: 22px;
        }

        .ab-story-stack {
            position: relative;
            min-height: 500px;
        }

        .ab-story-main {
            position: absolute;
            right: 0;
            top: 0;
            width: 80%;
            height: 400px;
            border-radius: 28px;
            overflow: hidden;
            box-shadow: var(--shadow-md);
        }

        .ab-story-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .ab-story-sm {
            position: absolute;
            left: 0;
            bottom: 10px;
            width: 52%;
            height: 200px;
            border-radius: 22px;
            overflow: hidden;
            border: 4px solid #fff;
            box-shadow: var(--shadow-md);
        }

        .ab-story-sm img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .ab-story-badge {
            position: absolute;
            right: -2px;
            bottom: 132px;
            background: linear-gradient(135deg, var(--a1), var(--a2));
            color: #fff;
            border-radius: 18px;
            text-align: center;
            padding: 18px 22px;
            box-shadow: 0 18px 40px rgba(229, 158, 32, 0.28);
        }

        .ab-story-badge .num {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            line-height: 1;
            font-weight: 900;
        }

        .ab-story-badge .lbl {
            font-size: 12px;
            margin-top: 4px;
            opacity: .9;
        }

        /* PRODUCTS */
        .ab-products-wrap {
            padding: 30px 28px;
        }

        .ab-prod-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
        }

        .ab-prod-card {
            background: #fff;
            border-radius: 24px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.9);
            box-shadow: var(--shadow-sm);
            transition: .35s ease;
        }

        .ab-prod-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-md);
        }

        .ab-prod-img-wrap {
            height: 220px;
            position: relative;
            overflow: hidden;
        }

        .ab-prod-img-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: .45s ease;
        }

        .ab-prod-card:hover .ab-prod-img-wrap img {
            transform: scale(1.06);
        }

        .ab-prod-img-wrap::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(26, 92, 58, 0.34) 0%, transparent 54%);
        }

        .ab-prod-tag {
            position: absolute;
            top: 14px;
            left: 14px;
            z-index: 2;
            background: linear-gradient(135deg, var(--g1), var(--g2));
            color: #fff;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .ab-prod-body {
            padding: 20px 18px 22px;
        }

        .ab-prod-body h5 {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .ab-prod-body p {
            font-size: 14px;
            line-height: 1.78;
            color: var(--muted);
            margin-bottom: 16px;
        }

        .ab-prod-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .ab-prod-price {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            font-weight: 900;
            color: var(--g2);
        }

        .ab-prod-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--a1), var(--a2));
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            transition: .3s ease;
        }

        .ab-prod-btn:hover {
            color: #fff;
            transform: translateY(-2px);
        }

        /* BANNER */
        .ab-banner-card {
            min-height: 360px;
            padding: 0;
        }

        .ab-banner-card img {
            width: 100%;
            height: 360px;
            object-fit: cover;
        }

        .ab-banner-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(20, 77, 45, 0.82) 0%, rgba(20, 77, 45, 0.44) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            flex-direction: column;
            padding: 24px;
        }

        .ab-banner-overlay h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 5vw, 56px);
            line-height: 1.1;
            font-weight: 900;
            color: #fff;
            margin-bottom: 12px;
        }

        .ab-banner-overlay p {
            max-width: 640px;
            color: rgba(255, 255, 255, 0.88);
            font-size: 16px;
            line-height: 1.85;
            margin-bottom: 26px;
        }

        /* MVV */
        .ab-mvv-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        .ab-mvv-card {
            padding: 34px 28px;
        }

        .ab-mvv-icon {
            width: 64px;
            height: 64px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 24px;
            margin-bottom: 20px;
            background: linear-gradient(135deg, var(--g1), var(--g2));
            box-shadow: 0 14px 28px rgba(26, 92, 58, 0.20);
        }

        .ab-mvv-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 12px;
        }

        .ab-mvv-card p {
            font-size: 15px;
            line-height: 1.82;
            color: var(--muted);
        }

        /* VALUES */
        .ab-values-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
        }

        .ab-val-card {
            padding: 32px 20px;
            text-align: center;
        }

        .ab-val-num {
            position: absolute;
            top: 10px;
            right: 14px;
            font-family: 'Playfair Display', serif;
            font-size: 66px;
            line-height: 1;
            font-weight: 900;
            color: rgba(45, 138, 86, 0.08);
        }

        .ab-val-icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            margin: 0 auto 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 22px;
            background: linear-gradient(135deg, var(--a1), var(--a2));
            box-shadow: 0 12px 24px rgba(229, 158, 32, 0.22);
        }

        .ab-val-card h5 {
            font-size: 17px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .ab-val-card p {
            font-size: 14px;
            line-height: 1.75;
            color: var(--muted);
        }

        /* TEAM */
        .ab-team-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        .ab-member {
            padding: 0;
        }

        .ab-member-top {
            padding: 36px 24px 24px;
            text-align: center;
            background: linear-gradient(180deg, var(--g5) 0%, #ffffff 100%);
            position: relative;
        }

        .ab-member-top::after {
            content: '';
            position: absolute;
            left: 0;
            right: 0;
            bottom: -1px;
            height: 28px;
            background: #fff;
            clip-path: ellipse(56% 100% at 50% 100%);
        }

        .ab-avatar {
            width: 102px;
            height: 102px;
            border-radius: 50%;
            margin: 0 auto 16px;
            border: 4px solid #fff;
            box-shadow: 0 12px 26px rgba(26, 92, 58, 0.18);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            font-size: 34px;
            font-family: 'Playfair Display', serif;
            font-weight: 800;
            position: relative;
            z-index: 1;
        }

        .ab-member-body {
            padding: 20px 24px 28px;
            text-align: center;
        }

        .ab-member-body h5 {
            font-family: 'Playfair Display', serif;
            font-size: 21px;
            font-weight: 800;
            margin-bottom: 6px;
        }

        .ab-member-role {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 999px;
            background: var(--a3);
            color: var(--a2);
            border: 1px solid rgba(229, 158, 32, 0.20);
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .ab-member-bio {
            font-size: 14px;
            color: var(--muted);
            line-height: 1.78;
            margin-bottom: 20px;
        }

        .ab-member-socials {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .ab-soc {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
            border: 1px solid rgba(78, 184, 122, 0.16);
            color: var(--g2);
            font-size: 14px;
            transition: .3s ease;
        }

        .ab-soc:hover {
            transform: translateY(-3px);
            background: var(--g2);
            color: #fff;
        }

        /* WHY */
        .ab-why-block {
            background: linear-gradient(135deg, var(--g1) 0%, #1f6f42 50%, var(--g2) 100%);
            color: #fff;
            padding: 34px 28px;
        }

        .ab-why-block::after {
            content: '';
            position: absolute;
            inset: 0;
            background: repeating-linear-gradient(45deg,
                    rgba(255, 255, 255, 0.03) 0,
                    rgba(255, 255, 255, 0.03) 1px,
                    transparent 1px,
                    transparent 22px);
            pointer-events: none;
        }

        .ab-why-inner {
            position: relative;
            z-index: 2;
        }

        .ab-why-head {
            text-align: center;
            margin-bottom: 26px;
        }

        .ab-why-head .ab-section-tag {
            color: rgba(255, 255, 255, 0.82);
            justify-content: center;
        }

        .ab-why-head .ab-section-tag::before {
            background: rgba(255, 255, 255, 0.45);
        }

        .ab-why-head h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 48px);
            font-weight: 900;
            line-height: 1.14;
        }

        .ab-why-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        .ab-why-card {
            background: rgba(255, 255, 255, 0.10);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 22px;
            padding: 28px 24px;
            transition: .35s ease;
        }

        .ab-why-card:hover {
            transform: translateY(-8px);
            background: rgba(255, 255, 255, 0.16);
        }

        .ab-why-num {
            font-family: 'Playfair Display', serif;
            font-size: 46px;
            line-height: 1;
            font-weight: 900;
            color: #ffffff;
            margin-bottom: 14px;
        }

        .ab-why-card h4 {
            font-size: 18px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .ab-why-card p {
            font-size: 14px;
            line-height: 1.75;
            color: rgba(255, 255, 255, 0.86);
        }

        /* CTA */
        .ab-cta {
            padding: 42px 0 90px;
        }

        .ab-cta-box {
            padding: 56px 36px;
            text-align: center;
        }

        .ab-cta-box h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 52px);
            line-height: 1.12;
            font-weight: 900;
            margin-bottom: 14px;
        }

        .ab-cta-box h2 span {
            color: var(--g2);
        }

        .ab-cta-box p {
            max-width: 760px;
            margin: 0 auto 28px;
            font-size: 15.5px;
            line-height: 1.85;
            color: var(--muted);
        }

        .ab-cta-btns {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 14px;
        }

        /* RESPONSIVE */
        @media (max-width: 1199px) {

            .ab-hero-grid,
            .ab-story-grid,
            .ab-mvv-grid {
                grid-template-columns: 1fr;
            }

            .ab-hero-right {
                order: -1;
            }

            .ab-hero-image img {
                height: 460px;
            }
        }

        @media (max-width: 1100px) {
            .ab-stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .ab-prod-grid,
            .ab-values-grid,
            .ab-team-grid,
            .ab-why-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 767px) {
            .ab-wrap {
                padding: 0 16px;
            }

            .ab-hero {
                padding: 0px 0 12px;
            }

            .ab-card {
                border-radius: 24px;
            }

            .ab-hero-left,
            .ab-hero-right,
            .ab-products-wrap,
            .ab-why-block,
            .ab-cta-box {
                padding: 24px 20px;
            }

            .ab-breadcrumb {
                padding: 22px 0 8px;
            }

            .ab-hero-left h1 {
                font-size: 42px;
                line-height: 1.08;
            }

            .ab-hero-actions,
            .ab-cta-btns {
                flex-direction: column;
            }

            .btn-primary-theme,
            .btn-outline-theme {
                width: 100%;
            }

            .ab-stats-grid,
            .ab-prod-grid,
            .ab-values-grid,
            .ab-team-grid,
            .ab-why-grid {
                grid-template-columns: 1fr;
            }

            .ab-hero-image img {
                height: 320px;
            }

            .ab-floating-thumb {
                display: none;
            }

            .ab-floating-badge {
                position: static;
                margin-top: 14px;
                width: 100%;
                justify-content: flex-start;
            }

            .ab-story-stack {
                min-height: 360px;
            }

            .ab-story-main {
                width: 82%;
                height: 280px;
            }

            .ab-story-sm {
                width: 56%;
                height: 140px;
            }

            .ab-story-badge {
                right: 0;
                bottom: 90px;
                padding: 14px 16px;
            }

            .ab-banner-card img {
                height: 300px;
            }

        }



        .ab-hero-right {
            padding: 0;
            background: transparent;
            box-shadow: none;
            border: none;
        }

        .ab-hero-visual {
            position: relative;
            min-height: 540px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .ab-main-frame {
            position: relative;
            width: 100%;
            max-width: 480px;
            height: 520px;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.12);
            background: #fff;
        }

        .ab-main-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .ab-overlay-shade {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top,
                    rgba(0, 0, 0, 0.55) 0%,
                    rgba(0, 0, 0, 0.18) 35%,
                    rgba(0, 0, 0, 0.05) 100%);
        }

        .ab-hero-label {
            position: absolute;
            left: 24px;
            right: 24px;
            bottom: 120px;
            background: rgba(255, 255, 255, 0.14);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.22);
            border-radius: 20px;
            padding: 18px 18px;
            color: #fff;
        }

        .ab-hero-label span {
            display: inline-block;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            background: rgba(229, 158, 32, 0.95);
            color: #fff;
            padding: 6px 12px;
            border-radius: 30px;
            margin-bottom: 10px;
        }

        .ab-hero-label strong {
            display: block;
            font-size: 24px;
            line-height: 1.3;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .ab-hero-label p {
            margin: 0;
            font-size: 14px;
            line-height: 1.6;
            color: rgba(255, 255, 255, 0.9);
        }

        .ab-mini-card {
            position: absolute;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.10);
            padding: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 3;
        }

        .ab-product-card {
            left: -60px;
            bottom: -10px;
            width: 245px;
        }

        .ab-badge-card {
            right: -60px;
            top: 42px;
            width: 220px;
        }

        .ab-mini-img {
            width: 68px;
            height: 68px;
            border-radius: 16px;
            overflow: hidden;
            flex-shrink: 0;
            background: #f7f7f7;
        }

        .ab-mini-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .ab-badge-icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            background: linear-gradient(135deg, #e59e20, #c98510);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            flex-shrink: 0;
        }

        .ab-mini-content small {
            display: block;
            font-size: 12px;
            color: #7a7a7a;
            margin-bottom: 4px;
            font-weight: 500;
        }

        .ab-mini-content h4 {
            margin: 0 0 4px;
            font-size: 18px;
            font-weight: 700;
            color: #1f1f1f;
            line-height: 1.2;
        }

        .ab-mini-content p {
            margin: 0;
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }

        @media (max-width: 991px) {
            .ab-hero-visual {
                min-height: auto;
                padding-top: 50px;
            }

            .ab-main-frame {
                max-width: 100%;
                height: 460px;
            }

            .ab-product-card {
                left: 10px;
                bottom: -90px;
                width: 220px;
            }

            .ab-badge-card {
                right: 10px;
                top: 15px;
                width: 200px;
            }
        }

        @media (max-width: 575px) {
            .ab-main-frame {
                height: 390px;
                border-radius: 22px;
            }

            .ab-hero-label {
                left: 16px;
                right: 16px;
                bottom: 16px;
                padding: 14px;
            }

            .ab-hero-label strong {
                font-size: 20px;
            }

            .ab-hero-label p {
                font-size: 13px;
            }

            .ab-mini-card {
                position: static;
                width: 100%;
                margin-top: 14px;
            }

            .ab-hero-visual {
                display: block;
            }
        }
    </style>

    <style>
        :root {
            --nature-1: #1f6b45;
            --nature-2: #2f8f5b;
            --nature-3: #79c98c;
            --nature-4: #eaf7ee;
            --nature-5: #f7fcf8;
            --text-dark: #153224;
            --text-muted: #5e7568;
            --white: #ffffff;
            --danger: #dc3545;
            --warning: #f4a825;
            --line: #dceadf;
            --shadow: 0 20px 60px rgba(21, 50, 36, 0.10);
            --radius: 24px;
        }

        body {
            background: linear-gradient(180deg, #f7fcf8 0%, #eef8f1 100%);
        }

        .track-page {
            position: relative;
            overflow: hidden;
            min-height: 100vh;
            padding: 70px 0 90px;
            background:
                radial-gradient(circle at top left, rgba(121, 201, 140, 0.18), transparent 28%),
                radial-gradient(circle at bottom right, rgba(47, 143, 91, 0.15), transparent 24%),
                linear-gradient(135deg, #f6fbf7 0%, #edf8f0 45%, #f9fdf9 100%);
        }

        .track-page::before,
        .track-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            filter: blur(10px);
            z-index: 0;
        }

        .track-page::before {
            width: 320px;
            height: 320px;
            top: -90px;
            left: -80px;
            background: rgba(121, 201, 140, 0.18);
        }

        .track-page::after {
            width: 260px;
            height: 260px;
            bottom: -70px;
            right: -50px;
            background: rgba(31, 107, 69, 0.10);
        }

        .track-wrap {
            position: relative;
            z-index: 2;
        }

        .track-top {
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 28px;
        }

        .track-titlebox small {
            display: inline-block;
            color: var(--nature-2);
            font-weight: 700;
            letter-spacing: .4px;
            margin-bottom: 10px;
        }

        .track-titlebox h1 {
            margin: 0;
            color: var(--text-dark);
            font-size: 42px;
            font-weight: 800;
        }

        .track-titlebox p {
            margin: 10px 0 0;
            color: var(--text-muted);
            font-size: 15px;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 18px;
            border-radius: 999px;
            text-decoration: none;
            font-weight: 700;
            color: var(--nature-1);
            background: #fff;
            border: 1px solid #d8e8dc;
            transition: all .3s ease;
            box-shadow: 0 10px 24px rgba(31, 107, 69, 0.06);
        }

        .back-btn:hover {
            color: #fff;
            background: var(--nature-1);
            border-color: var(--nature-1);
        }

        .info-card,
        .map-card,
        .timeline-card,
        .side-card,
        .product-card {
            background: rgba(255, 255, 255, 0.86);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.7);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .info-card,
        .timeline-card,
        .map-card,
        .product-card {
            padding: 24px;
        }

        .side-card {
            padding: 22px;
            position: sticky;
            top: 110px;
        }

        .hero-status {
            display: grid;
            grid-template-columns: 1.2fr .8fr;
            gap: 22px;
        }

        .status-panel {
            padding: 26px;
            border-radius: 22px;
            background: linear-gradient(135deg, rgba(31, 107, 69, 0.95), rgba(47, 143, 91, 0.88));
            color: #fff;
            position: relative;
            overflow: hidden;
        }

        .status-panel::before {
            content: "";
            position: absolute;
            width: 180px;
            height: 180px;
            right: -40px;
            top: -40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .status-panel small {
            display: inline-block;
            font-size: 13px;
            font-weight: 700;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.14);
            margin-bottom: 14px;
        }

        .status-panel h2 {
            margin: 0 0 10px;
            font-size: 34px;
            font-weight: 800;
            position: relative;
            z-index: 2;
        }

        .status-panel p {
            margin: 0;
            font-size: 15px;
            color: rgba(255, 255, 255, 0.92);
            position: relative;
            z-index: 2;
        }

        .eta-panel {
            padding: 26px;
            border-radius: 22px;
            background: linear-gradient(180deg, #ffffff, #f6fbf7);
            border: 1px solid #dceadf;
        }

        .eta-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 18px;
        }

        .eta-top h4 {
            margin: 0;
            color: var(--text-dark);
            font-size: 20px;
            font-weight: 800;
        }

        .eta-badge {
            font-size: 12px;
            font-weight: 700;
            color: var(--nature-1);
            background: var(--nature-4);
            border: 1px solid #dbeee0;
            padding: 8px 12px;
            border-radius: 999px;
        }

        .eta-time {
            font-size: 38px;
            line-height: 1;
            font-weight: 800;
            color: var(--nature-1);
            margin-bottom: 10px;
        }

        .eta-panel p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .grid-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-top: 22px;
        }

        .stat-box {
            padding: 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
            text-align: center;
        }

        .stat-box i {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, rgba(31, 107, 69, 0.10), rgba(47, 143, 91, 0.15));
            color: var(--nature-1);
            font-size: 18px;
            margin-bottom: 12px;
        }

        .stat-box h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 16px;
            font-weight: 800;
        }

        .stat-box p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .section-head {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 12px;
            margin-bottom: 40px;
        }

        .section-head h3 {
            margin: 0;
            color: var(--text-dark);
            font-size: 32px;
            font-weight: 800;
        }

        .section-head span {
            font-size: 13px;
            font-weight: 700;
            color: var(--nature-1);
            background: var(--nature-4);
            border: 1px solid #dbeee0;
            padding: 8px 12px;
            border-radius: 999px;
        }

        .route-box {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 16px;
            align-items: center;
            margin-bottom: 18px;
        }

        .route-point {
            padding: 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .route-point small {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .route-point h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 18px;
            font-weight: 800;
        }

        .route-point p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .route-arrow {
            width: 58px;
            height: 58px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--nature-1), var(--nature-2));
            color: #fff;
            font-size: 20px;
            box-shadow: 0 14px 30px rgba(31, 107, 69, 0.16);
        }

        .fake-map {
            min-height: 260px;
            border-radius: 22px;
            position: relative;
            overflow: hidden;
            border: 1px solid #dceadf;
            background: linear-gradient(0deg, rgba(255, 255, 255, .75), rgba(255, 255, 255, .75)),
                url("{{ asset('Website/assets/images/hb4.jpg') }}") center/cover no-repeat;
        }

        .fake-map::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                linear-gradient(90deg, rgba(31, 107, 69, 0.10) 1px, transparent 1px),
                linear-gradient(rgba(31, 107, 69, 0.10) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: .25;
        }

        .map-route {
            position: absolute;
            left: 12%;
            top: 65%;
            width: 70%;
            height: 6px;
            background: repeating-linear-gradient(90deg,
                    var(--nature-1),
                    var(--nature-1) 20px,
                    rgba(31, 107, 69, .3) 20px,
                    rgba(31, 107, 69, .3) 32px);
            border-radius: 999px;
            transform: rotate(-18deg);
            box-shadow: 0 8px 25px rgba(31, 107, 69, .15);
        }

        .map-pin {
            position: absolute;
            width: 58px;
            height: 58px;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 20px;
            box-shadow: 0 14px 30px rgba(31, 107, 69, .18);
        }

        .map-pin.start {
            left: 10%;
            top: 60%;
            background: linear-gradient(135deg, #1f6b45, #2f8f5b);
        }

        .map-pin.middle {
            left: 46%;
            top: 40%;
            background: linear-gradient(135deg, #e8a525, #f4bd43);
        }

        .map-pin.end {
            right: 12%;
            top: 22%;
            background: linear-gradient(135deg, #2f8f5b, #79c98c);
        }

        .map-label {
            position: absolute;
            background: #fff;
            border: 1px solid #dceadf;
            border-radius: 14px;
            padding: 8px 12px;
            font-size: 13px;
            font-weight: 700;
            color: var(--text-dark);
            box-shadow: 0 10px 24px rgba(31, 107, 69, .08);
        }

        .map-label.label-1 {
            left: 8%;
            top: 78%;
        }

        .map-label.label-2 {
            left: 42%;
            top: 57%;
        }

        .map-label.label-3 {
            right: 8%;
            top: 12%;
        }

        .timeline {
            position: relative;
            margin-left: 12px;
            padding-left: 26px;
        }

        .timeline::before {
            content: "";
            position: absolute;
            left: 7px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(180deg, var(--nature-2), rgba(47, 143, 91, .15));
            border-radius: 999px;
        }

        .timeline-item {
            position: relative;
            padding-bottom: 24px;
        }

        .timeline-item:last-child {
            padding-bottom: 0;
        }

        .timeline-dot {
            position: absolute;
            left: -26px;
            top: 2px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #d8ebe0;
            border: 4px solid #fff;
            box-shadow: 0 0 0 2px #d8ebe0;
        }

        .timeline-item.active .timeline-dot {
            background: var(--nature-1);
            box-shadow: 0 0 0 2px rgba(31, 107, 69, .3);
        }

        .timeline-item.current .timeline-dot {
            background: var(--warning);
            box-shadow: 0 0 0 2px rgba(244, 168, 37, .35);
        }

        .timeline-content {
            padding: 16px 18px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .timeline-content small {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .timeline-content h5 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 17px;
            font-weight: 800;
        }

        .timeline-content p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .delivery-person {
            display: flex;
            gap: 14px;
            align-items: center;
            margin-bottom: 18px;
            padding: 16px;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #dceadf;
        }

        .delivery-avatar {
            width: 64px;
            height: 64px;
            border-radius: 18px;
            background: linear-gradient(135deg, var(--nature-1), var(--nature-3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 800;
        }

        .delivery-person h5 {
            margin: 0 0 5px;
            color: var(--text-dark);
            font-size: 18px;
            font-weight: 800;
        }

        .delivery-person p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .contact-btns {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 14px;
        }

        .contact-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            height: 48px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 800;
            transition: all .3s ease;
        }

        .call-btn {
            background: #fff;
            color: var(--nature-1);
            border: 1px solid var(--nature-1);
        }

        .call-btn:hover {
            background: var(--nature-1);
            color: #fff;
        }

        .support-btn {
            background: linear-gradient(135deg, var(--nature-1), var(--nature-2));
            color: #fff;
            border: 1px solid transparent;
            box-shadow: 0 12px 26px rgba(31, 107, 69, .16);
        }

        .support-btn:hover {
            transform: translateY(-2px);
            color: #fff;
        }

        .detail-list {
            display: grid;
            gap: 12px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid var(--line);
            font-size: 14px;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-row span {
            color: var(--text-muted);
        }

        .detail-row strong {
            color: var(--text-dark);
            text-align: right;
        }

        .mini-product {
            display: flex;
            gap: 12px;
            padding: 14px 0;
            border-bottom: 1px solid var(--line);
        }

        .mini-product:last-child {
            border-bottom: none;
        }

        .mini-product img {
            width: 64px;
            height: 64px;
            border-radius: 14px;
            object-fit: cover;
            border: 1px solid #e3efe6;
            background: #f7fcf8;
        }

        .mini-product h6 {
            margin: 0 0 6px;
            color: var(--text-dark);
            font-size: 15px;
            font-weight: 800;
        }

        .mini-product p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .help-note {
            margin-top: 18px;
            padding: 14px 16px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(121, 201, 140, 0.12), rgba(47, 143, 91, 0.08));
            color: var(--nature-1);
            font-size: 14px;
            font-weight: 700;
            border: 1px solid #dceee1;
        }

        @media (max-width: 1199px) {
            .grid-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 991px) {
            .hero-status {
                grid-template-columns: 1fr;
            }

            .side-card {
                position: static;
                margin-top: 24px;
            }

            .track-titlebox h1 {
                font-size: 34px;
            }
        }

        @media (max-width: 767px) {
            .track-titlebox h1 {
                font-size: 30px;
            }

            .info-card,
            .map-card,
            .timeline-card,
            .product-card,
            .side-card {
                padding: 18px;
            }

            .route-box {
                grid-template-columns: 1fr;
            }

            .route-arrow {
                margin: 0 auto;
                transform: rotate(90deg);
            }

            .grid-stats {
                grid-template-columns: 1fr;
            }

            .contact-btns {
                grid-template-columns: 1fr;
            }

            .eta-time {
                font-size: 32px;
            }
        }
    </style>
    <style>
        :root {
            --g1: #1a5c3a;
            --g2: #2d8a56;
            --g3: #4eb87a;
            --g4: #a8e6bf;
            --g5: #e8f8ee;
            --ink: #0f2a1a;
            --muted: #4a6a57;
            --white: #ffffff;
            --line: rgba(78, 184, 122, 0.18);
            --card-bg: rgba(255, 255, 255, 0.88);
            --shadow-soft: 0 8px 40px rgba(26, 92, 58, 0.10);
            --shadow-med: 0 20px 70px rgba(26, 92, 58, 0.15);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: #f0f9f3;
            color: var(--ink);
            overflow-x: clip;
        }

        .pp-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .pp-bg-blob {
            position: absolute;
            border-radius: 50%;
        }

        .pp-bg-blob:nth-child(1) {
            width: 700px;
            height: 700px;
            top: -220px;
            left: -180px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.20) 0%, transparent 70%);
            animation: blobDrift1 16s ease-in-out infinite alternate;
        }

        .pp-bg-blob:nth-child(2) {
            width: 500px;
            height: 500px;
            bottom: -160px;
            right: -120px;
            background: radial-gradient(circle, rgba(26, 92, 58, 0.13) 0%, transparent 70%);
            animation: blobDrift2 20s ease-in-out infinite alternate;
        }

        .pp-bg-blob:nth-child(3) {
            width: 350px;
            height: 350px;
            top: 42%;
            left: 58%;
            background: radial-gradient(circle, rgba(168, 230, 191, 0.16) 0%, transparent 70%);
            animation: blobDrift3 24s ease-in-out infinite alternate;
        }

        .pp-bg-dots {
            position: absolute;
            inset: 0;
            background-image: radial-gradient(circle, rgba(78, 184, 122, 0.14) 1.5px, transparent 1.5px);
            background-size: 38px 38px;
            opacity: 0.55;
        }

        @keyframes blobDrift1 {
            to {
                transform: translate(50px, 60px) scale(1.1);
            }
        }

        @keyframes blobDrift2 {
            to {
                transform: translate(-40px, -50px) scale(1.07);
            }
        }

        @keyframes blobDrift3 {
            to {
                transform: translate(25px, -35px);
            }
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(28px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }



        .pp-page {
            position: relative;
            z-index: 2;
        }

        .pp-wrap {
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .pp-hero {
            min-height: 72vh;
            display: grid;
            grid-template-columns: 1.05fr 0.95fr;
            align-items: center;
            gap: 60px;
            padding: 90px 24px 70px;
            max-width: 1340px;
            margin: 0 auto;
        }

        .pp-hero-left {
            animation: fadeUp 0.8s ease both;
        }

        .pp-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12.5px;
            font-weight: 600;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--g2);
            background: rgba(78, 184, 122, 0.12);
            border: 1px solid rgba(78, 184, 122, 0.28);
            padding: 6px 18px;
            border-radius: 100px;
            margin-bottom: 26px;
        }

        .pp-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(42px, 6vw, 74px);
            font-weight: 900;
            line-height: 1.08;
            color: var(--ink);
            margin-bottom: 22px;
        }

        .pp-hero h1 em {
            font-style: italic;
            color: var(--g2);
        }

        .pp-hero-desc {
            font-size: 17px;
            line-height: 1.8;
            color: var(--muted);
            max-width: 560px;
            margin-bottom: 34px;
        }

        .pp-hero-meta {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }

        .pp-meta-chip {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(78, 184, 122, 0.18);
            box-shadow: var(--shadow-soft);
            color: var(--g1);
            font-size: 14px;
            font-weight: 600;
        }

        .btn-primary-green {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 30px;
            border-radius: 14px;
            background: #e59e20;
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            cursor: pointer;
            box-shadow: 0 14px 40px rgba(26, 92, 58, 0.28);
            transition: all 0.35s ease;
        }

        .btn-primary-green:hover {
            transform: translateY(-3px);
            color: #fff;
            box-shadow: 0 20px 50px rgba(26, 92, 58, 0.35);
        }

        .btn-outline-green {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 30px;
            border-radius: 14px;
            background: transparent;
            color: var(--g1);
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: 2px solid rgba(26, 92, 58, 0.28);
            transition: all 0.35s ease;
        }

        .btn-outline-green:hover {
            background: rgba(26, 92, 58, 0.06);
            border-color: var(--g2);
            color: var(--g2);
            transform: translateY(-3px);
        }

        .pp-hero-right {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeUp 0.8s 0.2s ease both;
        }

        .pp-card-stack {
            position: relative;
            width: 100%;
            max-width: 470px;
            height: 480px;
        }

        .pp-main-card {
            position: absolute;
            inset: 20px 20px 60px 40px;
            border-radius: 30px;
            background: linear-gradient(160deg, rgba(255, 255, 255, 0.92), rgba(232, 248, 238, 0.95));
            box-shadow: 0 40px 90px rgba(26, 92, 58, 0.22);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.85);
            padding: 34px 30px;
        }

        .pp-main-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, var(--g1), var(--g3), var(--g4));
        }

        .pp-main-card-icon {
            width: 72px;
            height: 72px;
            border-radius: 20px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 28px;
            margin-bottom: 22px;
            box-shadow: 0 16px 36px rgba(26, 92, 58, 0.22);
        }

        .pp-main-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 14px;
            color: var(--ink);
        }

        .pp-main-card p {
            font-size: 15px;
            line-height: 1.8;
            color: var(--muted);
            margin-bottom: 22px;
        }

        .pp-mini-points {
            list-style: none;
            display: grid;
            gap: 12px;
        }

        .pp-mini-points li {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .pp-mini-points i {
            width: 24px;
            height: 24px;
            border-radius: 8px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            flex-shrink: 0;
            margin-top: 1px;
        }

        .pp-floating-box {
            position: absolute;
            background: #fff;
            border-radius: 18px;
            padding: 14px 18px;
            box-shadow: var(--shadow-med);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: float 5s ease-in-out infinite;
            border: 1px solid rgba(255, 255, 255, 0.9);
        }

        .pp-floating-box.one {
            top: 16px;
            right: -10px;
        }

        .pp-floating-box.two {
            bottom: 24px;
            left: 0;
            animation-delay: 1.6s;
        }

        .pp-floating-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: #e59e20;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        .pp-floating-text .lbl {
            font-size: 11px;
            color: var(--muted);
            font-weight: 500;
        }

        .pp-floating-text .val {
            font-size: 16px;
            color: var(--ink);
            font-weight: 800;
            line-height: 1.1;
        }

        .pp-highlights {
            padding: 0 0 40px;
        }

        .pp-highlight-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
            margin-top: -10px;
        }

        .pp-highlight-card {
            background: var(--card-bg);
            border-radius: 22px;
            padding: 26px 22px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.85);
            transition: transform 0.35s ease, box-shadow 0.35s ease;
        }

        .pp-highlight-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-med);
        }

        .pp-highlight-card i {
            width: 54px;
            height: 54px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 16px;
            box-shadow: 0 10px 24px rgba(26, 92, 58, 0.18);
        }

        .pp-highlight-card h4 {
            font-size: 18px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 10px;
        }

        .pp-highlight-card p {
            font-size: 14px;
            line-height: 1.75;
            color: var(--muted);
        }

        .pp-policy-section {
            padding: 40px 0 90px;
        }

        .pp-policy-wrap {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 32px;
            align-items: start;
        }

        .pp-sidebar {
            position: sticky;
            top: 110px;
            background: rgba(255, 255, 255, 0.86);
            border: 1px solid rgba(78, 184, 122, 0.14);
            border-radius: 24px;
            box-shadow: var(--shadow-soft);
            padding: 24px;
            backdrop-filter: blur(10px);
        }

        .pp-sidebar h5 {
            font-size: 16px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 16px;
        }

        .pp-sidebar ul {
            list-style: none;
            display: grid;
            gap: 12px;
        }

        .pp-sidebar a {
            text-decoration: none;
            color: var(--muted);
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .pp-sidebar a:hover {
            color: var(--g2);
            padding-left: 4px;
        }

        .pp-content {
            display: grid;
            gap: 24px;
        }

        .pp-block {
            background: var(--card-bg);
            border-radius: 26px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.85);
            overflow: hidden;
        }

        .pp-block-head {
            padding: 24px 28px;
            background: linear-gradient(135deg, rgba(232, 248, 238, 0.95), rgba(255, 255, 255, 0.95));
            border-bottom: 1px solid rgba(78, 184, 122, 0.12);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .pp-block-head .icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .pp-block-head h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            line-height: 1.2;
            color: var(--ink);
        }

        .pp-block-body {
            padding: 28px;
        }

        .pp-block-body p {
            font-size: 15.5px;
            line-height: 1.9;
            color: var(--muted);
            margin-bottom: 16px;
        }

        .pp-block-body p:last-child {
            margin-bottom: 0;
        }

        .pp-list {
            list-style: none;
            display: grid;
            gap: 14px;
            margin-top: 10px;
        }

        .pp-list li {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            color: var(--muted);
            font-size: 15px;
            line-height: 1.75;
        }

        .pp-list i {
            width: 26px;
            height: 26px;
            border-radius: 8px;
            background: #e59e20;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            flex-shrink: 0;
            margin-top: 2px;
        }

        .pp-note {
            margin-top: 18px;
            padding: 16px 18px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(78, 184, 122, 0.10), rgba(168, 230, 191, 0.18));
            border: 1px solid rgba(78, 184, 122, 0.18);
            color: var(--g1);
            font-size: 14px;
            line-height: 1.7;
            font-weight: 500;
        }

        .pp-cta {
            padding: 0 0 90px;
        }

        .pp-cta-card {
            background: var(--card-bg);
            border-radius: 32px;
            padding: 62px 48px;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.9);
            position: relative;
            overflow: hidden;
            text-align: center;
        }

        .pp-cta-card::before {
            content: '';
            position: absolute;
            top: -1px;
            left: 20%;
            right: 20%;
            height: 4px;
            background: linear-gradient(90deg, var(--g1), var(--g3), var(--g4));
            border-radius: 0 0 4px 4px;
        }

        .pp-section-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--g2);
            margin-bottom: 18px;
        }

        .pp-section-tag::before {
            content: '';
            width: 24px;
            height: 3px;
            border-radius: 2px;
            background: var(--g3);
        }

        .pp-cta-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 52px);
            font-weight: 900;
            color: var(--ink);
            line-height: 1.15;
            margin-bottom: 16px;
        }

        .pp-cta-card h2 span {
            color: var(--g2);
        }

        .pp-cta-card p {
            font-size: 17px;
            color: var(--muted);
            max-width: 650px;
            margin: 0 auto 34px;
            line-height: 1.8;
        }

        .pp-cta-btns {
            display: flex;
            justify-content: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        @media (max-width: 991px) {
            .pp-hero {
                grid-template-columns: 1fr;
                min-height: auto;
                padding-top: 70px;
            }

            .pp-hero-right {
                display: none;
            }

            .pp-highlight-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .pp-policy-wrap {
                grid-template-columns: 1fr;
            }

            .pp-sidebar {
                position: relative;
                top: 0;
            }
        }

        @media (max-width: 575px) {
            .pp-highlight-grid {
                grid-template-columns: 1fr;
            }

            .pp-block-head {
                padding: 20px;
            }

            .pp-block-head h3 {
                font-size: 24px;
            }

            .pp-block-body {
                padding: 20px;
            }

            .pp-cta-card {
                padding: 40px 24px;
            }

            .pp-hero h1 {
                font-size: 38px;
            }
        }
    </style>


    <style>


        .tc-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .tc-bg-blob {
            position: absolute;
            border-radius: 50%;
        }

        .tc-bg-blob:nth-child(1) {
            width: 700px;
            height: 700px;
            top: -220px;
            left: -180px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.20) 0%, transparent 70%);
            animation: blobDrift1 16s ease-in-out infinite alternate;
        }

        .tc-bg-blob:nth-child(2) {
            width: 500px;
            height: 500px;
            bottom: -160px;
            right: -120px;
            background: radial-gradient(circle, rgba(26, 92, 58, 0.13) 0%, transparent 70%);
            animation: blobDrift2 20s ease-in-out infinite alternate;
        }

        .tc-bg-blob:nth-child(3) {
            width: 350px;
            height: 350px;
            top: 42%;
            left: 58%;
            background: radial-gradient(circle, rgba(168, 230, 191, 0.16) 0%, transparent 70%);
            animation: blobDrift3 24s ease-in-out infinite alternate;
        }

        .tc-bg-dots {
            position: absolute;
            inset: 0;
            background-image: radial-gradient(circle, rgba(78, 184, 122, 0.14) 1.5px, transparent 1.5px);
            background-size: 38px 38px;
            opacity: 0.55;
        }

        @keyframes blobDrift1 {
            to {
                transform: translate(50px, 60px) scale(1.1);
            }
        }

        @keyframes blobDrift2 {
            to {
                transform: translate(-40px, -50px) scale(1.07);
            }
        }

        @keyframes blobDrift3 {
            to {
                transform: translate(25px, -35px);
            }
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(28px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }



        .tc-page {
            position: relative;
            z-index: 2;
        }

        .tc-wrap {
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .tc-hero {
            min-height: 72vh;
            display: grid;
            grid-template-columns: 1.05fr 0.95fr;
            align-items: center;
            gap: 60px;
            padding: 90px 24px 70px;
            max-width: 1340px;
            margin: 0 auto;
        }

        .tc-hero-left {
            animation: fadeUp 0.8s ease both;
        }

        .tc-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12.5px;
            font-weight: 600;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--g2);
            background: rgba(78, 184, 122, 0.12);
            border: 1px solid rgba(78, 184, 122, 0.28);
            padding: 6px 18px;
            border-radius: 100px;
            margin-bottom: 26px;
        }

        .tc-hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(42px, 6vw, 74px);
            font-weight: 900;
            line-height: 1.08;
            color: var(--ink);
            margin-bottom: 22px;
        }

        .tc-hero h1 em {
            font-style: italic;
            color: var(--g2);
        }

        .tc-hero-desc {
            font-size: 17px;
            line-height: 1.8;
            color: var(--muted);
            max-width: 560px;
            margin-bottom: 34px;
        }

        .tc-hero-meta {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }

        .tc-meta-chip {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(78, 184, 122, 0.18);
            box-shadow: var(--shadow-soft);
            color: var(--g1);
            font-size: 14px;
            font-weight: 600;
        }

        .btn-primary-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 30px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--btn-accent), var(--btn-accent-dark));
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            cursor: pointer;
            box-shadow: 0 14px 40px rgba(229, 158, 32, 0.28);
            transition: all 0.35s ease;
        }

        .btn-primary-theme:hover {
            transform: translateY(-3px);
            color: #fff;
            box-shadow: 0 20px 50px rgba(229, 158, 32, 0.34);
        }

        .btn-outline-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 30px;
            border-radius: 14px;
            background: transparent;
            color: var(--btn-accent-dark);
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: 2px solid rgba(229, 158, 32, 0.34);
            transition: all 0.35s ease;
        }

        .btn-outline-theme:hover {
            background: var(--btn-accent-soft);
            border-color: var(--btn-accent);
            color: var(--btn-accent-dark);
            transform: translateY(-3px);
        }

        .tc-hero-right {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeUp 0.8s 0.2s ease both;
        }

        .tc-card-stack {
            position: relative;
            width: 100%;
            max-width: 470px;
            height: 480px;
        }

        .tc-main-card {
            position: absolute;
            inset: 20px 20px 60px 40px;
            border-radius: 30px;
            background: linear-gradient(160deg, rgba(255, 255, 255, 0.92), rgba(232, 248, 238, 0.95));
            box-shadow: 0 40px 90px rgba(26, 92, 58, 0.22);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.85);
            padding: 34px 30px;
        }

        .tc-main-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, var(--g1), var(--g3), var(--g4));
        }

        .tc-main-card-icon {
            width: 72px;
            height: 72px;
            border-radius: 20px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 28px;
            margin-bottom: 22px;
            box-shadow: 0 16px 36px rgba(26, 92, 58, 0.22);
        }

        .tc-main-card h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 14px;
            color: var(--ink);
        }

        .tc-main-card p {
            font-size: 15px;
            line-height: 1.8;
            color: var(--muted);
            margin-bottom: 22px;
        }

        .tc-mini-points {
            list-style: none;
            display: grid;
            gap: 12px;
        }

        .tc-mini-points li {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .tc-mini-points i {
            width: 24px;
            height: 24px;
            border-radius: 8px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            flex-shrink: 0;
            margin-top: 1px;
        }

        .tc-floating-box {
            position: absolute;
            background: #fff;
            border-radius: 18px;
            padding: 14px 18px;
            box-shadow: var(--shadow-med);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: float 5s ease-in-out infinite;
            border: 1px solid rgba(255, 255, 255, 0.9);
        }

        .tc-floating-box.one {
            top: 16px;
            right: -10px;
        }

        .tc-floating-box.two {
            bottom: 24px;
            left: 0;
            animation-delay: 1.6s;
        }

        .tc-floating-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: #e59e20;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }

        .tc-floating-text .lbl {
            font-size: 11px;
            color: var(--muted);
            font-weight: 500;
        }

        .tc-floating-text .val {
            font-size: 16px;
            color: var(--ink);
            font-weight: 800;
            line-height: 1.1;
        }

        .tc-highlights {
            padding: 0 0 40px;
        }

        .tc-highlight-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
            margin-top: -10px;
        }

        .tc-highlight-card {
            background: var(--card-bg);
            border-radius: 22px;
            padding: 26px 22px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.85);
            transition: transform 0.35s ease, box-shadow 0.35s ease;
            position: relative;
            overflow: hidden;
        }

        .tc-highlight-card::after {
            content: '';
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--g1), var(--g3));
        }

        .tc-highlight-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-med);
        }

        .tc-highlight-card i {
            width: 54px;
            height: 54px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 16px;
            box-shadow: 0 10px 24px rgba(26, 92, 58, 0.18);
        }

        .tc-highlight-card h4 {
            font-size: 18px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 10px;
        }

        .tc-highlight-card p {
            font-size: 14px;
            line-height: 1.75;
            color: var(--muted);
        }

        .tc-policy-section {
            padding: 40px 0 90px;
        }

        .tc-policy-wrap {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 32px;
            align-items: start;
        }

        .tc-sidebar {
            position: sticky;
            top: 110px;
            background: rgba(255, 255, 255, 0.86);
            border: 1px solid rgba(78, 184, 122, 0.14);
            border-radius: 24px;
            box-shadow: var(--shadow-soft);
            padding: 24px;
            backdrop-filter: blur(10px);
        }

        .tc-sidebar h5 {
            font-size: 16px;
            font-weight: 700;
            color: var(--ink);
            margin-bottom: 16px;
        }

        .tc-sidebar ul {
            list-style: none;
            display: grid;
            gap: 12px;
        }

        .tc-sidebar a {
            text-decoration: none;
            color: var(--muted);
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tc-sidebar a:hover {
            color: var(--g2);
            padding-left: 4px;
        }

        .tc-content {
            display: grid;
            gap: 24px;
        }

        .tc-block {
            background: var(--card-bg);
            border-radius: 26px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.85);
            overflow: hidden;
        }

        .tc-block-head {
            padding: 24px 28px;
            background: linear-gradient(135deg, rgba(232, 248, 238, 0.95), rgba(255, 255, 255, 0.95));
            border-bottom: 1px solid rgba(78, 184, 122, 0.12);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .tc-block-head .icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .tc-block-head h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            line-height: 1.2;
            color: var(--ink);
        }

        .tc-block-body {
            padding: 28px;
        }

        .tc-block-body p {
            font-size: 15.5px;
            line-height: 1.9;
            color: var(--muted);
            margin-bottom: 16px;
        }

        .tc-block-body p:last-child {
            margin-bottom: 0;
        }

        .tc-list {
            list-style: none;
            display: grid;
            gap: 14px;
            margin-top: 10px;
        }

        .tc-list li {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            color: var(--muted);
            font-size: 15px;
            line-height: 1.75;
        }

        .tc-list i {
            width: 26px;
            height: 26px;
            border-radius: 8px;
            background: #e59e20;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            flex-shrink: 0;
            margin-top: 2px;
        }

        .tc-note {
            margin-top: 18px;
            padding: 16px 18px;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(78, 184, 122, 0.10), rgba(168, 230, 191, 0.18));
            border: 1px solid rgba(78, 184, 122, 0.18);
            color: var(--g1);
            font-size: 14px;
            line-height: 1.7;
            font-weight: 500;
        }

        .tc-cta {
            padding: 0 0 90px;
        }

        .tc-cta-card {
            background: var(--card-bg);
            border-radius: 32px;
            padding: 62px 48px;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.9);
            position: relative;
            overflow: hidden;
            text-align: center;
        }

        .tc-cta-card::before {
            content: '';
            position: absolute;
            top: -1px;
            left: 20%;
            right: 20%;
            height: 4px;
            background: linear-gradient(90deg, var(--g1), var(--g3), var(--g4));
            border-radius: 0 0 4px 4px;
        }

        .tc-section-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--g2);
            margin-bottom: 18px;
        }

        .tc-section-tag::before {
            content: '';
            width: 24px;
            height: 3px;
            border-radius: 2px;
            background: var(--g3);
        }

        .tc-cta-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 52px);
            font-weight: 900;
            color: var(--ink);
            line-height: 1.15;
            margin-bottom: 16px;
        }

        .tc-cta-card h2 span {
            color: var(--g2);
        }

        .tc-cta-card p {
            font-size: 17px;
            color: var(--muted);
            max-width: 650px;
            margin: 0 auto 34px;
            line-height: 1.8;
        }

        .tc-cta-btns {
            display: flex;
            justify-content: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        @media (max-width: 991px) {
            .tc-hero {
                grid-template-columns: 1fr;
                min-height: auto;
                padding-top: 70px;
            }

            .tc-hero-right {
                display: none;
            }

            .tc-highlight-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .tc-policy-wrap {
                grid-template-columns: 1fr;
            }

            .tc-sidebar {
                position: relative;
                top: 0;
            }
        }

        @media (max-width: 575px) {
            .tc-highlight-grid {
                grid-template-columns: 1fr;
            }

            .tc-block-head {
                padding: 20px;
            }

            .tc-block-head h3 {
                font-size: 24px;
            }

            .tc-block-body {
                padding: 20px;
            }

            .tc-cta-card {
                padding: 40px 24px;
            }

            .tc-hero h1 {
                font-size: 38px;
            }
        }
    </style>

    <style>
        :root {
            --g1: #1a5c3a;
            --g2: #2d8a56;
            --g3: #4eb87a;
            --g4: #a8e6bf;
            --g5: #e8f8ee;

            --btn-accent: #e59e20;
            --btn-accent-dark: #c98510;
            --btn-accent-soft: #fff4dc;

            --ink: #0f2a1a;
            --muted: #4a6a57;
            --white: #ffffff;
            --line: rgba(78, 184, 122, 0.18);
            --card-bg: rgba(255, 255, 255, 0.88);
            --shadow-soft: 0 8px 40px rgba(26, 92, 58, 0.10);
            --shadow-med: 0 20px 70px rgba(26, 92, 58, 0.15);
            --shadow-green: 0 30px 80px rgba(26, 92, 58, 0.22);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: #f0f9f3;
            color: var(--ink);
            overflow-x: clip;
        }

        .pr-bg {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .pr-bg-blob {
            position: absolute;
            border-radius: 50%;
        }

        .pr-bg-blob:nth-child(1) {
            width: 720px;
            height: 720px;
            top: -240px;
            left: -180px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.18) 0%, transparent 70%);
            animation: blobDrift1 16s ease-in-out infinite alternate;
        }

        .pr-bg-blob:nth-child(2) {
            width: 500px;
            height: 500px;
            bottom: -140px;
            right: -120px;
            background: radial-gradient(circle, rgba(26, 92, 58, 0.12) 0%, transparent 70%);
            animation: blobDrift2 20s ease-in-out infinite alternate;
        }

        .pr-bg-blob:nth-child(3) {
            width: 360px;
            height: 360px;
            top: 42%;
            left: 58%;
            background: radial-gradient(circle, rgba(168, 230, 191, 0.15) 0%, transparent 70%);
            animation: blobDrift3 24s ease-in-out infinite alternate;
        }

        .pr-bg-dots {
            position: absolute;
            inset: 0;
            background-image: radial-gradient(circle, rgba(78, 184, 122, 0.13) 1.5px, transparent 1.5px);
            background-size: 38px 38px;
            opacity: 0.55;
        }

        @keyframes blobDrift1 {
            to {
                transform: translate(50px, 60px) scale(1.1);
            }
        }

        @keyframes blobDrift2 {
            to {
                transform: translate(-40px, -50px) scale(1.07);
            }
        }

        @keyframes blobDrift3 {
            to {
                transform: translate(25px, -35px);
            }
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(28px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .pr-page {
            position: relative;
            z-index: 2;
        }

        .pr-wrap {
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .pr-hero {
            padding: 90px 0 40px;
        }

        .pr-hero-grid {
            display: grid;
            grid-template-columns: 1fr 430px;
            gap: 28px;
            align-items: stretch;
        }

        .pr-hero-left,
        .pr-hero-right {
            background: var(--card-bg);
            border-radius: 34px;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.90);
            position: relative;
            overflow: hidden;
        }



        .pr-hero-left {
            padding: 44px 42px;
            animation: fadeUp .8s ease both;
        }

        .pr-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12.5px;
            font-weight: 700;
            letter-spacing: 2.4px;
            text-transform: uppercase;
            color: var(--g2);
            background: rgba(78, 184, 122, 0.12);
            border: 1px solid rgba(78, 184, 122, 0.24);
            padding: 8px 18px;
            border-radius: 100px;
            margin-bottom: 22px;
        }

        .pr-hero-left h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(38px, 5vw, 68px);
            line-height: 1.08;
            font-weight: 900;
            color: var(--ink);
            margin-bottom: 18px;
        }

        .pr-hero-left h1 em {
            color: var(--g2);
            font-style: italic;
        }

        .pr-hero-left p {
            max-width: 720px;
            font-size: 16.5px;
            line-height: 1.85;
            color: var(--muted);
            margin-bottom: 26px;
        }

        .pr-hero-points {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 28px;
        }

        .pr-chip {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.88);
            border: 1px solid rgba(78, 184, 122, 0.18);
            box-shadow: var(--shadow-soft);
            color: var(--g1);
            font-size: 14px;
            font-weight: 600;
        }

        .pr-chip i {
            color: var(--g2);
        }

        .pr-hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
        }

        .btn-primary-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 15px 30px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--btn-accent), var(--btn-accent-dark));
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: none;
            cursor: pointer;
            box-shadow: 0 14px 40px rgba(229, 158, 32, 0.28);
            transition: all 0.35s ease;
        }

        .btn-primary-theme:hover {
            transform: translateY(-3px);
            color: #fff;
            box-shadow: 0 20px 50px rgba(229, 158, 32, 0.34);
        }

        .btn-outline-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 15px 30px;
            border-radius: 14px;
            background: transparent;
            color: var(--btn-accent-dark);
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            border: 2px solid rgba(229, 158, 32, 0.34);
            transition: all 0.35s ease;
        }

        .btn-outline-theme:hover {
            background: var(--btn-accent-soft);
            border-color: var(--btn-accent);
            color: var(--btn-accent-dark);
            transform: translateY(-3px);
        }

        .pr-hero-right {
            padding: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(180deg, rgba(232, 248, 238, 0.92) 0%, rgba(255, 255, 255, 0.95) 100%);
            animation: fadeUp .85s .12s ease both;
        }

        .pr-hero-card {
            width: 100%;
            max-width: 360px;
            position: relative;
        }

        .pr-hero-image {
            border-radius: 28px;
            overflow: hidden;
            box-shadow: var(--shadow-green);
            position: relative;
        }

        .pr-hero-image img {
            width: 100%;
            height: 420px;
            object-fit: cover;
            display: block;
            transition: transform .5s ease;
        }

        .pr-hero-card:hover .pr-hero-image img {
            transform: scale(1.04);
        }

        .pr-hero-image::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(26, 92, 58, 0.42) 0%, transparent 55%);
        }

        .pr-floating-tag,
        .pr-floating-price {
            position: absolute;
            background: #fff;
            border-radius: 18px;
            box-shadow: var(--shadow-med);
            padding: 14px 18px;
            z-index: 2;
            animation: float 4.5s ease-in-out infinite;
        }

        .pr-floating-tag {
            top: 18px;
            right: -12px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .pr-floating-price {
            bottom: 24px;
            left: -10px;
            animation-delay: 1.4s;
        }

        .pr-float-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 16px;
        }

        .pr-floating-tag .lbl,
        .pr-floating-price .lbl {
            font-size: 11px;
            color: var(--muted);
            font-weight: 500;
        }

        .pr-floating-tag .val,
        .pr-floating-price .val {
            font-size: 16px;
            color: var(--ink);
            font-weight: 800;
            line-height: 1.1;
        }

        .pr-filters {
            margin-top: 34px;
            background: var(--card-bg);
            border-radius: 28px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.9);
            padding: 24px;
            position: relative;
        }

        .pr-filter-grid {
            display: grid;
            grid-template-columns: 1.5fr repeat(4, 1fr);
            gap: 14px;
            align-items: center;
        }

        .pr-search,
        .pr-select {
            width: 100%;
            height: 54px;
            border-radius: 14px;
            border: 1px solid rgba(78, 184, 122, 0.18);
            background: rgba(255, 255, 255, 0.84);
            padding: 0 16px;
            font-size: 14.5px;
            color: var(--ink);
            outline: none;
            transition: all .25s ease;
        }

        .pr-search:focus,
        .pr-select:focus {
            border-color: rgba(45, 138, 86, 0.45);
            box-shadow: 0 0 0 4px rgba(78, 184, 122, 0.10);
        }

        .pr-search-wrap {
            position: relative;
        }

        .pr-search-wrap i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--g2);
            font-size: 14px;
        }

        .pr-search {
            padding-left: 42px;
        }

        .pr-section {
            padding: 42px 0 0;
        }

        .pr-section-head {
            background: var(--card-bg);
            border-radius: 28px;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.9);
            padding: 28px 28px 24px;
            margin-bottom: 24px;
            position: relative;
        }

        .pr-section-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2.4px;
            text-transform: uppercase;
            color: var(--g2);
            margin-bottom: 12px;
        }

        .pr-section-tag::before {
            content: '';
            width: 24px;
            height: 3px;
            border-radius: 2px;
            background: var(--g3);
        }

        .pr-section-head h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(28px, 4vw, 46px);
            line-height: 1.15;
            color: var(--ink);
            font-weight: 900;
            margin-bottom: 10px;
        }

        .pr-section-head p {
            font-size: 15.5px;
            line-height: 1.8;
            color: var(--muted);
            max-width: 760px;
        }

        .pr-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 22px;
        }

        .pr-card {
            background: var(--card-bg);
            border-radius: 24px;
            overflow: hidden;
            box-shadow: var(--shadow-soft);
            border: 1px solid rgba(255, 255, 255, 0.88);
            transition: transform .35s ease, box-shadow .35s ease;
            position: relative;
        }

        .pr-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-med);
        }

        .pr-card.hidden {
            display: none;
        }

        .pr-card-media {
            position: relative;
            height: 250px;
            overflow: hidden;
        }

        .pr-card-media img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform .5s ease;
        }

        .pr-card:hover .pr-card-media img {
            transform: scale(1.06);
        }

        .pr-card-media::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(26, 92, 58, 0.38) 0%, transparent 55%);
        }

        .pr-badge {
            position: absolute;
            top: 14px;
            left: 14px;
            z-index: 2;
            background: linear-gradient(135deg, var(--g1), var(--g2));
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            padding: 6px 12px;
            border-radius: 100px;
            box-shadow: 0 10px 26px rgba(26, 92, 58, 0.18);
        }

        .pr-wishlist {
            position: absolute;
            top: 14px;
            right: 14px;
            z-index: 2;
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid rgba(255, 255, 255, 0.96);
            color: var(--g2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            text-decoration: none;
            transition: all .3s ease;
            cursor: pointer;
        }

        .pr-wishlist.active,
        .pr-wishlist:hover {
            background: var(--g2);
            color: #fff;
            transform: translateY(-2px);
        }

        .pr-card-body {
            padding: 20px 18px 22px;
        }

        .pr-rating {
            display: flex;
            align-items: center;
            gap: 3px;
            color: #f5b301;
            font-size: 12px;
            margin-bottom: 10px;
        }

        .pr-rating span {
            color: var(--muted);
            font-size: 12px;
            margin-left: 6px;
            font-weight: 500;
        }

        .pr-card-body h4 {
            font-family: 'Playfair Display', serif;
            font-size: 21px;
            line-height: 1.2;
            color: var(--ink);
            margin-bottom: 8px;
            font-weight: 700;
        }

        .pr-card-body p {
            font-size: 14px;
            color: var(--muted);
            line-height: 1.75;
            margin-bottom: 16px;
        }

        .pr-meta-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 16px;
        }

        .pr-meta {
            font-size: 12px;
            font-weight: 600;
            color: var(--g1);
            background: var(--g5);
            border: 1px solid rgba(78, 184, 122, 0.16);
            padding: 7px 10px;
            border-radius: 100px;
            cursor: pointer;
            transition: all .2s;
        }

        .pr-meta:hover,
        .pr-meta.active {
            background: var(--saffron-lt);
            border-color: var(--saffron);
            color: var(--saffron-dk);
        }

        .pr-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
        }

        .pr-price {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .pr-price strong {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            color: var(--g2);
            line-height: 1;
            font-weight: 900;
        }

        .pr-price span {
            font-size: 12px;
            color: var(--muted);
        }

        .pr-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 16px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--btn-accent), var(--btn-accent-dark));
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
            box-shadow: 0 12px 28px rgba(229, 158, 32, 0.18);
            transition: all .3s ease;
            white-space: nowrap;
        }

        .pr-btn:hover {
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 16px 36px rgba(229, 158, 32, 0.26);
        }

        .pr-banner {
            margin-top: 48px;
            background: linear-gradient(135deg, rgba(26, 92, 58, 0.96) 0%, rgba(45, 138, 86, 0.95) 100%);
            border-radius: 32px;
            padding: 48px 38px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-med);
        }

        .pr-banner::after {
            content: '';
            position: absolute;
            inset: 0;
            background: repeating-linear-gradient(-45deg,
                    rgba(255, 255, 255, 0.03) 0px,
                    rgba(255, 255, 255, 0.03) 1px,
                    transparent 1px,
                    transparent 18px);
            pointer-events: none;
        }

        .pr-banner-inner {
            position: relative;
            z-index: 2;
            display: grid;
            grid-template-columns: 1.1fr .9fr;
            gap: 28px;
            align-items: center;
        }

        .pr-banner h3 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 48px);
            color: #fff;
            line-height: 1.15;
            font-weight: 900;
            margin-bottom: 14px;
        }

        .pr-banner p {
            font-size: 16px;
            color: rgba(255, 255, 255, 0.84);
            line-height: 1.85;
            max-width: 650px;
        }

        .pr-banner-features {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
        }

        .pr-banner-feature {
            background: rgba(255, 255, 255, 0.10);
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 18px;
            padding: 18px 16px;
            color: #fff;
            backdrop-filter: blur(12px);
        }

        .pr-banner-feature h5 {
            font-size: 16px;
            margin-bottom: 6px;
            font-weight: 700;
        }

        .pr-banner-feature p {
            font-size: 13px;
            line-height: 1.65;
            color: rgba(255, 255, 255, 0.74);
        }

        .pr-cta {
            padding: 52px 0 90px;
        }

        .pr-cta-card {
            background: var(--card-bg);
            border-radius: 34px;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.90);
            padding: 54px 36px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .pr-cta-card h2 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(30px, 4vw, 50px);
            color: var(--ink);
            line-height: 1.14;
            font-weight: 900;
            margin-bottom: 14px;
        }

        .pr-cta-card h2 span {
            color: var(--g2);
        }

        .pr-cta-card p {
            max-width: 760px;
            margin: 0 auto 30px;
            font-size: 16px;
            line-height: 1.85;
            color: var(--muted);
        }

        .pr-cta-actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 14px;
        }

        @media (max-width: 1100px) {
            .pr-grid {
                grid-template-columns: repeat(3, 1fr);
            }

            .pr-filter-grid {
                grid-template-columns: 1fr 1fr;
            }

            .pr-hero-grid,
            .pr-banner-inner {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767px) {
            .pr-wrap {
                padding: 0 16px;
            }

            .pr-hero {
                padding: 70px 0 28px;
            }

            .pr-hero-left,
            .pr-hero-right,
            .pr-filters,
            .pr-section-head,
            .pr-banner,
            .pr-cta-card {
                border-radius: 24px;
            }

            .pr-hero-left,
            .pr-hero-right,
            .pr-banner,
            .pr-cta-card {
                padding: 24px 20px;
            }

            .pr-filters {
                padding: 18px;
            }

            .pr-filter-grid {
                grid-template-columns: 1fr;
            }

            .pr-grid {
                grid-template-columns: 1fr;
            }

            .pr-banner-features {
                grid-template-columns: 1fr;
            }

            .pr-hero-actions,
            .pr-cta-actions {
                flex-direction: column;
            }

            .btn-primary-theme,
            .btn-outline-theme {
                width: 100%;
                justify-content: center;
            }

            .pr-floating-tag,
            .pr-floating-price {
                position: static;
                margin-top: 14px;
                animation: none;
            }

            .pr-hero-image img {
                height: 320px;
            }
        }
    </style>

    <style>


        .success-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 60px 20px;
            position: relative;
        }

        .success-page::before,
        .success-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            z-index: 0;
        }

        .success-page::before {
            width: 320px;
            height: 320px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.16) 0%, transparent 70%);
            top: 40px;
            left: 40px;
        }

        .success-page::after {
            width: 260px;
            height: 260px;
            background: radial-gradient(circle, rgba(229, 158, 32, 0.12) 0%, transparent 70%);
            bottom: 30px;
            right: 30px;
        }

        .success-card {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 700px;
            background: rgba(255, 255, 255, 0.94);
            border-radius: 28px;
            padding: 50px 35px;
            text-align: center;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.8);
            overflow: hidden;
        }

        .success-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: #368e5d;
        }

        .success-icon {
            width: 92px;
            height: 92px;
            margin: 0 auto 22px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--g1), var(--g3));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 34px;
            box-shadow: 0 18px 40px rgba(26, 92, 58, 0.22);
        }

        .success-tag {
            display: inline-block;
            font-size: 12px;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: 700;
            color: var(--g2);
            background: rgba(78, 184, 122, 0.10);
            border: 1px solid rgba(78, 184, 122, 0.18);
            padding: 8px 16px;
            border-radius: 50px;
            margin-bottom: 18px;
        }

        .success-card h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(32px, 5vw, 52px);
            line-height: 1.15;
            margin-bottom: 14px;
            color: var(--ink);
        }

        .success-card h1 span {
            color: var(--g2);
        }

        .success-card p {
            max-width: 520px;
            margin: 0 auto 28px;
            font-size: 16px;
            line-height: 1.8;
            color: var(--muted);
        }

        .success-meta {
            display: flex;
            justify-content: center;
            gap: 14px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        .success-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 16px;
            border-radius: 14px;
            background: #f8fffa;
            border: 1px solid rgba(78, 184, 122, 0.16);
            color: var(--g1);
            font-size: 14px;
            font-weight: 600;
            box-shadow: var(--shadow-soft);
        }

        .success-actions {
            display: flex;
            justify-content: center;
            gap: 14px;
            flex-wrap: wrap;
        }

        .btn-primary-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 28px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--btn-accent), var(--btn-accent-dark));
            color: #fff;
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 14px 36px rgba(229, 158, 32, 0.28);
        }

        .btn-primary-theme:hover {
            transform: translateY(-3px);
            color: #fff;
        }

        .btn-outline-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 28px;
            border-radius: 14px;
            background: transparent;
            color: var(--btn-accent-dark);
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            border: 2px solid rgba(229, 158, 32, 0.30);
            transition: all 0.3s ease;
        }

        .btn-outline-theme:hover {
            background: var(--btn-accent-soft);
            transform: translateY(-3px);
            color: var(--btn-accent-dark);
        }

        @media (max-width: 575px) {
            .success-card {
                padding: 38px 22px;
                border-radius: 22px;
            }

            .success-card p {
                font-size: 15px;
            }

            .success-actions a {
                width: 100%;
                justify-content: center;
            }
        }
    </style>


    <style>
        :root {
            --g1: #1a5c3a;
            --g2: #2d8a56;
            --g3: #4eb87a;
            --g4: #a8e6bf;
            --g5: #e8f8ee;

            --btn-accent: #e59e20;
            --btn-accent-dark: #c98510;
            --btn-accent-soft: #fff4dc;

            --danger: #d64545;
            --danger-dark: #b83434;
            --danger-soft: #fff1f1;

            --ink: #0f2a1a;
            --muted: #4a6a57;
            --white: #ffffff;
            --shadow-soft: 0 12px 40px rgba(26, 92, 58, 0.10);
            --shadow-med: 0 20px 70px rgba(26, 92, 58, 0.16);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background: linear-gradient(180deg, #f3fbf6 0%, #edf8f1 100%);
            color: var(--ink);
            overflow-x: clip;
        }

        .failed-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 60px 20px;
            position: relative;
        }

        .failed-page::before,
        .failed-page::after {
            content: "";
            position: absolute;
            border-radius: 50%;
            z-index: 0;
        }

        .failed-page::before {
            width: 320px;
            height: 320px;
            background: radial-gradient(circle, rgba(78, 184, 122, 0.14) 0%, transparent 70%);
            top: 40px;
            left: 40px;
        }

        .failed-page::after {
            width: 260px;
            height: 260px;
            background: radial-gradient(circle, rgba(214, 69, 69, 0.10) 0%, transparent 70%);
            bottom: 30px;
            right: 30px;
        }

        .failed-card {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 700px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 28px;
            padding: 50px 35px;
            text-align: center;
            box-shadow: var(--shadow-med);
            border: 1px solid rgba(255, 255, 255, 0.85);
            overflow: hidden;
        }

        .failed-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--danger), #f08b8b, var(--btn-accent));
        }

        .failed-icon {
            width: 92px;
            height: 92px;
            margin: 0 auto 22px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--danger), var(--danger-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 34px;
            box-shadow: 0 18px 40px rgba(214, 69, 69, 0.22);
        }

        .failed-tag {
            display: inline-block;
            font-size: 12px;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: 700;
            color: var(--danger);
            background: var(--danger-soft);
            border: 1px solid rgba(214, 69, 69, 0.16);
            padding: 8px 16px;
            border-radius: 50px;
            margin-bottom: 18px;
        }

        .failed-card h1 {
            font-family: 'Playfair Display', serif;
            font-size: clamp(32px, 5vw, 52px);
            line-height: 1.15;
            margin-bottom: 14px;
            color: var(--ink);
        }

        .failed-card h1 span {
            color: var(--danger);
        }

        .failed-card p {
            max-width: 540px;
            margin: 0 auto 28px;
            font-size: 16px;
            line-height: 1.8;
            color: var(--muted);
        }

        .failed-meta {
            display: flex;
            justify-content: center;
            gap: 14px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        .failed-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 16px;
            border-radius: 14px;
            background: #fff;
            border: 1px solid rgba(214, 69, 69, 0.14);
            color: var(--danger-dark);
            font-size: 14px;
            font-weight: 600;
            box-shadow: var(--shadow-soft);
        }

        .failed-actions {
            display: flex;
            justify-content: center;
            gap: 14px;
            flex-wrap: wrap;
        }

        .btn-primary-theme {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 28px;
            border-radius: 14px;
            background: linear-gradient(135deg, var(--btn-accent), var(--btn-accent-dark));
            color: #fff;
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 14px 36px rgba(229, 158, 32, 0.28);
        }

        .btn-primary-theme:hover {
            transform: translateY(-3px);
            color: #fff;
        }

        .btn-outline-danger {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 28px;
            border-radius: 14px;
            background: transparent;
            color: var(--danger-dark);
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            border: 2px solid rgba(214, 69, 69, 0.24);
            transition: all 0.3s ease;
        }

        .btn-outline-danger:hover {
            background: var(--danger-soft);
            transform: translateY(-3px);
            color: var(--danger-dark);
        }

        @media (max-width: 575px) {
            .failed-card {
                padding: 38px 22px;
                border-radius: 22px;
            }

            .failed-card p {
                font-size: 15px;
            }

            .failed-actions a {
                width: 100%;
                justify-content: center;
            }
        }
    </style>

    <style>
        :root {
            --saffron: #E8870A;
            --saffron-lt: #FFF4E0;
            --saffron-dk: #B5640A;
            --forest: #2D5016;
            --forest-lt: #EBF2E4;
            --cream: #FDFAF3;
            --charcoal: #1C1C1C;
            --muted: #6B6B6B;
            --border: #E8E0D0;
            --white: #FFFFFF;
            --shadow: 0 4px 32px rgba(28, 28, 28, 0.08);
            --shadow-lg: 0 12px 60px rgba(28, 28, 28, 0.13);
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--cream);
            color: var(--charcoal);
            font-family: 'DM Sans', sans-serif;
            font-size: 16px;
            line-height: 1.65;
        }

        h1,
        h2,
        h3,
        h4 {
            font-family: 'Cormorant Garamond', serif;
            line-height: 1.2;
        }

        img {
            display: block;
            width: 100%;
            object-fit: cover;
        }

        /* ── BREADCRUMB ── */
        .breadcrumb-bar {
            background: var(--white);
            border-bottom: 1px solid var(--border);
            padding: 0.75rem 0;
        }

        .breadcrumb-bar .container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.82rem;
            color: var(--muted);
            flex-wrap: wrap;
        }

        .breadcrumb-bar a {
            color: var(--muted);
            text-decoration: none;
            transition: color .2s;
        }

        .breadcrumb-bar a:hover {
            color: var(--saffron);
        }

        .breadcrumb-bar .sep {
            color: var(--border);
        }

        .breadcrumb-bar .current {
            color: var(--charcoal);
            font-weight: 500;
        }

        /* ── HERO ── */
        .product-hero {
            padding: 5rem 0 2rem;
            background: var(--cream);
        }

        /* ── GALLERY ── */
        .gallery-wrap {
            position: relative;
        }

        .gallery-main-swiper {
            border-radius: 20px;
            overflow: hidden;
            background: #fff;
            box-shadow: var(--shadow-lg);
            aspect-ratio: 1 / 1;
        }

        .gallery-main-swiper .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .badge-float {
            position: absolute;
            top: 1.1rem;
            left: 1.1rem;
            z-index: 10;
            background: var(--saffron);
            color: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 0.78rem;
            font-weight: 600;
            letter-spacing: 0.06em;
            padding: 0.35rem 0.9rem;
            border-radius: 100px;
            text-transform: uppercase;
        }

        .gallery-thumbs-swiper {
            margin-top: 1rem;
        }

        .gallery-thumbs-swiper .swiper-slide {
            border-radius: 10px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color .25s, opacity .25s;
            opacity: 0.6;
            aspect-ratio: 1/1;
        }

        .gallery-thumbs-swiper .swiper-slide img {
            height: 100%;
            object-fit: cover;
        }

        .gallery-thumbs-swiper .swiper-slide-thumb-active {
            border-color: var(--saffron);
            opacity: 1;
        }

        /* ── INFO PANEL ── */
        .info-panel {
            background: var(--white);
            border-radius: 20px;
            padding: 2.5rem 2rem;
            box-shadow: var(--shadow);
            height: 100%;
        }

        .tag-row {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }

        .tag {
            font-size: 0.72rem;
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            padding: 0.3rem 0.85rem;
            border-radius: 100px;
        }

        .tag-green {
            background: var(--forest-lt);
            color: var(--forest);
        }

        .tag-orange {
            background: var(--saffron-lt);
            color: var(--saffron-dk);
        }

        .tag-red {
            background: #FEECEC;
            color: #C0392B;
        }

        .product-name {
            font-size: 2.8rem;
            font-weight: 700;
            color: var(--charcoal);
            margin-bottom: 0.4rem;
        }

        .product-meta {
            font-size: 0.9rem;
            color: var(--muted);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
            flex-wrap: wrap;
        }

        .meta-dot {
            width: 4px;
            height: 4px;
            background: var(--border);
            border-radius: 50%;
        }

        .star-row {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            margin-bottom: 1.5rem;
        }

        .stars {
            color: var(--saffron);
            letter-spacing: 2px;
            font-size: 1rem;
        }

        .star-count {
            font-size: 0.85rem;
            color: var(--muted);
        }

        .price-row {
            display: flex;
            align-items: baseline;
            gap: 0.8rem;
            margin-bottom: 0.5rem;
        }

        .price-now {
            font-family: 'Cormorant Garamond', serif;
            font-size: 3rem;
            font-weight: 700;
            color: var(--saffron-dk);
        }

        .price-old {
            font-size: 1.3rem;
            color: #BDBDBD;
            text-decoration: line-through;
        }

        .price-save {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--forest);
            background: var(--forest-lt);
            padding: 0.2rem 0.65rem;
            border-radius: 100px;
        }

        .incl-tax {
            font-size: 0.78rem;
            color: var(--muted);
            margin-bottom: 2rem;
        }

        /* Size picker */
        .size-label {
            font-size: 0.82rem;
            font-weight: 600;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 0.6rem;
        }

        .size-options {
            display: flex;
            gap: 0.6rem;
            margin-bottom: 1.8rem;
            flex-wrap: wrap;
        }

        .size-btn {
            padding: 0.4rem 1.2rem;
            border: 2px solid var(--border);
            border-radius: 100px;
            background: var(--white);
            font-family: 'DM Sans', sans-serif;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--charcoal);
            cursor: pointer;
            transition: all .2s;
        }

        .size-btn:hover,
        .size-btn.active {
            border-color: var(--saffron);
            background: var(--saffron-lt);
            color: var(--saffron-dk);
        }

        /* Qty + CTA */
        .cta-row {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.2rem;
            flex-wrap: wrap;
        }

        .qty-box {
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--border);
            border-radius: 100px;
            overflow: hidden;
            height: 52px;
        }

        .qty-btn {
            width: 46px;
            height: 100%;
            background: none;
            border: none;
            font-size: 1.3rem;
            color: var(--charcoal);
            cursor: pointer;
            transition: background .2s;
        }

        .qty-btn:hover {
            background: var(--saffron-lt);
        }

        .qty-inp {
            width: 46px;
            text-align: center;
            border: none;
            outline: none;
            font-family: 'DM Sans', sans-serif;
            font-size: 1.05rem;
            font-weight: 600;
            background: transparent;
            color: var(--charcoal);
        }

        .btn-cart {
            flex: 1;
            min-width: 160px;
            height: 52px;
            border: none;
            border-radius: 100px;
            background: var(--saffron);
            color: #fff;
            font-family: 'DM Sans', sans-serif;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background .25s, transform .2s, box-shadow .25s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            letter-spacing: 0.02em;
        }

        .btn-cart:hover {
            background: var(--saffron-dk);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(232, 135, 10, 0.35);
        }

        .btn-wishlist {
            width: 52px;
            height: 52px;
            border: 2px solid var(--border);
            border-radius: 50%;
            background: var(--white);
            color: var(--muted);
            font-size: 1.1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all .2s;
        }

        .btn-wishlist:hover {
            border-color: #C0392B;
            color: #C0392B;
            background: #FEECEC;
        }

        .btn-buy {
            width: 100%;
            height: 52px;
            border: 2.5px solid var(--saffron);
            border-radius: 100px;
            background: transparent;
            color: var(--saffron-dk);
            font-family: 'DM Sans', sans-serif;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .25s;
            margin-bottom: 1.8rem;
        }

        .btn-buy:hover {
            background: var(--saffron);
            color: #fff;
        }

        /* Trust strip */
        .trust-strip {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.75rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border);
        }

        .trust-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: 0.4rem;
        }

        .trust-icon {
            width: 40px;
            height: 40px;
            background: var(--saffron-lt);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.15rem;
            color: var(--saffron-dk);
        }

        .trust-lbl {
            font-size: 0.72rem;
            font-weight: 600;
            color: var(--charcoal);
            line-height: 1.3;
        }

        /* ── TABS SECTION ── */
        .tabs-section {
            padding: 4rem 0;
            background: var(--white);
        }

        .section-heading {
            font-size: 2.2rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 2.5rem;
            position: relative;
        }

        .section-heading::after {
            content: '';
            display: block;
            width: 60px;
            height: 3px;
            background: var(--saffron);
            border-radius: 2px;
            margin: 0.7rem auto 0;
        }

        .custom-tabs {
            display: flex;
            gap: 0;
            border-bottom: 2px solid var(--border);
            margin-bottom: 2.5rem;
            overflow-x: auto;
        }

        .custom-tab-btn {
            background: none;
            border: none;
            padding: 0.8rem 1.6rem;
            font-family: 'DM Sans', sans-serif;
            font-size: 0.92rem;
            font-weight: 500;
            color: var(--muted);
            cursor: pointer;
            position: relative;
            white-space: nowrap;
            transition: color .2s;
        }

        .custom-tab-btn::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--saffron);
            transform: scaleX(0);
            transition: transform .25s;
        }

        .custom-tab-btn.active {
            color: var(--saffron-dk);
            font-weight: 600;
        }

        .custom-tab-btn.active::after {
            transform: scaleX(1);
        }

        .tab-pane-custom {
            display: none;
        }

        .tab-pane-custom.active {
            display: block;
            animation: fadeIn .3s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(6px);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .tab-pane-custom h3 {
            font-size: 1.7rem;
            margin-bottom: 1rem;
            color: var(--charcoal);
        }

        .tab-pane-custom p,
        .tab-pane-custom li {
            color: var(--muted);
            font-size: 0.97rem;
        }

        .tab-pane-custom ul {
            padding-left: 1.2rem;
        }

        .tab-pane-custom li {
            margin-bottom: 0.5rem;
        }

        .benefit-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.25rem;
            margin-top: 1rem;
        }

        .benefit-card {
            background: var(--cream);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 1.5rem 1.25rem;
            display: flex;
            gap: 1rem;
            align-items: flex-start;
            transition: box-shadow .2s, transform .2s;
        }

        .benefit-card:hover {
            box-shadow: var(--shadow);
            transform: translateY(-3px);
        }

        .benefit-card .bc-icon {
            width: 44px;
            height: 44px;
            min-width: 44px;
            border-radius: 12px;
            background: var(--saffron-lt);
            color: var(--saffron-dk);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
        }

        .benefit-card .bc-title {
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 0.25rem;
            color: var(--charcoal);
        }

        .benefit-card .bc-body {
            font-size: 0.85rem;
            color: var(--muted);
        }

        /* FAQ accordion */
        .faq-item {
            border-bottom: 1px solid var(--border);
        }

        .faq-question {
            width: 100%;
            background: none;
            border: none;
            text-align: left;
            padding: 1.1rem 0;
            font-family: 'DM Sans', sans-serif;
            font-size: 0.97rem;
            font-weight: 600;
            color: var(--charcoal);
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .faq-question i {
            color: var(--saffron);
            transition: transform .3s;
            font-size: 0.85rem;
        }

        .faq-question.open i {
            transform: rotate(180deg);
        }

        .faq-answer {
            font-size: 0.9rem;
            color: var(--muted);
            max-height: 0;
            overflow: hidden;
            transition: max-height .35s ease, padding .35s;
        }

        .faq-answer.open {
            max-height: 200px;
            padding-bottom: 1rem;
        }

        /* ── PROCESS STRIP ── */
        .process-section {
            padding: 3.5rem 0;
            background: linear-gradient(135deg, #2D5016 0%, #3d6b1f 100%);
            color: #fff;
        }

        .process-section .section-heading {
            color: #fff;
        }

        .process-section .section-heading::after {
            background: var(--saffron);
        }

        .process-steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1.5rem;
            position: relative;
        }

        .process-step {
            text-align: center;
            padding: 1.5rem 1rem;
        }

        .step-num {
            font-family: 'Cormorant Garamond', serif;
            font-size: 3.5rem;
            font-weight: 700;
            color: rgba(255, 255, 255, 0.15);
            line-height: 1;
            margin-bottom: 0.5rem;
        }

        .step-icon {
            font-size: 2rem;
            margin-bottom: 0.75rem;
            color: var(--saffron);
        }

        .step-title {
            font-weight: 600;
            font-size: 1rem;
            margin-bottom: 0.4rem;
        }

        .step-desc {
            font-size: 0.82rem;
            color: rgba(255, 255, 255, 0.7);
        }

        /* ── RELATED ── */
        .related-section {
            padding: 4rem 0;
            background: var(--cream);
        }

        .p-card-mini {
            background: var(--white);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: transform .25s, box-shadow .25s;
            cursor: pointer;
        }

        .p-card-mini:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .p-img-wrap {
            aspect-ratio: 1/1;
            overflow: hidden;
        }

        .p-img-wrap img {
            height: 100%;
            object-fit: cover;
            transition: transform .4s;
        }

        .p-card-mini:hover .p-img-wrap img {
            transform: scale(1.06);
        }

        .p-card-body {
            padding: 1rem 1rem 1.2rem;
        }

        .p-cat {
            font-size: 0.72rem;
            font-weight: 600;
            letter-spacing: 0.07em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 0.3rem;
        }

        .p-name {
            font-family: 'Cormorant Garamond', serif;
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--charcoal);
            margin-bottom: 0.5rem;
        }

        .p-price-row {
            display: flex;
            align-items: baseline;
            gap: 0.5rem;
            margin-bottom: 0.9rem;
        }

        .p-price-now {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--saffron-dk);
        }

        .p-price-old {
            font-size: 0.88rem;
            color: #BDBDBD;
            text-decoration: line-through;
        }

        .p-btn-cart {
            width: 100%;
            height: 40px;
            border: 2px solid var(--saffron);
            border-radius: 100px;
            background: transparent;
            color: var(--saffron-dk);
            font-family: 'DM Sans', sans-serif;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s;
        }

        .p-btn-cart:hover {
            background: var(--saffron);
            color: #fff;
        }

        /* Related swiper nav */
        .related-nav-wrap {
            position: relative;
        }

        .related-section .swiper-button-prev,
        .related-section .swiper-button-next {
            color: var(--saffron);
            background: var(--white);
            width: 42px;
            height: 42px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            top: 40%;
        }

        .related-section .swiper-button-prev::after,
        .related-section .swiper-button-next::after {
            font-size: 0.9rem;
            font-weight: 700;
        }

        /* ── UTILITY ── */
        .container {
            max-width: 1340px;
            margin: 0 auto;
            padding: 0 1.25rem !important;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .col-gallery {
            flex: 0 0 calc(50% - 1rem);
            max-width: calc(50% - 1rem);
        }

        .col-info {
            flex: 0 0 calc(50% - 1rem);
            max-width: calc(50% - 1rem);
        }

        @media (max-width: 900px) {

            .col-gallery,
            .col-info {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .product-name {
                font-size: 2.2rem;
            }

            .trust-strip {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .product-name {
                font-size: 1.9rem;
            }

            .price-now {
                font-size: 2.4rem;
            }

            .cta-row {
                gap: 0.65rem;
            }

            .btn-cart {
                min-width: 130px;
                font-size: 0.9rem;
            }

            .info-panel {
                padding: 1.5rem 1.2rem;
            }
            .container{
                margin-bottom:20px;
                
            }
        }
    </style>

    <style>
        .add-to-cart-btn {

            background-color: #e59e20;
            /* Button background color */
            color: #fff;
            /* White text color */
            font-size: 16px;
            /* Font size */
            padding: 10px 20px;
            /* Padding inside the button */
            border: none;
            /* Remove border */
            border-radius: 24px;
            /* Rounded corners */
            display: flex;
            /* Flex display for icon and text alignment */
            align-items: center;
            /* Align items vertically in the center */
            justify-content: center;
            /* Align items horizontally in the center */
            cursor: pointer;
            /* Pointer cursor on hover */
            transition: background-color 0.3s ease, transform 0.3s ease;
            /* Smooth transition */
        }

        .add-to-cart-btn i {
            margin-right: 8px;
            /* Space between icon and text */
        }

        .add-to-cart-btn:hover {
            background-color: #d88b16;
            /* Darker shade on hover */
            transform: translateY(-2px);
            /* Subtle lift effect on hover */
        }

        .add-to-cart-btn:focus {
            outline: none;
            /* Remove outline on focus */
        }
        
        
        @media (max-width: 1100px) {
    .swiper-outer-wrap {
        padding: 0px !important;
    }
}

@media (max-width: 767px) {
    .login-page {
        padding: 30px 0 60px;
        margin-top: 40px;
    }
}

        /* Global Add to Cart Button Style (Green - Matching request) */
        .pc-cart, .pr-btn, .btn-cart {
            background: #1a5c3a !important; /* Premium Dark Green */
            color: #fff !important;
            border: none !important;
            border-radius: 12px !important;
            font-weight: 700 !important;
            transition: all 0.3s ease !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 8px !important;
            height: 48px !important;
            padding: 0 20px !important;
            cursor: pointer !important;
        }
        .pc-cart:hover, .pr-btn:hover, .btn-cart:hover {
            background: #14452b !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 12px rgba(26, 92, 58, 0.2) !important;
        }

        /* Variant Selection Pills */
        .pc-qty-btn, .pr-meta, .size-btn {
            background: #f8fafc !important;
            color: #475569 !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 20px !important;
            transition: all 0.2s ease !important;
        }

        /* Variant Selection Style */
        .pc-qty-btn.active, .pr-meta.active, .size-btn.active, .shop-meta.active {
            background: #E59E20 !important;
            color: #fff !important;
            border-color: #E59E20 !important;
        }

        /* Quantity Box Consistency */
        .qty-box {
            display: flex !important;
            align-items: center !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 25px !important;
            padding: 4px !important;
            background: #fff !important;
            width: fit-content !important;
        }
        .qty-btn {
            width: 32px !important;
            height: 32px !important;
            border-radius: 50% !important;
            border: none !important;
            background: #f8fafc !important;
            color: #1a5c3a !important;
            font-weight: 700 !important;
            cursor: pointer !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            transition: all 0.2s !important;
        }
        .qty-btn:hover {
            background: #e2e8f0 !important;
        }
        .qty-inp {
            width: 40px !important;
            text-align: center !important;
            border: none !important;
            background: transparent !important;
            font-weight: 700 !important;
            color: #1e293b !important;
            font-size: 15px !important;
            outline: none !important;
        }
        .pr-meta.active, .shop-meta.active {
            background: #E59E20 !important;
            color: #fff !important;
            border-color: #E59E20 !important;
        }
        .pc-qty-btn.active {
            background: #E59E20 !important;
            color: #fff !important;
        }

        /* Wishlist Icon Consistency */
        .pc-wish, .pr-wishlist, .btn-wishlist {
            background: #ffffff !important;
            border: 1px solid #e2e8f0 !important;
            color: #94a3b8 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 50% !important;
            transition: all 0.2s ease !important;
            cursor: pointer !important;
        }
        
        .pc-wish i, .pr-wishlist i, .btn-wishlist i {
            color: #94a3b8 !important;
            transition: all 0.2s ease !important;
        }

        /* Active State (Red Heart) */
        .pc-wish.active i, .pr-wishlist.active i, .btn-wishlist.active i,
        .pc-wish .fa-solid, .pr-wishlist .fa-solid, .btn-wishlist .fa-solid {
            color: #ef4444 !important;
        }

        .pc-wish:hover, .pr-wishlist:hover, .btn-wishlist:hover {
            border-color: #ef4444 !important;
            background: #fff5f5 !important;
        }

        /* Force Outfit font globally */
        body, h1, h2, h3, h4, h5, h6, p, span, a, button, input, label, select, textarea {
            font-family: 'Outfit', 'Poppins', sans-serif !important;
        }
        .font-caveat, .font-caveat * {
            font-family: 'Caveat', cursive !important;
        }
    </style>

    <!-- ==================== HIMALAYAN LUXURY TRAVEL REDESIGN OVERRIDES ==================== -->
    <style>
    /* CSS custom variables override */
    :root {
        --brand-navy: #102A43 !important;
        --brand-dark: #0B1F26 !important;
        --brand-green: #1F4D3A !important;
        --gold: #C6923A !important;
        --gold-hover: #102A43 !important;
        --bg-warm: #F7F8F5 !important;
        --bg-nature: #EEF2ED !important;
        --border-color: #DDE3DD !important;
        --text-muted: #5E6872 !important;
        --text: #102A43 !important;
        --navy: #102A43 !important;
    }

    /* Global Body and Typography */
    body {
        background-color: #F7F8F5 !important;
        color: #5E6872 !important;
        font-family: 'Poppins', 'Sora', sans-serif !important;
        -webkit-font-smoothing: antialiased;
    }
    
    p {
        color: #5E6872 !important;
    }

    h1, h2, h3, h4, h5, h6 {
        font-family: 'Playfair Display', serif !important;
        color: #102A43 !important;
        font-weight: 700 !important;
    }

    /* Keep dark section headings white */
    .bg-navy h1, .bg-navy h2, .bg-navy h3, .bg-navy h4,
    .bg-\[\#102A43\] h1, .bg-\[\#102A43\] h2, .bg-\[\#102A43\] h3,
    .bg-\[\#0B1F26\] h1, .bg-\[\#0B1F26\] h2, .bg-\[\#0B1F26\] h3,
    #contact h1, #contact h2, #contact h3,
    #contact p,
    .text-white h1, .text-white h2, .text-white h3, .text-white h4,
    .heroSwiper .swiper-slide h1, .heroSwiper .swiper-slide h2, .heroSwiper .swiper-slide h3,
    .ct-cta h2, .ct-info-side h2, .ct-form-side h2,
    footer h1, footer h2, footer h3, footer h4,
    .bg-slate-900 h1, .bg-slate-900 h2, .bg-slate-900 h3 {
        color: #ffffff !important;
    }

    /* Category card title explicit color (Original UI layout) */
    #categories .swiper-slide h3,
    #categories .category-name {
        color: #102A43 !important;
    }
    #categories .swiper-slide a.group:hover h3,
    #categories .swiper-slide a.group:hover .category-name {
        color: #cca43b !important;
    }

    /* Small Section Label / Eyebrows */
    section span.font-caveat,
    .max-w-7xl span.font-caveat {
        font-family: 'Sora', sans-serif !important;
        font-size: 13px !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.15em !important;
        color: #C6923A !important;
        display: block !important;
        width: 100% !important;
        margin-bottom: 8px !important;
    }
    
    /* Ensure Swiper slider cursive tag badge stays inline */
    .swiper-slide span.font-caveat {
        font-family: 'Caveat', cursive !important;
        font-size: 2.2rem !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        display: inline-block !important;
        width: auto !important;
        margin-bottom: 0 !important;
        color: #C6923A !important;
    }

    /* Section Background Rhythm mapping */
    #categories { background: #F7F8F5 !important; }
    #destinations { background: #EEF2ED !important; }
    #packages { background: #FFFFFF !important; }
    #why-choose-us { background: #EEF2ED !important; }
    #services { background: #F7F8F5 !important; }
    #route-map { background: #EEF2ED !important; }
    #gallery { background: #FFFFFF !important; }
    #testimonials { background: #EEF2ED !important; }
    #blogs { background: #FFFFFF !important; }
    #faq { background: #F7F8F5 !important; }
    #contact { background: #FFFFFF !important; }

    section > div > div.text-center > h2.font-outfit,
    section > div.text-center > h2.font-outfit,
    section > div > .text-left > h2.font-outfit,
    section > div > .text-center > h2.font-outfit {
        font-family: 'Playfair Display', serif !important;
        font-size: 2.5rem !important;
        color: #102A43 !important;
    }

    @media (max-width: 768px) {
        h1, h2,
        section h2,
        section h2.font-outfit,
        section > div > div.text-center > h2.font-outfit,
        section > div.text-center > h2.font-outfit,
        section > div > .text-left > h2.font-outfit,
        section > div > .text-center > h2.font-outfit,
        .gallery-title,
        .about-heading {
            font-size: 20px !important;
            line-height: 1.35 !important;
        }
    }

    section > div > div.text-center > h2.font-outfit::before,
    section > div > div.text-center > h2.font-outfit::after,
    section > div.text-center > h2.font-outfit::before,
    section > div.text-center > h2.font-outfit::after,
    section > div > .text-left > h2.font-outfit::before,
    section > div > .text-left > h2.font-outfit::after,
    section > div > .text-center > h2.font-outfit::before,
    section > div > .text-center > h2.font-outfit::after {
        background: linear-gradient(to bottom, 
            #102A43 0px, #102A43 1.5px, 
            transparent 1.5px, transparent 3.5px, 
            #C6923A 3.5px, #C6923A 5px
        ) !important;
    }

    /* Global Premium Card Styles (Destinations, Category, Packages, Services, Blogs) */
    .package-card-item, 
    .dest-slide, 
    #why-choose-us .bg-white,
    #services .grid > div,
    #blogs .grid > div {
        background-color: #FFFFFF !important;
        border: 1px solid #DDE3DD !important;
        border-radius: 20px !important;
        box-shadow: 0 10px 30px rgba(16, 42, 67, 0.04) !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }

    /* Card hover translations */
    .package-card-item:hover,
    .dest-slide:hover,
    #services .grid > div:hover,
    #blogs .grid > div:hover {
        transform: translateY(-8px) !important;
        border-color: #C6923A !important;
        box-shadow: 0 20px 40px rgba(16, 42, 67, 0.08) !important;
    }

    /* Card title hover color transition */
    .package-card-item:hover h3,
    .dest-slide:hover h3,
    #services .grid > div:hover h3,
    #blogs .grid > div:hover h3 {
        color: #C6923A !important;
    }

    /* Image zoom in card on hover */
    .package-card-item img,
    .dest-slide img,
    #blogs .grid > div img {
        transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    .package-card-item:hover img,
    .dest-slide:hover img,
    #blogs .grid > div:hover img {
        transform: scale(1.05) !important;
    }

    /* Category Cards - Gold border transition on Hover */
    #categories .swiper-slide a.group > div {
        border: 4px solid #ffffff !important;
        box-shadow: 0 10px 30px rgba(16, 42, 67, 0.05) !important;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    #categories .swiper-slide a.group:hover > div {
        border-color: #C6923A !important;
        box-shadow: 0 18px 36px rgba(198, 146, 58, 0.2) !important;
        transform: translateY(-4px) !important;
    }

    /* Why Choose Us Section Light Theme Overrides */
    #why-choose-us {
        background-color: #EEF2ED !important;
        border-color: #DDE3DD !important;
        padding-bottom: 20px !important;
    }
    #services {
        padding-top: 24px !important;
    }
    #why-choose-us h2.font-outfit::before,
    #why-choose-us h2.font-outfit::after {
        background: linear-gradient(to bottom, 
            #102A43 0px, #102A43 1.5px, 
            transparent 1.5px, transparent 3.5px, 
            #C6923A 3.5px, #C6923A 5px
        ) !important;
    }
    #why-choose-us .bg-white {
        background-color: #ffffff !important;
        border-color: #DDE3DD !important;
        box-shadow: 0 10px 30px rgba(16, 42, 67, 0.04) !important;
    }
    #why-choose-us .bg-white:hover {
        background-color: #ffffff !important;
        border-color: #C6923A !important;
        transform: translateY(-5px) !important;
        box-shadow: 0 20px 40px rgba(16, 42, 67, 0.08) !important;
    }
    #why-choose-us .bg-white span {
        color: #C6923A !important;
    }
    #why-choose-us .bg-white h3 {
        color: #102A43 !important;
    }
    #why-choose-us .bg-white p {
        color: #5E6872 !important;
    }
    #why-choose-us .w-8.h-8.rounded-full {
        background-color: #ffffff !important;
        border-color: #C6923A !important;
        color: #C6923A !important;
    }
    #why-choose-us .group:hover .w-8.h-8.rounded-full {
        background-color: #C6923A !important;
        color: #ffffff !important;
    }
    #why-choose-us .bg-\[\#E5DBC5\] {
        background-color: rgba(198, 146, 58, 0.2) !important;
    }

    /* Buttons Style Redesign */
    /* Primary Buttons */
    .bg-gold,
    .btn-gold,
    #openAddReviewBtn,
    #addReviewForm submit,
    #addReviewForm button[type="submit"],
    a[class*="bg-[#cca43b]"]:not(.get-in-touch-btn),
    button[class*="bg-[#cca43b]"],
    a[class*="bg-gold"]:not(.get-in-touch-btn),
    button[class*="bg-gold"] {
        background: #C6923A !important;
        color: #FFFFFF !important;
        font-family: 'Sora', sans-serif !important;
        font-weight: 700 !important;
        border: none !important;
        box-shadow: 0 8px 20px rgba(198, 146, 58, 0.25) !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    
    .bg-gold:hover,
    .btn-gold:hover,
    #openAddReviewBtn:hover,
    #addReviewForm submit:hover,
    #addReviewForm button[type="submit"]:hover,
    a[class*="bg-[#cca43b]"]:not(.get-in-touch-btn):hover,
    button[class*="bg-[#cca43b]"]:hover,
    a[class*="bg-gold"]:not(.get-in-touch-btn):hover,
    button[class*="bg-gold"]:hover {
        background: #102A43 !important;
        color: #FFFFFF !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 12px 24px rgba(16, 42, 67, 0.3) !important;
    }

    /* Secondary Buttons / Inactive Filter Tabs */
    .btn-secondary,
    a[class*="border-[#cca43b]"]:not(.bg-gold):not(.active),
    button[class*="border-[#cca43b]"]:not(.bg-gold):not(.active),
    .category-tab-btn:not(.active):not(.bg-gold) {
        border: 1.5px solid #102A43 !important;
        color: #102A43 !important;
        background: transparent !important;
        font-family: 'Sora', sans-serif !important;
        font-weight: 700 !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    }
    
    .btn-secondary:hover,
    a[class*="border-[#cca43b]"]:not(.bg-gold):not(.active):hover,
    button[class*="border-[#cca43b]"]:not(.bg-gold):not(.active):hover,
    .category-tab-btn:not(.active):not(.bg-gold):hover {
        background: #102A43 !important;
        color: #FFFFFF !important;
        border-color: #102A43 !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 20px rgba(16, 42, 67, 0.2) !important;
    }

    .category-tab-btn.active {
        background: #cca43b !important;
        color: #ffffff !important;
        border-color: #cca43b !important;
    }

    a.get-in-touch-btn {
        background: #102A43 !important;
        color: #FFFFFF !important;
    }
    a.get-in-touch-btn:hover {
        background: #CCA43B !important;
        color: #FFFFFF !important;
    }
    
    /* Active filter tab button override */
    .category-tab-btn.bg-gold {
        background: #C6923A !important;
        border-color: #C6923A !important;
        color: #FFFFFF !important;
    }

    /* Header & Navigation Overrides */
    .site-header, header {
        background-color: rgba(255, 255, 255, 0.96) !important;
        backdrop-filter: blur(10px) !important;
        border-bottom: 1px solid #DDE3DD !important;
        box-shadow: 0 4px 20px rgba(16, 42, 67, 0.03) !important;
    }
    .site-header a, header a {
        color: #102A43 !important;
        font-weight: 600 !important;
    }
    .site-header a:hover, header a:hover {
        color: #C6923A !important;
    }
    .site-header a.active, header a.active {
        color: #C6923A !important;
        border-bottom-color: #C6923A !important;
    }
    
    /* Ensure Header logo stays visible and appropriately sized */
    .site-header img, header img {
        filter: none !important;
    }

    /* Footer Design Overrides */
    footer, .site-footer {
        background-color: #0B1F26 !important;
        color: #cbd5e1 !important;
        border-top: 1px solid rgba(255, 255, 255, 0.05) !important;
    }
    footer h1, footer h2, footer h3, footer h4, footer h5, footer h6 {
        color: #ffffff !important;
        font-family: 'Playfair Display', serif !important;
    }
    footer a {
        color: #94a3b8 !important;
        transition: color 0.3s ease !important;
    }
    footer a:hover {
        color: #C6923A !important;
    }
    footer span, footer .text-gold {
        color: #C6923A !important;
    }

    /* Testimonials Override */
    #testimonials {
        background-color: #EEF2ED !important;
    }
    #testimonials .bg-white {
        background-color: #ffffff !important;
        border: 1px solid #DDE3DD !important;
        border-radius: 20px !important;
        box-shadow: 0 10px 30px rgba(16, 42, 67, 0.04) !important;
    }

    /* Contact CTA Overrides - Deep Forest Navy bg-[#0B1F26] */
    #contact .bg-gradient-to-r {
        background: #0B1F26 !important;
        border-color: rgba(255, 255, 255, 0.08) !important;
        box-shadow: 0 15px 35px rgba(5, 12, 24, 0.2) !important;
    }
    #contact h2 {
        color: #ffffff !important;
        font-family: 'Playfair Display', serif !important;
    }
    #contact p {
        color: #cbd5e1 !important;
    }
    #contact a {
        background: #C6923A !important;
        color: #ffffff !important;
        box-shadow: 0 8px 20px rgba(198, 146, 58, 0.25) !important;
    }
    #contact a:hover {
        background: #102A43 !important;
        color: #ffffff !important;
        box-shadow: 0 12px 24px rgba(16, 42, 67, 0.3) !important;
    }
    
    /* Fix for buttons inside dark-background cards / widgets */
    .bg-\[\#050c18\]\/90 a[class*="border-[#cca43b]"] {
        border: 1px solid rgba(198, 146, 58, 0.5) !important;
        color: #C6923A !important;
        background: transparent !important;
    }
    
    .bg-\[\#050c18\]\/90 a[class*="border-[#cca43b]"]:hover {
        background-color: #C6923A !important;
        color: #ffffff !important;
        border-color: #C6923A !important;
    }
    
    /* Restore legible soft-gray paragraph color inside dark sections/widgets */
    .bg-navy p,
    .bg-\[\#102A43\] p,
    .bg-\[\#0B1F26\] p,
    [class*="from-[#050c18]"] p,
    [class*="bg-[#050c18]"] p,
    #why-choose-us p,
    #contact p,
    footer p,
    .site-footer p,
    .bg-slate-900 p,
    .bg-\[\#050c18\]\/90 p {
        color: #cbd5e1 !important;
    }

    /* Fix for mobile menu drawer links to prevent them from becoming dark navy */
    #mobileDrawer a {
        color: #f1f5f9 !important;
        font-weight: 500 !important;
    }
    #mobileDrawer a:hover,
    #mobileDrawer a.text-\[\#cca43b\] {
        color: #C6923A !important;
    }
    </style>

    <!-- Frontend HEIC Image Renderer Fallback -->
    <script src="{{ asset('Website/assets/js/heic2any.min.js') }}"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            function convertHeicImages() {
                var imgs = document.querySelectorAll('img');
                imgs.forEach(function (img) {
                    if (img._heicProcessed) return;
                    var src = img.getAttribute('src') || '';
                    if (src.toLowerCase().includes('.heic') || src.toLowerCase().includes('.heif')) {
                        img._heicProcessed = true;
                        if (typeof heic2any === 'function') {
                            fetch(src)
                                .then(function(res) { return res.blob(); })
                                .then(function(rawBlob) {
                                    var heicBlob = new Blob([rawBlob], { type: 'image/heic' });
                                    return heic2any({ blob: heicBlob, toType: 'image/jpeg', quality: 0.88 });
                                })
                                .then(function(conversionResult) {
                                    var resultBlob = Array.isArray(conversionResult) ? conversionResult[0] : conversionResult;
                                    img.src = URL.createObjectURL(resultBlob);
                                })
                                .catch(function(err) {
                                    console.warn('Frontend HEIC conversion failed for', src, err);
                                });
                        }
                    }
                });
            }
            convertHeicImages();
            setTimeout(convertHeicImages, 1200);
        });
    </script>
    <style>
        body {
            opacity: 0;
        }
        body.tailwind-ready {
            opacity: 1;
            transition: opacity 0.12s ease-in-out;
        }
    </style>
    <script>
        (function() {
            var timeout = setTimeout(function() {
                if (document.body) {
                    document.body.classList.add('tailwind-ready');
                } else {
                    document.addEventListener("DOMContentLoaded", function() {
                        document.body.classList.add('tailwind-ready');
                    });
                }
            }, 1200); // Fail-safe: 1.2 seconds max blank screen

            function checkTailwind() {
                if (window.tailwind && document.body) {
                    clearTimeout(timeout);
                    document.body.classList.add('tailwind-ready');
                } else {
                    setTimeout(checkTailwind, 10);
                }
            }
            checkTailwind();
        })();
    </script>
</head>

<body>