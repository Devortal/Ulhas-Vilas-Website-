@include('Website.includes.CssLink')
@include('Website.includes.Header')

@php
    if (!isset($packages) || count($packages) == 0) {
        $packages = DB::table('packages')->whereIn('status', [1, '1'])->orderBy('id', 'desc')->get();
    }
@endphp

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
    .contact-page {
        --navy: #050c18;
        --navy2: #0d1b3a;
        --gold: #cca43b;
        --gold2: #b08b2d;
        --text: #4a5568;
        --muted: #718096;
        --line: rgba(204,164,59,0.18);
        --soft: #faf6ee;
        color: var(--navy);
        background: radial-gradient(circle at 50% 50%, rgba(250, 246, 238, 0.45) 0%, rgba(246, 247, 251, 1) 100%) !important;
        font-family: 'Outfit', sans-serif;
        position: relative;
        overflow: hidden;
    }
    .contact-page * { box-sizing: border-box; }

    /* Premium background glow blobs */
    .contact-page::before {
        content: "";
        position: absolute;
        width: 500px;
        height: 500px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(204,164,59,0.08) 0%, transparent 70%);
        top: 20%;
        right: -150px;
        z-index: 0;
        pointer-events: none;
    }
    .contact-page::after {
        content: "";
        position: absolute;
        width: 600px;
        height: 600px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(5,12,24,0.04) 0%, transparent 70%);
        bottom: 5%;
        left: -200px;
        z-index: 0;
        pointer-events: none;
    }

    /* ── HERO ── */
    .ct-hero {
        padding: 95px 0 90px;
        border-bottom: 1px solid rgba(204, 164, 59, 0.25);
        background: linear-gradient(180deg, rgba(5, 12, 24, 0.78) 0%, rgba(5, 12, 24, 0.55) 100%), url('{{ asset("Website/assets/images/hero/hero_bg.png") }}') center center/cover no-repeat !important;
        color: #ffffff;
        position: relative;
        overflow: hidden;
    }

    .ct-hero::after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--gold), transparent);
    }

    .ct-breadcrumb {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 10px;
        color: #a0aec0;
        font-size: 13px;
        font-weight: 700;
    }

    .ct-breadcrumb a {
        color: var(--gold);
        text-decoration: none;
    }

    .ct-hero-tagline {
        font-family: 'Caveat', cursive !important;
        color: var(--gold) !important;
        font-size: 28px !important;
        font-weight: 500 !important;
        letter-spacing: 0.5px;
        margin-bottom: 6px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .ct-hero h1 {
        margin: 0;
        color: #ffffff !important;
        font-family: 'Outfit', sans-serif !important;
        font-size: clamp(34px, 4.2vw, 56px) !important;
        font-weight: 800 !important;
        line-height: 1.15 !important;
        letter-spacing: -0.025em !important;
    }

    .ct-hero h1 span { color: var(--gold) !important; }

    .ct-hero p {
        max-width: 760px;
        margin: 14px 0 0;
        color: #e2e8f0 !important;
        font-size: 15.5px;
        line-height: 1.65;
    }
    .ct-hero-btns {
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
    }
    .ct-hero-btn {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        padding: 13px 24px;
        border-radius: 8px;
        font-family: 'Outfit', sans-serif;
        font-size: 14px;
        font-weight: 700;
        text-decoration: none;
        transition: all .25s ease;
        cursor: pointer;
        border: none;
    }
    .ct-hero-btn-gold {
        background: var(--gold);
        color: #fff;
    }
    .ct-hero-btn-gold:hover {
        background: var(--gold2);
        transform: translateY(-2px);
        color: #fff;
    }
    .ct-hero-btn-outline {
        background: transparent;
        border: 2px solid rgba(255,255,255,0.5);
        color: #fff;
    }
    .ct-hero-btn-outline:hover {
        border-color: var(--gold);
        color: var(--gold);
        transform: translateY(-2px);
    }

    /* ── MAIN BODY ── */
    .ct-shell {
        max-width: 1280px;
        margin: 0 auto;
        padding: 0 24px;
    }

    /* ── TWO COLUMN SPLIT ── */
    .ct-split {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0;
        background: #fff;
        box-shadow: 0 20px 50px rgba(5,12,24,0.08) !important;
        border-radius: 24px !important;
        margin: -60px auto 80px !important;
        max-width: 1200px !important;
        width: calc(100% - 48px) !important;
        overflow: hidden !important;
        border: 1px solid rgba(204, 164, 59, 0.15) !important;
        position: relative;
        z-index: 10;
    }
    @media(max-width:900px){
        .ct-split {
            grid-template-columns: 1fr;
            margin: 20px auto 50px !important;
            width: calc(100% - 32px) !important;
        }
    }

    /* LEFT INFO SIDE */
    .ct-info-side {
        padding: 55px 48px;
        background: #fff;
        border-right: 1px solid var(--line);
    }
    .ct-section-tag {
        display: inline-block;
        font-size: 11.5px;
        font-weight: 800;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: var(--gold);
        margin-bottom: 10px;
    }
    .ct-section-tag::before {
        content: '— ';
    }
    .ct-info-side h2 {
        font-family: 'Outfit', sans-serif !important;
        font-size: clamp(28px, 3.2vw, 38px) !important;
        font-weight: 800 !important;
        color: var(--navy) !important;
        margin: 0 0 16px;
        line-height: 1.25 !important;
        letter-spacing: -0.02em !important;
    }
    .ct-info-side h2 span { color: var(--gold) !important; }
    .ct-info-side > p {
        color: var(--text) !important;
        font-size: 15.5px !important;
        line-height: 1.75 !important;
        margin: 0 0 36px;
        max-width: 380px;
    }
    .ct-info-list {
        display: flex;
        flex-direction: column;
        gap: 26px;
    }
    .ct-info-row {
        display: flex;
        align-items: flex-start;
        gap: 18px;
    }
    .ct-info-icon {
        width: 46px;
        height: 46px;
        flex-shrink: 0;
        border-radius: 50%;
        background: var(--soft);
        border: 2px solid var(--line);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gold);
        font-size: 17px;
        margin-top: 2px;
    }
    .ct-info-text h5 {
        margin: 0 0 4px;
        font-size: 13px;
        font-weight: 800;
        color: var(--navy);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .ct-info-text p,
    .ct-info-text a {
        margin: 0;
        font-size: 14.5px;
        color: var(--text);
        line-height: 1.55;
        text-decoration: none;
        word-break: break-word !important;
        overflow-wrap: break-word !important;
    }
    .ct-info-text a:hover { color: var(--gold); }

    /* RIGHT FORM SIDE */
    .ct-form-side {
        padding: 55px 48px;
        background: #f9fafb;
    }
    .ct-form-side h2 {
        font-family: 'Outfit', sans-serif !important;
        font-size: clamp(28px, 3.2vw, 38px) !important;
        font-weight: 800 !important;
        color: var(--navy) !important;
        margin: 0 0 30px;
        line-height: 1.25 !important;
        letter-spacing: -0.02em !important;
    }
    .ct-form-side h2 span { color: var(--gold) !important; }

    .ct-row2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    @media(max-width:600px){ .ct-row2{ grid-template-columns:1fr; } }

    .ct-fgroup {
        margin-bottom: 16px;
    }
    .ct-input-wrap {
        position: relative;
    }
    .ct-input-wrap i {
        position: absolute;
        top: 50%;
        left: 16px;
        transform: translateY(-50%);
        color: var(--muted);
        font-size: 14px;
        pointer-events: none;
        transition: color .2s;
    }
    .ct-input-wrap.ta-wrap i {
        top: 17px;
        transform: none;
    }
    .ct-input {
        width: 100%;
        height: 52px;
        border: 1.5px solid #e2e8f0;
        border-radius: 8px;
        background: #fff;
        padding: 0 16px 0 44px;
        font-family: 'Outfit', sans-serif;
        font-size: 14.5px;
        color: var(--navy);
        font-weight: 500;
        outline: none;
        transition: border-color .2s, box-shadow .2s;
        -webkit-appearance: none;
    }
    .ct-input::placeholder { color: #b0bec5; }
    .ct-input:focus {
        border-color: var(--gold);
        box-shadow: 0 0 0 3px rgba(204,164,59,0.12);
    }
    .ct-input:focus ~ i,
    .ct-input-wrap:focus-within i {
        color: var(--gold);
    }
    .ct-input.ta {
        height: 130px;
        padding-top: 14px;
        resize: vertical;
    }
    .ct-input.is-invalid {
        border-color: #e53e3e !important;
    }
    .ct-error {
        display: block;
        color: #e53e3e;
        font-size: 11.5px;
        font-weight: 600;
        margin-top: 4px;
        min-height: 16px;
    }
    .ct-submit {
        width: 100%;
        height: 54px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        border: none;
        border-radius: 8px;
        background: var(--gold);
        color: #fff;
        font-family: 'Outfit', sans-serif;
        font-size: 15px;
        font-weight: 700;
        cursor: pointer;
        transition: all .25s ease;
        box-shadow: 0 6px 20px rgba(204,164,59,0.30);
        margin-top: 6px;
    }
    .ct-submit:hover {
        background: var(--gold2);
        transform: translateY(-2px);
        box-shadow: 0 10px 28px rgba(204,164,59,0.40);
    }
    .ct-submit:disabled { opacity:.7; cursor:not-allowed; transform:none; }

    /* ── MAP SECTION ── */
    .ct-map-section {
        margin: 0;
        display: grid;
        grid-template-columns: 320px 1fr;
        border-top: 1px solid var(--line);
        background: #fff;
    }
    @media(max-width:768px){
        .ct-map-section { grid-template-columns:1fr; }
    }
    .ct-map-info {
        padding: 40px 36px;
        border-right: 1px solid var(--line);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .ct-map-info-top h4 {
        font-size: 16px;
        font-weight: 800;
        color: var(--navy);
        margin: 0 0 8px;
    }
    .ct-map-info-top p {
        font-size: 14px;
        color: var(--text);
        line-height: 1.6;
        margin: 0;
    }
    .ct-dir-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 22px;
        background: var(--navy);
        color: #fff;
        border-radius: 8px;
        font-family: 'Outfit', sans-serif;
        font-size: 14px;
        font-weight: 700;
        text-decoration: none;
        margin-top: 24px;
        transition: all .25s ease;
    }
    .ct-dir-btn:hover {
        background: var(--gold);
        color: #fff;
    }
    .ct-map-embed iframe {
        width: 100%;
        height: 340px;
        border: none;
        display: block;
    }

    /* ── BOTTOM CTA ── */
    .ct-cta {
        background: linear-gradient(135deg, #050c18 0%, #0d1b3a 100%);
        padding: 60px 32px;
        text-align: center;
        position: relative;
        overflow: hidden;
    }
    .ct-cta::before {
        content: '';
        position: absolute;
        width: 400px; height: 400px;
        top: -150px; left: -100px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(204,164,59,0.10) 0%, transparent 70%);
        pointer-events: none;
    }
    .ct-cta::after {
        content: '';
        position: absolute;
        width: 300px; height: 300px;
        bottom: -100px; right: -80px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(204,164,59,0.08) 0%, transparent 70%);
        pointer-events: none;
    }
    .ct-cta-inner { position: relative; z-index:2; max-width: 640px; margin: 0 auto; }
    .ct-cta h2 {
        font-size: clamp(26px,4vw,40px);
        font-weight: 800;
        color: #fff;
        margin: 0 0 14px;
    }
    .ct-cta h2 span { color: var(--gold); }
    .ct-cta p {
        color: rgba(255,255,255,0.70);
        font-size: 15.5px;
        line-height: 1.6;
        margin: 0 0 30px;
    }
    .ct-cta-btn {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 14px 32px;
        background: var(--gold);
        color: #fff;
        border-radius: 8px;
        font-family: 'Outfit', sans-serif;
        font-size: 15px;
        font-weight: 700;
        text-decoration: none;
        transition: all .25s ease;
        box-shadow: 0 6px 20px rgba(204,164,59,0.35);
    }
    .ct-cta-btn:hover {
        background: var(--gold2);
        transform: translateY(-3px);
        color: #fff;
    }

    /* ── TOAST ── */
    .ct-toast {
        position: fixed;
        bottom: 28px; right: 28px;
        z-index: 9999;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 22px;
        background: #050c18;
        color: #fff;
        border-left: 4px solid var(--gold);
        border-radius: 10px;
        box-shadow: 0 12px 32px rgba(5,12,24,0.3);
        font-family: 'Outfit', sans-serif;
        font-size: 14px;
        font-weight: 600;
        transform: translateY(80px);
        opacity: 0;
        transition: all .4s cubic-bezier(.175,.885,.32,1.275);
    }
    .ct-toast.show { transform: translateY(0); opacity: 1; }
    .ct-toast i { color: var(--gold); font-size: 18px; }

    /* ── RESPONSIVE OVERRIDES ── */
    @media (max-width: 768px) {
        .ct-hero {
            padding: 80px 0 60px !important;
        }
        .ct-hero h1 {
            font-size: clamp(28px, 5vw, 42px) !important;
        }
        .ct-hero p {
            font-size: 14px !important;
        }
        .ct-info-side, 
        .ct-form-side {
            padding: 40px 24px !important;
        }
        .ct-info-side h2,
        .ct-form-side h2 {
            font-size: clamp(22px, 4vw, 28px) !important;
            margin-bottom: 20px !important;
        }
        .ct-row2 {
            grid-template-columns: 1fr !important;
            gap: 12px !important;
        }
        .ct-info-list {
            gap: 20px !important;
        }
        .ct-info-row {
            gap: 14px !important;
        }
        .ct-info-icon {
            width: 40px !important;
            height: 40px !important;
            font-size: 15px !important;
        }
        .ct-map-info {
            padding: 30px 24px !important;
            border-right: none !important;
            border-bottom: 1px solid var(--line) !important;
        }
        .ct-map-embed iframe {
            height: 280px !important;
        }
    }
</style>

<!-- TOAST -->
<div class="ct-toast" id="ctToast">
    <i class="fa-solid fa-circle-check"></i>
    <span>Message sent! We'll contact you shortly.</span>
</div>

<main class="contact-page">

    <!-- ── HERO ── -->
    <section class="ct-hero">
        <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10 w-full">
            <div class="ct-breadcrumb">
                <a href="{{ url('/') }}">Home</a>
                <span>/</span>
                <span>Contact & Inquiries</span>
            </div>
            <div class="ct-hero-tagline">
                <span>Private Estate Concierge</span>
                <i class="fa-solid fa-gem text-gold text-xs"></i>
            </div>
            <h1>Connect With <span class="text-gold">Ulhas Vilas</span></h1>
            <p>
                Schedule a private walkthrough or inquire about customized residence allocations in the serene highlands of Himachal Pradesh.
            </p>
        </div>
    </section>

    <!-- ── SPLIT: INFO + FORM ── -->
    <div class="ct-split">

        <!-- LEFT: INFO -->
        <div class="ct-info-side">
            <div class="ct-section-tag">Private Concierge</div>
            <h2>Schedule A <span>Private Consultation</span></h2>
            <p>Our senior estate management team offers discreet, personalized advisory for buyers, investors, and guests seeking architectural excellence.</p>

            <div class="ct-info-list">
                <div class="ct-info-row">
                    <div class="ct-info-icon"><i class="fa-solid fa-location-dot"></i></div>
                    <div class="ct-info-text">
                        <h5>Estate Location</h5>
                        <p>{!! nl2br(e($info->address ?? "Shimla Highway, Himachal Pradesh,\nIndia – 171001")) !!}</p>
                    </div>
                </div>
                <div class="ct-info-row">
                    <div class="ct-info-icon"><i class="fa-solid fa-phone-volume"></i></div>
                    <div class="ct-info-text">
                        <h5>Concierge Line</h5>
                        <p><a href="tel:{{ $info->mobile ?? '+919876543210' }}">{{ $info->mobile ?? '+91 98765 43210' }}</a></p>
                        <p style="color:#a0aec0;font-size:13px;">Direct private desk</p>
                    </div>
                </div>
                <div class="ct-info-row">
                    <div class="ct-info-icon"><i class="fa-solid fa-envelope-open-text"></i></div>
                    <div class="ct-info-text">
                        <h5>Direct Email</h5>
                        <p><a href="mailto:{{ $info->email ?? 'enquiries@ulhasvilas.com' }}">{{ $info->email ?? 'enquiries@ulhasvilas.com' }}</a></p>
                        <p style="color:#a0aec0;font-size:13px;">Private inquiry response</p>
                    </div>
                </div>
                <div class="ct-info-row">
                    <div class="ct-info-icon"><i class="fa-regular fa-clock"></i></div>
                    <div class="ct-info-text">
                        <h5>Concierge Hours</h5>
                        <p>{{ $info->office_time ?? 'Mon – Sun: 9:00 AM – 8:00 PM' }}</p>
                        <p style="color:#a0aec0;font-size:13px;">7 days a week</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT: FORM -->
        <div class="ct-form-side">
            <div class="ct-section-tag">Express Interest</div>
            <h2>Register Your <span>Residence Inquiry</span></h2>

            <form id="add_form" action="javascript:void(0);" method="POST">
                @csrf
                <div class="ct-fgroup">
                    <label style="font-size:12px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;color:#475569;margin-bottom:6px;display:block;">Full Name</label>
                    <div class="ct-input-wrap">
                        <input type="text" name="name" id="name" class="ct-input" placeholder="e.g. Alexander Wright" required>
                        <i class="fa-regular fa-user"></i>
                    </div>
                    <span id="name_error" class="ct-error"></span>
                </div>

                <div class="ct-row2">
                    <div class="ct-fgroup">
                        <label style="font-size:12px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;color:#475569;margin-bottom:6px;display:block;">Phone Number</label>
                        <div class="ct-input-wrap">
                            <input type="tel" name="mobile" id="mobile" class="ct-input" placeholder="+91 98765 00000" required>
                            <i class="fa-solid fa-phone"></i>
                        </div>
                        <span id="mobile_error" class="ct-error"></span>
                    </div>
                    <div class="ct-fgroup">
                        <label style="font-size:12px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;color:#475569;margin-bottom:6px;display:block;">Email Address</label>
                        <div class="ct-input-wrap">
                            <input type="email" name="email" id="email" class="ct-input" placeholder="alexander@example.com" required>
                            <i class="fa-regular fa-envelope"></i>
                        </div>
                        <span id="email_error" class="ct-error"></span>
                    </div>
                </div>

                <div class="ct-fgroup">
                    <label style="font-size:12px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;color:#475569;margin-bottom:6px;display:block;">Residence Preference</label>
                    <div class="ct-input-wrap">
                        <select name="residence_id" id="residence_id" class="ct-input" style="padding-left:44px;cursor:pointer;">
                            <option value="">Select Residence Interest</option>
                            @if(isset($residences) && count($residences) > 0)
                                @foreach($residences as $res)
                                    <option value="{{ $res->id }}">{{ $res->name }}</option>
                                @endforeach
                            @else
                                <option value="1">1 BHK Villa Residence</option>
                                <option value="2">2 BHK Luxury Villa</option>
                                <option value="3">3 BHK Signature Villa</option>
                                <option value="4">4 BHK Grand Penthouse</option>
                            @endif
                        </select>
                        <i class="fa-solid fa-house-chimney"></i>
                    </div>
                </div>

                <div class="ct-fgroup">
                    <label style="font-size:12px;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;color:#475569;margin-bottom:6px;display:block;">Message / Specific Preferences</label>
                    <div class="ct-input-wrap ta-wrap">
                        <textarea name="message" class="ct-input ta" placeholder="Tell us about your timeframe or specific requirements..." rows="4"></textarea>
                        <i class="fa-regular fa-comment-dots"></i>
                    </div>
                </div>

                <button type="submit" class="ct-submit" id="ctSubmitBtn">
                    Submit Inquiry &nbsp;<i class="fa-solid fa-paper-plane"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- ── MAP SECTION ── -->
    <div class="ct-map-section">
        <div class="ct-map-info">
            <div class="ct-map-info-top">
                <h4>The Ulhas Vilas Estates</h4>
                <p>{!! nl2br(e($info->address ?? "Shimla Highway, Himachal Pradesh,\nIndia – 171001")) !!}</p>
            </div>
            <a href="{{ $info->map_link ?? 'https://maps.google.com' }}" target="_blank" class="ct-dir-btn">
                Get Directions <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
        <div class="ct-map-embed">
            <iframe
                src="{{ $info->map_link ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d54408.31576396063!2d77.12993705!3d32.2431996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3904831b0816eac7%3A0xb47cfa14a31ed14!2sShimla%2C%20Himachal%20Pradesh!5e0!3m2!1sen!2sin!4v1692000000000!5m2!1sen!2sin' }}"
                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>

    <!-- ── CTA BANNER ── -->
    <div class="ct-cta">
        <div class="ct-cta-inner">
            <h2>Ready to Start <span>Your Journey?</span></h2>
            <p>Explore the beauty of Himachal Pradesh with our expertly curated tour packages.</p>
            <a href="{{ url('/product') }}" class="ct-cta-btn">
                Plan Your Trip &nbsp;<i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
    </div>

</main>

@include('Website.includes.JsLink')
@include('Website.includes.Footer')

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
    function showToast(){
        var t=document.getElementById('ctToast');
        t.classList.add('show');
        setTimeout(function(){ t.classList.remove('show'); },4000);
    }
    function validateName(){
        var v=$("#name").val();
        if(v.length>0&&v.length<3){ $("#name_error").text("Name must be at least 3 characters"); $("#name").addClass("is-invalid"); return false; }
        $("#name_error").text(""); $("#name").removeClass("is-invalid"); return true;
    }
    function validateEmail(){
        var v=$("#email").val(), r=/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if(v.length>0&&!r.test(v)){ $("#email_error").text("Enter a valid email"); $("#email").addClass("is-invalid"); return false; }
        $("#email_error").text(""); $("#email").removeClass("is-invalid"); return true;
    }
    function validateMobile(){
        var v=$("#mobile").val();
        if(v.length>0&&v.length!=10){ $("#mobile_error").text("Mobile must be 10 digits"); $("#mobile").addClass("is-invalid"); return false; }
        $("#mobile_error").text(""); $("#mobile").removeClass("is-invalid"); return true;
    }
    $("#name").on("input",validateName);
    $("#email").on("input",validateEmail);
    $("#mobile").on("input",validateMobile);
    $("#add_form").submit(function(e){
        e.preventDefault();
        if(!validateName()||$("#name").val().length<3){ validateName(); return; }
        if(!validateEmail()){ validateEmail(); return; }
        if(!validateMobile()||$("#mobile").val().length!=10){ validateMobile(); return; }
        var btn=$("#ctSubmitBtn"), orig=btn.html();
        btn.prop('disabled',true).html('<i class="fa-solid fa-spinner fa-spin"></i> Sending...');
        $.ajax({
            type:"POST", url:"{{ url('/contact_submit') }}", data:new FormData(this),
            contentType:false, cache:false, processData:false, dataType:"json",
            success:function(d){
                if(d.success === true || d.success === 'success'){ 
                    document.getElementById("add_form").reset(); 
                    showToast(); 
                }
                else swal({title:"Error",text:d.message || "Failed to submit enquiry",icon:"error",timer:2500,buttons:false});
            },
            error:function(xhr){
                var m=xhr.responseJSON&&xhr.responseJSON.message?xhr.responseJSON.message:"Something went wrong!";
                swal({title:"Error",text:m,icon:"error",timer:2500,buttons:false});
            },
            complete:function(){ btn.prop('disabled',false).html(orig); }
        });
    });
</script>