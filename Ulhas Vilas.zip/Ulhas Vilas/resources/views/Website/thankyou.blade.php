<script>
    if (!sessionStorage.getItem('allow_thankyou')) {
        window.location.replace("{{ url('/contact') }}");
    } else {
        sessionStorage.removeItem('allow_thankyou');
    }
</script>

@include('Website.includes.CssLink')
@include('Website.includes.Header')

<style>
    .thankyou-section {
        min-height: 82vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 150px 24px 90px 24px;
        background: radial-gradient(circle at 50% 20%, #0d2238 0%, #060e18 100%);
        position: relative;
        overflow: hidden;
    }

    .thankyou-section::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: url("{{ asset('Website/assets/images/WhatsApp Image 2026-08-18 at 5.00.20 PM.jpeg') }}") center center / cover no-repeat;
        opacity: 0.08;
        pointer-events: none;
    }

    .thankyou-card {
        max-width: 1220px;
        width: 100%;
        background: #ffffff;
        border-radius: 28px;
        padding: 48px 52px;
        box-shadow: 0 35px 80px rgba(0, 0, 0, 0.5);
        border: 1.5px solid rgba(204, 164, 59, 0.45);
        position: relative;
        z-index: 2;
        animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .thankyou-grid {
        display: grid;
        grid-template-columns: 0.85fr 1.35fr;
        gap: 45px;
        align-items: center;
    }

    .success-icon-wrap {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(204, 164, 59, 0.18) 0%, rgba(204, 164, 59, 0.08) 100%);
        border: 2px solid #cca43b;
        color: #cca43b;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 20px rgba(204, 164, 59, 0.2);
        vertical-align: middle;
        margin-right: 12px;
    }

    .thankyou-pill {
        display: inline-block;
        padding: 4px 14px;
        background: rgba(204, 164, 59, 0.12);
        border: 1px solid #cca43b;
        border-radius: 30px;
        font-size: 10.5px;
        font-weight: 800;
        letter-spacing: 1.8px;
        text-transform: uppercase;
        color: #8f6f1c;
        margin-bottom: 10px;
    }

    .thankyou-title {
        font-family: 'Marcellus', Georgia, serif;
        font-size: 28px;
        font-weight: 700;
        color: #071524;
        margin: 0 0 10px 0;
        line-height: 1.25;
        letter-spacing: 0.5px;
    }

    .thankyou-sub {
        font-size: 14px;
        line-height: 1.65;
        color: #556980;
        margin: 0 0 24px 0;
    }

    /* Luxury Brochure Download Box - Expanded Width & Padding */
    .brochure-download-card {
        background: linear-gradient(135deg, #071524 0%, #112842 100%);
        border-radius: 20px;
        padding: 38px 42px;
        border: 1.5px solid rgba(204, 164, 59, 0.45);
        box-shadow: 0 16px 36px rgba(7, 21, 36, 0.3);
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        width: 100%;
        box-sizing: border-box;
    }

    .brochure-badge {
        font-size: 11px;
        font-weight: 800;
        color: #e8c96a;
        letter-spacing: 2px;
        text-transform: uppercase;
        margin-bottom: 10px;
    }

    .brochure-heading {
        color: #ffffff;
        font-family: 'Marcellus', Georgia, serif;
        font-size: 22px;
        margin: 0 0 10px 0;
        letter-spacing: 0.5px;
        line-height: 1.3;
    }

    .brochure-desc {
        color: #cbd5e1;
        font-size: 13.5px;
        line-height: 1.6;
        margin: 0 0 24px 0;
    }

    .download-gold-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        background: linear-gradient(135deg, #c99e32 0%, #f3d782 50%, #c99e32 100%);
        color: #071524;
        font-weight: 800;
        font-size: 13px;
        letter-spacing: 1.2px;
        text-transform: uppercase;
        padding: 15px 32px;
        border-radius: 50px;
        text-decoration: none;
        box-shadow: 0 6px 18px rgba(201, 158, 50, 0.35);
        transition: all 0.3s ease;
        width: 100%;
        box-sizing: border-box;
    }

    .download-gold-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 22px rgba(201, 158, 50, 0.5);
        color: #000;
    }

    /* Actions Navigation */
    .thankyou-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    .action-link-btn {
        padding: 11px 22px;
        border-radius: 50px;
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .action-link-btn.primary {
        background: #071524;
        color: #ffffff;
        border: 1px solid #071524;
    }

    .action-link-btn.primary:hover {
        background: #cca43b;
        border-color: #cca43b;
        color: #071524;
    }

    .action-link-btn.secondary {
        background: transparent;
        color: #071524;
        border: 1.5px solid #cbd5e1;
    }

    .action-link-btn.secondary:hover {
        border-color: #071524;
        background: #f8fafc;
    }

    @media (max-width: 860px) {
        .thankyou-section {
            padding: 130px 20px 60px 20px;
            min-height: auto;
        }
        .thankyou-grid {
            grid-template-columns: 1fr;
            gap: 28px;
        }
        .thankyou-card {
            padding: 36px 26px;
        }
        .thankyou-title {
            font-size: 24px;
        }
    }

    @media (max-width: 640px) {
        .thankyou-section {
            padding: 115px 15px 50px 15px;
        }
        .action-link-btn {
            width: 100%;
            justify-content: center;
        }
    }

    .footer-newsletter-banner {
        display: none !important;
    }
</style>

<section class="thankyou-section">
    <div class="thankyou-card">
        <div class="thankyou-grid">
            
            <!-- Left Column: Message & Navigation -->
            <div>
                <div style="display: flex; align-items: center; margin-bottom: 12px;">
                    <div class="success-icon-wrap">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>
                    <div class="thankyou-pill">ENQUIRY RECEIVED</div>
                </div>

                <!-- Heading -->
                <h1 class="thankyou-title">Thank You For Reaching Out</h1>

                <!-- Subtitle -->
                <p class="thankyou-sub">
                    We have received your enquiry. Our private client relationship concierge will connect with you shortly. A confirmation email with project highlights has also been sent to your inbox.
                </p>

                <!-- Action Links -->
                <div class="thankyou-actions">
                    <a href="{{ url('/residences') }}" class="action-link-btn primary">
                        Explore Residences &rarr;
                    </a>
                    <a href="{{ url('/') }}" class="action-link-btn secondary">
                        Back to Homepage
                    </a>
                </div>
            </div>

            <!-- Right Column: Brochure Download Box -->
            <div>
                <div class="brochure-download-card">
                    <div class="brochure-badge">OFFICIAL PRESENTATION &bull; {{ $brochure_type ?? 'PDF' }}</div>
                    <h3 class="brochure-heading">Estate Architectural Brochure &amp; Floor Plans</h3>
                    <p class="brochure-desc">
                        Explore master layouts, valley-facing decks, suite dimensions, and wellness amenities.
                    </p>
                    <a href="{{ url('/download-brochure') }}" class="download-gold-btn">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                        <span>DOWNLOAD OFFICIAL BROCHURE ({{ $brochure_type ?? 'PDF' }})</span>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

@include('Website.includes.Footer')
@include('Website.includes.JsLink')
