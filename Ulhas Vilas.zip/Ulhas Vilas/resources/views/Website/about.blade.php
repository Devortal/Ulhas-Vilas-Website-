@include('Website.includes.CssLink')

    <!-- =========================================================
         PAGE SPECIFIC CSS: ABOUT US (DEEP EMERALD LUXURY THEME)
    ========================================================= -->
    <style>
    .about-polaroid-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
     filter:none !important;
    transition: filter 0.4s ease, transform 0.6s ease;
}

    :root {
        --about-bg-dark: #081B15;
        --about-bg-darker: #05130E;
        --about-bg-card: rgba(16, 43, 34, 0.45);
        --about-text-light: #F6F4EE;
        --about-text-muted: rgba(246, 244, 238, 0.78);
        --about-accent-gold: #DCB658;
        --about-accent-peach: #D3A794;
        --about-border-subtle: rgba(255, 255, 255, 0.16);
    }

    .about-page-body {
        background-color: var(--about-bg-dark);
        color: var(--about-text-light);
        font-family: var(--font-body);
        overflow-x: hidden;
        min-height: 100vh;
    }

    /* ══════════════════════════════════════════════════════════
       1. HERO SECTION ("the RESPIRE STORY" STYLE LAYOUT)
    ══════════════════════════════════════════════════════════ */
    /* ══════════════════════════════════════════════════════════
       1. HERO SECTION (ULTRA-LUXURY CINEMATIC SHOWCASE)
    ══════════════════════════════════════════════════════════ */
    .about-hero-section {
        position: relative;
        background: #06090A;
        padding: 11.5rem 1.75rem 6.5rem;
        overflow: hidden;
        min-height: 96vh;
        display: flex;
        align-items: center;
    }

    .about-hero-video-wrapper {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
        background-color: #0b0e12;
        background-image: url('{{ asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg') }}');
        background-size: cover;
        background-position: center;
    }

    .about-hero-bg-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 1;
        filter: brightness(1.04) contrast(1.04) saturate(1.05);
        transform: scale(1.02);
    }

    .about-hero-dark-overlay {
        position: absolute;
        inset: 0;
        background: 
            linear-gradient(90deg, rgba(7, 10, 13, 0.65) 0%, rgba(7, 10, 13, 0.38) 45%, rgba(7, 10, 13, 0.10) 80%, rgba(7, 10, 13, 0.15) 100%),
            linear-gradient(180deg, rgba(7, 10, 13, 0.40) 0%, rgba(7, 10, 13, 0.0) 40%, rgba(7, 10, 13, 0.18) 75%, rgba(7, 10, 13, 0.65) 100%);
        z-index: 2;
        pointer-events: none;
    }

    .about-hero-container {
        position: relative;
        z-index: 5;
        max-width: 1300px;
        width: 100%;
        margin: 0 auto;
        display: grid;
        grid-template-columns: 1.15fr 1fr;
        gap: 4rem;
        align-items: center;
    }

    /* Left Column: Typography & Luxury Specs */
    .about-hero-text-col {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding-top: 0.5rem;
    }

    .about-hero-eyebrow-wrap {
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 1rem;
    }

    .about-hero-eyebrow-line {
        width: 32px;
        height: 1.5px;
        background: linear-gradient(90deg, #DCB658, transparent);
    }

    .about-hero-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.26em;
        text-transform: uppercase;
        color: #DCB658;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.8);
    }

    .about-hero-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-size: 54px !important;
        font-weight: 400 !important;
        line-height: 1.18;
        letter-spacing: -0.01em;
        color: #FFFFFF;
        margin: 0 0 1rem;
        max-width: 100%;
        text-shadow: 0 4px 28px rgba(0, 0, 0, 0.8), 0 2px 10px rgba(0, 0, 0, 0.5);
        text-transform: none;
    }

    .about-hero-title .hero-highlight {
        color: #DCB658;
        font-style: italic;
        font-family: 'Cormorant Garamond', 'Marcellus', serif;
    }

    .about-hero-subtitle {
        font-family: var(--font-body);
        font-size: clamp(0.96rem, 1.1vw, 1.08rem);
        font-weight: 400;
        line-height: 1.68;
        color: rgba(255, 255, 255, 0.88);
        max-width: 600px;
        margin: 0 0 1.75rem;
        text-shadow: 0 2px 12px rgba(0, 0, 0, 0.7);
    }

    /* Hero Key Stats Ribbon */
    .about-hero-stats-ribbon {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
        background: rgba(12, 16, 20, 0.75);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(220, 182, 88, 0.28);
        border-radius: 16px;
        padding: 1rem 1.25rem;
        margin-bottom: 2rem;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.08);
        max-width: 580px;
    }

    .about-hero-stat-item {
        display: flex;
        flex-direction: column;
        border-right: 1px solid rgba(255, 255, 255, 0.12);
        padding-right: 0.75rem;
    }

    .about-hero-stat-item:last-child {
        border-right: none;
        padding-right: 0;
    }

    .about-hero-stat-num {
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 1.35rem;
        color: #DCB658;
        line-height: 1.15;
        font-weight: 500;
    }

    .about-hero-stat-label {
        font-family: 'Manrope', sans-serif;
        font-size: 0.68rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: rgba(255, 255, 255, 0.75);
        margin-top: 2px;
    }

    .about-hero-actions {
        display: flex;
        align-items: center;
        gap: 1.25rem;
        flex-wrap: wrap;
    }

    /* Primary Gold Button */
    .about-hero-actions .btn-primary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        min-width: 178px;
        min-height: 50px;
        background: linear-gradient(135deg, #DCB658 0%, #E5C36E 100%);
        color: #0A120E !important;
        font-family: var(--font-heading);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        font-size: 0.88rem;
        padding: 0.85rem 2rem;
        border-radius: 9999px;
        text-decoration: none;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 6px 25px rgba(220, 182, 88, 0.35);
        border: 1px solid #DCB658;
    }

    .about-hero-actions .btn-primary:hover {
        background: #FFFFFF;
        border-color: #FFFFFF;
        color: #0A120E !important;
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(255, 255, 255, 0.3);
    }

    .about-hero-actions .btn-primary .btn-arrow {
        transition: transform 0.3s ease;
    }

    .about-hero-actions .btn-primary:hover .btn-arrow {
        transform: translateX(4px);
    }

    /* Secondary Dark Glass Button */
    .about-hero-actions .btn-secondary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 168px;
        min-height: 50px;
        background: rgba(14, 18, 24, 0.75);
        border: 1px solid rgba(220, 182, 88, 0.45);
        color: #FFFFFF !important;
        font-family: var(--font-heading);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        font-size: 0.88rem;
        padding: 0.85rem 2rem;
        border-radius: 9999px;
        text-decoration: none;
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
    }

    .about-hero-actions .btn-secondary:hover {
        background: rgba(220, 182, 88, 0.15);
        border-color: #DCB658;
        color: #DCB658 !important;
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(220, 182, 88, 0.25);
    }

    /* Right Column: Layered Architectural Showcase */
    .about-hero-visual-col {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .about-hero-main-frame {
        position: relative;
        width: 100%;
        max-width: 500px;
        height: 500px;
        border-radius: 24px;
        overflow: hidden;
        border: 1.5px solid rgba(220, 182, 88, 0.45);
        box-shadow: 0 30px 70px rgba(0, 0, 0, 0.65), 0 0 45px rgba(220, 182, 88, 0.15);
        background: #080B10;
    }

    .about-hero-main-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.9s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .about-hero-main-frame:hover .about-hero-main-img {
        transform: scale(1.05);
    }

    .about-hero-frame-gradient {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(0, 0, 0, 0.15) 0%, rgba(0, 0, 0, 0.6) 100%);
        pointer-events: none;
    }

    /* Floating Top Glass Badge */
    .about-hero-badge-top {
        position: absolute;
        top: 1.25rem;
        left: 1.25rem;
        z-index: 8;
        background: rgba(8, 14, 11, 0.88);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(220, 182, 88, 0.55);
        border-radius: 9999px;
        padding: 0.45rem 1rem;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        color: #DCB658;
        font-family: 'Manrope', sans-serif;
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
    }

    .about-hero-badge-top-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: #DCB658;
        box-shadow: 0 0 8px #DCB658;
    }

    /* Floating Location Tag */
    .about-hero-tag-loc {
        position: absolute;
        bottom: 1.25rem;
        right: 1.25rem;
        z-index: 8;
        background: rgba(8, 14, 11, 0.85);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 9999px;
        padding: 0.4rem 0.95rem;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        color: #FFFFFF;
        font-family: 'Manrope', sans-serif;
        font-size: 0.68rem;
        font-weight: 600;
        letter-spacing: 0.08em;
    }

    /* Floating Tilted Polaroid Card */
    .about-polaroid-card {
        position: absolute;
        bottom: -28px;
        left: -32px;
        background: #FFFFFF;
        padding: 10px 10px 14px 10px;
        border-radius: 14px;
        box-shadow: 0 24px 50px rgba(0, 0, 0, 0.55), 0 0 20px rgba(220, 182, 88, 0.2);
        transform: rotate(-6.5deg);
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        z-index: 10;
        border: 1.5px solid rgba(220, 182, 88, 0.4);
    }

    .about-polaroid-card:hover {
        transform: rotate(-2deg) scale(1.06) translateY(-8px);
        box-shadow: 0 32px 70px rgba(0, 0, 0, 0.7);
        border-color: #DCB658;
    }

    .about-polaroid-img-wrapper {
        width: 190px;
        height: 235px;
        overflow: hidden;
        background: #111111;
        border-radius: 8px;
    }

    .about-polaroid-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        filter: grayscale(80%) contrast(1.1);
        transition: filter 0.4s ease, transform 0.6s ease;
    }

    .about-polaroid-card:hover .about-polaroid-img {
        filter: grayscale(0%) contrast(1.05);
        transform: scale(1.05);
    }

    .about-polaroid-caption {
        font-family: 'Cormorant Garamond', serif;
        font-style: italic;
        font-size: 0.88rem;
        color: #1A2420;
        text-align: center;
        margin-top: 8px;
        letter-spacing: 0.02em;
        font-weight: 600;
    }

    /* ══════════════════════════════════════════════════════════
       2. NARRATIVE SECTION ("ABOUT US" ULTRA-LUXURY EDITORIAL)
    ══════════════════════════════════════════════════════════ */
    .about-narrative-section {
        position: relative;
        background: #FFFFFF;
        padding: 6rem 1.75rem 6.5rem;
        overflow: hidden;
    }

    .about-narrative-section::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(220, 182, 88, 0.04) 0%, rgba(255, 255, 255, 0) 70%);
        pointer-events: none;
    }

    .about-narrative-container {
        position: relative;
        z-index: 5;
        max-width: 1280px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: 1fr 1.05fr;
        gap: 4.5rem;
        align-items: center;
    }

    /* Left Column: 4-Photo Staggered Collage with Floating Centerpiece Badge */
    .about-narrative-visual-col {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .about-collage-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.25rem;
        width: 100%;
        max-width: 560px;
    }

    .about-collage-col {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
    }

    .about-collage-col-offset {
        transform: translateY(28px);
    }

    .about-collage-card {
        position: relative;
        border-radius: 16px;
        overflow: hidden;
        background: #0E1210;
        box-shadow: 0 14px 35px rgba(10, 20, 16, 0.08);
        border: 1px solid #ECE5D8;
        transition: transform 0.45s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.45s ease, border-color 0.3s ease;
    }

    .about-collage-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 24px 50px rgba(10, 20, 16, 0.16);
        border-color: #DCB658;
    }

    .about-collage-card--tall {
        height: 280px;
    }

    .about-collage-card--medium {
        height: 215px;
    }

    .about-collage-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.85s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .about-collage-card:hover .about-collage-img {
        transform: scale(1.07);
    }

    /* Center Floating Luxury Seal */
    .about-collage-floating-badge {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 6;
        background: rgba(12, 18, 15, 0.92);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        border: 1.5px solid #DCB658;
        border-radius: 9999px;
        padding: 0.7rem 1.35rem;
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.35), 0 0 24px rgba(220, 182, 88, 0.25);
        white-space: nowrap;
        pointer-events: none;
    }

    .about-collage-badge-icon {
        color: #DCB658;
        font-size: 1.1rem;
        line-height: 1;
    }

    .about-collage-badge-text {
        display: flex;
        flex-direction: column;
        text-align: left;
    }

    .about-collage-badge-title {
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 0.86rem;
        color: #FFFFFF;
        letter-spacing: 0.05em;
        line-height: 1.2;
    }

    .about-collage-badge-sub {
        font-family: 'Manrope', sans-serif;
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #DCB658;
        line-height: 1.2;
        margin-top: 2px;
    }

    /* Right Column: Narrative Story & Actions */
    .about-narrative-right {
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .about-narrative-eyebrow-wrap {
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
    }

    .about-narrative-eyebrow-line {
        width: 24px;
        height: 1px;
        background: #DCB658;
    }

    .about-narrative-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #B88B2A;
    }

    .about-section-heading {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-size: 42px !important;
        font-weight: 400 !important;
        letter-spacing: -0.01em;
        text-transform: none;
        color: #111827;
        margin: 0 0 0.65rem;
        line-height: 1.22;
    }

    .about-section-tagline {
        font-family: 'Cormorant Garamond', 'Marcellus', serif;
        font-style: italic;
        font-size: clamp(1.1rem, 1.45vw, 1.3rem);
        color: #8C7335;
        line-height: 1.45;
        margin: 0 0 1.65rem;
        padding-left: 1rem;
        border-left: 2px solid #DCB658;
    }

    .about-story-paragraphs {
        display: flex;
        flex-direction: column;
        gap: 1.15rem;
        margin-bottom: 1.65rem;
    }

    .about-story-p {
        font-size: clamp(0.92rem, 1.02vw, 0.98rem);
        color: #4B5563;
        line-height: 1.72;
        margin: 0;
        font-weight: 400;
    }

    .about-story-highlight {
        font-family: 'Marcellus', serif !important;
        color: #B88B2A;
        font-weight: 600;
        font-size: 1.06em;
        letter-spacing: 0.01em;
    }

    /* Luxury Key Pillars Strip */
    .about-narrative-pillars {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 0.75rem;
        padding: 1.1rem 1.25rem;
        background: #FBF9F5;
        border: 1px solid #ECE5D8;
        border-radius: 12px;
        margin-bottom: 2rem;
    }

    .about-narrative-pillar-item {
        display: flex;
        flex-direction: column;
        gap: 0.2rem;
    }

    .about-narrative-pillar-title {
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 0.88rem;
        color: #111827;
        font-weight: 500;
        line-height: 1.25;
    }

    .about-narrative-pillar-sub {
        font-family: 'Manrope', sans-serif;
        font-size: 0.68rem;
        color: #7B8880;
        line-height: 1.35;
    }

    /* Action Buttons Row */
    .about-actions-row {
        display: flex;
        align-items: center;
        gap: 1.15rem;
        flex-wrap: wrap;
    }

    .about-btn-pill-solid {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        background: #111827;
        color: #FFFFFF !important;
        font-family: var(--font-heading);
        font-size: 0.84rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        text-decoration: none;
        padding: 0.85rem 2rem;
        border-radius: 9999px;
        border: 1px solid #111827;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 8px 24px rgba(17, 24, 39, 0.2);
    }

    .about-btn-pill-solid:hover {
        background: #DCB658;
        border-color: #DCB658;
        color: #0A1410 !important;
        transform: translateY(-3px);
        box-shadow: 0 12px 30px rgba(220, 182, 88, 0.35);
    }

    .about-btn-pill-outline {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        background: #FFFFFF;
        color: #111827 !important;
        font-family: var(--font-heading);
        font-size: 0.84rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        text-decoration: none;
        padding: 0.85rem 2rem;
        border-radius: 9999px;
        border: 1px solid #D1D5DB;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .about-btn-pill-outline:hover {
        background: #111827;
        border-color: #111827;
        color: #FFFFFF !important;
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    }

    /* ══════════════════════════════════════════════════════════
       2.5 CINEMATIC VISION BANNER (VIDEO BACKGROUND & DARK GRADIENT)
    ══════════════════════════════════════════════════════════ */
    .about-promo-banner-section {
        position: relative;
        min-height: 380px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        background: #080A0C;
        padding: 5rem 1.5rem 5.5rem;
        overflow: hidden;
    }

    .about-promo-video-wrapper {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .about-promo-bg-video {
        position: absolute;
        top: 50%;
        left: 50%;
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
        object-fit: cover;
        transform: translate(-50%, -50%);
        opacity: 0.8;
        filter: brightness(0.92) contrast(1.08);
    }

    .about-promo-dark-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(8, 10, 12, 0.58) 0%, rgba(10, 14, 18, 0.35) 50%, rgba(8, 10, 12, 0.68) 100%);
        z-index: 2;
        pointer-events: none;
    }

    .about-promo-content-container {
        position: relative;
        z-index: 5;
        max-width: 1060px;
        margin: 0 auto;
        padding: 0 1.25rem;
        text-align: center;
    }

    .about-vision-quote-mark {
        font-family: 'Cormorant Garamond', serif;
        font-size: 3.8rem;
        line-height: 0.55;
        color: #DCB658;
        opacity: 0.95;
        display: block;
        margin: 0 auto 0.75rem;
    }

    .about-vision-quote-text {
        font-family: 'Cormorant Garamond', 'Marcellus', serif;
        font-style: italic;
        font-size: clamp(1.45rem, 2.4vw, 2.2rem);
        color: #FFFFFF;
        line-height: 1.45;
        margin: 0 auto 1.35rem;
        letter-spacing: 0.01em;
        text-shadow: 0 2px 14px rgba(0, 0, 0, 0.75);
        max-width: 980px;
    }

    .about-vision-author {
        font-family: var(--font-heading);
        font-size: 0.9rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658;
        margin: 0;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
    }

    .about-vision-role {
        font-size: 0.76rem;
        color: rgba(255, 255, 255, 0.75);
        text-transform: uppercase;
        letter-spacing: 0.16em;
        margin-top: 0.35rem;
        font-weight: 500;
        text-shadow: 0 1px 6px rgba(0, 0, 0, 0.6);
    }

    /* ══════════════════════════════════════════════════════════
       2.8 EDITORIAL MISSION, VISION & VALUES (AMAN / SIX SENSES STYLE)
    ══════════════════════════════════════════════════════════ */
    /* ══════════════════════════════════════════════════════════
       2.8 EDITORIAL MISSION, VISION & VALUES (LUXURY 3-CHAPTER SHOWCASE)
    ══════════════════════════════════════════════════════════ */
    .about-mvv-section {
        position: relative;
        background: #FAF7F2;
        padding: 6.5rem 1.75rem 7rem;
        border-top: 1px solid #ECE5D8;
        border-bottom: 1px solid #ECE5D8;
        overflow: hidden;
    }

    .about-mvv-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 1100px;
        height: 550px;
        background: radial-gradient(circle, rgba(220, 182, 88, 0.08) 0%, rgba(250, 247, 242, 0) 70%);
        pointer-events: none;
    }

    .about-mvv-container {
        position: relative;
        z-index: 2;
        max-width: 1200px;
        margin: 0 auto;
    }

    .about-mvv-header {
        text-align: center;
        max-width: 780px;
        margin: 0 auto 4rem;
    }

    .about-mvv-eyebrow-wrap {
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
    }

    .about-mvv-eyebrow-line {
        width: 24px;
        height: 1px;
        background: #DCB658;
    }

    .about-mvv-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.24em;
        text-transform: uppercase;
        color: #B88B2A;
        display: inline-block;
        margin: 0;
    }

    .about-mvv-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-size: 42px !important;
        text-transform: none;
        color: #111827;
        margin: 0 0 1rem;
        line-height: 1.25;
        letter-spacing: -0.01em;
    }

    .about-mvv-desc {
        font-family: inherit;
        font-style: normal !important;
        font-size: 0.98rem;
        color: #55635C;
        line-height: 1.74;
        margin: 0 auto;
        max-width: 680px;
        font-weight: 400;
    }

    /* 3-Chapter Alternating Showcase Stack */
    .about-mvv-showcase {
        display: flex;
        flex-direction: column;
        gap: 2.75rem;
    }

    .about-mvv-row {
        display: grid;
        grid-template-columns: 1fr 1.15fr;
        gap: 3.5rem;
        align-items: center;
        background: #FFFFFF;
        border: 1px solid #EAE3D5;
        border-radius: 24px;
        padding: 2.25rem 2.5rem;
        box-shadow: 0 10px 32px rgba(20, 34, 29, 0.04);
        position: relative;
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .about-mvv-row::before {
        content: '';
        position: absolute;
        top: 0;
        left: 40px;
        right: 40px;
        height: 2px;
        background: linear-gradient(90deg, transparent 0%, #DCB658 50%, transparent 100%);
        opacity: 0;
        transition: opacity 0.35s ease;
    }

    .about-mvv-row:hover {
        transform: translateY(-5px);
        border-color: #DCB658;
        box-shadow: 0 22px 50px rgba(20, 34, 29, 0.08), 0 0 0 1px rgba(220, 182, 88, 0.2);
    }

    .about-mvv-row:hover::before {
        opacity: 1;
    }

    /* Reverse Row for Alternating Cadence */
    .about-mvv-row--reverse {
        grid-template-columns: 1.15fr 1fr;
    }

    .about-mvv-row--reverse .about-mvv-row-media {
        order: 2;
    }

    .about-mvv-row--reverse .about-mvv-row-content {
        order: 1;
    }

    /* Center Featured Row (Vision) */
    .about-mvv-row--featured {
        border: 1.5px solid #DCB658;
        background: linear-gradient(135deg, #FFFFFF 0%, #FCFAF5 100%);
        box-shadow: 0 14px 40px rgba(220, 182, 88, 0.12);
    }

    .about-mvv-row-media {
        position: relative;
        height: 310px;
        border-radius: 18px;
        overflow: hidden;
        background: #080A0C;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        border: 1px solid #ECE5D8;
    }

    .about-mvv-row-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.85s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .about-mvv-row:hover .about-mvv-row-img {
        transform: scale(1.06);
    }

    .about-mvv-row-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(0, 0, 0, 0.05) 0%, rgba(8, 12, 10, 0.55) 100%);
        pointer-events: none;
    }

    .about-mvv-row-badge {
        position: absolute;
        top: 1.1rem;
        left: 1.1rem;
        z-index: 3;
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        background: rgba(10, 18, 14, 0.88);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(220, 182, 88, 0.55);
        color: #DCB658;
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.7rem;
        font-weight: 700;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        padding: 0.38rem 0.95rem;
        border-radius: 9999px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
    }

    .about-mvv-row-badge--gold {
        background: #DCB658;
        color: #0A1410;
        border-color: #DCB658;
        box-shadow: 0 4px 16px rgba(220, 182, 88, 0.4);
    }

    .about-mvv-row-num {
        position: absolute;
        bottom: 0.85rem;
        right: 1.25rem;
        z-index: 3;
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 2.4rem;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.88);
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
        line-height: 1;
    }

    /* Content Column */
    .about-mvv-row-content {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 0.5rem 0.5rem 0.5rem 0;
    }

    .about-mvv-row--reverse .about-mvv-row-content {
        padding: 0.5rem 0 0.5rem 0.5rem;
    }

    .about-mvv-row-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: #B88B2A;
        margin-bottom: 0.5rem;
        display: block;
    }

    .about-mvv-row-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-size: 1.65rem;
        color: #111827;
        margin: 0 0 0.85rem;
        line-height: 1.28;
        transition: color 0.3s ease;
    }

    .about-mvv-row:hover .about-mvv-row-title {
        color: #8F6A1E;
    }

    .about-mvv-row-desc {
        font-size: 0.94rem;
        color: #55635C;
        line-height: 1.76;
        margin: 0 0 1.5rem;
        font-weight: 400;
    }

    .about-mvv-pills-row {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .about-mvv-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        padding: 0.35rem 0.9rem;
        border-radius: 9999px;
        background: #FAF6ED;
        border: 1px solid rgba(220, 182, 88, 0.45);
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.07em;
        text-transform: uppercase;
        color: #8F6A1E;
        font-style: normal !important;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
        transition: all 0.3s ease;
    }

    .about-mvv-pill-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: #DCB658;
        transition: background 0.3s ease;
    }

    .about-mvv-row:hover .about-mvv-pill {
        background: #DCB658;
        border-color: #DCB658;
        color: #0A1410;
        box-shadow: 0 3px 10px rgba(220, 182, 88, 0.3);
    }

    .about-mvv-row:hover .about-mvv-pill-dot {
        background: #0A1410;
    }

    .about-mvv-pill--gold {
        background: #FAF6ED;
        border-color: rgba(220, 182, 88, 0.55);
        color: #8F6A1E;
    }

    @media (max-width: 992px) {
        .about-mvv-row,
        .about-mvv-row--reverse {
            grid-template-columns: 1fr;
            gap: 2rem;
            padding: 1.75rem 1.5rem;
        }

        .about-mvv-row--reverse .about-mvv-row-media {
            order: 1;
        }

        .about-mvv-row--reverse .about-mvv-row-content {
            order: 2;
            padding: 0;
        }

        .about-mvv-row-content {
            padding: 0;
        }

        .about-mvv-row-media {
            height: 260px;
        }

        .about-mvv-section {
            padding: 4.5rem 1.5rem 5rem;
        }
    }

    /* ══════════════════════════════════════════════════════════
       3. PROMO BANNER (LUXURY VIDEO BANNER + DOWNLOAD BROCHURE)
    ══════════════════════════════════════════════════════════ */
    .wellness-promo-section {
        position: relative;
        padding: 2.25rem 1.75rem 2.75rem;
        background: #FFFFFF;
        overflow: hidden;
    }

    .wellness-promo-container {
        max-width: 1300px;
        margin: 0 auto;
        width: 100%;
        position: relative;
        z-index: 2;
    }

    .wellness-promo-card {
        position: relative;
        border-radius: 24px;
        overflow: hidden;
        border: 1px solid rgba(220, 182, 88, 0.35);
        box-shadow: 0 24px 60px rgba(0, 0, 0, 0.6), 0 0 35px rgba(220, 182, 88, 0.12);
        display: grid;
        grid-template-columns: 1.6fr 1fr;
        align-items: center;
        min-height: 340px;
        background: #0A0E12;
    }

    .wellness-promo-video-wrapper {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .wellness-promo-bg-video {
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.45;
        filter: brightness(0.85) contrast(1.15) saturate(1.1);
        transform: scale(1.02);
    }

    .wellness-promo-video-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg, rgba(8, 12, 16, 0.94) 0%, rgba(8, 12, 16, 0.82) 55%, rgba(8, 12, 16, 0.4) 100%);
        z-index: 2;
    }

    .wellness-promo-content {
        position: relative;
        z-index: 3;
        padding: 3.5rem 3.5rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .wellness-promo-eyebrow-row {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.85rem;
    }

    .wellness-promo-eyebrow-row span {
        font-family: var(--font-heading);
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        color: #DCB658;
    }

    .wellness-promo-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-size: clamp(2rem, 3.2vw, 2.75rem);
        font-weight: 400 !important;
        color: #FFFFFF;
        line-height: 1.18;
        margin: 0 0 1rem;
        letter-spacing: -0.01em;
        text-transform: none;
    }

    .wellness-promo-desc {
        font-family: var(--font-body);
        font-size: 0.95rem;
        line-height: 1.65;
        color: rgba(255, 255, 255, 0.82);
        margin: 0 0 1.85rem;
        max-width: 580px;
    }

    .wellness-promo-btn-group {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 1rem;
    }

    .wellness-brochure-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.65rem;
        padding: 0.85rem 1.75rem;
        background: linear-gradient(135deg, #DCB658 0%, #C99E38 100%);
        color: #0A0E12;
        border: none;
        border-radius: 9999px;
        font-family: var(--font-heading);
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.35s ease;
        box-shadow: 0 8px 24px rgba(220, 182, 88, 0.35);
    }

    .wellness-brochure-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px rgba(220, 182, 88, 0.55);
        filter: brightness(1.08);
    }

    .wellness-promo-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.85rem 1.65rem;
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.28);
        border-radius: 9999px;
        color: #FFFFFF;
        font-family: var(--font-heading);
        font-size: 0.76rem;
        font-weight: 600;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        cursor: pointer;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        transition: all 0.35s ease;
    }

    .wellness-promo-btn:hover {
        background: rgba(255, 255, 255, 0.18);
        border-color: #DCB658;
        color: #DCB658;
        transform: translateY(-2px);
    }

    .wellness-promo-badge-box {
        position: relative;
        z-index: 3;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }

    .wellness-circular-badge {
        width: 155px;
        height: 155px;
        border-radius: 50%;
        background: radial-gradient(circle at 30% 30%, rgba(220, 182, 88, 0.35) 0%, rgba(14, 18, 22, 0.95) 75%);
        border: 2px dashed rgba(220, 182, 88, 0.65);
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.5), inset 0 0 20px rgba(220, 182, 88, 0.2);
        animation: promoBadgePulse 4s ease-in-out infinite alternate;
    }

    @keyframes promoBadgePulse {
        0% { transform: scale(1); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.5), inset 0 0 20px rgba(220, 182, 88, 0.2); }
        100% { transform: scale(1.04); box-shadow: 0 16px 40px rgba(220, 182, 88, 0.3), inset 0 0 28px rgba(220, 182, 88, 0.35); }
    }

    .circ-badge-inner {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .circ-small {
        font-family: var(--font-heading);
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.14em;
        color: #DCB658;
        text-transform: uppercase;
        line-height: 1;
    }

    .circ-large {
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 2.35rem;
        font-weight: 700;
        color: #FFFFFF;
        line-height: 1.05;
        margin: 0.15rem 0;
        text-shadow: 0 2px 10px rgba(0,0,0,0.6);
    }

    .circ-sub {
        font-family: var(--font-heading);
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.2em;
        color: #DCB658;
        text-transform: uppercase;
        line-height: 1;
    }

    @media (max-width: 992px) {
        .wellness-promo-card {
            grid-template-columns: 1fr;
            text-align: center;
        }
        .wellness-promo-content {
            align-items: center;
            text-align: center;
            padding: 3rem 2rem 1.5rem;
            max-width: 100%;
        }
        .wellness-promo-desc {
            margin-left: auto;
            margin-right: auto;
        }
        .wellness-promo-btn-group {
            justify-content: center;
        }
        .wellness-promo-badge-box {
            padding: 1rem 2rem 3rem;
        }
    }

    @media (max-width: 520px) {
        .wellness-promo-btn-group {
            flex-direction: column;
            width: 100%;
        }
        .wellness-brochure-btn,
        .wellness-promo-btn {
            width: 100%;
            justify-content: center;
        }
        .wellness-circular-badge {
            width: 120px;
            height: 120px;
        }
        .circ-large {
            font-size: 1.75rem;
        }
    }

    /* ══════════════════════════════════════════════════════════
       3.5 WHY CHOOSE US (PURE WHITE EDITORIAL LUXURY THEME)
    ══════════════════════════════════════════════════════════ */
    .about-why-section {
        position: relative;
        background: #FFFFFF;
        padding: 4.5rem 1.75rem 5rem;
        color: #111827;
        border-top: 1px solid #ECE7DE;
        overflow: hidden;
    }

    .about-why-container {
        position: relative;
        z-index: 2;
        max-width: 1400px;
        margin: 0 auto;
    }

    .about-why-header {
        text-align: center;
        max-width: 780px;
        margin: 0 auto 2.75rem;
    }

    .about-why-eyebrow-wrap {
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.65rem;
    }

    .about-why-eyebrow-line {
        width: 24px;
        height: 1px;
        background: #DCB658;
    }

    .about-why-eyebrow {
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #B88B2A;
        display: inline-block;
        margin: 0;
    }

    .about-why-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-size: 42px !important;
        text-transform: none;
        color: #111827;
        line-height: 1.25;
        margin: 0 0 0.85rem;
        letter-spacing: -0.01em;
    }

    .about-why-desc {
        font-size: 0.92rem;
        color: #55635C;
        line-height: 1.68;
        margin: 0 auto;
        max-width: 660px;
    }

    .about-why-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.25rem;
        max-width: 1380px;
        margin: 0 auto;
    }

    .about-why-card {
        background: #FFFFFF;
        border: 1px solid #E5DDCF;
        border-top: 3px solid #DCB658;
        border-radius: 14px;
        padding: 1.5rem 1.35rem 1.35rem;
        display: flex;
        flex-direction: column;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.04), 0 2px 6px rgba(0, 0, 0, 0.02);
        position: relative;
    }

    .about-why-card:hover {
        transform: translateY(-5px);
        background: #FFFFFF;
        border-color: #DCB658;
        border-top-color: #B88B2A;
        box-shadow: 0 16px 36px rgba(20, 34, 29, 0.1), 0 0 0 1px rgba(220, 182, 88, 0.35);
    }

    .about-why-card-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1rem;
    }

    .about-why-icon-box {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: #FAF7F0;
        border: 1px solid rgba(220, 182, 88, 0.4);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #B88B2A;
        box-shadow: 0 3px 10px rgba(220, 182, 88, 0.12);
        transition: all 0.35s ease;
    }

    .about-why-card:hover .about-why-icon-box {
        background: #FAF4E5;
        border-color: #DCB658;
        transform: scale(1.06);
        box-shadow: 0 5px 15px rgba(220, 182, 88, 0.22);
    }

    .about-why-watermark {
        font-family: var(--font-heading), 'Marcellus', serif;
        font-size: 1.6rem;
        line-height: 1;
        font-weight: 700;
        letter-spacing: 0.05em;
        color: rgba(184, 139, 42, 0.3);
        user-select: none;
        transition: all 0.3s ease;
    }

    .about-why-card:hover .about-why-watermark {
        color: #B88B2A;
    }

    .about-why-card-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-style: normal !important;
        font-weight: 500 !important;
        font-size: 1.08rem;
        color: #111827;
        margin: 0 0 0.55rem;
        line-height: 1.35;
        transition: color 0.3s ease;
    }

    .about-why-card:hover .about-why-card-title {
        color: #8F6A1E;
    }

    .about-why-card-text {
        font-size: 0.85rem;
        color: #4B5563;
        line-height: 1.62;
        margin: 0 0 1.15rem;
        flex-grow: 1;
    }

    .about-why-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.3rem 0.75rem;
        border-radius: 9999px;
        background: #FAF6ED;
        border: 1px solid rgba(220, 182, 88, 0.45);
        color: #8F6A1E;
        font-family: 'Manrope', sans-serif !important;
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        align-self: flex-start;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
        transition: all 0.3s ease;
    }

    .about-why-pill-dot {
        width: 4.5px;
        height: 4.5px;
        border-radius: 50%;
        background: #DCB658;
        transition: background 0.3s ease;
    }

    .about-why-card:hover .about-why-pill {
        background: #DCB658;
        border-color: #DCB658;
        color: #0A1410;
        box-shadow: 0 4px 12px rgba(220, 182, 88, 0.3);
    }

    .about-why-card:hover .about-why-pill-dot {
        background: #0A1410;
    }

    @media (max-width: 1120px) {
        .about-why-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.25rem;
        }
    }

    @media (max-width: 640px) {
        .about-why-grid {
            grid-template-columns: 1fr;
            gap: 1.15rem;
        }
        .about-why-section {
            padding: 3.5rem 1.25rem 4rem;
        }
        .about-why-card {
            padding: 1.35rem 1.25rem 1.25rem;
        }
    }

    /* ══════════════════════════════════════════════════════════
       RESPONSIVE MEDIA QUERIES (MOBILE OPTIMIZED)
    ══════════════════════════════════════════════════════════ */
    @media (max-width: 1024px) {
        .about-hero-container {
            grid-template-columns: 1fr;
            gap: 3.5rem;
        }
        .about-hero-visual-col {
            justify-content: center;
        }
        .about-hero-main-frame {
            max-width: 100%;
            height: 440px;
        }
        .about-polaroid-card {
            bottom: -1.5rem;
            left: 0;
        }
        .about-narrative-container {
            grid-template-columns: 1fr;
            gap: 3.5rem;
        }
    }

    @media (max-width: 768px) {
        /* Section Spacing */
        .about-hero-section {
            padding: 8.5rem 1.25rem 4rem;
            min-height: auto;
        }
        .about-narrative-section {
            padding: 3.5rem 1.25rem 4rem;
        }
        .about-promo-banner-section {
            padding: 3rem 1.25rem;
        }
        .about-mvv-section {
            padding: 3.5rem 1.25rem 4rem;
        }
        .about-retreat-section {
            padding: 3.5rem 1.25rem 4rem;
        }
        .about-why-section {
            padding: 3.5rem 1.25rem 4rem;
        }

        /* Centered Headings & Standard Mobile Font Sizes */
        .about-hero-title {
            font-size: 32px !important;
            text-align: center !important;
            line-height: 1.22 !important;
            margin: 0 auto 1rem !important;
        }
        .about-section-heading,
        .about-mvv-title,
        .about-retreat-title,
        .about-why-title {
            font-size: 28px !important;
            text-align: center !important;
            line-height: 1.25 !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }

        /* Centered Eyebrows & Taglines */
        .about-hero-text-col {
            align-items: center;
            text-align: center;
        }
        .about-hero-eyebrow-wrap,
        .about-narrative-eyebrow-wrap,
        .about-mvv-eyebrow-wrap,
        .about-why-eyebrow-wrap {
            justify-content: center;
            text-align: center;
            width: 100%;
        }
        .about-retreat-eyebrow {
            text-align: center;
            display: block;
            width: 100%;
        }
        .about-hero-subtitle {
            text-align: center;
            margin: 0 auto 1.5rem;
        }
        .about-section-tagline {
            text-align: center;
            padding-left: 0;
            border-left: none;
            margin: 0 auto 1.5rem;
        }
        .about-mvv-desc,
        .about-retreat-desc,
        .about-why-desc {
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }

        /* Hero Stats Ribbon on Mobile */
        .about-hero-stats-ribbon {
            grid-template-columns: repeat(3, 1fr);
            gap: 0.5rem;
            padding: 0.85rem 0.75rem;
            margin: 0 auto 1.75rem;
            width: 100%;
        }
        .about-hero-stat-num {
            font-size: 1.15rem;
        }
        .about-hero-stat-label {
            font-size: 0.6rem;
            letter-spacing: 0.05em;
        }

        /* Hero Actions & Visual on Mobile */
        .about-hero-actions,
        .about-actions-row {
            flex-direction: column;
            width: 100%;
            justify-content: center;
            align-items: center;
            gap: 0.85rem;
        }
        .about-hero-actions .btn-primary,
        .about-hero-actions .btn-secondary,
        .about-btn-pill-solid,
        .about-btn-pill-outline {
            width: 100%;
            text-align: center;
            justify-content: center;
        }

        /* Hero Visual Art (Scaled Down & Perfectly Proportioned for Mobile) */
        .about-hero-visual-col {
            margin: 1.75rem auto 0;
            width: 100%;
            max-width: 320px;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .about-hero-main-frame {
            width: 100%;
            max-width: 320px;
            height: 300px;
            border-radius: 18px;
        }
        .about-polaroid-card {
            max-width: 125px;
            padding: 5px 5px 8px;
            bottom: -14px;
            left: -10px;
            border-radius: 10px;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.6);
        }
        .about-polaroid-img-wrapper {
            width: 115px;
            height: 130px;
            border-radius: 6px;
        }
        .about-polaroid-caption {
            font-size: 0.68rem;
            margin-top: 4px;
        }
        .about-hero-badge-top {
            top: 0.75rem;
            left: 0.75rem;
            padding: 0.32rem 0.75rem;
            font-size: 0.62rem;
        }
        .about-hero-tag-loc {
            bottom: 0.75rem;
            right: 0.75rem;
            padding: 0.28rem 0.65rem;
            font-size: 0.62rem;
        }

        /* Narrative Story on Mobile */
        .about-narrative-right {
            align-items: center;
            text-align: center;
        }
        .about-story-p {
            text-align: left;
            font-size: 0.92rem;
            line-height: 1.7;
        }
        .about-narrative-pillars {
            grid-template-columns: 1fr;
            gap: 0.85rem;
            width: 100%;
            text-align: center;
        }
        .about-narrative-pillar-item {
            align-items: center;
            text-align: center;
        }

        .about-collage-grid {
            gap: 0.85rem;
        }
        .about-collage-card--tall {
            height: 210px;
        }
        .about-collage-card--medium {
            height: 165px;
        }
        .about-collage-floating-badge {
            padding: 0.5rem 0.95rem;
        }

        /* MVV Section on Mobile */
        .about-mvv-header {
            margin-bottom: 2.5rem;
        }
        .about-mvv-row,
        .about-mvv-row--reverse {
            grid-template-columns: 1fr;
            gap: 1.75rem;
            padding: 1.5rem 1.25rem;
        }
        .about-mvv-row--reverse .about-mvv-row-media {
            order: 1;
        }
        .about-mvv-row--reverse .about-mvv-row-content {
            order: 2;
        }
        .about-mvv-row-content {
            padding: 0;
            align-items: flex-start;
            text-align: left;
        }
        .about-mvv-row-eyebrow {
            text-align: left;
        }
        .about-mvv-row-title {
            text-align: left;
            font-size: 1.35rem;
        }
        .about-mvv-row-desc {
            text-align: left;
        }
        .about-mvv-pills-row {
            justify-content: flex-start;
        }
        .about-mvv-row-media {
            height: 220px;
            width: 100%;
        }

        /* Retreat Section on Mobile */
        .about-retreat-left {
            align-items: center;
            text-align: center;
        }
        .about-retreat-desc {
            text-align: left;
        }
        .about-retreat-badges-wrap {
            justify-content: center;
        }

        /* Vision Quote on Mobile */
        .about-vision-quote-text {
            font-size: 1.35rem;
            line-height: 1.45;
        }

        /* Why Choose Us Section on Mobile (Clean Left-Aligned Content with Centered Section Header) */
        .about-why-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .about-why-grid {
            grid-template-columns: 1fr;
            gap: 1.15rem;
        }
        .about-why-card {
            text-align: left !important;
            align-items: flex-start !important;
            padding: 1.35rem 1.4rem;
        }
        .about-why-card-top {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.75rem;
        }
        .about-why-card-title {
            text-align: left !important;
            font-size: 1.15rem !important;
            margin: 0 0 0.5rem 0 !important;
        }
        .about-why-card-text {
            text-align: left !important;
            font-size: 0.88rem !important;
            line-height: 1.65 !important;
            margin: 0 0 1.25rem 0 !important;
        }
        .about-why-pill {
            align-self: flex-start !important;
        }
    }

    @media (max-width: 480px) {
        .about-hero-title {
            font-size: 28px !important;
        }
        .about-section-heading,
        .about-mvv-title,
        .about-retreat-title,
        .about-why-title {
            font-size: 25px !important;
        }
        .about-hero-stats-ribbon {
            grid-template-columns: 1fr;
            gap: 0.65rem;
            text-align: center;
        }
        .about-hero-stat-item {
            border-right: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding-bottom: 0.5rem;
            padding-right: 0;
        }
        .about-hero-stat-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        /* Smaller hero image on small phones */
        .about-hero-visual-col {
            max-width: 270px;
        }
        .about-hero-main-frame {
            max-width: 270px;
            height: 255px;
        }
        .about-polaroid-card {
            max-width: 105px;
            padding: 4px 4px 7px;
            bottom: -10px;
            left: -8px;
        }
        .about-polaroid-img-wrapper {
            width: 97px;
            height: 110px;
        }
        .about-polaroid-caption {
            font-size: 0.62rem;
            margin-top: 3px;
        }
    }
    </style>
</head>
<body class="about-page-body">

    <!-- GLASS HEADER NAVIGATION -->
    @include('Website.includes.Header')

    <!-- =========================================================
         1. HERO SECTION (ULTRA-LUXURY CINEMATIC SHOWCASE)
    ========================================================= -->
    <section class="about-hero-section">
        <!-- Background Video with Dark Gradient Overlay -->
        <div class="about-hero-video-wrapper">
            <video class="about-hero-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="auto" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg') }}">
                <source src="{{ asset('Website/assets/images/residencies.mp4') }}" type="video/mp4">
            </video>
            <div class="about-hero-dark-overlay"></div>
        </div>

        <div class="about-hero-container">
            
            <!-- Left: Headline, Subtitle, Stats Ribbon & Actions -->
            <div class="about-hero-text-col">
                <div class="about-hero-eyebrow-wrap">
                    <span class="about-hero-eyebrow-line"></span>
                    <span class="about-hero-eyebrow">HIMALAYAN SANCTUARY, HP</span>
                </div>

                <h1 class="about-hero-title">
                    The Story Of <span class="hero-highlight">Ulhas Vilas</span><br>
                    Where Serenity Whispers Joy
                </h1>

                <p class="about-hero-subtitle">
                    Discover the vision, architectural passion, and timeless Himalayan spirit that shape our luxury private sanctuary along pristine pine ridge lines.
                </p>

                <!-- Hero Key Stats Ribbon -->
                <div class="about-hero-stats-ribbon">
                    <div class="about-hero-stat-item">
                        <span class="about-hero-stat-num">5,500 Ft</span>
                        <span class="about-hero-stat-label">Alpine Altitude</span>
                    </div>
                    <div class="about-hero-stat-item">
                        <span class="about-hero-stat-num">100%</span>
                        <span class="about-hero-stat-label">Clear Freehold</span>
                    </div>
                    <div class="about-hero-stat-item">
                        <span class="about-hero-stat-num">Ayurvyaas</span>
                        <span class="about-hero-stat-label">Wellness Enclave</span>
                    </div>
                </div>

                <div class="about-hero-actions">
                    <a href="{{ url('/contact') }}" class="btn-primary">
                        Schedule A Visit <span class="btn-arrow">→</span>
                    </a>
                    <a href="{{ url('/contact') }}" class="btn-secondary">
                        Download Brochure
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 6px;">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Right: Framed Architectural Photo with Floating Polaroid & Badges -->
            <div class="about-hero-visual-col">
                <div class="about-hero-main-frame">
                    <img src="{{ asset('Website/assets/images/investment4.jpeg') }}" alt="The Ulhas Vilas Himalayan Sundeck" class="about-hero-main-img">
                    <div class="about-hero-frame-gradient"></div>

                    <!-- Floating Top Experience Badge -->
                    <div class="about-hero-badge-top">
                        <span class="about-hero-badge-top-dot"></span>
                        <span>Private Ridge Enclave</span>
                    </div>

                    <!-- Floating Location Tag -->
                  <!--  <div class="about-hero-tag-loc">
                        <span>✦ Solan Ridge Lines</span>
                    </div>-->
                </div>

                <!-- Floating Tilted Polaroid Card (Black and White Villa Interior) -->
                <!--<div class="about-polaroid-card">-->
                <!--    <div class="about-polaroid-img-wrapper">-->
                <!--        <img src="{{ asset('Website/assets/images/investment2.jpeg') }}" alt="Quiet Moments of Serenity" class="about-polaroid-img">-->
                <!--    </div>-->
                <!--    <div class="about-polaroid-caption">Serenity in every detail</div>-->
                <!--</div>-->
            </div>

        </div>
    </section>

    <!-- =========================================================
         2. NARRATIVE SECTION ("ABOUT US" SPLIT CONTENT)
    ========================================================= -->
    <section class="about-narrative-section">
        <div class="about-narrative-container">
            
            <!-- Left: 4-Photo Staggered Collage with Floating Centerpiece Badge -->
            <div class="about-narrative-visual-col">
                <div class="about-collage-grid">
                    <!-- Column 1 -->
                    <div class="about-collage-col">
                        <div class="about-collage-card about-collage-card--medium">
                            <img src="{{ asset('Website/assets/images/villa3.jpeg') }}" alt="Panoramic Alpine Sundeck" class="about-collage-img" loading="lazy">
                        </div>
                        <div class="about-collage-card about-collage-card--tall">
                            <img src="{{ asset('Website/assets/images/villa4.jpeg') }}" alt="Arched Mountain View Terrace" class="about-collage-img" loading="lazy">
                        </div>
                    </div>

                    <!-- Column 2 (Offset Downward for Editorial Cadence) -->
                    <div class="about-collage-col about-collage-col-offset">
                        <div class="about-collage-card about-collage-card--tall">
                            <img src="{{ asset('Website/assets/images/investment2.jpeg') }}" alt="Presidential Villa Architecture" class="about-collage-img" loading="lazy">
                        </div>
                        <div class="about-collage-card about-collage-card--medium">
                            <img src="{{ asset('Website/assets/images/mountain2.jpeg') }}" alt="Serene Master Suite & Mountain Panorama" class="about-collage-img" loading="lazy">
                        </div>
                    </div>
                </div>

                <!-- Floating Centerpiece Luxury Seal -->
                <div class="about-collage-floating-badge">
                    <span class="about-collage-badge-icon">✦</span>
                    <div class="about-collage-badge-text">
                        <span class="about-collage-badge-title">The Ulhas Vilas</span>
                        <span class="about-collage-badge-sub">5,500 Ft Elevation</span>
                    </div>
                </div>
            </div>

            <!-- Right: Narrative Brand Story, Pillars & Action Pills -->
            <div class="about-narrative-right">
                <div class="about-narrative-eyebrow-wrap">
                    <span class="about-narrative-eyebrow-line"></span>
                    <span class="about-narrative-eyebrow">OUR HERITAGE &amp; VISION</span>
                </div>

                <h2 class="about-section-heading">About Us</h2>

                <p class="about-section-tagline">
                    Where serenity whispers joy and luxury finds its purest mountain expression
                </p>

                <div class="about-story-paragraphs">
                    <p class="about-story-p">
                        <strong class="about-story-highlight">The Ulhas Vilas</strong> was born from a singular, uncompromising vision: to create a haven where the untamed beauty of Himachal Pradesh seamlessly merges with world-class architectural sophistication and intimate hospitality.
                    </p>

                    <p class="about-story-p">
                        Perched along pristine ridge lines, our sanctuary offers a profound pause from the noise of modern life. Here, waking up to misty pine canopies and golden Himalayan sunsets is not merely a getaway—it is an elevated way of living designed to nourish the soul and deepen your connection with nature.
                    </p>

                    <p class="about-story-p">
                        Whether you are arriving for a transformative wellness retreat, a family holiday in our bespoke villas, or securing a legacy freehold residence, our attentive staff and personalized concierge ensure every moment feels effortless, private, and deeply memorable.
                    </p>

                    <p class="about-story-p">
                        What sets us apart is our meticulous attention to craft: from sustainable Himalayan stone architecture and heated infinity pools to organic farm-to-table culinary dining and private valley sundecks. Every contour of The Ulhas Vilas has been sculpted with intention.
                    </p>
                </div>

                <!-- Luxury Pillars Strip -->
                <div class="about-narrative-pillars">
                    <div class="about-narrative-pillar-item">
                        <span class="about-narrative-pillar-title">Freehold Haven</span>
                        <span class="about-narrative-pillar-sub">Generational titles</span>
                    </div>
                    <div class="about-narrative-pillar-item">
                        <span class="about-narrative-pillar-title">Ayurvyaas Synergy</span>
                        <span class="about-narrative-pillar-sub">Holistic wellness</span>
                    </div>
                    <div class="about-narrative-pillar-item">
                        <span class="about-narrative-pillar-title">24/7 Concierge</span>
                        <span class="about-narrative-pillar-sub">Turnkey bespoke care</span>
                    </div>
                </div>

                <!-- Action Buttons matching reference -->
                <div class="about-actions-row">
                    <a href="{{ url('/contact') }}" class="about-btn-pill-solid">
                        Download Brochure
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 4px;">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                        </svg>
                    </a>
                    <a href="{{ url('/residences') }}" class="about-btn-pill-outline">View Residences</a>
                </div>
            </div>

        </div>
    </section>

    <!-- =========================================================
         2.5 CINEMATIC VISION BANNER (BACKGROUND VIDEO & DARK GRADIENT)
    ========================================================= -->
    <section class="about-promo-banner-section">
        <!-- Background Video & Dark Gradient -->
        <div class="about-promo-video-wrapper">
            <video class="about-promo-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg') }}">
                <source src="{{ asset('Website/assets/images/about2.mp4') }}" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="about-promo-dark-overlay"></div>
        </div>

        <div class="about-promo-content-container">
            <span class="about-vision-quote-mark">“</span>
            <p class="about-vision-quote-text">
                We did not build The Ulhas Vilas to compete with nature, but to surrender to it—creating spaces where architecture becomes a silent frame for the mountains.
            </p>
            <p class="about-vision-author">THE FOUNDING VISION</p>
            <p class="about-vision-role">THE ULHAS VILAS LUXURY ESTATES</p>
        </div>
    </section>

    <!-- =========================================================
         2.8 EDITORIAL MISSION, VISION & VALUES (LUXURY 3-CHAPTER SHOWCASE)
    ========================================================= -->
    <section class="about-mvv-section">
        <div class="about-mvv-container">
            <div class="about-mvv-header">
                <div class="about-mvv-eyebrow-wrap">
                    <span class="about-mvv-eyebrow-line"></span>
                    <span class="about-mvv-eyebrow">PURPOSE &amp; PHILOSOPHY</span>
                    <span class="about-mvv-eyebrow-line"></span>
                </div>
                <h2 class="about-mvv-title">Rooted in Stillness, Built for Generations</h2>
                <p class="about-mvv-desc">
                    Every contour of The Ulhas Vilas is shaped by an uncompromising devotion to Himalayan serenity, timeless architectural artistry, and conscious ecological stewardship.
                </p>
            </div>

            <div class="about-mvv-showcase">
                <!-- Chapter 1: Our Mission (Image Left, Story Right) -->
                <div class="about-mvv-row">
                    <div class="about-mvv-row-media">
                        <img src="{{ asset('Website/assets/images/WhatsApp Image 2026-08-22 at 3.41.05 PM.jpeg') }}" alt="Surrender to Nature's Grandeur" class="about-mvv-row-img">
                        <div class="about-mvv-row-overlay"></div>
                        <span class="about-mvv-row-badge">OUR MISSION</span>
                        <span class="about-mvv-row-num">01</span>
                    </div>
                    <div class="about-mvv-row-content">
                        <span class="about-mvv-row-eyebrow">FOUNDATIONAL PURPOSE</span>
                        <h3 class="about-mvv-row-title">To Surrender to Nature’s Grandeur</h3>
                        <p class="about-mvv-row-desc">
                            Our mission is to sculpt bespoke residential sanctuaries along pine ridge lines where architectural design surrenders unconditionally to the natural landscape. We cultivate peaceful retreats that offer residents and guests a profound, lifelong pause to restore, reflect, and reconnect.
                        </p>
                        <div class="about-mvv-pills-row">
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Harmony</span>
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Ecological Balance</span>
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Sanctuary</span>
                        </div>
                    </div>
                </div>

                <!-- Chapter 2: Our Vision (Story Left, Image Right - Featured Centerpiece) -->
                <div class="about-mvv-row about-mvv-row--reverse about-mvv-row--featured">
                    <div class="about-mvv-row-media">
                        <img src="{{ asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.44 PM.jpeg') }}" alt="Pinnacle of Himalayan Living" class="about-mvv-row-img">
                        <div class="about-mvv-row-overlay"></div>
                        <span class="about-mvv-row-badge about-mvv-row-badge--gold">OUR VISION</span>
                        <span class="about-mvv-row-num" style="color: rgba(220, 182, 88, 0.95);">02</span>
                    </div>
                    <div class="about-mvv-row-content">
                        <span class="about-mvv-row-eyebrow">ASPIRATION &amp; HORIZON</span>
                        <h3 class="about-mvv-row-title">The Benchmark of Himalayan Living</h3>
                        <p class="about-mvv-row-desc">
                            We envision The Ulhas Vilas as the premier Himalayan enclave—where world-class engineering, sustainable native stone craft, and bespoke holistic wellness converge to create legacy freehold homes that enrich family lives and celebrate Himachal Pradesh’s incomparable beauty.
                        </p>
                        <div class="about-mvv-pills-row">
                            <span class="about-mvv-pill about-mvv-pill--gold"><span class="about-mvv-pill-dot" style="background: #B88B2A;"></span>Prestige</span>
                            <span class="about-mvv-pill about-mvv-pill--gold"><span class="about-mvv-pill-dot" style="background: #B88B2A;"></span>Generational Legacy</span>
                            <span class="about-mvv-pill about-mvv-pill--gold"><span class="about-mvv-pill-dot" style="background: #B88B2A;"></span>Wellness</span>
                        </div>
                    </div>
                </div>

                <!-- Chapter 3: Our Values (Image Left, Story Right) -->
                <div class="about-mvv-row">
                    <div class="about-mvv-row-media">
                        <img src="{{ asset('Website/assets/images/WhatsApp Image 2026-08-22 at 3.42.42 PM.jpeg') }}" alt="Uncompromising Craft & Reverence" class="about-mvv-row-img">
                        <div class="about-mvv-row-overlay"></div>
                        <span class="about-mvv-row-badge">OUR VALUES</span>
                        <span class="about-mvv-row-num">03</span>
                    </div>
                    <div class="about-mvv-row-content">
                        <span class="about-mvv-row-eyebrow">GUIDING PRINCIPLES</span>
                        <h3 class="about-mvv-row-title">Steadfast Craft &amp; Reverence</h3>
                        <p class="about-mvv-row-desc">
                            From native cedar and dressed mountain stone to intuitive 24/7 personalized concierge, our decisions honor authenticity over shortcuts. We protect your peace with absolute privacy and safeguard the pristine ecology of the valley for future generations.
                        </p>
                        <div class="about-mvv-pills-row">
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Integrity</span>
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Mindfulness</span>
                            <span class="about-mvv-pill"><span class="about-mvv-pill-dot"></span>Authenticity</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         3. PROMO BANNER (LUXURY VIDEO BANNER + DOWNLOAD BROCHURE)
    ========================================================= -->
    <section class="wellness-promo-section">
        <div class="wellness-promo-container">
            <div class="wellness-promo-card">
                <!-- Ambient Background Video -->
                <div class="wellness-promo-video-wrapper">
                    <video class="wellness-promo-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/amenities3.jpeg') }}">
                        <source src="{{ asset('Website/assets/images/amenities_video2.mp4') }}" type="video/mp4">
                        Your browser does not support HTML5 video.
                    </video>
                    <div class="wellness-promo-video-overlay"></div>
                </div>

                <!-- Banner Content Column -->
                <div class="wellness-promo-content">
                    <div class="wellness-promo-eyebrow-row">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#DCB658" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 2C10 6 6 10 2 12C6 14 10 18 12 22C14 18 18 14 22 12C18 10 14 6 12 2Z"/>
                            <circle cx="12" cy="12" r="2.5" fill="#DCB658"/>
                        </svg>
                        <span>LIMITED TIME ESTATE PRIVILEGE</span>
                    </div>

                    <h2 class="wellness-promo-title">Relax More, Live Grand</h2>
                    <p class="wellness-promo-desc">
                        Enjoy up to 20% privilege savings on signature retreats, private cabana pavilions, and bespoke residence ownership privileges. Explore full floor plans and amenity details in our official brochure.
                    </p>

                    <!-- Dual Action Buttons -->
                    <div class="wellness-promo-btn-group">
                        <button type="button" class="wellness-brochure-btn" onclick="openQuoteModal('', '', '')">
                            <span>DOWNLOAD BROCHURE</span>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                <polyline points="7 10 12 15 17 10"/>
                                <line x1="12" y1="15" x2="12" y2="3"/>
                            </svg>
                        </button>
                        <a href="{{ url('/residences') }}" class="wellness-promo-btn" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:0.5rem;">
                            <span>EXPLORE PACKAGES</span>
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                </div>

                <!-- Right Circular Badge -->
                <div class="wellness-promo-badge-box">
                    <div class="wellness-circular-badge">
                        <div class="circ-badge-inner">
                            <span class="circ-small">UP TO</span>
                            <span class="circ-large">20%</span>
                            <span class="circ-sub">OFF</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         3.5 WHY CHOOSE US (PURE WHITE EDITORIAL LUXURY THEME)
    ========================================================= -->
    <section class="about-why-section">
        <div class="about-why-container">
            <div class="about-why-header">
                <div class="about-why-eyebrow-wrap">
                    <span class="about-why-eyebrow-line"></span>
                    <span class="about-why-eyebrow">DISTINCTIVE ADVANTAGES</span>
                    <span class="about-why-eyebrow-line"></span>
                </div>
                <h2 class="about-why-title">Why Choose The Ulhas Vilas</h2>
                <p class="about-why-desc">
                    Exclusive benefits of owning a holiday apartment at Ulhas Vilas
                </p>
            </div>

            <div class="about-why-grid">
                <!-- Card 1: 5-Year Ayurvyaas Membership -->
                <div class="about-why-card">
                    <div class="about-why-card-top">
                        <div class="about-why-icon-box">
                            <!-- 5-Year Rosette Badge Icon -->
                            <svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="16" cy="12" r="8.5" stroke="#DCB658" stroke-width="2" fill="#FAF6ED"/>
                                <path d="M12 18.5L8.5 28.5L16 24.5L23.5 28.5L20 18.5" stroke="#B88B2A" stroke-width="1.8" fill="#FAF6ED"/>
                                <text x="16" y="16" font-family="'Marcellus', serif" font-size="11.5" font-weight="700" fill="#8F6A1E" text-anchor="middle" stroke="none">5</text>
                            </svg>
                        </div>
                        <span class="about-why-watermark">01</span>
                    </div>
                    <h3 class="about-why-card-title">5-Year Ayurvyaas Membership</h3>
                    <p class="about-why-card-text">
                        Get a complimentary five year membership for Ayurvyaas Retreat. Access world-class wellness packages at discounted rates while staying in the comfort of your own home.
                    </p>
                    <span class="about-why-pill">
                        <span class="about-why-pill-dot"></span>
                        Ayurvyaas Privilege
                    </span>
                </div>

                <!-- Card 2: Guaranteed Lease & Impressive Returns -->
                <div class="about-why-card">
                    <div class="about-why-card-top">
                        <div class="about-why-icon-box">
                            <!-- Hand & Investment Bag Icon -->
                            <svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M19 4L22.5 9H15.5L19 4Z" fill="#DCB658" stroke="#DCB658" stroke-width="1.2"/>
                                <path d="M12 11C12 9.5 15 8 19 8C23 8 26 9.5 26 11C26 15 27.5 18 27.5 20C27.5 22 23.5 23 19 23C14.5 23 10.5 22 10.5 20C10.5 18 12 15 12 11Z" stroke="#B88B2A" stroke-width="1.8" fill="#FAF6ED"/>
                                <text x="19" y="18" font-family="'Manrope', sans-serif" font-size="9.5" font-weight="700" fill="#8F6A1E" text-anchor="middle" stroke="none">₹</text>
                                <path d="M4.5 24H12L17 26.5H26.5C28 26.5 29 25 28.5 23.5L25.5 20" stroke="#2B7A78" stroke-width="1.8"/>
                                <path d="M4 27.5L10.5 27.5" stroke="#2B7A78" stroke-width="1.8"/>
                            </svg>
                        </div>
                        <span class="about-why-watermark">02</span>
                    </div>
                    <h3 class="about-why-card-title">Guaranteed Lease & Impressive Returns</h3>
                    <p class="about-why-card-text">
                        Whether you keep this property as a personal retreat or take advantage of guaranteed lease, your investment promises impressive returns.
                    </p>
                    <span class="about-why-pill">
                        <span class="about-why-pill-dot"></span>
                        High-Yield ROI
                    </span>
                </div>

                <!-- Card 3: Exclusive Rooftop Restaurant & Bar -->
                <div class="about-why-card">
                    <div class="about-why-card-top">
                        <div class="about-why-icon-box">
                            <!-- Restaurant Cloche & Cocktail Icon -->
                            <svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M4 23H24" stroke="#2B7A78" stroke-width="1.8"/>
                                <path d="M6.5 23C6.5 17 11 12.5 17.5 12.5C19.5 12.5 21.2 13 22.8 14" stroke="#2B7A78" stroke-width="1.8"/>
                                <circle cx="17.5" cy="10.5" r="2" fill="#DCB658" stroke="#DCB658" stroke-width="1"/>
                                <path d="M21 7L29 7L25 13.5L21 7Z" stroke="#B88B2A" stroke-width="1.6" fill="#FAF6ED"/>
                                <path d="M25 13.5V19.5" stroke="#B88B2A" stroke-width="1.6"/>
                                <path d="M22.5 19.5H27.5" stroke="#B88B2A" stroke-width="1.6"/>
                                <circle cx="26.5" cy="4.5" r="1.5" fill="#DCB658" stroke="none"/>
                            </svg>
                        </div>
                        <span class="about-why-watermark">03</span>
                    </div>
                    <h3 class="about-why-card-title">Rooftop Restaurant & Bar Access</h3>
                    <p class="about-why-card-text">
                        Exclusive access to the rooftop restaurant and bar with a perfect blend of leisure and luxury.
                    </p>
                    <span class="about-why-pill">
                        <span class="about-why-pill-dot"></span>
                        Leisure & Luxury Dining
                    </span>
                </div>

                <!-- Card 4: Onsite Gym & Meeting Lounge -->
                <div class="about-why-card">
                    <div class="about-why-card-top">
                        <div class="about-why-icon-box">
                            <!-- Treadmill Fitness Runner Icon -->
                            <svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="21" cy="7.5" r="2.5" fill="#DCB658" stroke="none"/>
                                <path d="M19 12L21.5 15.5L18 20.5" stroke="#B88B2A" stroke-width="1.8"/>
                                <path d="M21.5 15.5L25 17L27 21" stroke="#B88B2A" stroke-width="1.8"/>
                                <path d="M19.5 13L16 16.5L13 15" stroke="#B88B2A" stroke-width="1.8"/>
                                <path d="M9 22L11 28H27.5" stroke="#2B7A78" stroke-width="1.8"/>
                                <path d="M11 22H15" stroke="#2B7A78" stroke-width="1.8"/>
                                <path d="M9 28L6 29.5" stroke="#2B7A78" stroke-width="1.8"/>
                            </svg>
                        </div>
                        <span class="about-why-watermark">04</span>
                    </div>
                    <h3 class="about-why-card-title">Onsite Gym & Meeting Lounge</h3>
                    <p class="about-why-card-text">
                        Experience the onsite gym and meeting lounge, ensuring a balanced & productive lifestyle.
                    </p>
                    <span class="about-why-pill">
                        <span class="about-why-pill-dot"></span>
                        Active & Productive Living
                    </span>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER & JS INCLUDES -->
    @include('Website.includes.Footer')
    @include('Website.includes.JsLink')

    <!-- =========================================================
         PAGE INTERACTIVE JAVASCRIPT
    ========================================================= -->
    <script>
        // Ensure all ambient background videos autoplay properly
        document.addEventListener('DOMContentLoaded', function() {
            var bgVideos = document.querySelectorAll('.about-promo-bg-video, .about-hero-bg-video, .wellness-promo-bg-video');
            bgVideos.forEach(function(v) {
                v.muted = true;
                var promise = v.play();
                if (promise !== undefined) {
                    promise.catch(function() {
                        // Autoplay prevented, retry on user interaction
                        document.body.addEventListener('touchstart', function() { v.play(); }, { once: true });
                        document.body.addEventListener('click', function() { v.play(); }, { once: true });
                    });
                }
            });
        });

        // Subtle tilt animation for polaroid on mousemove
        (function() {
            var card = document.querySelector('.about-polaroid-card');
            if (!card) return;
            
            card.addEventListener('mouseenter', function() {
                this.style.transition = 'transform 0.25s ease-out, box-shadow 0.25s ease-out';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transition = 'transform 0.5s ease-in-out, box-shadow 0.5s ease-in-out';
                this.style.transform = 'rotate(-6.5deg)';
            });
        })();
    </script>
