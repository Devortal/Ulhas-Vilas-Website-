@include('Website.includes.CssLink')
@include('Website.includes.Header')

<style>
    /* Home Hero View Packages Button Custom Override to prevent CssLink collision */
    a.hero-view-packages-btn[class*="border-[#cca43b]"] {
        color: #ffffff !important;
        border: 1.5px solid rgba(204, 164, 59, 0.6) !important;
        background: rgba(255, 255, 255, 0.1) !important;
        font-family: 'Outfit', sans-serif !important;
    }
    a.hero-view-packages-btn[class*="border-[#cca43b]"]:hover {
        background: #102A43 !important;
        color: #ffffff !important;
        border-color: #102A43 !important;
    }
    a.hero-view-packages-btn[class*="border-[#cca43b]"] span {
        color: #ffffff !important;
    }
    a.hero-view-packages-btn[class*="border-[#cca43b]"]:hover span {
        color: #ffffff !important;
    }
    a.get-in-touch-btn {
        background: #102A43 !important;
        color: #ffffff !important;
    }
    a.get-in-touch-btn:hover {
        background: #CCA43B !important;
        color: #ffffff !important;
    }
</style>

@php
    $isLoggedIn = session()->has('user_login');
    $userType = 'B2C';
    if ($isLoggedIn) {
        $user = session('user_login');
        $userData = is_array($user) ? $user[0] : $user;
        $userType = strtoupper($userData->user_type ?? 'B2C');
    }

    $sliders = DB::table('sliders')->where('status', 1)->orderBy('id', 'desc')->get();
@endphp

<section class="relative min-h-[65vh] lg:min-h-[75vh] bg-[#050c18] overflow-hidden font-sora">
    <div class="swiper heroSwiper min-h-[65vh] lg:min-h-[75vh]">
        <div class="swiper-wrapper">
            @if(isset($sliders) && count($sliders) > 0)
                @foreach($sliders as $slider)
                    <div class="swiper-slide relative flex items-center min-h-[65vh] lg:min-h-[75vh]">
                        <!-- Hero Background Image with Smart Scenery Framing -->
                        <div class="absolute inset-0 z-0 overflow-hidden bg-[#050c18]">
                            <img src="{{ asset($slider->image) }}" alt="" class="absolute inset-0 w-full h-full object-cover blur-3xl opacity-35 scale-110">
                            <img src="{{ asset($slider->image) }}" alt="{{ $slider->title ?? 'Explore Himachal' }}" class="relative w-full h-full object-cover object-[center_75%] opacity-85">
                            <div class="absolute inset-0 bg-gradient-to-r from-[#050c18]/90 via-[#050c18]/55 to-transparent"></div>
                            <div class="absolute inset-0 bg-gradient-to-t from-[#050c18]/70 via-transparent to-transparent"></div>
                        </div>
                        <!-- Content Wrapper -->
                        <div class="max-w-7xl mx-auto w-full px-4 md:px-8 relative z-10 pt-14 pb-20 md:pt-20 md:pb-28">
                            <div class="max-w-2xl text-white space-y-5">
                                <!-- Tag / Cursive Eyebrow -->
                                @if(!empty($slider->tag))
                                    <div class="flex items-center gap-2">
                                        <span class="font-caveat text-[#cca43b] text-2xl md:text-3.5xl font-medium tracking-wide">{{ $slider->tag }}</span>
                                        <svg class="w-12 h-6 text-[#cca43b] opacity-80" viewBox="0 0 50 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 19C10 15 20 5 35 7C42 8 47 15 48 10" stroke="currentColor" stroke-dasharray="3 3" stroke-width="1.5"/>
                                            <path d="M48 10L42 7M48 10L45 15" stroke="currentColor" stroke-width="1.5"/>
                                        </svg>
                                    </div>
                                @endif
                                <!-- Title -->
                                <h1 class="font-outfit text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight text-white">
                                    {{ $slider->title }}
                                </h1>
                                <!-- Description -->
                                @if(!empty($slider->description))
                                    <p class="text-sm md:text-base text-gray-200 max-w-xl leading-relaxed font-normal">
                                        {{ $slider->description }}
                                    </p>
                                @endif
                                <!-- Buttons -->
                                <div class="flex flex-wrap items-center gap-4 pt-4">
                                    <a href="/contact-us" class="bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#b8860b] hover:to-[#cca43b] text-slate-950 font-bold text-sm px-7 py-3.5 rounded-full flex items-center gap-2 shadow-lg shadow-[#cca43b]/25 transform hover:-translate-y-0.5 transition duration-300">
                                        <i class="fa-solid fa-paper-plane text-sm"></i>
                                        <span>Contact Us</span>
                                    </a>
                                    <a href="/packages" class="hero-view-packages-btn bg-white/10 hover:bg-white/20 text-white border border-[#cca43b]/60 hover:border-[#cca43b] font-bold text-sm px-7 py-3.5 rounded-full flex items-center justify-center gap-2 backdrop-blur-sm shadow-md transform hover:-translate-y-0.5 transition duration-300">
                                        <i class="fa-solid fa-compass text-sm text-[#cca43b]"></i>
                                        <span>View Packages</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <!-- Slide 1 Fallback -->
                <div class="swiper-slide relative flex items-center min-h-[65vh] lg:min-h-[75vh]">
                    <div class="absolute inset-0 z-0 overflow-hidden bg-[#050c18]">
                        <img src="{{ asset('Website/assets/images/hero/hero_bg.png') }}" alt="Explore Himachal" class="relative w-full h-full object-cover object-center opacity-85">
                        <div class="absolute inset-0 bg-gradient-to-r from-[#050c18]/90 via-[#050c18]/50 to-transparent"></div>
                    </div>
                    <div class="max-w-7xl mx-auto w-full px-4 md:px-8 relative z-10 pt-14 pb-20 md:pt-20 md:pb-28">
                        <div class="max-w-2xl text-white space-y-5">
                            <div class="flex items-center gap-2">
                                <span class="font-caveat text-[#cca43b] text-2xl md:text-3.5xl font-medium tracking-wide">Explore the Beauty of</span>
                                <svg class="w-12 h-6 text-[#cca43b] opacity-80" viewBox="0 0 50 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 19C10 15 20 5 35 7C42 8 47 15 48 10" stroke="currentColor" stroke-dasharray="3 3" stroke-width="1.5"/>
                                    <path d="M48 10L42 7M48 10L45 15" stroke="currentColor" stroke-width="1.5"/>
                                </svg>
                            </div>
                            <h1 class="font-outfit text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
                                <span class="block md:whitespace-nowrap">Himachal Pradesh</span>
                                <span class="block text-[#cca43b] md:whitespace-nowrap">with Chaarvi</span>
                            </h1>
                            <p class="text-sm md:text-base text-gray-200 max-w-xl leading-relaxed font-normal">
                                Unforgettable journeys to the most beautiful places in Himachal Pradesh. Plan your perfect escape today.
                            </p>
                            <div class="flex flex-wrap items-center gap-4 pt-4">
                                <a href="/contact-us" class="bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#b8860b] hover:to-[#cca43b] text-slate-950 font-bold text-sm px-7 py-3.5 rounded-full flex items-center gap-2 shadow-lg shadow-[#cca43b]/25 transform hover:-translate-y-0.5 transition duration-300">
                                    <i class="fa-solid fa-paper-plane text-sm"></i>
                                    <span>Contact Us</span>
                                </a>
                                <a href="/packages" class="hero-view-packages-btn bg-white/10 hover:bg-white/20 text-white border border-[#cca43b]/60 hover:border-[#cca43b] font-bold text-sm px-7 py-3.5 rounded-full flex items-center justify-center gap-2 backdrop-blur-sm shadow-md transform hover:-translate-y-0.5 transition duration-300">
                                    <i class="fa-solid fa-compass text-sm text-[#cca43b]"></i>
                                    <span>View Packages</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide 2 Fallback -->
                <div class="swiper-slide relative flex items-center min-h-[65vh] lg:min-h-[75vh]">
                    <div class="absolute inset-0 z-0 overflow-hidden bg-[#050c18]">
                        <img src="{{ asset('Website/assets/images/destinations/shimla.png') }}" alt="Scenic Shimla & Spiti Valley" class="relative w-full h-full object-cover object-center opacity-85">
                        <div class="absolute inset-0 bg-gradient-to-r from-[#050c18]/90 via-[#050c18]/50 to-transparent"></div>
                    </div>
                    <div class="max-w-7xl mx-auto w-full px-4 md:px-8 relative z-10 pt-14 pb-20 md:pt-18 md:pb-24">
                        <div class="max-w-2xl text-white space-y-5">
                            <div class="flex items-center gap-2">
                                <span class="font-caveat text-[#cca43b] text-2xl md:text-3.5xl font-medium tracking-wide">Discover the Charm of</span>
                            </div>
                            <h1 class="font-outfit text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
                                <span class="block md:whitespace-nowrap">Scenic Shimla &</span>
                                <span class="block text-[#cca43b] md:whitespace-nowrap">Spiti Valley</span>
                            </h1>
                            <p class="text-sm md:text-base text-gray-200 max-w-xl leading-relaxed font-normal">
                                Explore the snow-capped mountains, ancient monasteries, and serene landscapes of Shimla and Spiti.
                            </p>
                            <div class="flex flex-wrap items-center gap-4 pt-4">
                                <a href="/contact-us" class="bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#b8860b] hover:to-[#cca43b] text-slate-950 font-bold text-sm px-7 py-3.5 rounded-full flex items-center gap-2 shadow-lg shadow-[#cca43b]/25 transform hover:-translate-y-0.5 transition duration-300">
                                    <i class="fa-solid fa-paper-plane text-sm"></i>
                                    <span>Contact Us</span>
                                </a>
                                <a href="/packages" class="hero-view-packages-btn bg-white/10 hover:bg-white/20 text-white border border-[#cca43b]/60 hover:border-[#cca43b] font-bold text-sm px-6 py-3.5 rounded-full flex items-center justify-center gap-2 backdrop-blur-sm shadow-md transform hover:-translate-y-0.5 transition duration-300">
                                    <i class="fa-solid fa-compass text-sm text-[#cca43b]"></i>
                                    <span>View Packages</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <!-- Slider Pagination Dots -->
        <div class="hero-pagination absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2"></div>
    </div>
</section>


<!-- ==================== HERO TRUST / BENEFITS STRIP ==================== -->
<section class="relative z-30 -mt-10 md:-mt-12 px-4 md:px-8 font-outfit">
    <div class="max-w-7xl mx-auto">
        <div class="bg-white rounded-2xl border border-[#EEE7DA] shadow-[0_10px_35px_rgba(15,23,42,0.06)] overflow-hidden">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#E8E1D5]">

                <!-- Benefit 1 -->
                <div class="group flex items-center gap-4 px-6 py-6 transition-all duration-300 hover:bg-[#FFFBF3]">
                    <div class="w-16 h-16 shrink-0 rounded-full border border-[#D9B96E] bg-[#FFFDF8] flex items-center justify-center transition-all duration-300 group-hover:bg-[#C59C3A] group-hover:scale-105 group-hover:shadow-md">
                        <i class="fa-solid fa-route text-[22px] text-[#A97822] transition-colors duration-300 group-hover:text-white"></i>
                    </div>
                    <div class="min-w-0">
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-1">
                            Pathankot to Dalhousie
                        </h3>
                        <p class="text-[13px] text-[#5F6670] leading-snug">
                            Specialized tour &amp; cab packages
                        </p>
                    </div>
                </div>

                <!-- Benefit 2 -->
                <div class="group flex items-center gap-4 px-6 py-6 transition-all duration-300 hover:bg-[#FFFBF3]">
                    <div class="w-16 h-16 shrink-0 rounded-full border border-[#D9B96E] bg-[#FFFDF8] flex items-center justify-center transition-all duration-300 group-hover:bg-[#C59C3A] group-hover:scale-105 group-hover:shadow-md">
                        <i class="fa-solid fa-hand-holding-dollar text-[22px] text-[#A97822] transition-colors duration-300 group-hover:text-white"></i>
                    </div>
                    <div class="min-w-0">
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-1">
                            Best Price Guarantee
                        </h3>
                        <p class="text-[13px] text-[#5F6670] leading-snug">
                            No hidden charges
                        </p>
                    </div>
                </div>

                <!-- Benefit 3 -->
                <div class="group flex items-center gap-4 px-6 py-6 transition-all duration-300 hover:bg-[#FFFBF3]">
                    <div class="w-16 h-16 shrink-0 rounded-full border border-[#D9B96E] bg-[#FFFDF8] flex items-center justify-center transition-all duration-300 group-hover:bg-[#C59C3A] group-hover:scale-105 group-hover:shadow-md">
                        <i class="fa-solid fa-car-side text-[22px] text-[#A97822] transition-colors duration-300 group-hover:text-white"></i>
                    </div>
                    <div class="min-w-0">
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-1">
                            Verified Cabs & Drivers
                        </h3>
                        <p class="text-[13px] text-[#5F6670] leading-snug">
                            Expert mountain drivers
                        </p>
                    </div>
                </div>

                <!-- Benefit 4 -->
                <div class="group flex items-center gap-4 px-6 py-6 transition-all duration-300 hover:bg-[#FFFBF3]">
                    <div class="w-16 h-16 shrink-0 rounded-full border border-[#D9B96E] bg-[#FFFDF8] flex items-center justify-center transition-all duration-300 group-hover:bg-[#C59C3A] group-hover:scale-105 group-hover:shadow-md">
                        <i class="fa-solid fa-headset text-[22px] text-[#A97822] transition-colors duration-300 group-hover:text-white"></i>
                    </div>
                    <div class="min-w-0">
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-1">
                            24/7 On-Trip Support
                        </h3>
                        <p class="text-[13px] text-[#5F6670] leading-snug">
                            Dedicated trip manager
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- ==================== CATEGORIES ==================== -->
<section id="categories" class="pt-4 pb-6 md:pt-14 md:pb-6 bg-gradient-to-b from-[#FCFAF5] to-white relative overflow-hidden font-sora">
    <div class="absolute top-0 left-0 w-64 h-64 bg-gold/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>

    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-10">
        <div class="flex flex-col items-center justify-center">
            <span class="font-caveat text-gold text-2xl md:text-3.5xl font-medium tracking-wide">Wonderful Place For You</span>
            <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">Tour Categories</h2>
            <div class="h-[2px] w-16 bg-gold mt-4"></div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="relative px-6">
            <div class="swiper categorySwiper py-4">
                <div class="swiper-wrapper">
                    @php
                        try {
                            $categories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'desc')->get();
                        } catch (\Exception $e) {
                            $categories = collect();
                        }
                        $totalCategories = count($categories);
                    @endphp
                    @forelse($categories as $index => $cat)
                        @php
                            if ($totalCategories > 1) {
                                $step = 6 / ($totalCategories - 1);
                                $angle = round(-3 + ($index * $step), 1);
                            } else {
                                $angle = 0;
                            }
                            $rotationStyle = "transform: rotate({$angle}deg);";

                            $catImg = trim($cat->image ?? '');
                            $cleanPath = ltrim($catImg, '/');

                            if (!empty($cleanPath) && file_exists(public_path($cleanPath))) {
                                $imageSrc = asset($cleanPath);
                            } elseif (!empty($cleanPath)) {
                                $imageSrc = asset($cleanPath);
                            } else {
                                $imageSrc = asset('Website/assets/images/destinations/manali.png');
                            }
                        @endphp
                        <div class="swiper-slide flex justify-center py-4">
                            <a href="/packages?category_id={{ $cat->id ?? '' }}" style="{{ $rotationStyle }}" class="group flex flex-col items-center transition-all duration-500 hover:-translate-y-2 hover:!rotate-0 w-[200px]">
                                <div class="w-full aspect-[4/5] rounded-[28px] overflow-hidden mb-3 shadow-[0_12px_30px_rgba(0,0,0,0.12)] border-4 border-white relative">
                                    <img src="{{ $imageSrc }}" alt="{{ $cat->category_name ?? 'Category' }}" class="w-full h-full object-cover transform group-hover:scale-110 transition duration-700">
                                    <div class="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                                </div>
                                <h3 class="category-name font-outfit text-xs sm:text-sm font-bold text-[#102A43] group-hover:text-[#cca43b] transition-colors duration-300 text-center" style="color: #102A43 !important;">
                                    {{ $cat->category_name }}
                                </h3>
                            </a>
                        </div>
                    @empty
                        <div class="text-center py-8 text-gray-400 w-full">
                            No categories found.
                        </div>
                    @endforelse
                </div>
            </div>

            <!-- Slider Navigation Buttons -->
            <button class="cat-prev absolute left-0 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white hover:bg-[#cca43b] text-[#050c18] hover:text-white flex items-center justify-center shadow-lg transition-all duration-300 focus:outline-none border border-gray-100 group">
                <i class="fa-solid fa-chevron-left text-sm text-[#050c18] group-hover:text-white transition-colors duration-300"></i>
            </button>
            <button class="cat-next absolute right-0 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white hover:bg-[#cca43b] text-[#050c18] hover:text-white flex items-center justify-center shadow-lg transition-all duration-300 focus:outline-none border border-gray-100 group">
                <i class="fa-solid fa-chevron-right text-sm text-[#050c18] group-hover:text-white transition-colors duration-300"></i>
            </button>
        </div>
    </div>
</section>

<!-- ==================== COUNTER / STATISTICS STRIP (LIGHT THEME) ==================== -->
<section class="bg-gradient-to-r from-[#FFFDF9] via-[#FAF6ED] to-[#FFFDF9] text-navy font-sora py-6 md:py-8 relative overflow-hidden border-y border-[#EBE3D3]">
    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-200/80 gap-y-8 md:gap-y-0">
            
            <!-- Stat 1 -->
            <div class="flex items-center justify-center gap-4 px-4 sm:px-6">
                <div class="w-12 h-12 rounded-full border border-gold/30 bg-gold/10 flex items-center justify-center text-gold shrink-0 shadow-sm">
                    <i class="fa-solid fa-award text-lg"></i>
                </div>
                <div>
                    <h3 class="font-outfit text-2xl sm:text-3xl md:text-3.5xl font-black text-navy leading-none tracking-tight">
                        {{ $info->stat_1_val ?? '8+' }}
                    </h3>
                    <p class="text-[11px] sm:text-xs font-bold text-gray-500 uppercase tracking-wider mt-1.5">{{ $info->stat_1_title ?? 'Years of Excellence' }}</p>
                </div>
            </div>

            <!-- Stat 2 -->
            <div class="flex items-center justify-center gap-4 px-4 sm:px-6">
                <div class="w-12 h-12 rounded-full border border-gold/30 bg-gold/10 flex items-center justify-center text-gold shrink-0 shadow-sm">
                    <i class="fa-solid fa-users text-lg"></i>
                </div>
                <div>
                    <h3 class="font-outfit text-2xl sm:text-3xl md:text-3.5xl font-black text-navy leading-none tracking-tight">
                        {{ $info->stat_2_val ?? '15k+' }}
                    </h3>
                    <p class="text-[11px] sm:text-xs font-bold text-gray-500 uppercase tracking-wider mt-1.5">{{ $info->stat_2_title ?? 'Happy Travelers' }}</p>
                </div>
            </div>

            <!-- Stat 3 -->
            <div class="flex items-center justify-center gap-4 px-4 sm:px-6">
                <div class="w-12 h-12 rounded-full border border-gold/30 bg-gold/10 flex items-center justify-center text-gold shrink-0 shadow-sm">
                    <i class="fa-solid fa-map-location-dot text-lg"></i>
                </div>
                <div>
                    <h3 class="font-outfit text-2xl sm:text-3xl md:text-3.5xl font-black text-navy leading-none tracking-tight">
                        {{ $info->stat_3_val ?? '100+' }}
                    </h3>
                    <p class="text-[11px] sm:text-xs font-bold text-gray-500 uppercase tracking-wider mt-1.5">{{ $info->stat_3_title ?? 'Destinations & Packages' }}</p>
                </div>
            </div>

            <!-- Stat 4 -->
            <div class="flex items-center justify-center gap-4 px-4 sm:px-6">
                <div class="w-12 h-12 rounded-full border border-gold/30 bg-gold/10 flex items-center justify-center text-gold shrink-0 shadow-sm">
                    <i class="fa-solid fa-star text-lg"></i>
                </div>
                <div>
                    <h3 class="font-outfit text-2xl sm:text-3xl md:text-3.5xl font-black text-navy leading-none tracking-tight flex items-center gap-0.5">
                        {{ $info->stat_4_val ?? '4.9★' }}
                    </h3>
                    <p class="text-[11px] sm:text-xs font-bold text-gray-500 uppercase tracking-wider mt-1.5">{{ $info->stat_4_title ?? 'Average Rating' }}</p>
                </div>
            </div>

        </div>
    </div>
</section>

<style>
    .cat-pagination .swiper-pagination-bullet-active {
        width: 1.5rem !important;
        background-color: #0ea5e9 !important;
        opacity: 1 !important;
        border-radius: 9999px !important;
    }
</style>

<!-- ==================== TOP DESTINATIONS (COVERFLOW) ==================== -->
<section id="destinations" class="py-08 bg-[#F8F9FA] relative overflow-hidden font-sora">
    <div class="absolute top-0 left-0 w-64 h-64 bg-gold/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl translate-x-1/3 translate-y-1/3"></div>

    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-12">
        <div class="flex flex-col items-center justify-center">
            <span class="font-caveat text-gold text-2xl md:text-3.5xl font-medium tracking-wide">Top Destination</span>
            <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-[#050c18] mt-1">Top Destination</h2>
            <div class="h-[2px] w-16 bg-gold mt-4"></div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="relative">
            <div class="swiper destinationSwiper py-6 overflow-visible">
                <div class="swiper-wrapper">
                    @php
                        $displayDestinations = isset($destinations) ? $destinations : collect();
                        if (count($displayDestinations) > 0 && count($displayDestinations) < 8) {
                            $multiplier = ceil(8 / count($displayDestinations));
                            $repeated = collect();
                            for ($i = 0; $i < $multiplier; $i++) {
                                $repeated = $repeated->concat($displayDestinations);
                            }
                            $displayDestinations = $repeated;
                        }
                    @endphp
                    @if(count($displayDestinations) > 0)
                        @foreach($displayDestinations as $dest)
                            @php
                                $destName = $dest->destination;
                                $imgVal = $dest->image ?? '';
                                $rawImages = [];
                                if (!empty($imgVal)) {
                                    if (str_starts_with(trim($imgVal), '[')) {
                                        $rawImages = json_decode($imgVal, true) ?: [];
                                    } else {
                                        $rawImages = array_values(array_filter(array_map('trim', explode(',', $imgVal))));
                                    }
                                }
                                $firstImg = !empty($rawImages[0]) ? asset(ltrim($rawImages[0], '/')) : asset('Website/assets/images/destinations/manali.png');
                                $pkgCount = $dest->total_packages ?? 1;
                            @endphp
                            <div class="swiper-slide dest-slide w-[260px] sm:w-[320px] aspect-[3/4] rounded-[32px] overflow-hidden relative shadow-[0_20px_50px_rgba(0,0,0,0.15)] select-none cursor-pointer" onclick="window.location.href='/packages?destination={{ urlencode($destName) }}'">
                                <img src="{{ $firstImg }}" alt="{{ $destName }}" class="absolute inset-0 w-full h-full object-cover">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent"></div>
                                
                                <div class="absolute bottom-6 left-6 right-6 z-10 text-left text-white">
                                    <h3 class="font-outfit text-base sm:text-lg font-bold tracking-tight leading-snug">{{ $destName }}</h3>
                                    <p class="text-[11px] text-gray-300 font-medium mt-1">{{ $pkgCount }} {{ $pkgCount == 1 ? 'Package' : 'Packages' }}</p>
                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>

            <!-- Custom Drag Indicator -->
            <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none hidden md:block">
                <div class="bg-navy/80 backdrop-blur-sm text-white text-xs font-bold px-4 py-2.5 rounded-full flex items-center gap-1.5 shadow-lg select-none border border-white/10">
                    <i class="fa-solid fa-chevron-left text-[9px] opacity-60"></i>
                    <span>DRAG</span>
                    <i class="fa-solid fa-chevron-right text-[9px] opacity-60"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==================== PLAN YOUR TRIP WITH US (SPECIAL TRAVEL OFFER) ==================== -->
<section class="pt-6 pb-12 md:pt-8 md:pb-16 bg-white font-sora">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        
        <!-- Outer Banner Container matching Screenshot 2 -->
        <div class="bg-gradient-to-r from-[#050c18] via-[#09152a] to-[#050c18] rounded-[32px] p-8 md:p-12 lg:p-14 text-white border border-slate-800 shadow-2xl relative overflow-hidden">
            <!-- Background Glow -->
            <div class="absolute top-0 right-0 w-96 h-96 bg-gold/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
                
                <!-- Left Content Column (7 cols) -->
                <div class="lg:col-span-7 space-y-6 text-left">
                    <!-- Special Travel Offer Badge -->
                    <div>
                        <span class="inline-flex items-center gap-2 bg-[#cca43b]/15 text-[#cca43b] text-xs font-bold px-4 py-1.5 rounded-full border border-[#cca43b]/40 uppercase tracking-wider shadow-sm">
                            <i class="fa-solid fa-gift text-xs"></i>
                            <span>Special Travel Offer</span>
                        </span>
                    </div>

                    <!-- Main Offer Heading -->
                    <h2 class="font-outfit text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight tracking-tight">
                        Get Flat <span class="text-[#cca43b]">10% Off</span> On Himachal Group &amp; Family Packages!
                    </h2>

                    <!-- Offer Description -->
                    <p class="text-sm md:text-base text-gray-300 leading-relaxed font-normal max-w-xl">
                        Plan your next getaway today. Book any customized group tour or family package and unlock exclusive price cuts, luxury stays, and private cab transfers.
                    </p>

                    <!-- Bottom Action Bar (Use Code Pill + Book Trip CTA Button) -->
                    <div class="flex flex-wrap items-center gap-4 pt-3">
                        <div class="bg-white/10 border border-white/20 backdrop-blur-md px-5 py-3 rounded-full text-xs font-bold text-gray-200 tracking-wider">
                            USE CODE: <span class="text-white font-black">CHAARVI10</span>
                        </div>
                        <a href="/contact-us" class="bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#b8860b] hover:to-[#cca43b] text-slate-950 font-bold text-sm px-8 py-3.5 rounded-full flex items-center gap-2.5 shadow-lg shadow-[#cca43b]/25 transform hover:-translate-y-0.5 transition duration-300">
                            <span>Book Your Trip Now</span>
                            <i class="fa-solid fa-arrow-right text-xs"></i>
                        </a>
                    </div>
                </div>

                <!-- Right Fanned Polaroid Images Stack Column (5 cols) matching Screenshot 2 -->
                <div class="lg:col-span-5 relative flex items-center justify-center min-h-[260px] pt-4 lg:pt-0">
                    <div class="relative w-full max-w-[360px] h-[250px] flex items-center justify-center">
                        
                        <!-- Polaroid Image 1 (Left Tilt) -->
                        <div class="absolute w-[150px] sm:w-[170px] bg-white p-2 pb-5 rounded-2xl shadow-2xl border border-gray-200 transform -rotate-12 -translate-x-16 hover:rotate-0 hover:scale-110 hover:z-30 transition-all duration-500 cursor-pointer">
                            <div class="aspect-[4/3] rounded-xl overflow-hidden mb-2">
                                <img src="{{ asset('Website/assets/images/destinations/shimla.png') }}" alt="Shimla Package" class="w-full h-full object-cover">
                            </div>
                            <p class="font-caveat text-navy text-xs font-bold text-center">Manali &amp; Shimla</p>
                        </div>

                        <!-- Polaroid Image 2 (Center Primary - Larger) -->
                        <div class="absolute w-[170px] sm:w-[190px] bg-white p-2.5 pb-6 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-gray-100 transform z-20 hover:scale-110 transition-all duration-500 cursor-pointer">
                            <div class="aspect-[4/3] rounded-xl overflow-hidden mb-2">
                                <img src="{{ asset('Website/assets/images/destinations/manali.png') }}" alt="Spiti Valley" class="w-full h-full object-cover">
                            </div>
                            <p class="font-caveat text-navy text-sm font-bold text-center">Spiti Valley</p>
                        </div>

                        <!-- Polaroid Image 3 (Right Tilt) -->
                        <div class="absolute w-[150px] sm:w-[170px] bg-white p-2 pb-5 rounded-2xl shadow-2xl border border-gray-200 transform rotate-12 translate-x-16 hover:rotate-0 hover:scale-110 hover:z-30 transition-all duration-500 cursor-pointer">
                            <div class="aspect-[4/3] rounded-xl overflow-hidden mb-2">
                                <img src="https://images.unsplash.com/photo-1597074866923-dc0589150358?auto=format&fit=crop&w=500&q=80" alt="Dalhousie Trip" class="w-full h-full object-cover">
                            </div>
                            <p class="font-caveat text-navy text-xs font-bold text-center">Dalhousie &amp; Khajjiar</p>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
</section>

<style>
    .dest-slide {
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1), filter 0.6s ease, opacity 0.6s ease;
        filter: blur(4px) brightness(0.7);
        transform: scale(0.85);
        opacity: 0.7;
    }
    .dest-slide.swiper-slide-active {
        filter: blur(0) brightness(1);
        transform: scale(1);
        opacity: 1;
        z-index: 20;
    }
    .dest-slide.swiper-slide-prev,
    .dest-slide.swiper-slide-next {
        opacity: 0.9;
        filter: blur(2px) brightness(0.8);
        transform: scale(0.9);
    }
    .scrollbar-none::-webkit-scrollbar {
        display: none;
    }
    .scrollbar-none {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
</style>

<!-- ==================== WHY TRAVEL WITH US ==================== -->
<section class="pt-6 pb-12 md:pt-8 md:pb-14 bg-[#FDFBF7] border-t border-b border-[#F0ECE3] font-outfit">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <!-- Left Side: Visual Pitch & Narrative -->
            <div class="lg:col-span-5 space-y-6">
                <div>
                    <span class="block text-[11px] font-bold text-gold uppercase tracking-widest">— WHY TRAVEL WITH US —</span>
                    <h2 class="text-3xl md:text-4xl font-extrabold text-navy leading-tight mt-2">Your Journey, Our Priority</h2>
                </div>
                <p class="text-[14px] text-[#5e6670] leading-relaxed">
                    At Chaarvi Tours &amp; Travels, we believe in creating journeys that stay with you forever. We take care of every detail so you can focus on making beautiful memories in Himachal Pradesh.
                </p>
                
                <!-- Scenic Picture with Float Badge -->
                <div class="relative rounded-2xl overflow-hidden shadow-lg h-[240px] group">
                    <img src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=600&q=80" alt="Beautiful Himachal Valleys" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                    <div class="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm border border-[#D9B96E] rounded-xl px-4 py-2.5 flex items-center gap-3 shadow-md">
                        <div class="w-8 h-8 rounded-full bg-[#FAF2E8] flex items-center justify-center text-gold">
                            <i class="fa-solid fa-award"></i>
                        </div>
                        <div>
                            <span class="block text-[10px] text-gray-500 uppercase tracking-wider font-bold leading-none">Registered &amp; Approved</span>
                            <span class="block text-xs font-bold text-navy mt-1">Govt. Tourism Partner</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side: 2x2 Feature Grid -->
            <div class="lg:col-span-7">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    
                    <!-- Feature 1 -->
                    <div class="group bg-white border border-[#EBE6DD] rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-gold/30">
                        <div class="w-12 h-12 rounded-xl bg-[#FAF2E8] border border-gold/20 flex items-center justify-center text-gold text-lg transition-all duration-300 group-hover:bg-gold group-hover:text-white mb-4">
                            <i class="fa-solid fa-users"></i>
                        </div>
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-2">Trusted by 5000+ Travelers</h3>
                        <p class="text-[12.5px] text-[#5e6670] leading-relaxed">
                            Thousands of happy families and group travelers trust us for their vacations.
                        </p>
                    </div>

                    <!-- Feature 2 -->
                    <div class="group bg-white border border-[#EBE6DD] rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-gold/30">
                        <div class="w-12 h-12 rounded-xl bg-[#FAF2E8] border border-gold/20 flex items-center justify-center text-gold text-lg transition-all duration-300 group-hover:bg-gold group-hover:text-white mb-4">
                            <i class="fa-solid fa-user-gear"></i>
                        </div>
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-2">Customized Experiences</h3>
                        <p class="text-[12.5px] text-[#5e6670] leading-relaxed">
                            Tailored travel plans designed to fit your unique expectations and preferences.
                        </p>
                    </div>

                    <!-- Feature 3 -->
                    <div class="group bg-white border border-[#EBE6DD] rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-gold/30">
                        <div class="w-12 h-12 rounded-xl bg-[#FAF2E8] border border-gold/20 flex items-center justify-center text-gold text-lg transition-all duration-300 group-hover:bg-gold group-hover:text-white mb-4">
                            <i class="fa-solid fa-car-side"></i>
                        </div>
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-2">Comfortable Journeys</h3>
                        <p class="text-[12.5px] text-[#5e6670] leading-relaxed">
                            Well-planned schedules, premium stays, and comfortable transport arrangements.
                        </p>
                    </div>

                    <!-- Feature 4 -->
                    <div class="group bg-white border border-[#EBE6DD] rounded-2xl p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:border-gold/30">
                        <div class="w-12 h-12 rounded-xl bg-[#FAF2E8] border border-gold/20 flex items-center justify-center text-gold text-lg transition-all duration-300 group-hover:bg-gold group-hover:text-white mb-4">
                            <i class="fa-solid fa-camera"></i>
                        </div>
                        <h3 class="text-[15px] font-bold text-[#080F1D] leading-tight mb-2">Memories for a Lifetime</h3>
                        <p class="text-[12.5px] text-[#5e6670] leading-relaxed">
                            We curate local sightseeing and secret spots to make every trip unforgettable.
                        </p>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<!-- ==================== POPULAR DESTINATIONS / FEATURED PACKAGES ==================== -->
<section id="packages" class="pt-6 pb-12 md:pt-8 md:pb-16 bg-white relative overflow-hidden font-sora border-b border-gray-100">
    <!-- Section Header (Centered) -->
    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-10 flex flex-col items-center justify-center">
        <span class="font-caveat text-gold text-2xl md:text-3.5xl font-medium tracking-wide">Our Featured Trips</span>
        <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">Featured Packages</h2>
        <div class="h-[3px] w-16 bg-gold mx-auto mt-4"></div>
        
        <!-- View All Button -->
        <div class="mt-6 md:mt-0 md:absolute md:right-8 md:bottom-1">
            <a href="/packages" class="bg-[#cca43b] hover:bg-[#b08b2d] text-white font-bold text-xs px-6 py-3 rounded-xl transition duration-300 shadow-md shadow-gold/15 flex items-center gap-2">
                <span>View All Packages</span>
                <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
    </div>

    @php
        try {
            $allFeaturedProducts = DB::table('packages')
                ->leftJoin('categories', 'packages.category_id', '=', 'categories.id')
                ->select('packages.*', 'categories.category_name')
                ->whereIn('packages.status', [1, '1'])
                ->orderBy('packages.id', 'desc')
                ->get();
        } catch (\Exception $e) {
            $allFeaturedProducts = collect();
        }

        try {
            $categories = DB::table('categories')->whereIn('status', [1, '1'])->orderBy('id', 'desc')->get();
        } catch (\Exception $e) {
            $categories = collect();
        }
    @endphp

    <!-- Category Tabs (No huge side gaps) -->
    <div class="max-w-7xl mx-auto px-4 relative z-10 flex overflow-x-auto md:flex-wrap md:justify-center items-center gap-2 mb-10 pt-3 pb-3 scrollbar-none whitespace-nowrap">
        <button class="category-tab-btn active px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 border border-[#cca43b] bg-[#cca43b] text-white shrink-0" onclick="filterCategory('all', this)">
            All Packages
        </button>
        @if(isset($categories) && count($categories) > 0)
            @foreach($categories as $cat)
                <button class="category-tab-btn px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 border border-gray-200 text-gray-500 hover:border-gold hover:text-gold bg-white shrink-0" onclick="filterCategory('{{ $cat->id ?? '' }}', this)">
                    {{ $cat->category_name ?? 'Category' }}
                </button>
            @endforeach
        @endif
    </div>

    <!-- Grid of Packages -->
    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="featured-packages-grid">
            @forelse($allFeaturedProducts as $prod)
                @php
                    $prodName = $prod->package_name ?? 'Featured Tour Package';
                    $prodId = $prod->id ?? 0;
                    $tagName = $prod->tag_name ?? '';
                    $destination = $prod->destination ?? 'Himachal';
                    $categoryName = $prod->category_name ?? 'Tour Package';
                    $categoryId = $prod->category_id ?? 0;
                    $description = \Illuminate\Support\Str::limit(strip_tags($prod->description ?? ''), 110);

                    // Gallery images array
                    $imgVal = $prod->image ?? '';
                    $rawImages = [];
                    if (!empty($imgVal)) {
                        if (str_starts_with(trim($imgVal), '[')) {
                            $rawImages = json_decode($imgVal, true) ?: [];
                        } else {
                            $rawImages = array_values(array_filter(array_map('trim', explode(',', $imgVal))));
                        }
                    }

                    $imagesGallery = [];
                    foreach ($rawImages as $rImg) {
                        $cleanR = ltrim($rImg, '/');
                        if (!empty($cleanR) && file_exists(public_path($cleanR))) {
                            $imagesGallery[] = asset($cleanR);
                        } elseif (!empty($cleanR)) {
                            $imagesGallery[] = asset($cleanR);
                        }
                    }
                    if (empty($imagesGallery)) {
                        $imagesGallery[] = asset('Website/assets/images/destinations/manali.png');
                    }

                    // Fetch pickup pricing from package_pickup_prices
                    $pickupPricing = DB::table('package_pickup_prices')
                        ->join('pickup_points', 'package_pickup_prices.pickup_point_id', '=', 'pickup_points.id')
                        ->where('package_pickup_prices.package_id', $prodId)
                        ->select('pickup_points.id', 'pickup_points.name as point_name', 'pickup_points.price', 'pickup_points.offer_price')
                        ->orderByRaw('CAST(REPLACE(REPLACE(pickup_points.offer_price, ",", ""), " ", "") AS DECIMAL(12,2)) ASC')
                        ->get();

                    $firstPoint = $pickupPricing->first();
                    $defPrice = $firstPoint ? (float) ($firstPoint->price ?? 0) : (float) ($prod->price ?? 0);
                    $defOfferPrice = $firstPoint ? (float) ($firstPoint->offer_price ?? $defPrice) : (float) ($prod->offer_price ?? $defPrice);
                    $prodSlug = \Illuminate\Support\Str::slug($prodName);
                @endphp

                <!-- Package Card matching packages.blade.php exactly (Default 6 items visible) -->
                <div class="package-card-item group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-slate-100 flex flex-col justify-between h-full p-0 {{ $loop->iteration > 6 ? 'hidden' : '' }}" data-package-id="{{ $prodId }}" data-category-id="{{ $categoryId }}">
                    <div class="flex-1 flex flex-col justify-between">
                        <div>
                            <!-- Image Gallery Swiper Container -->
                            <div class="relative w-full aspect-[16/10] overflow-hidden shadow-sm group/gallery">
                                <span class="absolute top-2.5 left-2.5 z-20 bg-white/95 backdrop-blur-md text-slate-800 text-[10.5px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 shadow-sm border border-slate-100">
                                    <i class="fa-solid fa-compass text-amber-500 text-[10px]"></i>
                                    <span>{{ $categoryName }}</span>
                                </span>

                                <div class="swiper card-gallery-swiper w-full h-full">
                                    <div class="swiper-wrapper">
                                        @foreach($imagesGallery as $gImg)
                                            <div class="swiper-slide w-full h-full">
                                                <img src="{{ $gImg }}" alt="{{ $prodName }}" class="w-full h-full object-cover">
                                            </div>
                                        @endforeach
                                    </div>
                                    <div class="swiper-pagination card-gallery-pagination !bottom-2"></div>
                                </div>

                                <span class="absolute bottom-2.5 left-2.5 z-20 bg-black/60 backdrop-blur-md text-white text-[10.5px] font-medium px-2.5 py-0.5 rounded-full flex items-center gap-1 border border-white/10">
                                    <i class="fa-solid fa-location-dot text-amber-400 text-[10px]"></i>
                                    <span>{{ $destination }}</span>
                                </span>

                                <span class="absolute bottom-2.5 right-2.5 z-20 bg-black/60 backdrop-blur-md text-white text-[10px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 border border-white/10">
                                    <i class="fa-regular fa-image text-[9.5px]"></i>
                                    <span class="gallery-counter-text">1/{{ count($imagesGallery) }}</span>
                                </span>
                            </div>

                            <!-- Card Content -->
                            <div class="p-3.5 pb-0 space-y-1.5">
                                <div class="min-h-[2.4rem] flex flex-col justify-start">
                                    <h3 class="font-outfit text-sm font-bold text-slate-900 leading-snug tracking-tight line-clamp-2">
                                        {{ $prodName }}
                                    </h3>
                                </div>
                                <div class="min-h-[2rem]">
                                    <p class="text-slate-500 text-[11.5px] leading-relaxed line-clamp-2">
                                        {{ $description }}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Pickup Points Dropdown -->
                        @if(count($pickupPricing) > 0)
                            <div class="px-3.5 mt-auto pt-2">
                                <div class="bg-indigo-50/70 border border-indigo-100 rounded-xl p-2 flex items-center justify-between gap-2">
                                    <span class="text-[11px] font-bold text-indigo-700 flex items-center gap-1 shrink-0">
                                        <i class="fa-solid fa-location-dot text-indigo-500 text-[10px]"></i>
                                        <span>Pickup Point:</span>
                                    </span>
                                    <select class="pkg-pickup-select bg-white border border-indigo-200 text-xs font-bold text-slate-800 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-400 cursor-pointer max-w-[170px]" onchange="handlePickupChange(this)">
                                        @foreach($pickupPricing as $pp)
                                            <option value="{{ $pp->id }}" data-price="{{ $pp->price }}" data-offer="{{ $pp->offer_price }}">
                                                {{ $pp->point_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        @endif
                    </div>

                    <!-- Footer Pricing & Action Buttons -->
                    <div class="p-3.5 pt-0">
                        <div class="pt-2 mt-2 border-t border-slate-100 flex items-center justify-between">
                            <span class="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider">Starts From</span>
                            <div class="flex items-baseline gap-1.5">
                                <span class="card-offer-price text-lg font-black text-amber-600">₹{{ number_format($defOfferPrice, 0) }}</span>
                                @if($defPrice > $defOfferPrice)
                                    <del class="card-orig-price text-xs font-bold text-slate-400">₹{{ number_format($defPrice, 0) }}</del>
                                @else
                                    <del class="card-orig-price text-xs font-bold text-slate-400 hidden"></del>
                                @endif
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 mt-2">
                            <a href="/package-detail/{{ $prodId }}/{{ $prodSlug }}" onclick="goToPackageDetails(event, this.href, '{{ $prodId }}')" class="border border-slate-200 hover:border-amber-500 hover:text-amber-600 text-slate-700 text-xs font-bold py-2 rounded-xl transition duration-300 flex items-center justify-center gap-1">
                                <i class="fa-regular fa-eye"></i> Details
                            </a>
                            <button type="button" onclick="openBookingModal('{{ addslashes($prodName) }}', '{{ $prodId }}')" class="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2 rounded-xl transition duration-300 shadow-sm flex items-center justify-center gap-1">
                                <i class="fa-regular fa-calendar-check"></i> Book Now
                            </button>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-12 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                    <p class="text-gray-500 font-semibold text-sm">No featured tour packages found at the moment.</p>
                </div>
            @endforelse
        </div>

        <!-- Featured Packages Pagination -->
        <div id="featured-packages-pagination" class="mt-8 flex justify-center"></div>



    </div>
</section>

<!-- ==================== WHY CHOOSE US / THE CHAARVI EXPERIENCE ==================== -->
<section id="why-choose-us" class="py-12 md:py-16 bg-[#FCFAF7] border-b border-gray-100 font-sora">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        
        <!-- Header -->
        <div class="text-center max-w-2xl mx-auto pt-4 mb-12 lg:mb-16">
            <span class="font-caveat text-gold text-2.5xl md:text-3.5xl font-medium tracking-wide">Why Choose Us</span>
            <h2 class="font-outfit text-3xl sm:text-4xl lg:text-4.5xl font-extrabold text-navy tracking-tight mt-1">
                Travel Services You Can Trust
            </h2>
            <p class="text-xs sm:text-sm text-gray-500 mt-2 font-normal">
                Handcrafted Himachal journeys designed for comfort, safety, and unforgettable memories.
            </p>
            <div class="h-[2.5px] w-14 bg-gold mx-auto mt-4 rounded-full"></div>
        </div>

            <!-- 8 Cards Grid with Timeline Dots -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
                
                <!-- Card 1 -->
                <div class="relative group">
                    <!-- Step/Dot Header -->
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-plane-departure text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <!-- White Content Box -->
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">01. Fleet & Flight</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Best Travel Deals
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Compare and book top cab packages and flights at best rates.
                        </p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-hotel text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">02. Stays</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Handpicked Hotels
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Stay at top verified mountain resorts with premium comfort.
                        </p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-user-tie text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">03. Guidance</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Expert Local Drivers
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Explore with friendly, experienced mountain drivers and guides.
                        </p>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-shield-halved text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden lg:block opacity-0"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">04. Protection</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Safe & Secure
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Your safety is our priority with 100% verified cabs and trips.
                        </p>
                    </div>
                </div>

                <!-- Card 5 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-map-location-dot text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">05. Customization</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Tailored Itineraries
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Custom tour packages tailored to your schedule and budget.
                        </p>
                    </div>
                </div>

                <!-- Card 6 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-calendar-check text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">06. Hassle-Free</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Instant Booking
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Simple, transparent booking in just a few easy steps.
                        </p>
                    </div>
                </div>

                <!-- Card 7 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-headset text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden sm:block"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">07. Assistance</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            24/7 On-Trip Support
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            Dedicated trip managers available throughout your journey.
                        </p>
                    </div>
                </div>

                <!-- Card 8 -->
                <div class="relative group">
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 rounded-full border-2 border-gold bg-white flex items-center justify-center text-gold shadow-sm z-10 group-hover:scale-110 group-hover:bg-gold group-hover:text-white transition-all duration-300">
                            <i class="fa-solid fa-award text-xs"></i>
                        </div>
                        <div class="flex-1 h-[2px] bg-[#E5DBC5] ml-2 hidden lg:block opacity-0"></div>
                    </div>
                    <div class="bg-white rounded-2xl p-6 border border-[#EAE1CF] shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1 transition-all duration-300 min-h-[160px] flex flex-col justify-start">
                        <span class="text-[10.5px] font-bold tracking-wider text-gold uppercase mb-1">08. Assurance</span>
                        <h3 class="font-outfit text-[15px] font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                            Best Price Guarantee
                        </h3>
                        <p class="text-xs text-gray-500 mt-2 leading-relaxed">
                            No hidden costs, fair pricing, and best value for money.
                        </p>
                    </div>
                </div>

            </div>

    </div>
</section>





<!-- ==================== EXPLORE OUR SERVICES ==================== -->
<section id="services" class="py-12 md:py-16 bg-white border-b border-gray-100 font-sora">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        
        <!-- Section Header -->
        <div class="text-center max-w-2xl mx-auto pt-4 mb-12 lg:mb-16">
            <span class="font-caveat text-gold text-2.5xl md:text-3.5xl font-medium tracking-wide">What We Offer</span>
            <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy tracking-tight mt-1">
                Explore Our Travel Services
            </h2>
            <p class="text-xs sm:text-sm text-gray-500 mt-2 font-normal">
                Comprehensive tour packages, luxury cabs, and hotel bookings crafted for your Himachal journey.
            </p>
            <div class="h-[2.5px] w-14 bg-gold mx-auto mt-4 rounded-full"></div>
        </div>

        <!-- 4 Cards Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            
            <!-- Service 1: Customized Tour Packages -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/80 p-6 shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xl mb-5 group-hover:bg-gold group-hover:text-white transition-all duration-300 shadow-sm">
                        <i class="fa-solid fa-mountain-sun"></i>
                    </div>
                    <h3 class="font-outfit text-lg font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                        Customized Tour Packages
                    </h3>
                    <p class="text-xs text-gray-500 mt-2.5 leading-relaxed">
                        Tailor-made itineraries for families, couples, and group vacations across Himachal Pradesh.
                    </p>
                </div>
                <div class="pt-6 mt-4 border-t border-gray-100">
                    <a href="/packages" class="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-navy transition-colors">
                        <span>Explore Packages</span>
                        <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
            </div>

            <!-- Service 2: Luxury Cabs & Transfers -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/80 p-6 shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xl mb-5 group-hover:bg-gold group-hover:text-white transition-all duration-300 shadow-sm">
                        <i class="fa-solid fa-car-side"></i>
                    </div>
                    <h3 class="font-outfit text-lg font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                        Luxury Cabs &amp; Transfers
                    </h3>
                    <p class="text-xs text-gray-500 mt-2.5 leading-relaxed">
                        Reliable Pathankot to Dalhousie, Shimla &amp; Manali cab transfers with expert drivers.
                    </p>
                </div>
                <div class="pt-6 mt-4 border-t border-gray-100">
                    <a href="/contact-us" class="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-navy transition-colors">
                        <span>Book Cab Transfer</span>
                        <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
            </div>

            <!-- Service 3: Handpicked Hotel Stays -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/80 p-6 shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xl mb-5 group-hover:bg-gold group-hover:text-white transition-all duration-300 shadow-sm">
                        <i class="fa-solid fa-hotel"></i>
                    </div>
                    <h3 class="font-outfit text-lg font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                        Handpicked Hotel Stays
                    </h3>
                    <p class="text-xs text-gray-500 mt-2.5 leading-relaxed">
                        Verified 3-Star &amp; 5-Star luxury resort bookings with scenic mountain views and dining.
                    </p>
                </div>
                <div class="pt-6 mt-4 border-t border-gray-100">
                    <a href="/packages" class="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-navy transition-colors">
                        <span>View Hotel Stays</span>
                        <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
            </div>

            <!-- Service 4: Adventure & Activities -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/80 p-6 shadow-sm hover:shadow-xl hover:border-gold/30 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group">
                <div>
                    <div class="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xl mb-5 group-hover:bg-gold group-hover:text-white transition-all duration-300 shadow-sm">
                        <i class="fa-solid fa-person-hiking"></i>
                    </div>
                    <h3 class="font-outfit text-lg font-bold text-navy leading-snug group-hover:text-gold transition-colors duration-300">
                        Adventure &amp; Sightseeing
                    </h3>
                    <p class="text-xs text-gray-500 mt-2.5 leading-relaxed">
                        Thrilling experiences including paragliding, river rafting, snow sports, and local excursions.
                    </p>
                </div>
                <div class="pt-6 mt-4 border-t border-gray-100">
                    <a href="/packages" class="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-navy transition-colors">
                        <span>Discover Activities</span>
                        <i class="fa-solid fa-arrow-right text-[10px] group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ==================== EXPLORE OUR TRAVEL COVERAGE ==================== -->
<section id="route-map" class="py-14 md:py-18 bg-gradient-to-b from-[#FFFDF9] via-[#FAF6ED] to-[#FFFDF9] relative overflow-hidden font-sora border-b border-gray-100">
    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-12">
        <span class="font-caveat text-gold text-2.5xl md:text-3.5xl font-medium tracking-wide">Featured Himachal Packages</span>
        <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">Explore Our Travel Coverage</h2>
        <div class="h-[2.5px] w-14 bg-gold mx-auto mt-4 rounded-full"></div>
        <p class="text-xs sm:text-sm text-gray-500 max-w-2xl mx-auto mt-3 leading-relaxed">
            Discover Himachal's top tour packages with curated itineraries, premium stays, and verified cab transfers.
        </p>
    </div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        @php
            try {
                $coveragePackages = DB::table('packages')
                    ->whereIn('status', [1, '1'])
                    ->orderBy('id', 'desc')
                    ->limit(8)
                    ->get();

                foreach($coveragePackages as $cp) {
                    $imgVal = $cp->image ?? '';
                    $rawImages = [];
                    if (!empty($imgVal)) {
                        if (str_starts_with(trim($imgVal), '[')) {
                            $rawImages = json_decode($imgVal, true) ?: [];
                        } else {
                            $rawImages = array_values(array_filter(array_map('trim', explode(',', $imgVal))));
                        }
                    }
                    $clean0 = !empty($rawImages[0]) ? ltrim($rawImages[0], '/') : '';
                    if (!empty($clean0) && file_exists(public_path($clean0))) {
                        $cp->cover_image = asset($clean0);
                    } elseif (!empty($clean0)) {
                        $cp->cover_image = asset($clean0);
                    } else {
                        $cp->cover_image = asset('Website/assets/images/destinations/manali.png');
                    }
                    $cp->slug = \Illuminate\Support\Str::slug($cp->package_name ?? 'tour');
                }
            } catch (\Exception $e) {
                $coveragePackages = collect();
            }
        @endphp

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 lg:gap-8">
            @forelse($coveragePackages as $cp)
                <div class="h-[340px] sm:h-[380px] rounded-[28px] overflow-hidden relative shadow-md hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group border border-[#EBE4D5] cursor-pointer bg-white" onclick="window.location.href='/package-detail/{{ $cp->id }}/{{ $cp->slug }}'">
                    <!-- Cover Image (Index 0) -->
                    <img src="{{ $cp->cover_image }}" alt="{{ $cp->package_name }}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                    
                    <!-- Top Duration Badge (Replacing 1 Packages text) -->
                    <span class="absolute top-4 left-4 bg-white/95 backdrop-blur-md text-navy text-xs font-bold px-3.5 py-1.5 rounded-full shadow-sm border border-gray-100 flex items-center gap-1.5 z-10">
                        <i class="fa-regular fa-clock text-gold text-xs"></i>
                        <span>{{ $cp->duration ?? 'Custom Duration' }}</span>
                    </span>

                    <!-- Bottom Details Overlay -->
                    <div class="absolute bottom-0 inset-x-0 p-5 sm:p-6 bg-gradient-to-t from-[#050c18]/95 via-[#050c18]/80 to-transparent text-white space-y-2">
                        <!-- Destination Column -->
                        <span class="text-[10px] font-extrabold text-gold uppercase tracking-widest block">{{ $cp->destination ?? 'Himachal Pradesh' }}</span>
                        
                        <!-- Package Name -->
                        <h3 class="font-outfit text-base sm:text-lg font-bold text-white group-hover:text-gold transition-colors duration-300 line-clamp-1">{{ $cp->package_name }}</h3>
                        
                        <!-- Description -->
                        <p class="text-xs text-gray-300 line-clamp-2 leading-relaxed font-normal">
                            {{ \Illuminate\Support\Str::limit(strip_tags($cp->description ?? ''), 85) }}
                        </p>

                        <!-- Action Link Footer -->
                        <div class="flex items-center justify-between text-xs font-medium text-gray-200 pt-2 border-t border-white/10">
                            <span class="font-bold text-gold">Explore Package Details</span>
                            <span class="w-7 h-7 rounded-full bg-gold/20 text-gold flex items-center justify-center group-hover:bg-gold group-hover:text-white transition-all duration-300">
                                <i class="fa-solid fa-arrow-right text-[10px]"></i>
                            </span>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-12 bg-white rounded-2xl border border-dashed border-gray-200">
                    <p class="text-gray-500 font-semibold text-sm">No coverage packages available at the moment.</p>
                </div>
            @endforelse
        </div>
    </div>
</section>

<!-- Route Map Script -->
<script>
    const mapDestinations = [
        {
            name: "Chandigarh",
            title: "Tour Gateway Hub",
            elevation: "321 Meters",
            highlight: "Sukhna Lake & Rock Garden tours. Seamless pickup and transfer to mountain valleys.",
            activities: "Private cab onboarding, welcome kit briefing, and drive along direct scenic expressways.",
            image: "{{ asset('Website/assets/images/destinations/kullu.png') }}"
        },
        {
            name: "Shimla",
            title: "Heritage Capital",
            elevation: "2,276 Meters",
            highlight: "Walk along colonial Ridge Road, Kufri pine viewpoints, and Jakhoo hill trails.",
            activities: "Sightseeing historical Christ Church, wooden crafts at Lakkar Bazaar, and high-altitude horse riding.",
            image: "{{ asset('Website/assets/images/destinations/shimla.png') }}"
        },
        {
            name: "Kullu Valley",
            title: "River adventure basin",
            elevation: "1,279 Meters",
            highlight: "Kullu shawl weaving hubs, Beas river valley rafting, and pristine camping fields.",
            activities: "Thrilling white-water river rafting, organic fruit farm tours, and riverside bonfire camps.",
            image: "{{ asset('Website/assets/images/destinations/kullu.png') }}"
        },
        {
            name: "Manali",
            title: "Adventure Capital",
            elevation: "2,050 Meters",
            highlight: "Atal Tunnel crossings, Hadimba pine temple, paragliding at Solang, and Rohtang pass snow slopes.",
            activities: "Snow sports and skiing, paragliding from Solang peaks, and hot spring sulphur bath therapy.",
            image: "{{ asset('Website/assets/images/destinations/manali.png') }}"
        },
        {
            name: "Spiti Valley",
            title: "High Altitude Desert",
            elevation: "3,800 Meters",
            highlight: "1000-year Key Monastery, high motorable Kibber roads, fossils at Langza, and Chicham bridge.",
            activities: "Buddhist monastery tours, high mountain pass exploration, stargazing under zero-pollution skies.",
            image: "{{ asset('Website/assets/images/destinations/spiti.png') }}"
        },
        {
            name: "Dharamshala",
            title: "Spiritual Hub",
            elevation: "1,457 Meters",
            highlight: "Dalai Lama monastery retreats, McLeodGanj cafe hopping, and views of Dhauladhar ranges.",
            activities: "Tibetan culture walks, Bhagsu waterfall hikes, and watching cricket matches at the high altitude stadium.",
            image: "{{ asset('Website/assets/images/destinations/dharamshala.png') }}"
        }
    ];

    let currentActiveNode = 0;
    let nodeTimer;

    function renderNodeDetails(index) {
        const data = mapDestinations[index];
        const card = document.getElementById('route-explorer-card');
        if (!card) return;

        // Toggle active class in map buttons
        const btns = document.querySelectorAll('.map-node-btn');
        btns.forEach((btn, idx) => {
            if (idx === index) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        card.innerHTML = `
            <div class="relative w-full aspect-[16/10] rounded-2xl overflow-hidden mb-6 shadow-sm border border-gray-100 select-none">
                <img src="${data.image}" alt="${data.name}" class="w-full h-full object-cover transform hover:scale-105 transition duration-700">
                <span class="absolute top-4 left-4 bg-gold text-white text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full z-10">${data.title}</span>
            </div>
            <div class="text-left space-y-3.5">
                <div class="flex items-center justify-between">
                    <h3 class="font-outfit text-2xl font-black text-navy leading-none">${data.name}</h3>
                    <span class="text-[9.5px] font-bold text-gold uppercase tracking-wider bg-gold/10 px-2.5 py-0.5 rounded border border-gold/15 flex items-center gap-1">
                        <i class="fa-solid fa-mountain"></i> Alt: ${data.elevation}
                    </span>
                </div>
                <div class="h-[2px] w-12 bg-gold rounded-full"></div>
                <div>
                    <h5 class="text-[10px] font-extrabold text-navy uppercase tracking-wider mb-1.5 flex items-center gap-1.5"><i class="fa-solid fa-map-location-dot text-gold"></i> Key Attractions</h5>
                    <p class="text-xs text-gray-500 leading-relaxed font-normal">${data.highlight}</p>
                </div>
                <div>
                    <h5 class="text-[10px] font-extrabold text-navy uppercase tracking-wider mb-1.5 flex items-center gap-1.5"><i class="fa-solid fa-person-running text-gold"></i> Included Activities</h5>
                    <p class="text-xs text-gray-500 leading-relaxed font-normal">${data.activities}</p>
                </div>
            </div>
        `;
    }

    function selectMapNode(index) {
        clearInterval(nodeTimer);
        currentActiveNode = index;
        renderNodeDetails(index);
        // Restart autoplay after 10s idle
        startAutoplay(10000);
    }

    function startAutoplay(delay = 4000) {
        nodeTimer = setInterval(() => {
            currentActiveNode = (currentActiveNode + 1) % mapDestinations.length;
            renderNodeDetails(currentActiveNode);
        }, delay);
    }

    document.addEventListener('DOMContentLoaded', () => {
        renderNodeDetails(0);
        startAutoplay(4000);
    });
</script>

<style>
    /* Styling for active map button state */
    .map-node-btn.active span span:first-child {
        background-color: #cca43b !important;
        opacity: 0.75 !important;
        transform: scale(2.2);
    }
    .map-node-btn.active span span:last-child {
        background-color: #ffffff !important;
        border-color: #cca43b !important;
        transform: scale(1.3);
    }
    .map-node-btn.active span {
        box-shadow: 0 0 20px rgba(204, 164, 59, 0.6);
    }

    /* Clean Pagination with generous spacing & 100% visible hover contrast */
    .pagination {
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 0.75rem !important;
        list-style: none !important;
        padding: 0 !important;
        margin: 0 !important;
    }
    .pagination .page-item {
        margin: 0 !important;
    }
    .pagination .page-link {
        width: 2.5rem !important;
        height: 2.5rem !important;
        border-radius: 9999px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-weight: 700 !important;
        font-size: 0.8rem !important;
        transition: all 0.3s ease !important;
        border: 1px solid #e2e8f0 !important;
        background-color: #ffffff !important;
        color: #050c18 !important;
        text-decoration: none !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;
    }
    .pagination .page-link *,
    .pagination .page-link a,
    .pagination .page-link span {
        color: #050c18 !important;
        transition: color 0.3s ease !important;
    }
    .pagination .page-item.active .page-link {
        background-color: #cca43b !important;
        border-color: #cca43b !important;
        color: #ffffff !important;
        box-shadow: 0 4px 12px rgba(204,164,59,0.3) !important;
        transform: scale(1.05) !important;
    }
    .pagination .page-item.active .page-link *,
    .pagination .page-item.active .page-link span {
        color: #ffffff !important;
    }
    .pagination .page-item:not(.active):not(.disabled) .page-link:hover {
        background-color: #cca43b !important;
        border-color: #cca43b !important;
        color: #ffffff !important;
    }
    .pagination .page-item:not(.active):not(.disabled) .page-link:hover *,
    .pagination .page-item:not(.active):not(.disabled) .page-link:hover span {
        color: #ffffff !important;
    }
    .pagination .page-item.disabled .page-link {
        opacity: 0.4 !important;
        cursor: not-allowed !important;
        background-color: #f8fafc !important;
        color: #a0aec0 !important;
    }
    .pagination .page-item.disabled .page-link * {
        color: #a0aec0 !important;
    }
</style>

<!-- ==================== PHOTO GALLERY EXPLORER ==================== -->
<section id="gallery" class="py-14 md:py-18 bg-[#FCFBF8] relative overflow-hidden font-sora border-b border-gray-100">
    <!-- Subtle Background Shapes -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl translate-x-1/3 -translate-y-1/3"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl -translate-x-1/3 translate-y-1/3"></div>

    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-10">
        <span class="font-caveat text-gold text-2xl md:text-3.5xl font-medium tracking-wide">Capture The Moments</span>
        <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">Our Travel Gallery</h2>
        <div class="h-[3px] w-16 bg-gold mx-auto mt-4"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <!-- Dynamic Gallery Grid Container -->
        <div id="home-gallery-grid-container">
            @include('Website.partials.home_gallery_grid')
        </div>

        <!-- AJAX Pagination -->
        <div class="mt-8 flex justify-center" id="home-gallery-pagination">
            @if(isset($galleries) && $galleries->hasPages())
                <ul class="pagination">
                    @if($galleries->onFirstPage())
                        <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
                    @else
                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="loadHomeGalleryPage({{ $galleries->currentPage() - 1 }})">&laquo;</a></li>
                    @endif

                    @for($i = 1; $i <= $galleries->lastPage(); $i++)
                        @if($i == $galleries->currentPage())
                            <li class="page-item active"><span class="page-link">{{ $i }}</span></li>
                        @else
                            <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="loadHomeGalleryPage({{ $i }})">{{ $i }}</a></li>
                        @endif
                    @endfor

                    @if($galleries->hasMorePages())
                        <li class="page-item"><a class="page-link" href="javascript:void(0);" onclick="loadHomeGalleryPage({{ $galleries->currentPage() + 1 }})">&raquo;</a></li>
                    @else
                        <li class="page-item disabled"><span class="page-link">&raquo;</span></li>
                    @endif
                </ul>
            @endif
        </div>
    </div>
</section>

<!-- Lightbox Modal for Home Gallery -->
<div id="homeLightbox" class="fixed inset-0 z-[99999] bg-black/90 hidden items-center justify-center p-4" onclick="closeHomeLightbox()">
    <button type="button" class="absolute top-6 right-6 text-white text-3xl font-bold hover:text-gold transition">&times;</button>
    <img id="homeLightboxImg" src="" class="max-w-full max-h-[85vh] rounded-2xl object-contain shadow-2xl" onclick="event.stopPropagation()">
</div>
</div>
</section>






<!-- ==================== TESTIMONIALS SECTION ==================== -->
<section id="testimonials" class="py-16 md:py-20 bg-gradient-to-b from-[#FFFDF9] via-[#FCFAF5] to-white relative overflow-hidden font-sora border-b border-gray-100">
    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-12">
        <span class="font-caveat text-gold text-2.5xl md:text-3.5xl font-medium tracking-wide">Customer Stories</span>
        <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">What Our Travelers Say</h2>
        <div class="h-[2.5px] w-14 bg-gold mx-auto mt-4 rounded-full"></div>
        <p class="text-xs sm:text-sm text-gray-500 max-w-xl mx-auto mt-3 leading-relaxed font-normal">
            Real experiences shared by families, couples, and travelers who explored Himachal Pradesh with us.
        </p>
    </div>

    <!-- Testimonials Slider Container -->
    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="relative px-2 sm:px-6">
            
            <style>
                .testimonial-nav-btn {
                    background-color: #ffffff !important;
                    color: #050c18 !important;
                    border: 1px solid #EBE4D5 !important;
                    transition: all 0.3s ease !important;
                }
                .testimonial-nav-btn:hover {
                    background-color: #cca43b !important;
                    color: #ffffff !important;
                    border-color: #cca43b !important;
                    box-shadow: 0 4px 15px rgba(204, 164, 59, 0.4) !important;
                }
                .testimonial-nav-btn:hover i {
                    color: #ffffff !important;
                }
            </style>
            <!-- Side Navigation Arrows -->
            <button type="button" class="testimonial-prev testimonial-nav-btn absolute -left-2 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center shadow-md z-20">
                <i class="fa-solid fa-chevron-left text-xs"></i>
            </button>
            <button type="button" class="testimonial-next testimonial-nav-btn absolute -right-2 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full flex items-center justify-center shadow-md z-20">
                <i class="fa-solid fa-chevron-right text-xs"></i>
            </button>

            <!-- Swiper Testimonials Slider -->
            <div class="swiper testimonialSwiper w-full z-10 my-auto">
                <div class="swiper-wrapper py-6" id="testimonials-wrapper">
                    @php
                        $displayReviews = isset($reviews) ? $reviews : collect();
                        if (count($displayReviews) > 0 && count($displayReviews) < 6) {
                            $multiplier = ceil(6 / count($displayReviews));
                            $repeated = collect();
                            for ($i = 0; $i < $multiplier; $i++) {
                                $repeated = $repeated->concat($displayReviews);
                            }
                            $displayReviews = $repeated;
                        }
                    @endphp
                    @if(count($displayReviews) > 0)
                        @foreach($displayReviews as $rev)
                            @php
                                $imgSrc = !empty($rev->image) ? asset($rev->image) : 'https://ui-avatars.com/api/?name=' . urlencode($rev->name ?? 'Traveler') . '&background=D9B96E&color=fff';
                                $starCount = (int) ($rev->rating ?? 5);
                            @endphp
                            <div class="swiper-slide h-auto">
                                <div class="bg-white border border-[#EBE4D5] rounded-[28px] p-6 sm:p-7 shadow-[0_8px_30px_rgba(0,0,0,0.03)] hover:shadow-2xl hover:border-gold/40 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between h-full min-h-[220px] relative group text-left">
                                    
                                    <!-- Top Row: Profile Avatar + Details + Decorative Quote Badge -->
                                    <div class="flex items-start justify-between gap-3 mb-4">
                                        <div class="flex items-center gap-3.5">
                                            <img src="{{ $imgSrc }}" alt="{{ $rev->name ?? 'Traveler' }}" class="w-12 h-12 rounded-full object-cover border-2 border-gold/30 shadow-sm flex-shrink-0">
                                            <div class="text-left leading-tight">
                                                <h4 class="text-sm font-bold text-navy group-hover:text-gold transition-colors duration-300">{{ $rev->name ?? 'Happy Traveler' }}</h4>
                                                <span class="text-xs text-gray-400 mt-0.5 block font-medium">{{ $rev->city ?? 'Verified Traveler' }}</span>
                                            </div>
                                        </div>
                                        <div class="w-9 h-9 rounded-full bg-gold/10 text-gold flex items-center justify-center shrink-0 border border-gold/20">
                                            <i class="fa-solid fa-quote-right text-xs"></i>
                                        </div>
                                    </div>

                                    <!-- Rating Stars Pill -->
                                    <div class="flex items-center gap-1 my-2">
                                        @for($s = 1; $s <= 5; $s++)
                                            <i class="{{ $s <= $starCount ? 'fa-solid text-amber-400' : 'fa-regular text-gray-300' }} fa-star text-xs"></i>
                                        @endfor
                                        <span class="text-xs font-bold text-navy ml-1.5">{{ number_format($starCount, 1) }}</span>
                                    </div>

                                    <!-- Review Feedback Text -->
                                    <p class="text-xs sm:text-sm text-gray-600 leading-relaxed font-normal italic mt-2">
                                        "{{ $rev->feedback }}"
                                    </p>

                                    <!-- Verified Badge Footer -->
                                    <div class="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                                        <span class="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-[10.5px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-200">
                                            <i class="fa-solid fa-circle-check text-[9.5px] text-emerald-600"></i>
                                            <span>Verified Trip</span>
                                        </span>
                                        <span class="text-[10px] text-gray-400 font-medium">Chaarvi Guest</span>
                                    </div>

                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
                <div class="testimonial-pagination flex justify-center gap-1.5 mt-6"></div>
            </div>
        </div>

        <!-- Add Review Action Button -->
        <div class="text-center mt-10">
            <button id="openAddReviewBtn" type="button" class="bg-gradient-to-r from-[#cca43b] via-[#f3c649] to-[#b8860b] hover:from-[#b8860b] hover:to-[#cca43b] text-slate-950 font-bold text-xs sm:text-sm px-8 py-3.5 rounded-full shadow-lg shadow-[#cca43b]/20 transition-all duration-300 transform hover:-translate-y-0.5 inline-flex items-center justify-center gap-2 mx-auto">
                <i class="fa-solid fa-pen-to-square text-xs"></i>
                <span>Add Your Review</span>
            </button>
        </div>
    </div>
</section>

<!-- ==================== ADD REVIEW MODAL ==================== -->
<div id="addReviewModal" class="fixed inset-0 z-[9999] bg-black/70 backdrop-blur-md hidden flex items-center justify-center p-4 transition-all duration-300 font-sora">
    <div class="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden transform transition-all duration-300 border border-gray-100 max-h-[90vh] flex flex-col my-auto">
        <!-- Header -->
        <div class="bg-navy text-white px-6 py-4 flex items-center justify-between shrink-0">
            <h3 class="font-outfit font-bold text-base text-white flex items-center gap-2">
                <i class="fa-solid fa-star text-gold"></i>
                <span>Share Your Journey Review</span>
            </h3>
            <button id="closeReviewModalBtn" type="button" class="text-gray-400 hover:text-white transition duration-200 text-xl font-bold">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <!-- Form -->
        <form id="addReviewForm" class="p-6 space-y-4 overflow-y-auto" enctype="multipart/form-data">
            @csrf
            <div>
                <label class="block text-[11px] font-bold text-navy uppercase tracking-wider mb-1.5">Your Full Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="reviewName" required class="w-full border border-gray-200 rounded-xl px-4 py-3 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold" placeholder="e.g. Amit Kumar">
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-[11px] font-bold text-navy uppercase tracking-wider mb-1.5">Your City / State <span class="text-red-500">*</span></label>
                    <input type="text" name="city" id="reviewLocation" required class="w-full border border-gray-200 rounded-xl px-4 py-3 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold" placeholder="e.g. Delhi">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-navy uppercase tracking-wider mb-1.5">Rating (Stars) <span class="text-red-500">*</span></label>
                    <div class="flex items-center gap-1.5 py-2 text-gold" id="starSelector">
                        <i class="fa-solid fa-star text-xl cursor-pointer star-select transition-transform hover:scale-125" data-rating="1"></i>
                        <i class="fa-solid fa-star text-xl cursor-pointer star-select transition-transform hover:scale-125" data-rating="2"></i>
                        <i class="fa-solid fa-star text-xl cursor-pointer star-select transition-transform hover:scale-125" data-rating="3"></i>
                        <i class="fa-solid fa-star text-xl cursor-pointer star-select transition-transform hover:scale-125" data-rating="4"></i>
                        <i class="fa-solid fa-star text-xl cursor-pointer star-select transition-transform hover:scale-125" data-rating="5"></i>
                    </div>
                    <input type="hidden" name="rating" id="reviewRating" value="5">
                </div>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-navy uppercase tracking-wider mb-1.5">Your Photo (Optional)</label>
                <input type="file" name="image" id="reviewImage" accept="image/*" class="w-full border border-gray-200 rounded-xl px-3 py-2 text-xs text-navy focus:outline-none focus:border-gold file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-gold/10 file:text-gold hover:file:bg-gold/20">
            </div>

            <div>
                <label class="block text-[11px] font-bold text-navy uppercase tracking-wider mb-1.5">Your Experience Details <span class="text-red-500">*</span></label>
                <textarea name="feedback" id="reviewText" required rows="4" class="w-full border border-gray-200 rounded-xl px-4 py-3 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold resize-none" placeholder="Share your holiday experience with Chaarvi Tours..."></textarea>
            </div>

            <button type="submit" id="submitReviewFormBtn" class="w-full bg-gold hover:bg-gold-dark text-white font-bold text-xs py-3.5 rounded-xl transition duration-300 shadow-md shadow-gold/20 flex items-center justify-center gap-2">
                <span>Submit Review</span>
                <i class="fa-solid fa-paper-plane text-xs"></i>
            </button>
        </form>
    </div>
</div>

<!-- ==================== BLOG SECTION (HIDDEN) ==================== -->
<section id="blogs" class="hidden py-24 bg-white relative overflow-hidden font-sora border-b border-gray-100">
    <div class="max-w-7xl mx-auto pt-4 px-4 md:px-8 relative z-10 text-center mb-12">
        <span class="font-caveat text-gold text-2xl md:text-3.5xl font-medium tracking-wide">Stories & Guides</span>
        <h2 class="font-outfit text-3.5xl md:text-4xl lg:text-4.5xl font-extrabold text-navy mt-1">Our Travel Blogs</h2>
        <div class="h-[3px] w-16 bg-gold mx-auto mt-4 mb-6"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Blog Card 1 -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/60 overflow-hidden shadow-sm hover:shadow-xl hover:border-gold/20 transition-all duration-300 group flex flex-col h-full">
                <div class="relative aspect-[16/10] overflow-hidden bg-gray-100">
                    <img src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?auto=format&fit=crop&w=600&q=80" alt="Spiti Valley" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-700">
                    <span class="absolute top-4 left-4 bg-gold text-white text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full">Adventure</span>
                </div>
                <div class="p-6 flex flex-col flex-grow justify-between">
                    <div>
                        <div class="flex items-center gap-3 text-[10px] text-gray-400 font-semibold mb-3">
                            <span><i class="fa-regular fa-calendar-days mr-1.5"></i>12 Aug 2026</span>
                            <span>|</span>
                            <span><i class="fa-regular fa-clock mr-1.5"></i>5 Mins Read</span>
                        </div>
                        <h4 class="font-outfit text-lg font-bold text-navy group-hover:text-gold transition-colors duration-300 leading-snug">
                            Exploring the Mystical Spiti Valley: A Himalayan Guide
                        </h4>
                        <p class="text-xs text-gray-500 leading-relaxed mt-2">
                            A comprehensive guide to planning the ultimate road trip to Key Monastery and the mountain villages of Spiti Valley.
                        </p>
                    </div>
                    <div class="mt-5 pt-4 border-t border-gray-50">
                        <a href="/product" class="text-xs font-bold text-gold hover:text-gold-dark inline-flex items-center gap-1.5 transition">
                            <span>Read Article</span>
                            <i class="fa-solid fa-arrow-right text-[10px] transform group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Blog Card 2 -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/60 overflow-hidden shadow-sm hover:shadow-xl hover:border-gold/20 transition-all duration-300 group flex flex-col h-full">
                <div class="relative aspect-[16/10] overflow-hidden bg-gray-100">
                    <img src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=600&q=80" alt="Manali" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-700">
                    <span class="absolute top-4 left-4 bg-gold text-white text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full">Travel Tips</span>
                </div>
                <div class="p-6 flex flex-col flex-grow justify-between">
                    <div>
                        <div class="flex items-center gap-3 text-[10px] text-gray-400 font-semibold mb-3">
                            <span><i class="fa-regular fa-calendar-days mr-1.5"></i>08 Aug 2026</span>
                            <span>|</span>
                            <span><i class="fa-regular fa-clock mr-1.5"></i>4 Mins Read</span>
                        </div>
                        <h4 class="font-outfit text-lg font-bold text-navy group-hover:text-gold transition-colors duration-300 leading-snug">
                            Top 5 Things to Do in Manali This Holiday Season
                        </h4>
                        <p class="text-xs text-gray-500 leading-relaxed mt-2">
                            From Solang valley adventures to peaceful local sightseeing, check out our tourist bucket list items.
                        </p>
                    </div>
                    <div class="mt-5 pt-4 border-t border-gray-50">
                        <a href="/product" class="text-xs font-bold text-gold hover:text-gold-dark inline-flex items-center gap-1.5 transition">
                            <span>Read Article</span>
                            <i class="fa-solid fa-arrow-right text-[10px] transform group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Blog Card 3 -->
            <div class="bg-white rounded-3xl border border-[#EBE6DD]/60 overflow-hidden shadow-sm hover:shadow-xl hover:border-gold/20 transition-all duration-300 group flex flex-col h-full">
                <div class="relative aspect-[16/10] overflow-hidden bg-gray-100">
                    <img src="https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?auto=format&fit=crop&w=600&q=80" alt="Bir Billing" class="w-full h-full object-cover transform group-hover:scale-105 transition duration-700">
                    <span class="absolute top-4 left-4 bg-gold text-white text-[9px] font-extrabold uppercase px-2.5 py-1 rounded-full">Adventure</span>
                </div>
                <div class="p-6 flex flex-col flex-grow justify-between">
                    <div>
                        <div class="flex items-center gap-3 text-[10px] text-gray-400 font-semibold mb-3">
                            <span><i class="fa-regular fa-calendar-days mr-1.5"></i>02 Aug 2026</span>
                            <span>|</span>
                            <span><i class="fa-regular fa-clock mr-1.5"></i>6 Mins Read</span>
                        </div>
                        <h4 class="font-outfit text-lg font-bold text-navy group-hover:text-gold transition-colors duration-300 leading-snug">
                            Sky High: Guide to Paragliding in Bir Billing
                        </h4>
                        <p class="text-xs text-gray-500 leading-relaxed mt-2">
                            Know the pricing, locations, best glider pilots, and flight safety checklists for paragliding in Bir Billing.
                        </p>
                    </div>
                    <div class="mt-5 pt-4 border-t border-gray-50">
                        <a href="/product" class="text-xs font-bold text-gold hover:text-gold-dark inline-flex items-center gap-1.5 transition">
                            <span>Read Article</span>
                            <i class="fa-solid fa-arrow-right text-[10px] transform group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==================== FAQ SECTION ==================== -->
<section id="faq" class="py-12 md:py-16 bg-[#FAF9F6] relative overflow-hidden font-sora border-b border-gray-100">
    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            <!-- Left Column: Poster Image Banner Card (Exact Screenshot Match) -->
            <div class="lg:col-span-5 relative rounded-[2.2rem] overflow-hidden min-h-[660px] shadow-2xl flex flex-col justify-between p-7 sm:p-9 border border-white/20 bg-slate-900 group">
                <!-- High Resolution Himalayan Road / Jeep Adventure Image -->
                <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80" alt="Adventure Awaits You" class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out">
                <div class="absolute inset-0 bg-gradient-to-b from-black/70 via-black/30 to-black/85 pointer-events-none"></div>

                <!-- Top Poster Header Overlay -->
                <div class="relative z-10 space-y-2">
                    <span class="font-caveat text-[#cca43b] text-3xl sm:text-4xl font-medium tracking-wide block">Adventure Awaits You</span>
                    <h3 class="font-outfit text-3xl sm:text-4xl font-extrabold text-white leading-tight">We handle the details,<br>you enjoy the journey.</h3>
                </div>

                <!-- Bottom Poster Content & Features -->
                <div class="relative z-10 mt-auto">
                    <!-- Floating Support Card -->
                    <div class="bg-[#050c18]/90 backdrop-blur-md p-5 rounded-2xl border border-white/10 text-white shadow-2xl mb-6">
                        <div class="flex items-center gap-3.5">
                            <div class="w-11 h-11 rounded-full bg-[#cca43b]/20 text-[#cca43b] flex items-center justify-center text-xl shrink-0 border border-[#cca43b]/30">
                                <i class="fa-solid fa-headset"></i>
                            </div>
                            <div>
                                <h4 class="font-outfit text-sm font-bold text-white leading-tight">Need help planning your trip?</h4>
                                <p class="text-[11px] text-gray-300 mt-0.5 font-normal">Our travel experts are here for you.</p>
                            </div>
                        </div>
                        <div class="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between">
                            <a href="{{ url('/contact-us') }}" class="inline-flex items-center gap-2 text-xs font-bold text-[#cca43b] border border-[#cca43b]/50 hover:bg-[#cca43b] hover:text-white px-4 py-2 rounded-full transition group/link">
                                <span>Contact Support</span>
                                <i class="fa-solid fa-arrow-right text-[10px] transform group-hover/link:translate-x-1 transition-transform"></i>
                            </a>
                            <span class="text-[10px] text-gray-400 font-mono">24/7 Available</span>
                        </div>
                    </div>

                    <!-- 4 Icon Feature Highlights Row -->
                    <div class="grid grid-cols-4 gap-2 pt-3 border-t border-white/15 text-center text-white">
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-shield-halved text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Secure Booking</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Safe & trusted</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-award text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Best Price</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Get best deals</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-regular fa-calendar-xmark text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Easy Cancel</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Hassle-free</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-phone-volume text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">24/7 Support</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Here always</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Accordion (Dynamic FAQs from Database) -->
            <div class="lg:col-span-7 space-y-5">
                <!-- Section Header with Mountain SVG Vector Art -->
                <div class="relative flex items-start justify-between gap-4">
                    <div>
                        <div class="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">
                            <a href="{{ url('/') }}" class="hover:text-[#cca43b] transition">Home</a>
                            <span>/</span>
                            <span class="text-[#cca43b]">FAQ</span>
                        </div>
                        <h2 class="font-outfit text-3xl sm:text-4xl lg:text-4.5xl font-extrabold text-[#050c18] leading-tight">
                            Frequently Asked <span class="text-[#cca43b]">Questions</span>
                        </h2>
                        <p class="text-gray-500 text-sm mt-1.5 font-medium leading-relaxed max-w-xl">
                            Get answers to common questions about bookings, payments, cancellations, pickup points, activities and more.
                        </p>
                    </div>
                    <!-- Line Art Mountain Illustration -->
                    <div class="hidden sm:block opacity-30 shrink-0 pt-1">
                        <svg width="120" height="70" viewBox="0 0 120 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 60 L40 20 L60 45 L85 10 L110 60 Z" stroke="#050c18" stroke-width="2" stroke-linejoin="round"/>
                            <path d="M25 40 L40 20 L50 35" stroke="#cca43b" stroke-width="2"/>
                            <path d="M72 25 L85 10 L98 30" stroke="#cca43b" stroke-width="2"/>
                        </svg>
                    </div>
                </div>

                <!-- Dynamic Accordion Container -->
                <div id="homeFaqAccordion" class="space-y-3 pt-2">
                    @php
                        $badgeStyles = [
                            ['bg' => 'bg-indigo-50/80', 'text' => 'text-indigo-600', 'border' => 'border-indigo-100', 'icon' => 'fa-regular fa-calendar-check'],
                            ['bg' => 'bg-amber-50/80', 'text' => 'text-amber-600', 'border' => 'border-amber-100', 'icon' => 'fa-solid fa-location-dot'],
                            ['bg' => 'bg-blue-50/80', 'text' => 'text-blue-600', 'border' => 'border-blue-100', 'icon' => 'fa-regular fa-credit-card'],
                            ['bg' => 'bg-emerald-50/80', 'text' => 'text-emerald-600', 'border' => 'border-emerald-100', 'icon' => 'fa-solid fa-headset'],
                            ['bg' => 'bg-purple-50/80', 'text' => 'text-purple-600', 'border' => 'border-purple-100', 'icon' => 'fa-regular fa-circle-question'],
                        ];
                    @endphp
                    @forelse(($faqs ?? []) as $idx => $faq)
                        @php
                            $style = $badgeStyles[$idx % count($badgeStyles)];
                            $isOpenInitial = ($idx === 0);
                        @endphp
                        <div class="home-faq-item border border-gray-200/80 bg-white rounded-2xl transition-all duration-200 overflow-hidden shadow-2xs">
                            <!-- Question Header -->
                            <button type="button" onclick="toggleHomeFaq(this)" class="w-full flex items-center justify-between py-3.5 px-4 sm:px-5 text-left cursor-pointer hover:bg-gray-50/50 transition gap-3.5">
                                <div class="flex items-center gap-3.5 flex-1 min-w-0">
                                    <!-- Left Soft Colored Icon Badge -->
                                    <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-xl {{ $style['bg'] }} {{ $style['text'] }} border {{ $style['border'] }} flex items-center justify-center font-bold text-sm shrink-0">
                                        <i class="{{ $style['icon'] }}"></i>
                                    </div>
                                    <!-- Question Title -->
                                    <span class="font-outfit text-[#050c18] text-[15px] sm:text-base font-bold leading-snug">{{ $faq->question }}</span>
                                </div>
                                <!-- Right Plus/Minus Icon -->
                                <span class="home-faq-pm-icon w-7 h-7 sm:w-8 sm:h-8 rounded-full border border-gray-200 text-gray-500 flex items-center justify-center text-xs transition-all duration-200 shrink-0">
                                    <i class="fa-solid {{ $isOpenInitial ? 'fa-minus' : 'fa-plus' }} text-[11px]"></i>
                                </span>
                            </button>

                            <!-- Answer Body -->
                            <div class="home-faq-answer-body {{ $isOpenInitial ? '' : 'hidden' }} px-4 sm:px-5 pb-4 pl-[3.25rem] sm:pl-[4.25rem] text-gray-500 text-xs sm:text-sm leading-relaxed border-t border-gray-100/80 pt-3">
                                {!! nl2br(e($faq->answer)) !!}
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-10 bg-white rounded-2xl border border-dashed border-gray-200 text-gray-400">
                            <i class="fa-regular fa-circle-question text-3xl mb-2 text-[#cca43b]"></i>
                            <p class="text-xs font-semibold">No questions available right now.</p>
                        </div>
                    @endforelse
                </div>

                <!-- Still Need Help Bottom Box -->
                <div class="bg-amber-50/70 border border-amber-200/60 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 mt-5">
                    <div class="flex items-center gap-3.5">
                        <div class="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#cca43b]/15 text-[#cca43b] flex items-center justify-center text-lg sm:text-xl shrink-0 border border-[#cca43b]/30">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <div>
                            <h4 class="font-outfit text-sm sm:text-base font-bold text-[#050c18] leading-tight">Still need help?</h4>
                            <p class="text-xs text-gray-500 mt-0.5 font-medium">Our travel experts are ready to assist you.</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 flex-wrap justify-center sm:justify-end">
                        <div class="bg-white border border-gray-200 px-3.5 py-1.5 rounded-full text-[#050c18] font-bold text-xs shadow-2xs flex items-center gap-2">
                            <i class="fa-solid fa-phone text-[#cca43b] text-xs"></i>
                            <div>
                                <a href="tel:{{ $info->mobile ?? '+919817609013' }}" class="block leading-none hover:text-[#cca43b] transition">{{ $info->mobile ?? '+91 9817609013' }}</a>
                                <span class="text-[9px] text-gray-400 font-normal">{{ $info->office_time ?? 'Mon - Sun, 9 AM - 9 PM' }}</span>
                            </div>
                        </div>
                        <a href="https://wa.me/{{ !empty($info->mobile) ? preg_replace('/[^0-9]/', '', $info->mobile) : '919817609013' }}" target="_blank" class="bg-[#cca43b] hover:bg-[#b08b2d] text-white px-4 py-2 rounded-full font-bold text-xs shadow-md transition flex items-center gap-2">
                            <i class="fa-brands fa-whatsapp text-sm"></i>
                            <span>Chat with an Expert</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Home FAQ Interactivity Script -->
<script>
    function toggleHomeFaq(btn) {
        const item = btn.closest('.home-faq-item');
        const body = item.querySelector('.home-faq-answer-body');
        const pmIcon = btn.querySelector('.home-faq-pm-icon');
        const icon = pmIcon.querySelector('i');
        const isOpen = !body.classList.contains('hidden');

        // Close all others
        document.querySelectorAll('.home-faq-item').forEach(other => {
            if (other !== item) {
                other.querySelector('.home-faq-answer-body').classList.add('hidden');
                const otherPm = other.querySelector('.home-faq-pm-icon');
                if (otherPm) {
                    otherPm.querySelector('i').className = 'fa-solid fa-plus text-[11px]';
                }
            }
        });

        // Toggle clicked item
        if (isOpen) {
            body.classList.add('hidden');
            icon.className = 'fa-solid fa-plus text-[11px]';
        } else {
            body.classList.remove('hidden');
            icon.className = 'fa-solid fa-minus text-[11px]';
        }
    }
</script>

<!-- ==================== GET IN TOUCH CTA SECTION ==================== -->
<section id="contact" class="py-12 md:py-16 bg-white font-sora border-b border-gray-100">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        <div class="w-full bg-gradient-to-r from-[#FFFDF9] via-[#FFFBF3] to-[#F8F2E4] border border-[#EFE5D3] rounded-[32px] p-8 sm:p-12 md:p-14 text-center shadow-md relative overflow-hidden group">
            
            <h2 class="font-outfit text-3xl sm:text-4xl md:text-4.5xl font-extrabold text-navy tracking-tight">
                Get In Touch With Us
            </h2>
            <p class="text-xs sm:text-sm text-gray-500 max-w-xl mx-auto mt-3 leading-relaxed font-normal">
                Have questions about custom tour packages, cab rentals, or group bookings? We'd love to hear from you.
            </p>
            
            <div class="mt-8 flex justify-center">
                <a href="/contact-us" class="get-in-touch-btn inline-flex items-center justify-center gap-2.5 bg-[#102A43] hover:bg-[#CCA43B] text-white font-bold text-xs sm:text-sm px-8 py-3.5 rounded-full shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300">
                    <span>Contact Us</span>
                    <i class="fa-solid fa-arrow-right text-xs"></i>
                </a>
            </div>

        </div>
    </div>
</section>

<!-- ==================== PROMO MODAL FOR DYNAMIC COUPONS ==================== -->
<div id="offersModal" class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden flex items-center justify-center p-4 transition-all duration-300 font-sora">
    <div class="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden transform scale-95 transition-all duration-300">
        
        <!-- Header -->
        <div class="bg-navy text-white px-6 py-4 flex items-center justify-between border-b border-gray-800">
            <div class="flex items-center gap-2">
                <i class="fa-solid fa-tags text-gold"></i>
                <span class="font-bold text-sm tracking-wider uppercase">Available Offers</span>
            </div>
            <button id="closeOffersBtn" class="text-gray-400 hover:text-white transition duration-200">
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>
        </div>

        <!-- Body -->
        <div class="p-6 max-h-[60vh] overflow-y-auto space-y-4">
            @forelse(($coupons ?? []) as $index => $coupon)
                @php
                    $expiry = !empty($coupon->expiry_date) ? date('d M Y', strtotime($coupon->expiry_date)) : 'No expiry';
                @endphp
                
                <!-- Coupon Card -->
                <div class="border border-dashed border-gray-300 rounded-xl p-4 bg-[#FAF7F0] flex items-center justify-between gap-4">
                    <div class="space-y-1">
                        <div class="flex items-baseline gap-1">
                            @if($coupon->discount_type === 'amount')
                                <span class="text-lg font-bold text-navy">â‚¹{{ number_format($coupon->coupon_price, 0) }}</span>
                            @else
                                <span class="text-lg font-bold text-navy">{{ number_format($coupon->coupon_price, 0) }}%</span>
                            @endif
                            <span class="text-xs text-gold font-bold">OFF</span>
                        </div>
                        <h4 class="text-xs font-bold text-navy leading-tight">{{ $coupon->title }}</h4>
                        <p class="text-[10px] text-gray-500 leading-normal">{{ $coupon->description }}</p>
                        <p class="text-[9px] text-gray-400"><i class="fa-regular fa-clock text-[8px] mr-1"></i>Valid till {{ $expiry }}</p>
                    </div>

                    <div class="flex flex-col items-end gap-2 flex-shrink-0">
                        <span class="bg-white border border-gray-200 text-navy font-mono text-xs font-bold px-2.5 py-1 rounded select-all cursor-pointer">
                            {{ $coupon->coupon }}
                        </span>
                        <button onclick="copyCouponCode('{{ $coupon->coupon }}', this)" class="bg-navy hover:bg-navy-dark text-white text-[10px] font-bold px-3 py-1.5 rounded transition duration-200">
                            Copy Code
                        </button>
                    </div>
                </div>
            @empty
                <div class="text-center py-8 text-gray-400 space-y-2">
                    <i class="fa-regular fa-face-frown text-3xl"></i>
                    <p class="text-xs">No active coupon offers available at this moment.</p>
                </div>
            @endforelse
        </div>
    </div>
</div>


<!-- ==================== JS LINK / FOOTER INCLUDES ==================== -->
@include('Website.includes.JsLink')
@include('Website.includes.Footer')

<!-- Interactivity and Swiper initialization script -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize Hero Swiper
        const heroSwiper = new Swiper('.heroSwiper', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },

            pagination: {
                el: '.hero-pagination',
                clickable: true,
                renderBullet: function (index, className) {
                    return '<span class="' + className + ' w-2.5 h-2.5 rounded-full bg-white opacity-40 cursor-pointer hover:opacity-100 transition duration-300"></span>';
                }
            }
        });

        // Initialize Category Swiper
        const categorySwiper = new Swiper('.categorySwiper', {
            slidesPerView: 1,
            spaceBetween: 20,
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.cat-next',
                prevEl: '.cat-prev',
            },
            pagination: {
                el: '.cat-pagination',
                clickable: true,
                renderBullet: function (index, className) {
                    return '<span class="' + className + ' w-2.5 h-2.5 rounded-full bg-navy opacity-20 cursor-pointer hover:opacity-100 transition duration-300"></span>';
                }
            },
            breakpoints: {
                480: {
                    slidesPerView: 2,
                    spaceBetween: 20,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 24,
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 30,
                },
                1200: {
                    slidesPerView: 5,
                    spaceBetween: 30,
                }
            }
        });

        // Initialize Destination Swiper (Coverflow effect)
        const destinationSwiper = new Swiper('.destinationSwiper', {
            effect: 'coverflow',
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: 'auto',
            loop: true,
            loopedSlides: 5,
            loopAdditionalSlides: 2,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            },
            coverflowEffect: {
                rotate: 0,
                stretch: -30,
                depth: 120,
                modifier: 1.5,
                slideShadows: false,
            }
        });

        // Dynamic category filtering & pagination for featured packages
        let featCurrentPage = 1;
        const featItemsPerPage = 6;

        window.renderFeaturedPagination = function() {
            const grid = document.getElementById('featured-packages-grid');
            if (!grid) return;
            const cards = Array.from(grid.querySelectorAll('.package-card-item'));
            
            const activeCards = cards.filter(c => !c.classList.contains('hidden-by-cat'));
            const total = activeCards.length;
            const totalPages = Math.ceil(total / featItemsPerPage);

            const paginationContainer = document.getElementById('featured-packages-pagination');
            let emptyMsg = document.getElementById('no-packages-msg');

            if (total === 0) {
                if (!emptyMsg) {
                    emptyMsg = document.createElement('div');
                    emptyMsg.id = 'no-packages-msg';
                    emptyMsg.className = 'col-span-full text-center py-12 text-gray-400 font-sora';
                    emptyMsg.innerHTML = `
                        <i class="fa-regular fa-face-frown text-3xl mb-2 block"></i>
                        <span class="text-xs">No packages found in this category.</span>
                    `;
                    grid.appendChild(emptyMsg);
                } else {
                    emptyMsg.classList.remove('hidden');
                }
                if (paginationContainer) paginationContainer.innerHTML = '';
                return;
            } else if (emptyMsg) {
                emptyMsg.classList.add('hidden');
            }

            if (!paginationContainer) return;

            if (totalPages <= 1) {
                activeCards.forEach(c => c.classList.remove('hidden'));
                paginationContainer.innerHTML = '';
                return;
            }

            activeCards.forEach((c, idx) => {
                const start = (featCurrentPage - 1) * featItemsPerPage;
                const end = start + featItemsPerPage;
                if (idx >= start && idx < end) {
                    c.classList.remove('hidden');
                } else {
                    c.classList.add('hidden');
                }
            });

            let html = '<div class="flex items-center justify-center gap-3.5 mt-8 flex-wrap">';
            
            // Prev Button
            const prevDisabled = featCurrentPage === 1;
            html += '<button type="button" onclick="changeFeaturedPage(' + (featCurrentPage - 1) + ')" class="w-10 h-10 rounded-full border border-gray-200 bg-white text-navy font-bold text-xs hover:border-[#cca43b] hover:bg-[#cca43b] hover:text-white transition-all duration-300 flex items-center justify-center shadow-xs ' + (prevDisabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer') + '" ' + (prevDisabled ? 'disabled' : '') + '><i class="fa-solid fa-chevron-left text-[11px]"></i></button>';

            for (let i = 1; i <= totalPages; i++) {
                const isActive = i === featCurrentPage;
                html += '<button type="button" onclick="changeFeaturedPage(' + i + ')" class="w-10 h-10 rounded-full font-bold text-xs transition-all duration-300 flex items-center justify-center shadow-xs ' + (isActive ? 'bg-[#cca43b] text-white border border-[#cca43b] shadow-md shadow-gold/20 scale-105' : 'bg-white text-navy border border-gray-200 hover:border-[#cca43b] hover:text-[#cca43b]') + '">' + i + '</button>';
            }

            // Next Button
            const nextDisabled = featCurrentPage === totalPages;
            html += '<button type="button" onclick="changeFeaturedPage(' + (featCurrentPage + 1) + ')" class="w-10 h-10 rounded-full border border-gray-200 bg-white text-navy font-bold text-xs hover:border-[#cca43b] hover:bg-[#cca43b] hover:text-white transition-all duration-300 flex items-center justify-center shadow-xs ' + (nextDisabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer') + '" ' + (nextDisabled ? 'disabled' : '') + '><i class="fa-solid fa-chevron-right text-[11px]"></i></button>';
            html += '</div>';

            paginationContainer.innerHTML = html;
        };

        window.changeFeaturedPage = function(page) {
            featCurrentPage = page;
            renderFeaturedPagination();
            const el = document.getElementById('packages');
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        };

        window.filterCategory = function(categoryId, btn) {
            if (btn) {
                const tabBtns = document.querySelectorAll('.category-tab-btn');
                tabBtns.forEach(b => {
                    b.classList.remove('active', 'bg-gold', 'bg-[#cca43b]', 'text-white', 'border-gold', 'border-[#cca43b]');
                    b.classList.add('bg-white', 'text-gray-500', 'border-gray-200');
                });
                btn.classList.remove('bg-white', 'text-gray-500', 'border-gray-200');
                btn.classList.add('active', 'bg-[#cca43b]', 'text-white', 'border-[#cca43b]');
            }

            const cards = document.querySelectorAll('.package-card-item');
            cards.forEach(card => {
                const cardCatId = card.getAttribute('data-category-id');
                if (categoryId === 'all' || cardCatId === categoryId) {
                    card.classList.remove('hidden-by-cat');
                } else {
                    card.classList.add('hidden-by-cat');
                    card.classList.add('hidden');
                }
            });

            featCurrentPage = 1;
            renderFeaturedPagination();
        };

        // Call featured pagination immediately
        renderFeaturedPagination();

        // ==================== TESTIMONIALS & MODAL SCRIPTS ====================
        const addReviewBtn = document.getElementById('openAddReviewBtn');
        const reviewModal = document.getElementById('addReviewModal');
        const closeReviewBtn = document.getElementById('closeReviewModalBtn');
        const addReviewForm = document.getElementById('addReviewForm');

        if (addReviewBtn && reviewModal) {
            addReviewBtn.addEventListener('click', function() {
                reviewModal.classList.remove('hidden');
                setTimeout(() => {
                    reviewModal.querySelector('.transform').classList.remove('scale-95');
                    reviewModal.querySelector('.transform').classList.add('scale-100');
                }, 10);
            });
        }

        if (closeReviewBtn && reviewModal) {
            closeReviewBtn.addEventListener('click', function() {
                reviewModal.querySelector('.transform').classList.add('scale-95');
                reviewModal.querySelector('.transform').classList.remove('scale-100');
                setTimeout(() => {
                    reviewModal.classList.add('hidden');
                }, 150);
            });
            // Close on overlay click
            reviewModal.addEventListener('click', function(e) {
                if (e.target === reviewModal) {
                    closeReviewBtn.click();
                }
            });
        }

        // Star Rating Selector inside Modal
        const starSelects = document.querySelectorAll('.star-select');
        const ratingInput = document.getElementById('reviewRating');
        if (starSelects && ratingInput) {
            starSelects.forEach(star => {
                star.addEventListener('click', () => {
                    const rating = parseInt(star.getAttribute('data-rating'));
                    ratingInput.value = rating;
                    starSelects.forEach((s, idx) => {
                        if (idx < rating) {
                            s.classList.remove('text-gray-300');
                            s.classList.add('text-gold');
                        } else {
                            s.classList.remove('text-gold');
                            s.classList.add('text-gray-300');
                        }
                    });
                });
            });
            // Trigger 5 stars initially
            if (starSelects.length > 4) {
                starSelects[4].click();
            }
        }

        var testimonialSwiper = null;
        function initTestimonialSwiper() {
            if (typeof Swiper === 'undefined') return;
            if (testimonialSwiper) {
                testimonialSwiper.destroy(true, true);
            }
            testimonialSwiper = new Swiper('.testimonialSwiper', {
                slidesPerView: 1,
                spaceBetween: 20,
                loop: true,
                loopAdditionalSlides: 3,
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                },
                navigation: {
                    nextEl: '.testimonial-next',
                    prevEl: '.testimonial-prev',
                },
                pagination: {
                    el: '.testimonial-pagination',
                    clickable: true,
                },
                breakpoints: {
                    640: {
                        slidesPerView: 2,
                        spaceBetween: 20,
                    },
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 24,
                    }
                }
            });
        }

        initTestimonialSwiper();

        document.querySelectorAll('.testimonial-next').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                if (testimonialSwiper) {
                    testimonialSwiper.slideNext();
                }
            });
        });
        document.querySelectorAll('.testimonial-prev').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                if (testimonialSwiper) {
                    testimonialSwiper.slidePrev();
                }
            });
        });

        // ==================== FAQ ACCORDION INTERACTIVITY ====================
        const faqItems = document.querySelectorAll('.faq-item');
        if (faqItems) {
            faqItems.forEach(item => {
                const button = item.querySelector('.faq-btn');
                const content = item.querySelector('.faq-content');
                const icon = item.querySelector('.faq-icon');
                
                if (button && content && icon) {
                    button.addEventListener('click', () => {
                        const isOpen = !content.classList.contains('hidden');
                        
                        faqItems.forEach(otherItem => {
                            const c = otherItem.querySelector('.faq-content');
                            const i = otherItem.querySelector('.faq-icon');
                            if (c && i) {
                                c.classList.add('hidden');
                                i.classList.remove('rotate-180');
                            }
                        });

                        if (!isOpen) {
                            content.classList.remove('hidden');
                            icon.classList.add('rotate-180');
                        } else {
                            content.classList.add('hidden');
                            icon.classList.remove('rotate-180');
                        }
                    });
                }
            });
        }

        const openBtn = document.getElementById('openOffersBtn');
        const closeBtn = document.getElementById('closeOffersBtn');
        const modal = document.getElementById('offersModal');
        
        if (openBtn && modal) {
            openBtn.addEventListener('click', function() {
                modal.classList.remove('hidden');
                setTimeout(() => {
                    modal.querySelector('.transform').classList.remove('scale-95');
                    modal.querySelector('.transform').classList.add('scale-100');
                }, 10);
            });
        }
        
        if (closeBtn && modal) {
            closeBtn.addEventListener('click', function() {
                modal.querySelector('.transform').classList.add('scale-95');
                modal.querySelector('.transform').classList.remove('scale-100');
                setTimeout(() => {
                    modal.classList.add('hidden');
                }, 150);
            });
            
            // Close on overlay click
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeBtn.click();
                }
            });
        }
    });

    function copyCouponCode(code, button) {
        navigator.clipboard.writeText(code).then(() => {
            const originalText = button.textContent;
            button.textContent = 'Copied!';
            button.classList.remove('bg-navy');
            button.classList.add('bg-green-600');
            
            setTimeout(() => {
                button.textContent = originalText;
                button.classList.remove('bg-green-600');
                button.classList.add('bg-navy');
            }, 1500);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
        });
    }

    // ==================== ENQUIRY & BOOKING MODAL TRIGGERS ====================
    window.openEnquiryModal = function(packageName = null, packageId = null) {
        const modal = document.getElementById('enquiryModal');
        const title = document.getElementById('enquiryModalTitle');
        const banner = document.getElementById('enqSelectedPackageBanner');
        const bannerText = document.getElementById('enqSelectedPackageName');
        
        if (!modal) return;
        
        const targetId = packageId ? packageId.toString() : '';
        let targetTitle = packageName || '';

        const matchedOpt = $(`.enq-package-option[data-value="${targetId}"]`);
        if (matchedOpt.length && targetId) {
            targetTitle = matchedOpt.data('title');
            $('.enq-package-option').removeClass('bg-gold/10 font-bold').addClass('font-semibold text-gray-700');
            $('.enq-package-option .check-icon').addClass('opacity-0').removeClass('opacity-100');
            matchedOpt.addClass('bg-gold/10 font-bold').removeClass('font-semibold text-gray-700');
            matchedOpt.find('.check-icon').removeClass('opacity-0').addClass('opacity-100');
        } else {
            $('.enq-package-option').removeClass('bg-gold/10 font-bold').addClass('font-semibold text-gray-700');
            $('.enq-package-option .check-icon').addClass('opacity-0').removeClass('opacity-100');
        }

        $('#enqPackageId').val(targetId);
        $('#enqPackageDropdownLabel').text(targetTitle || '-- Select Tour Package / Destination --');

        if (targetId) {
            if (title) title.textContent = 'Book Package';
            if (bannerText) bannerText.textContent = targetTitle;
            if (banner) banner.classList.remove('hidden');
        } else {
            if (title) title.textContent = 'Plan Your Journey';
            if (banner) banner.classList.add('hidden');
        }
        
        $('#enqPackageErr').addClass('hidden');
        $('#enqPackageDropdownBtn').removeClass('border-red-500');

        modal.classList.remove('hidden');
        setTimeout(() => {
            var trans = modal.querySelector('.transform');
            if (trans) {
                trans.classList.remove('scale-95');
                trans.classList.add('scale-100');
            }
        }, 10);
    };

    // Toggle custom package dropdown menu
    $(document).on('click', '#enqPackageDropdownBtn', function(e) {
        e.stopPropagation();
        $('#enqPackageDropdownMenu').toggleClass('hidden');
        $('#enqPackageDropdownChevron').toggleClass('rotate-180');
        if (!$('#enqPackageDropdownMenu').hasClass('hidden')) {
            $('#enqPackageSearchInput').val('').focus();
            $('.enq-package-option').show();
            $('#enqClearPackageSearch').addClass('hidden');
        }
    });

    // Close dropdown menu on click outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#enqPackageCustomDropdown').length) {
            $('#enqPackageDropdownMenu').addClass('hidden');
            $('#enqPackageDropdownChevron').removeClass('rotate-180');
        }
    });

    // Search filtering inside package dropdown
    $(document).on('input', '#enqPackageSearchInput', function() {
        const term = $(this).val().toLowerCase().trim();
        if (term.length > 0) {
            $('#enqClearPackageSearch').removeClass('hidden');
        } else {
            $('#enqClearPackageSearch').addClass('hidden');
        }

        $('.enq-package-option').each(function() {
            const title = $(this).data('title').toString().toLowerCase();
            if (title.includes(term)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Clear package search input
    $(document).on('click', '#enqClearPackageSearch', function(e) {
        e.stopPropagation();
        $('#enqPackageSearchInput').val('').focus();
        $(this).addClass('hidden');
        $('.enq-package-option').show();
    });

    // Select package option
    $(document).on('click', '.enq-package-option', function() {
        const val = $(this).data('value').toString();
        const title = $(this).data('title');

        $('.enq-package-option').removeClass('bg-gold/10 font-bold').addClass('font-semibold text-gray-700');
        $('.enq-package-option .check-icon').addClass('opacity-0').removeClass('opacity-100');
        
        $(this).addClass('bg-gold/10 font-bold').removeClass('font-semibold text-gray-700');
        $(this).find('.check-icon').removeClass('opacity-0').addClass('opacity-100');

        $('#enqPackageId').val(val);
        $('#enqPackageDropdownLabel').text(title);

        if (val) {
            $('#enqPackageErr').addClass('hidden');
            $('#enqPackageDropdownBtn').removeClass('border-red-500');
            $('#enqSelectedPackageBanner').removeClass('hidden');
            $('#enqSelectedPackageName').text(title);
        } else {
            $('#enqSelectedPackageBanner').addClass('hidden');
        }

        $('#enqPackageDropdownMenu').addClass('hidden');
        $('#enqPackageDropdownChevron').removeClass('rotate-180');
    });

    window.closeEnquiryModal = function() {
        var modal = document.getElementById('enquiryModal');
        if (!modal) return;
        var trans = modal.querySelector('.transform') || modal.firstElementChild;
        if (trans && trans.classList) {
            trans.classList.add('scale-95');
            trans.classList.remove('scale-100');
        }
        modal.classList.add('hidden');
    };

    window.openBookingModal = function(packageName, packageId) {
        var modal = document.getElementById('bookingModal');
        if (!modal) return;

        $('#bookPackageId').val(packageId);
        $('#bookSelectedPackageName').text(packageName);

        // Keep the pickup point already selected on the package card, even when
        // the visitor books without manually changing the dropdown first.
        var cardPickupSelect = document.querySelector('.package-card-item[data-package-id="' + packageId + '"] .pkg-pickup-select');
        var cardPickupOption = cardPickupSelect ? cardPickupSelect.options[cardPickupSelect.selectedIndex] : null;
        var cardPickupId = cardPickupOption ? cardPickupOption.value : null;
        var cardPickupPrice = cardPickupOption ? parseFloat(cardPickupOption.getAttribute('data-offer') || cardPickupOption.getAttribute('data-price') || 0) : 0;

        // Fetch package details dynamically to populate pickup points and prices
        $.ajax({
            url: '/get-package-details-for-booking',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                package_id: packageId
            },
            success: function(res) {
                if (res.status === 'success') {
                    var basePrice = cardPickupPrice || parseFloat(res.package.offer_price || res.package.price || 0);
                    $('#bookBasePrice').val(basePrice);
                    
                    var select = $('#bookPickupPoint');
                    var rememberedPickupId = (window.selectedPickupMap ? window.selectedPickupMap[packageId] : null) || cardPickupId;
                    select.html('<option value="" data-price="' + basePrice + '">Default Pickup Point (₹' + basePrice.toLocaleString('en-IN') + ')</option>');
                    if (res.pickup_points && res.pickup_points.length > 0) {
                        $.each(res.pickup_points, function(idx, pt) {
                            var ptPrice = parseFloat(pt.offer_price || pt.price || basePrice);
                            select.append('<option value="' + pt.id + '" data-price="' + ptPrice + '">' + pt.point_name + ' (₹' + ptPrice.toLocaleString('en-IN') + ')</option>');
                        });
                    }
                    if (rememberedPickupId && select.find('option[value="' + rememberedPickupId + '"]').length) {
                        select.val(String(rememberedPickupId));
                        if (cardPickupPrice) select.find('option:selected').attr('data-price', cardPickupPrice);
                    } else if (cardPickupId && cardPickupOption) {
                        select.append('<option value="' + cardPickupId + '" data-price="' + cardPickupPrice + '" selected>' + $('<div>').text(cardPickupOption.text).html() + '</option>');
                    }
                    calculateBookingPrice();
                }
            }
        });

        modal.classList.remove('hidden');
        setTimeout(function() {
            var trans = modal.querySelector('.transform');
            if (trans) {
                trans.classList.remove('scale-95');
                trans.classList.add('scale-100');
            }
        }, 10);
    };

    window.closeBookingModal = function() {
        var modal = document.getElementById('bookingModal');
        if (!modal) return;
        var trans = modal.querySelector('.transform') || modal.firstElementChild;
        if (trans && trans.classList) {
            trans.classList.add('scale-95');
            trans.classList.remove('scale-100');
        }
        modal.classList.add('hidden');
    };

    // Close modals when clicking backdrop overlay
    $(document).on('click', '#enquiryModal, #bookingModal', function(e) {
        if (e.target === this) {
            closeEnquiryModal();
            closeBookingModal();
        }
    });

    function calculateBookingPrice() {
        var basePrice = parseFloat($('#bookPickupPoint option:selected').data('price') || $('#bookBasePrice').val() || 0);
        var rawAdults = parseInt($('#bookAdults').val(), 10);
        var adults = (!isNaN(rawAdults) && rawAdults > 0) ? rawAdults : 0;
        var rawChildren = parseInt($('#bookChildren').val(), 10);
        var children = (!isNaN(rawChildren) && rawChildren > 0) ? rawChildren : 0;
        
        var totalMembers = adults + children;
        var displayMembers = totalMembers > 0 ? totalMembers : 1;
        var totalPrice = basePrice * displayMembers;
        
        $('#bookPriceCalcText').text('₹' + basePrice.toLocaleString('en-IN') + ' x ' + displayMembers + ' Travelers');
        $('#bookTotalPriceDisplay').text('₹' + totalPrice.toLocaleString('en-IN'));
    }

    $(document).on('change input', '#bookPickupPoint, #bookAdults, #bookChildren', function() {
        calculateBookingPrice();
    });

    // ==================== REAL-TIME INLINE VALIDATION ====================
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|in|org|net|edu|gov|mil|biz|info|mobi|name|aero|asia|jobs|museum|[a-zA-Z]{2})(\.[a-zA-Z]{2})?$/i;
    const mobilePattern = /^[6-9]\d{9}$/;

    function checkInlineEmail(inputSelector, errSelector) {
        var val = $(inputSelector).val() ? $(inputSelector).val().trim() : '';
        if (val.length === 0) {
            $(errSelector).addClass('hidden');
            $(inputSelector).removeClass('border-red-500').addClass('border-gray-200');
            return true;
        }
        if (!emailPattern.test(val)) {
            $(errSelector).removeClass('hidden');
            $(inputSelector).addClass('border-red-500').removeClass('border-gray-200');
            return false;
        } else {
            $(errSelector).addClass('hidden');
            $(inputSelector).removeClass('border-red-500').addClass('border-gray-200');
            return true;
        }
    }

    function checkInlineMobile(inputSelector, errSelector) {
        var val = $(inputSelector).val() ? $(inputSelector).val().replace(/[^0-9]/g, '') : '';
        if (val.length === 0) {
            $(errSelector).addClass('hidden');
            $(inputSelector).removeClass('border-red-500').addClass('border-gray-200');
            return true;
        }
        if (!mobilePattern.test(val)) {
            $(errSelector).removeClass('hidden');
            $(inputSelector).addClass('border-red-500').removeClass('border-gray-200');
            return false;
        } else {
            $(errSelector).addClass('hidden');
            $(inputSelector).removeClass('border-red-500').addClass('border-gray-200');
            return true;
        }
    }

    $(document).on('input blur', '#enqEmail', function() { checkInlineEmail('#enqEmail', '#enqEmailErr'); });
    $(document).on('input blur', '#enqMobile', function() { checkInlineMobile('#enqMobile', '#enqMobileErr'); });
    $(document).on('input blur', '#bookEmail', function() { checkInlineEmail('#bookEmail', '#bookEmailErr'); });
    $(document).on('input blur', '#bookMobile', function() { checkInlineMobile('#bookMobile', '#bookMobileErr'); });

    $(document).on('submit', '#enquiryModalForm', function(e) {
        e.preventDefault();
        var packageId = $('#enqPackageId').val();
        var name = $('#enqName').val();
        var email = $('#enqEmail').val();
        var mobile = $('#enqMobile').val();
        var travelDate = $('#enqTravelDate').val();
        var adults = $('#enqAdults').val();
        var children = $('#enqChildren').val();
        var budget = $('#enqBudget').val();
        var message = $('#enqMessage').val();

        if (!packageId) {
            $('#enqPackageErr').removeClass('hidden');
            $('#enqPackageDropdownBtn').addClass('border-red-500').focus();
            if (window.showAppNotification) window.showAppNotification('error', 'Please select a tour package or destination.');
            return false;
        }

        var isMobileValid = checkInlineMobile('#enqMobile', '#enqMobileErr');
        var isEmailValid = checkInlineEmail('#enqEmail', '#enqEmailErr');

        if (!isMobileValid) {
            $('#enqMobile').focus();
            if (window.showAppNotification) window.showAppNotification('error', 'Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.');
            return false;
        }

        if (email && email.trim() !== '' && !isEmailValid) {
            $('#enqEmail').focus();
            if (window.showAppNotification) window.showAppNotification('error', 'Please enter a valid email address.');
            return false;
        }

        var $btn = $('#enqSubmitBtn');
        var origHtml = '<i class="fa-solid fa-paper-plane text-xs"></i> <span>Submit Travel Inquiry</span>';
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin text-xs"></i> <span>Submitting...</span>');

        $.ajax({
            url: '/submit_enquiry',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                name: name,
                email: email,
                mobile: mobile,
                package_id: packageId || null,
                travel_date: travelDate,
                adults: adults,
                children: children,
                budget: budget,
                message: message
            },
            success: function(res) {
                $btn.prop('disabled', false).html(origHtml);
                if (res.status === 'success') {
                    closeEnquiryModal();
                    $('#enquiryModalForm')[0].reset();
                    $('#enqEmailErr, #enqMobileErr').addClass('hidden');
                    $('#enqEmail, #enqMobile').removeClass('border-red-500');
                    if (window.showAppNotification) {
                        window.showAppNotification('success', res.message);
                    }
                } else {
                    if (window.showAppNotification) window.showAppNotification('error', res.message);
                }
            },
            error: function(xhr) {
                $btn.prop('disabled', false).html(origHtml);
                var msg = (xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : 'Something went wrong. Please try again.';
                if (window.showAppNotification) window.showAppNotification('error', msg);
            }
        });
    });

    $(document).on('submit', '#bookingModalForm', function(e) {
        e.preventDefault();
        var name = $('#bookName').val();
        var email = $('#bookEmail').val();
        var mobile = $('#bookMobile').val();
        var packageId = $('#bookPackageId').val();
        var travelDate = $('#bookTravelDate').val();
        var adults = $('#bookAdults').val();
        var children = $('#bookChildren').val();
        var pickupPointId = $('#bookPickupPoint').val();
        var pickupPointName = $('#bookPickupPoint option:selected').text();
        var address = $('#bookAddress').val();

        var isMobileValid = checkInlineMobile('#bookMobile', '#bookMobileErr');
        var isEmailValid = checkInlineEmail('#bookEmail', '#bookEmailErr');

        if (!isMobileValid) {
            $('#bookMobile').focus();
            if (window.showAppNotification) window.showAppNotification('error', 'Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.');
            return false;
        }

        if (!isEmailValid) {
            $('#bookEmail').focus();
            if (window.showAppNotification) window.showAppNotification('error', 'Please enter a valid email address.');
            return false;
        }

        var $btn = $('#bookSubmitBtn');
        var origHtml = '<i class="fa-solid fa-cart-shopping"></i> <span>Confirm Booking</span>';
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin text-xs"></i> <span>Confirming Booking...</span>');

        $.ajax({
            url: '/submit-booking',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                name: name,
                email: email,
                mobile: mobile,
                package_id: packageId,
                travel_date: travelDate,
                adults: adults,
                children: children,
                pickup_point_id: pickupPointId,
                pickup_point_name: pickupPointName,
                address: address
            },
            success: function(res) {
                $btn.prop('disabled', false).html(origHtml);
                if (res.status === 'success') {
                    closeBookingModal();
                    $('#bookingModalForm')[0].reset();
                    if (window.showAppNotification) {
                        window.showAppNotification('success', res.message);
                    }
                } else {
                    if (window.showAppNotification) window.showAppNotification('error', res.message);
                }
            },
            error: function(xhr) {
                $btn.prop('disabled', false).html(origHtml);
                var msg = (xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : 'Something went wrong. Please try again.';
                if (window.showAppNotification) window.showAppNotification('error', msg);
            }
        });
    });
</script>

<!-- ==================== ENQUIRY & BOOKING MODAL ==================== -->
<!-- General Enquiry Modal -->
<div id="enquiryModal" class="fixed inset-0 z-[999999] bg-black/75 backdrop-blur-md hidden flex items-center justify-center p-3 sm:p-4 font-sora">
    <div class="transform scale-95 transition-all duration-300 bg-white rounded-[28px] max-w-lg w-full max-h-[92vh] shadow-2xl overflow-hidden flex flex-col border border-gray-100 relative my-auto">
        
        <!-- Header -->
        <div class="bg-[#050c18] text-white px-6 py-4 flex items-center justify-between shrink-0 border-b border-gray-800">
            <div class="text-left">
                <span class="text-[9px] font-extrabold text-gold uppercase tracking-widest bg-gold/15 px-2.5 py-0.5 rounded-full border border-gold/20">Enquiry Portal</span>
                <h3 class="font-outfit font-extrabold text-lg text-white mt-1" id="enquiryModalTitle">Plan Your Himachal Journey</h3>
            </div>
            <button type="button" id="closeEnquiryModalBtn" onclick="closeEnquiryModal()" class="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition duration-200 focus:outline-none">
                <i class="fa-solid fa-xmark text-base"></i>
            </button>
        </div>

        <!-- Form Body (Scrollable Compact Layout) -->
        <form id="enquiryModalForm" action="javascript:void(0);" method="POST" class="p-4 sm:p-5 space-y-3 overflow-y-auto text-left flex-1 scrollbar-none">
            <input type="hidden" id="enqPackageId" value="">
            
            <!-- Dynamic Selected Package Alert Banner -->
            <div id="enqSelectedPackageBanner" class="hidden bg-[#FFFDF9] border border-gold/30 rounded-xl p-2.5 flex items-center gap-2.5 shadow-sm">
                <div class="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center text-gold shrink-0 border border-gold/20">
                    <i class="fa-solid fa-compass text-xs"></i>
                </div>
                <div class="leading-tight text-left">
                    <span class="text-[9px] text-gray-400 font-bold uppercase tracking-wider block">Selected Package</span>
                    <span class="text-xs font-extrabold text-navy block mt-0.5" id="enqSelectedPackageName">Tour Package</span>
                </div>
            </div>

            <!-- Custom Searchable Select Tour Package Dropdown -->
            <div class="relative" id="enqPackageCustomDropdown">
                <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Select Tour Package / Destination <span class="text-red-500">*</span></label>
                
                <!-- Trigger Button -->
                <button type="button" id="enqPackageDropdownBtn" class="w-full border border-gray-200 rounded-xl pl-9 pr-8 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 bg-white cursor-pointer font-bold flex items-center justify-between text-left relative overflow-hidden">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                        <i class="fa-solid fa-compass text-xs"></i>
                    </span>
                    <span id="enqPackageDropdownLabel" class="truncate block text-navy pr-2">-- Select Tour Package / Destination --</span>
                    <span class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-400">
                        <i class="fa-solid fa-chevron-down text-[10px] transition-transform duration-200" id="enqPackageDropdownChevron"></i>
                    </span>
                </button>

                <!-- Dropdown Menu Panel (Contained strictly within modal width) -->
                <div id="enqPackageDropdownMenu" class="hidden absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-2xl shadow-2xl z-[99999] overflow-hidden transition-all duration-200">
                    <!-- Live Search Header -->
                    <div class="p-2 border-b border-gray-100 bg-slate-50 relative">
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                                <i class="fa-solid fa-magnifying-glass text-[11px]"></i>
                            </span>
                            <input type="text" id="enqPackageSearchInput" placeholder="Search destination or package..." class="w-full bg-white border border-gray-200 rounded-xl pl-8 pr-7 py-1.5 text-xs text-navy focus:outline-none focus:border-gold placeholder-gray-400 font-medium">
                            <button type="button" id="enqClearPackageSearch" class="hidden absolute inset-y-0 right-0 flex items-center pr-2.5 text-gray-400 hover:text-gray-600">
                                <i class="fa-solid fa-xmark text-xs"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Scrollable Options List -->
                    <div class="max-h-48 overflow-y-auto p-1 divide-y divide-gray-50 scrollbar-none" id="enqPackageOptionsList">
                        <div class="enq-package-option px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gold/10 hover:text-navy rounded-xl cursor-pointer transition flex items-center justify-between" data-value="" data-title="-- Select Tour Package / Destination --">
                            <span class="truncate">-- Select Tour Package / Destination --</span>
                            <i class="fa-solid fa-check text-gold text-xs opacity-0 check-icon"></i>
                        </div>
                        @if(isset($packages) && count($packages) > 0)
                            @foreach($packages as $pkg)
                                <div class="enq-package-option px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gold/10 hover:text-navy rounded-xl cursor-pointer transition flex items-center justify-between" data-value="{{ $pkg->id }}" data-title="{{ $pkg->package_name ?? 'Tour Package' }}@if(!empty($pkg->destination)) ({{ $pkg->destination }})@endif">
                                    <div class="truncate pr-2">
                                        <span class="font-extrabold text-navy block text-xs truncate">{{ $pkg->package_name ?? 'Tour Package' }}</span>
                                        @if(!empty($pkg->destination))
                                            <span class="text-[10px] text-gray-400 font-medium block truncate"><i class="fa-solid fa-location-dot text-red-400 mr-1"></i>{{ $pkg->destination }}</span>
                                        @endif
                                    </div>
                                    <i class="fa-solid fa-check text-gold text-xs opacity-0 check-icon shrink-0"></i>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>

                <span id="enqPackageErr" class="text-[10px] font-bold text-red-500 mt-1 hidden block">Please select a tour package or destination</span>
            </div>

            <!-- Full Name -->
            <div>
                <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Your Full Name <span class="text-red-500">*</span></label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                        <i class="fa-regular fa-user text-xs"></i>
                    </span>
                    <input type="text" id="enqName" required minlength="3" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="e.g. Amit Kumar">
                </div>
            </div>

            <!-- Email & Mobile row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Email Address</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                            <i class="fa-regular fa-envelope text-xs"></i>
                        </span>
                        <input type="email" id="enqEmail" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="e.g. amit@gmail.com">
                    </div>
                    <span id="enqEmailErr" class="text-[10px] font-bold text-red-500 mt-1 hidden block">Please enter a valid email address (e.g. name@domain.com)</span>
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Mobile Number <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                            <i class="fa-solid fa-phone text-xs"></i>
                        </span>
                        <input type="tel" id="enqMobile" required maxlength="10" pattern="[6-9][0-9]{9}" oninput="this.value=this.value.replace(/[^0-9]/g,'');if(this.value.length>10)this.value=this.value.slice(0,10);" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="10-digit mobile number">
                    </div>
                    <span id="enqMobileErr" class="text-[10px] font-bold text-red-500 mt-1 hidden block">Must be 10 digits starting with 6, 7, 8, or 9</span>
                </div>
            </div>

            <!-- Travel Date & Budget -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Travel Date</label>
                    <input type="date" id="enqTravelDate" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold cursor-pointer bg-white">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Budget Range</label>
                    <select id="enqBudget" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold cursor-pointer bg-white">
                        <option value="">Select Budget</option>
                        <option value="₹5,000 - ₹10,000">₹5,000 - ₹10,000</option>
                        <option value="₹10,000 - ₹20,000">₹10,000 - ₹20,000</option>
                        <option value="₹20,000 - ₹40,000">₹20,000 - ₹40,000</option>
                        <option value="₹40,000 - ₹60,000">₹40,000 - ₹60,000</option>
                        <option value="₹60,000+">₹60,000+</option>
                    </select>
                </div>
            </div>

            <!-- Guests count (Adults & Children) -->
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Adults Count <span class="text-red-500">*</span></label>
                    <input type="number" id="enqAdults" required min="1" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold placeholder-gray-400" placeholder="Enter adults">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Children Count</label>
                    <input type="number" id="enqChildren" min="0" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold placeholder-gray-400" placeholder="Enter children">
                </div>
            </div>

            <!-- Special Requests / Custom Message -->
            <div>
                <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Custom Tour Message</label>
                <div class="relative">
                    <span class="absolute left-3.5 top-3 text-gray-400">
                        <i class="fa-solid fa-pencil text-xs"></i>
                    </span>
                    <textarea id="enqMessage" rows="2" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold resize-none placeholder-gray-400" placeholder="Any specific hotels, vehicles, or custom itinerary requests..."></textarea>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="pt-1">
                <button type="submit" id="enqSubmitBtn" class="w-full bg-[#cca43b] hover:bg-[#b08b2d] text-white font-bold text-xs py-3.5 rounded-xl transition duration-300 shadow-md shadow-gold/10 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-paper-plane text-xs"></i>
                    <span>Submit Travel Inquiry</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Dedicated Booking Modal -->
<div id="bookingModal" class="fixed inset-0 z-[999999] bg-black/75 backdrop-blur-md hidden flex items-center justify-center p-3 sm:p-4 font-sora">
    <div class="transform scale-95 transition-all duration-300 bg-white rounded-[28px] max-w-lg w-full max-h-[92vh] shadow-2xl overflow-hidden flex flex-col border border-gray-100 relative my-auto">
        
        <!-- Header -->
        <div class="bg-[#050c18] text-white px-6 py-4 flex items-center justify-between shrink-0 border-b border-gray-800">
            <div class="text-left">
                <span class="text-[9px] font-extrabold text-gold uppercase tracking-widest bg-gold/15 px-2.5 py-0.5 rounded-full border border-gold/20">Booking Portal</span>
                <h3 class="font-outfit font-extrabold text-lg text-white mt-1">Book Tour Package</h3>
            </div>
            <button type="button" onclick="closeBookingModal()" class="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition duration-200 focus:outline-none">
                <i class="fa-solid fa-xmark text-base"></i>
            </button>
        </div>

        <!-- Form Body (Scrollable Compact Layout) -->
        <form id="bookingModalForm" action="javascript:void(0);" method="POST" class="p-4 sm:p-5 space-y-3 overflow-y-auto text-left flex-1 scrollbar-none">
            <input type="hidden" id="bookPackageId" value="">
            <input type="hidden" id="bookBasePrice" value="0">
            
            <!-- Selected Package Banner -->
            <div class="bg-[#FFFDF9] border border-gold/30 rounded-xl p-2.5 flex items-center gap-2.5 shadow-sm">
                <div class="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center text-gold shrink-0 border border-gold/20">
                    <i class="fa-solid fa-plane text-xs"></i>
                </div>
                <div class="leading-tight text-left">
                    <span class="text-[9px] text-gray-400 font-bold uppercase tracking-wider block">Selected Package</span>
                    <span class="text-xs font-extrabold text-navy block mt-0.5" id="bookSelectedPackageName">Tour Package</span>
                </div>
            </div>

            <!-- Full Name -->
            <div>
                <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Your Full Name <span class="text-red-500">*</span></label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                        <i class="fa-regular fa-user text-xs"></i>
                    </span>
                    <input type="text" id="bookName" required minlength="3" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="e.g. Amit Kumar">
                </div>
            </div>

            <!-- Email & Mobile row -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Email Address <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                            <i class="fa-regular fa-envelope text-xs"></i>
                        </span>
                        <input type="email" id="bookEmail" required class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="e.g. amit@gmail.com">
                    </div>
                    <span id="bookEmailErr" class="text-[10px] font-bold text-red-500 mt-1 hidden block">Please enter a valid email address (e.g. name@domain.com)</span>
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Mobile Number <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-400">
                            <i class="fa-solid fa-phone text-xs"></i>
                        </span>
                        <input type="tel" id="bookMobile" required maxlength="10" pattern="[6-9][0-9]{9}" oninput="this.value=this.value.replace(/[^0-9]/g,'');if(this.value.length>10)this.value=this.value.slice(0,10);" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition duration-200 placeholder-gray-400" placeholder="10-digit mobile number">
                    </div>
                    <span id="bookMobileErr" class="text-[10px] font-bold text-red-500 mt-1 hidden block">Must be 10 digits starting with 6, 7, 8, or 9</span>
                </div>
            </div>

            <!-- Travel Date & Pickup Point -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Travel Date <span class="text-red-500">*</span></label>
                    <input type="date" id="bookTravelDate" required class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold cursor-pointer bg-white">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Pickup Point</label>
                    <select id="bookPickupPoint" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold cursor-pointer bg-white">
                        <option value="">Default Pickup Point</option>
                    </select>
                </div>
            </div>

            <!-- Guests count -->
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Adults Count <span class="text-red-500">*</span></label>
                    <input type="number" id="bookAdults" required min="1" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold placeholder-gray-400" placeholder="Enter adults">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Children Count</label>
                    <input type="number" id="bookChildren" min="0" class="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold placeholder-gray-400" placeholder="Enter children">
                </div>
            </div>

            <!-- Address Field -->
            <div>
                <label class="block text-[10px] font-bold text-navy uppercase tracking-wider mb-1">Address <span class="text-red-500">*</span></label>
                <div class="relative">
                    <span class="absolute left-3.5 top-3 text-gray-400">
                        <i class="fa-solid fa-map-marker-alt text-xs"></i>
                    </span>
                    <textarea id="bookAddress" required rows="2" class="w-full border border-gray-200 rounded-xl pl-9 pr-3 py-2 text-xs text-navy focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold resize-none placeholder-gray-400" placeholder="Enter your full address..."></textarea>
                </div>
            </div>

            <!-- Price Display -->
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 flex flex-col text-left">
                <span class="text-[9px] text-amber-800 font-bold uppercase tracking-wider block">Estimated Price Details</span>
                <div class="flex justify-between items-center mt-1">
                    <span class="text-xs text-navy font-medium" id="bookPriceCalcText">₹0 x 1 Travelers</span>
                    <span class="text-sm font-black text-amber-700" id="bookTotalPriceDisplay">₹0</span>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="pt-1">
                <button type="submit" id="bookSubmitBtn" class="w-full bg-[#cca43b] hover:bg-[#b08b2d] text-white font-bold text-xs py-3.5 rounded-xl transition duration-300 shadow-md shadow-gold/10 flex items-center justify-center gap-2">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span>Confirm Booking</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Floating WhatsApp Widget (Pulsing Glow & Slide-out Tooltip) -->
<style>
    .whatsapp-float {
        position: fixed;
        bottom: 24px;
        left: 24px;
        background-color: #25d366;
        color: #fff;
        width: 54px;
        height: 54px;
        border-radius: 50%;
        box-shadow: 0 4px 15px rgba(37, 211, 102, 0.4);
        z-index: 999;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        cursor: pointer;
        text-decoration: none;
    }
    .whatsapp-float:hover {
        background-color: #128c7e;
        transform: scale(1.08) translateY(-3px);
        box-shadow: 0 8px 25px rgba(18, 140, 126, 0.5);
    }
    .whatsapp-pulse {
        position: absolute;
        width: 100%;
        height: 100%;
        background-color: rgba(37, 211, 102, 0.4);
        border-radius: 50%;
        z-index: -1;
        animation: whatsapp-glow 2s infinite;
    }
    @keyframes whatsapp-glow {
        0% {
            transform: scale(1);
            opacity: 0.8;
        }
        50% {
            transform: scale(1.3);
            opacity: 0.3;
        }
        100% {
            transform: scale(1.6);
            opacity: 0;
        }
    }
    .whatsapp-tooltip {
        position: absolute;
        left: 68px;
        background-color: #050c18;
        color: #fff;
        padding: 8px 16px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
        opacity: 0;
        transform: translateX(-10px);
        visibility: hidden;
        transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 6px;
        border: 1px solid rgba(255,255,255,0.05);
    }
    .whatsapp-float:hover .whatsapp-tooltip {
        opacity: 1;
        transform: translateX(0);
        visibility: visible;
    }

    /* Fixed Vertical Quick Enquiry Tab on right edge */
    .fixed-enquiry-btn {
        position: fixed;
        right: 0;
        top: 50%;
        transform: translateY(-50%) rotate(180deg);
        writing-mode: vertical-rl;
        text-orientation: mixed;
        z-index: 40;
        white-space: nowrap;
    }
</style>
<a href="https://wa.me/919876543210?text=Hi!%20I'm%20interested%20in%20Himachal%20tour%20packages." target="_blank" class="whatsapp-float">
    <div class="whatsapp-pulse"></div>
    <i class="fa-brands fa-whatsapp text-2xl"></i>
    <div class="whatsapp-tooltip">
        <span class="w-1.5 h-1.5 rounded-full bg-[#25d366] animate-ping"></span>
        Chat with our travel expert!
    </div>
</a>

<!-- Sticky Quick Enquiry Side Button -->
<button onclick="openEnquiryModal()" class="fixed-enquiry-btn bg-[#cca43b] hover:bg-[#b08b2d] text-white py-6 px-3.5 rounded-l-2xl font-bold uppercase text-[9.5px] tracking-widest cursor-pointer shadow-[0_4px_25px_rgba(0,0,0,0.15)] flex items-center justify-center gap-2 transition duration-300 border-l border-y border-white/20 select-none group focus:outline-none">
    <i class="fa-solid fa-paper-plane text-[9.5px] group-hover:-translate-y-1 transition duration-300"></i>
    <span>Enquiry Now</span>
</button>

<script>
    window.selectedPickupMap = window.selectedPickupMap || {};

    function handlePickupChange(select) {
        var opt = select.options[select.selectedIndex];
        var price = parseFloat(opt.getAttribute('data-price')) || 0;
        var offer = parseFloat(opt.getAttribute('data-offer')) || 0;
        var pickupId = select.value;

        var card = select.closest('.package-card-item');
        if (card) {
            var packageId = card.getAttribute('data-package-id');
            if (packageId && pickupId) {
                window.selectedPickupMap[packageId] = pickupId;
            }
            var offerEl = card.querySelector('.card-offer-price');
            var origEl = card.querySelector('.card-orig-price');

            if (offerEl) {
                offerEl.textContent = '₹' + Math.round(offer).toLocaleString('en-IN');
            }
            if (origEl) {
                if (price > offer && offer > 0) {
                    origEl.textContent = '₹' + Math.round(price).toLocaleString('en-IN');
                    origEl.classList.remove('hidden');
                    origEl.style.display = 'inline';
                } else {
                    origEl.classList.add('hidden');
                    origEl.style.display = 'none';
                }
            }

            var detailsLink = card.querySelector('a[href*="/package-detail/"]');
            if (detailsLink && pickupId) {
                var baseUrl = detailsLink.getAttribute('data-base-url') || detailsLink.href.split('?')[0];
                detailsLink.setAttribute('data-base-url', baseUrl);
                detailsLink.href = baseUrl + '?pickup_point_id=' + pickupId;
            }
        }
    }

    window.goToPackageDetails = function(event, url, packageId) {
        if (event) event.preventDefault();
        var targetUrl = url;
        var pickupId = null;
        
        if (event && event.target) {
            var card = event.target.closest('.package-card-item');
            if (card) {
                var select = card.querySelector('.pkg-pickup-select');
                if (select && select.value) {
                    pickupId = select.value;
                }
            }
        }
        
        if (!pickupId && window.selectedPickupMap && window.selectedPickupMap[packageId]) {
            pickupId = window.selectedPickupMap[packageId];
        }
        
        if (pickupId) {
            var cleanUrl = targetUrl.split('?')[0];
            targetUrl = cleanUrl + '?pickup_point_id=' + pickupId;
        }
        
        window.location.href = targetUrl;
    };

    document.addEventListener('DOMContentLoaded', function () {
        if (typeof Swiper !== 'undefined') {
            document.querySelectorAll('.card-gallery-swiper').forEach(function (swiperEl) {
                new Swiper(swiperEl, {
                    loop: true,
                    effect: 'fade',
                    fadeEffect: {
                        crossFade: true
                    },
                    speed: 800,
                    autoplay: {
                        delay: 4000,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: swiperEl.querySelector('.card-gallery-pagination'),
                        clickable: true,
                    },
                    on: {
                        slideChange: function () {
                            var realIndex = (this.realIndex !== undefined ? this.realIndex : 0) + 1;
                            var total = this.slides ? this.slides.length : 1;
                            if (this.params && this.params.loop && total > 2) {
                                total = total - 2;
                            }
                            var counterEl = swiperEl.closest('.relative').querySelector('.gallery-counter-text');
                            if (counterEl) {
                                counterEl.textContent = realIndex + '/' + total;
                            }
                        }
                    }
                });
            });
        }
    });

    // Home Gallery AJAX Pagination
    function loadHomeGalleryPage(page) {
        $.ajax({
            url: "{{ url('/fetch-home-gallery') }}",
            type: "POST",
            data: {
                page: page,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                if (res.success) {
                    $('#home-gallery-grid-container').html(res.html);
                    $('#home-gallery-pagination').html(res.pagination);
                }
            }
        });
    }

    function openHomeLightbox(src) {
        $('#homeLightboxImg').attr('src', src);
        $('#homeLightbox').removeClass('hidden').addClass('flex');
    }
    function closeHomeLightbox() {
        $('#homeLightbox').addClass('hidden').removeClass('flex');
    }

    // Add Review Modal & Contact Form Handlers
    $(document).ready(function() {
        $('#openAddReviewBtn').click(function() {
            $('#addReviewModal').removeClass('hidden').addClass('flex');
        });

        $('#closeReviewModalBtn').click(function() {
            $('#addReviewModal').addClass('hidden').removeClass('flex');
        });

        // Star rating click handler
        $('.star-select').click(function() {
            var rating = parseInt($(this).data('rating'));
            $('#reviewRating').val(rating);
            $('.star-select').each(function() {
                var currentStar = parseInt($(this).data('rating'));
                if (currentStar <= rating) {
                    $(this).removeClass('text-gray-300').addClass('text-gold');
                } else {
                    $(this).removeClass('text-gold').addClass('text-gray-300');
                }
            });
        });

        // Submit review via AJAX
        $('#addReviewForm').submit(function(e) {
            e.preventDefault();
            var btn = $('#submitReviewFormBtn');
            btn.prop('disabled', true).find('span').text('Submitting...');

            var formData = new FormData(this);
            $.ajax({
                url: "{{ url('/submit-review') }}",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    btn.prop('disabled', false).find('span').text('Submit Review');
                    if (res.success) {
                        $('#addReviewForm')[0].reset();
                        $('#addReviewModal').addClass('hidden').removeClass('flex');
                        if (window.showAppNotification) {
                            window.showAppNotification('success', res.message || 'Thank you! Your review has been submitted successfully.');
                            setTimeout(function(){ location.reload(); }, 1500);
                        } else if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Review Submitted!',
                                text: res.message || 'Thank you! Your review has been submitted successfully.',
                                confirmButtonColor: '#cca43b',
                                timer: 3000,
                                timerProgressBar: true
                            }).then(function() {
                                location.reload();
                            });
                        }
                    } else {
                        if (window.showAppNotification) {
                            window.showAppNotification('error', res.message || 'Error submitting review.');
                        } else if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Submission Error',
                                text: res.message || 'Error submitting review.',
                                confirmButtonColor: '#cca43b'
                            });
                        }
                    }
                },
                error: function() {
                    btn.prop('disabled', false).find('span').text('Submit Review');
                    if (window.showAppNotification) {
                        window.showAppNotification('error', 'Something went wrong. Please try again!');
                    } else if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Submission Error',
                            text: 'Something went wrong. Please try again!',
                            confirmButtonColor: '#cca43b'
                        });
                    }
                }
            });
        });

        // Submit home contact form via AJAX
        $('#home_contact_form').submit(function(e) {
            e.preventDefault();
            var btn = $('#home_contact_btn');
            btn.prop('disabled', true).addClass('opacity-75').find('span').text('Sending...');
            $.ajax({
                url: "{{ url('/submit_enquiry') }}",
                type: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    btn.prop('disabled', false).removeClass('opacity-75').find('span').text('Send Message');
                    var successText = response.message || 'Thank you for reaching out! Our travel expert will contact you shortly.';
                    if (window.showAppNotification) {
                        window.showAppNotification('success', successText);
                    } else if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Enquiry Sent Successfully!',
                            text: successText,
                            confirmButtonColor: '#cca43b',
                            timer: 4000,
                            timerProgressBar: true
                        });
                    }
                    $('#home_contact_form')[0].reset();
                },
                error: function(xhr) {
                    btn.prop('disabled', false).removeClass('opacity-75').find('span').text('Send Message');
                    var msg = (xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : 'Something went wrong. Please try again!';
                    if (window.showAppNotification) {
                        window.showAppNotification('error', msg);
                    } else if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Submission Failed',
                            text: msg,
                            confirmButtonColor: '#cca43b'
                        });
                    }
                }
            });
        });
    });

    // Animated Counter Observer
    document.addEventListener("DOMContentLoaded", function () {
        const counters = document.querySelectorAll(".counter-number");
        if (counters.length === 0) return;

        let animated = false;

        function startCounters() {
            counters.forEach(counter => {
                const target = parseFloat(counter.getAttribute("data-target"));
                const decimals = parseInt(counter.getAttribute("data-decimals") || "0");
                const duration = 1800;
                const startTime = performance.now();

                function update(currentTime) {
                    const elapsed = currentTime - startTime;
                    const progress = Math.min(elapsed / duration, 1);
                    const easeProgress = 1 - Math.pow(1 - progress, 3);
                    const currentVal = target * easeProgress;

                    counter.innerText = currentVal.toFixed(decimals);

                    if (progress < 1) {
                        requestAnimationFrame(update);
                    } else {
                        counter.innerText = target.toFixed(decimals);
                    }
                }
                requestAnimationFrame(update);
            });
        }

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !animated) {
                    animated = true;
                    startCounters();
                }
            });
        }, { threshold: 0.3 });

        const counterSection = counters[0].closest("section");
        if (counterSection) {
            observer.observe(counterSection);
        }
    });
</script>
