@include('Website.includes.CssLink')

    <!-- GLASS HEADER NAVIGATION -->
    @include('Website.includes.Header')

    <!-- =========================================================
         HERO BANNER (WITH BACKGROUND IMAGE SLIDER)
    ========================================================= -->
    <section class="contact-hero-light">
        <div class="contact-hero-slider-track" id="blogHeroTrack">
            <div class="contact-hero-slide active">
                <img src="{{ asset('Website/assets/images/hero_image.jpeg') }}" alt="Estate Journal">
            </div>
        </div>
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">Estate <span>Journal</span></h1>
            <p class="contact-hero-light-sub">Perspectives on biophilic architecture, alpine wellness, and refined hill living at Solan.</p>
        </div>
    </section>

    <!-- =========================================================
         BLOG MAIN SECTION
    ========================================================= -->
    <section class="blog-main-wrapper">
        <div class="blog-main-container">
            
            <!-- SECTION INTRO HEADER -->
            <div class="gallery-header-center">
                <span class="contact-eyebrow">INSIGHTS & ARTICLES</span>
                <h2 class="contact-heading">The Art Of <span>Sanctuary</span> Living</h2>
                <p class="gallery-intro-desc">
                    Explore curated stories from our architects, interior designers, and lifestyle connoisseurs on creating timeless luxury in the foothills of Himachal.
                </p>
            </div>

            <!-- FEATURED BLOG SPOTLIGHT CARD -->
            @php
                $formatBlogDate = function($dateStr) {
                    if (empty($dateStr)) return '';
                    $time = strtotime($dateStr);
                    $month = date('M', $time);
                    if ($month === 'Sep') {
                        $month = 'Sept';
                    }
                    return $month . ' ' . date('d, Y', $time);
                };
            @endphp
            @if(!empty($featuredBlog))
                @php
                    $featImg = !empty($featuredBlog->image) ? asset($featuredBlog->image) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg');
                    $featDate = !empty($featuredBlog->blog_date) ? $formatBlogDate($featuredBlog->blog_date) : $formatBlogDate($featuredBlog->created_at ?? 'now');
                    $featSlug = !empty($featuredBlog->slug) ? $featuredBlog->slug : $featuredBlog->id;
                    $featExcerpt = !empty($featuredBlog->short_description) ? $featuredBlog->short_description : Str::limit(strip_tags($featuredBlog->description ?? ''), 160);
                @endphp
                <div class="blog-featured-card">
                    <div class="blog-featured-img-wrapper">
                        <img src="{{ $featImg }}" alt="{{ $featuredBlog->title ?? 'Featured Blog' }}">
                    </div>
                    <div class="blog-featured-content">
                        <div class="blog-meta-row">
                            <span class="blog-date">{{ $featDate }}</span>
                            <span class="blog-dot-sep">•</span>
                            <span class="blog-read-time">{{ !empty($featuredBlog->category) ? $featuredBlog->category : 'Lifestyle' }}</span>
                        </div>
                        <h3 class="blog-featured-title">{{ $featuredBlog->title ?? '' }}</h3>
                        <p class="blog-featured-excerpt">
                            {{ $featExcerpt }}
                        </p>
                        <a href="{{ url('/blog/' . $featSlug) }}" class="send-msg-btn blog-read-btn">READ FULL ARTICLE</a>
                    </div>
                </div>
            @endif

            <!-- BLOG CARDS GRID (3 COLUMNS RESPONSIVE) -->
            <div class="blog-grid" id="blogGrid">
                @if(!empty($blogs) && count($blogs) > 0)
                    @foreach($blogs as $blog)
                        @php
                            $blogImg = !empty($blog->image) ? asset($blog->image) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.45 PM.jpeg');
                            $blogDate = !empty($blog->blog_date) ? $formatBlogDate($blog->blog_date) : $formatBlogDate($blog->created_at ?? 'now');
                            $blogSlug = !empty($blog->slug) ? $blog->slug : $blog->id;
                            $blogExcerpt = !empty($blog->short_description) ? $blog->short_description : Str::limit(strip_tags($blog->description ?? ''), 110);
                        @endphp
                        <div class="blog-card-item">
                            <div class="blog-card-img-box">
                                <img src="{{ $blogImg }}" alt="{{ $blog->title ?? 'Blog Article' }}" loading="lazy">
                            </div>
                            <div class="blog-card-body">
                                <div class="blog-meta-row">
                                    <span class="blog-date">{{ $blogDate }}</span>
                                    <span class="blog-dot-sep">•</span>
                                    <span class="blog-read-time">{{ !empty($blog->category) ? $blog->category : 'Lifestyle' }}</span>
                                </div>
                                <h3 class="blog-card-title">{{ $blog->title ?? '' }}</h3>
                                <p class="blog-card-excerpt">{{ $blogExcerpt }}</p>
                                <a href="{{ url('/blog/' . $blogSlug) }}" class="send-msg-btn blog-card-btn">READ ARTICLE</a>
                            </div>
                        </div>
                    @endforeach
                @else
                    @if(empty($featuredBlog))
                        <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: #8a7a58;">
                            <p>No journal entries published yet. Stay tuned for upcoming architectural and lifestyle stories.</p>
                        </div>
                    @endif
                @endif
            </div>

            <!-- PAGINATION IF AVAILABLE -->
            @if(!empty($blogs) && method_exists($blogs, 'links') && $blogs->hasPages())
                <div style="margin-top: 3rem; display: flex; justify-content: center;">
                    {{ $blogs->links() }}
                </div>
            @endif

        </div>
    </section>

    <!-- =========================================================
         LIGHT LUXURY NEWSLETTER CTA BANNER
    ========================================================= -->
    <section class="gallery-cta-section">
        <div class="gallery-cta-card">
            <span class="contact-eyebrow">STAY INFORMED</span>
            <h2 class="gallery-cta-title">Subscribe To Our <span>Journal</span></h2>
            <p class="gallery-cta-desc">
                Be the first to receive architectural previews, private site visit invitations, and market insights straight to your inbox.
            </p>
            <a href="{{ url('/contact') }}" class="send-msg-btn gallery-cta-btn">ENQUIRE FOR PRIVATE VISIT</a>
        </div>
    </section>

    <!-- FOOTER & SCRIPTS -->
    @include('Website.includes.Footer')
    @include('Website.includes.JsLink')
