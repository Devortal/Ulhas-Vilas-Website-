@include('Website.includes.CssLink')

    <!-- GLASS HEADER NAVIGATION -->
    @include('Website.includes.Header')

    @php
        $formatBlogDate = function($dateStr) {
            if (empty($dateStr)) return '';
            $time = strtotime($dateStr);
            $month = date('M', $time);
            if ($month === 'Sep') {
                $month = 'Sept';
            }
            return $month . ' ' . date('d, Y', $time);
        };
        $blogTitle = $blog->title ?? 'Estate Journal — The Ulhas Vilas';
        $blogImg = !empty($blog->image) ? asset($blog->image) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.55.26 PM.jpeg');
        $blogDate = !empty($blog->blog_date) ? $formatBlogDate($blog->blog_date) : $formatBlogDate($blog->created_at ?? 'now');
        $blogCategory = !empty($blog->category) ? $blog->category : 'Estate Journal';
        $blogDescription = $blog->description ?? '';
    @endphp

    <!-- =========================================================
         HERO BANNER (WITH BACKGROUND IMAGE SLIDER)
    ========================================================= -->
    <section class="contact-hero-light">
        <div class="contact-hero-slider-track" id="blogDetailHeroTrack">
            <div class="contact-hero-slide active">
                <img src="{{ $blogImg }}" alt="{{ $blogTitle }}">
            </div>
            <div class="contact-hero-slide">
                <img src="{{ asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM (1).jpeg') }}" alt="Sundeck Mountain Vistas">
            </div>
            <div class="contact-hero-slide">
                <img src="{{ asset('Website/assets/images/WhatsApp Image 2026-08-22 at 4.05.04 PM.jpeg') }}" alt="Estate Architecture Facade">
            </div>
        </div>
        <div class="contact-hero-light-overlay"></div>
        <div class="contact-hero-light-content">
            <h1 class="contact-hero-light-title">{{ $blogTitle }}</h1>
            <p class="contact-hero-light-sub">An architectural and lifestyle journal by The Ulhas Vilas Luxury Estates.</p>
        </div>
    </section>

    <!-- =========================================================
         BLOG ARTICLE CONTENT WRAPPER
    ========================================================= -->
    <section class="blog-detail-main-wrapper">
        <div class="blog-detail-container">
            
            <!-- ARTICLE META BAR -->
            <div class="blog-detail-meta-bar" style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #efe8da; padding-bottom: 1.5rem; margin-bottom: 2rem; flex-wrap: wrap; gap: 1.5rem;">
                <div class="blog-detail-meta-left" style="display: flex; flex-direction: column; gap: 0.35rem;">
                    <span class="contact-eyebrow" style="margin-bottom: 0; font-size: 13px; letter-spacing: 1.5px; color: #CCA43B; font-weight: 700; text-transform: uppercase;">{{ strtoupper($blogCategory) }}</span>
                    <div style="display: flex; align-items: center; gap: 0.65rem; font-size: 14px; color: #666666;">
                        <span style="color: #111111; font-weight: 700;">By The Ulhas Vilas</span>
                        <span style="color: #CCA43B; font-size: 10px;">●</span>
                        <span style="color: #666666; font-weight: 500;">{{ $blogDate }}</span>
                    </div>
                </div>
                <!-- Social Share Row Dynamic From Information Table Matching Footer -->
                @php
                    $fb = $info->facebook_link ?? $info->info_facebook_link ?? null;
                    $insta = $info->instagram_link ?? $info->info_instagram_link ?? null;
                    $tw = $info->twitter_link ?? $info->info_twitter_link ?? $info->info_xtwitter_link ?? null;
                    $li = $info->linkedin_link ?? null;
                    $yt = $info->youtube_link ?? null;
                @endphp
                @if(!empty($fb) || !empty($insta) || !empty($tw) || !empty($li) || !empty($yt))
                <div class="blog-share-actions" style="display: flex; align-items: center; gap: 0.65rem;">
                    <span class="blog-share-label" style="font-size: 13px; font-weight: 700; color: #666666; letter-spacing: 1px; text-transform: uppercase;">SHARE:</span>
                    @if(!empty($fb))
                        <a href="{{ $fb }}" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Facebook">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                        </a>
                    @endif
                    @if(!empty($insta))
                        <a href="{{ $insta }}" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Instagram">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                        </a>
                    @endif
                    @if(!empty($tw))
                        <a href="{{ $tw }}" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="Twitter / X">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/></svg>
                        </a>
                    @endif
                    @if(!empty($li))
                        <a href="{{ $li }}" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="LinkedIn">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                        </a>
                    @endif
                    @if(!empty($yt))
                        <a href="{{ $yt }}" target="_blank" rel="noopener noreferrer" class="contact-social-circle" aria-label="YouTube">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58A2.78 2.78 0 0 0 3.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
                        </a>
                    @endif
                </div>
                @endif
            </div>

            <!-- FEATURED ARTWORK -->
            <div class="blog-detail-featured-hero">
                <img src="{{ $blogImg }}" alt="{{ $blogTitle }}">
                <p class="blog-image-caption">{{ $blogTitle }}</p>
            </div>

            <!-- EDITORIAL BODY TEXT -->
            <article class="blog-article-body">
                {!! $blogDescription !!}
            </article>

            <!-- BESPOKE RESIDENCE CONSULTATION CARD -->
            <div class="blog-consultation-card">
                <div class="blog-consultation-content">
                    <span class="contact-eyebrow">BESPOKE RESIDENCES</span>
                    <h3 class="blog-consultation-title">Interested In Mountain Estate <span>Ownership?</span></h3>
                    <p class="blog-consultation-desc">
                        Experience the architectural elegance of The Ulhas Vilas in person. Our relationship team provides confidential site walkthroughs, personalized floor plans, and residence details.
                    </p>
                    <div class="blog-consultation-actions">
                        <a href="{{ url('/contact') }}" class="send-msg-btn blog-author-btn">SCHEDULE A PRIVATE SITE VISIT</a>
                        <a href="{{ url('/residences') }}" class="gallery-tab-btn" style="text-decoration: none; display: inline-block;">EXPLORE RESIDENCES</a>
                    </div>
                </div>
            </div>

            <!-- BACK TO BLOGS LINK -->
            <div class="blog-back-wrapper">
                <a href="{{ url('/blogs') }}" class="gallery-tab-btn active" style="display: inline-flex; align-items: center; gap: 0.5rem; text-decoration: none;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                    <span>Back to All Articles</span>
                </a>
            </div>

            <!-- RELATED ARTICLES GRID -->
            @if(!empty($recent_blogs) && count($recent_blogs) > 0)
                <div class="blog-related-section">
                    <div class="gallery-header-center" style="margin-bottom: 2.5rem;">
                        <span class="contact-eyebrow">CONTINUE READING</span>
                        <h2 class="contact-heading">More From Our <span>Journal</span></h2>
                    </div>

                    <div class="blog-grid">
                        @foreach($recent_blogs as $rBlog)
                            @php
                                $rImg = !empty($rBlog->image) ? asset($rBlog->image) : asset('Website/assets/images/WhatsApp Image 2026-08-18 at 1.49.45 PM.jpeg');
                                $rDate = !empty($rBlog->blog_date) ? $formatBlogDate($rBlog->blog_date) : $formatBlogDate($rBlog->created_at ?? 'now');
                                $rSlug = !empty($rBlog->slug) ? $rBlog->slug : $rBlog->id;
                                $rExcerpt = !empty($rBlog->short_description) ? $rBlog->short_description : Str::limit(strip_tags($rBlog->description ?? ''), 100);
                            @endphp
                            <div class="blog-card-item">
                                <div class="blog-card-img-box">
                                    <img src="{{ $rImg }}" alt="{{ $rBlog->title ?? '' }}" loading="lazy">
                                </div>
                                <div class="blog-card-body">
                                    <div class="blog-meta-row">
                                        <span class="blog-date">{{ $rDate }}</span>
                                        <span class="blog-dot-sep">•</span>
                                        <span class="blog-read-time">{{ $rBlog->category ?? 'Article' }}</span>
                                    </div>
                                    <h3 class="blog-card-title">{{ $rBlog->title ?? '' }}</h3>
                                    <p class="blog-card-excerpt">{{ $rExcerpt }}</p>
                                    <a href="{{ url('/blog/' . $rSlug) }}" class="send-msg-btn blog-card-btn">READ ARTICLE</a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endif

        </div>
    </section>

    <!-- =========================================================
         LIGHT LUXURY CTA BANNER
    ========================================================= -->
    <section class="gallery-cta-section">
        <div class="gallery-cta-card">
            <span class="contact-eyebrow">EXCLUSIVE PRIVATE SITE VISITS</span>
            <h2 class="gallery-cta-title">Experience The Architecture <span>In Person</span></h2>
            <p class="gallery-cta-desc">
                Schedule an exclusive private site visit with our relationship team and experience the timber and glass suites firsthand.
            </p>
            <a href="{{ url('/contact') }}" class="send-msg-btn gallery-cta-btn">BOOK A PRIVATE VISIT</a>
        </div>
    </section>

    <!-- FOOTER & SCRIPTS -->
    @include('Website.includes.Footer')
    @include('Website.includes.JsLink')
