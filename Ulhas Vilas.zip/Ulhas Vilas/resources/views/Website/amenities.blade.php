@include('Website.includes.CssLink')

    <!-- =========================================================
         PAGE SPECIFIC CSS: AMENITIES & WELLNESS SANCTUARY
    ========================================================= -->
    <style>
    /* 1. HERO SECTION WITH VIDEO & DARK GRADIENT */
    .wellness-hero-section {
        position: relative;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #080A0C;
        padding: 13.5rem 2rem 7.5rem;
        overflow: hidden;
    }

    .wellness-hero-video-wrapper {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .wellness-hero-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 0.96;
        filter: brightness(0.95) contrast(1.08);
        transform: scale(1.03);
    }

    .wellness-hero-dark-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(180deg, rgba(8, 10, 12, 0.62) 0%, rgba(14, 18, 22, 0.42) 50%, rgba(8, 10, 12, 0.75) 100%);
        pointer-events: none;
        z-index: 2;
    }

    .wellness-hero-container {
        position: relative;
        z-index: 5;
        max-width: 1100px;
        width: 100%;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 2.75rem;
    }

    .wellness-hero-content {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        max-width: 820px;
        margin: 0 auto;
    }

    .wellness-eyebrow {
        display: inline-block;
        font-family: var(--font-body);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658;
        margin-bottom: 0.75rem;
        text-align: center;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
    }

    .wellness-hero-title {
        font-family: var(--font-heading);
        font-size: clamp(2.1rem, 4.2vw, 3.35rem) !important;
        line-height: 1.18;
        color: #FFFFFF;
        font-weight: 400;
        margin-bottom: 1.15rem;
        text-align: center;
        letter-spacing: -0.01em;
        text-shadow: 0 3px 20px rgba(0, 0, 0, 0.75);
    }

    .wellness-hero-title span {
        color: #DCB658;
        font-style: normal;
    }

    .wellness-hero-desc {
        font-family: var(--font-body);
        font-size: clamp(0.9rem, 1.2vw, 1.02rem);
        line-height: 1.72;
        color: rgba(255, 255, 255, 0.92);
        margin: 0 auto 2.25rem;
        max-width: 660px;
        text-align: center;
        text-shadow: 0 2px 12px rgba(0, 0, 0, 0.7);
    }

    .wellness-hero-btn-group {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1.15rem;
        flex-wrap: wrap;
    }

    .wellness-btn-primary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.65rem;
        background: #DCB658;
        color: #0E1114 !important;
        border: 1px solid #DCB658;
        border-radius: 32px;
        padding: 0.85rem 2rem;
        font-size: 0.82rem;
        font-family: var(--font-heading);
        letter-spacing: 0.1em;
        cursor: pointer;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 4px 20px rgba(220, 182, 88, 0.3);
        text-decoration: none;
    }

    .wellness-btn-primary:hover {
        background: #FFFFFF;
        color: #0E1114 !important;
        border-color: #FFFFFF;
        transform: translateY(-2px);
        box-shadow: 0 8px 26px rgba(255, 255, 255, 0.35);
    }

    .wellness-btn-secondary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        background: rgba(255, 255, 255, 0.06);
        color: #FFFFFF !important;
        border: 1px solid rgba(255, 255, 255, 0.28);
        border-radius: 32px;
        padding: 0.85rem 1.85rem;
        font-size: 0.82rem;
        font-family: var(--font-heading);
        letter-spacing: 0.08em;
        text-decoration: none;
        cursor: pointer;
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        transition: all 0.35s ease;
    }

    .wellness-btn-secondary:hover {
        border-color: #DCB658;
        color: #DCB658 !important;
        background: rgba(220, 182, 88, 0.12);
        transform: translateY(-2px);
    }

    .wellness-btn-secondary .btn-arrow {
        transition: transform 0.3s ease;
    }

    .wellness-btn-secondary:hover .btn-arrow {
        transform: translateX(4px);
    }

    /* Hero Stats / Number Cards Below Buttons (Subtle, Muted & Minimal Glass) */
    .wellness-hero-stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0.85rem;
        width: 100%;
        max-width: 620px;
        margin: 2.25rem auto 0;
    }

    .wellness-hero-stat-card {
        background: rgba(255, 255, 255, 0.04);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.11);
        border-radius: 12px;
        padding: 0.65rem 0.75rem 0.6rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18);
        transition: all 0.3s ease;
        position: relative;
    }

    .wellness-hero-stat-card:hover {
        transform: translateY(-2px);
        border-color: rgba(255, 255, 255, 0.22);
        background: rgba(255, 255, 255, 0.07);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
    }

    .stat-card-num {
        font-family: var(--font-heading);
        font-size: clamp(1.2rem, 1.8vw, 1.45rem);
        font-weight: 600;
        color: #EDE8DE;
        line-height: 1.05;
        margin-bottom: 0.2rem;
        letter-spacing: -0.01em;
        text-shadow: none;
    }

    .stat-card-title {
        font-family: var(--font-body);
        font-size: 0.62rem;
        font-weight: 500;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: rgba(255, 255, 255, 0.65);
        line-height: 1.2;
    }

    /* 2. EDITORIAL SECTION: PROXIMITY TO NATURE, ADVENTURE & WELLNESS */
    .nature-retreat-editorial-section {
        background: #FAF8F3;
        padding: 6.5rem 2rem;
        position: relative;
        overflow: hidden;
        border-top: 1px solid #EAE3D2;
        border-bottom: 1px solid #EAE3D2;
    }

    .nature-retreat-container {
        max-width: 1320px;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }

    .nature-retreat-grid {
        display: grid;
        grid-template-columns: 1.15fr 1fr;
        gap: 4.5rem;
        align-items: center;
    }

    /* Left Narrative Column */
    .nature-retreat-narrative {
        display: flex;
        flex-direction: column;
    }

    .nature-retreat-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.65rem;
        font-family: var(--font-body);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #7E5420;
        margin-bottom: 1rem;
    }

    .nature-retreat-eyebrow-line {
        width: 32px;
        height: 1.5px;
        background: #C89D48;
    }

    .nature-retreat-headline {
        font-family: var(--font-heading);
        font-size: clamp(2.1rem, 3.4vw, 2.9rem);
        line-height: 1.22;
        color: #161A1D;
        font-weight: 400;
        margin-bottom: 1.6rem;
        letter-spacing: -0.01em;
    }

    .nature-retreat-text-flow {
        display: flex;
        flex-direction: column;
        gap: 1.15rem;
        margin-bottom: 2.25rem;
    }

    .nature-retreat-p {
        font-family: var(--font-body);
        font-size: 1.02rem;
        line-height: 1.78;
        color: #4A5258;
        margin: 0;
    }

    .nature-retreat-p strong {
        color: #161A1D;
        font-weight: 600;
    }

    .nature-retreat-highlights-list {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
        padding-top: 1.75rem;
        border-top: 1px solid #E5DEC9;
    }

    .nature-retreat-highlight-item {
        display: flex;
        flex-direction: column;
        gap: 0.35rem;
    }

    .nature-retreat-highlight-title {
        font-family: var(--font-heading);
        font-size: 0.95rem;
        font-weight: 600;
        color: #7E5420;
        letter-spacing: 0.03em;
        display: flex;
        align-items: center;
        gap: 0.4rem;
    }

    .nature-retreat-highlight-sub {
        font-family: var(--font-body);
        font-size: 0.82rem;
        color: #6C757D;
        line-height: 1.45;
    }

    /* Right Architectural Staggered Mosaic Column (No Borders, No Pills) */
    .nature-retreat-visual-col {
        position: relative;
    }

    .nature-retreat-mosaic {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.25rem;
        align-items: center;
        position: relative;
    }

    .mosaic-col-left {
        display: flex;
        flex-direction: column;
    }

    .mosaic-col-right {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        transform: translateY(1.25rem);
    }

    .mosaic-card {
        position: relative;
        border-radius: 22px;
        overflow: hidden;
        background: #F0EDE5;
        border: none !important;
        box-shadow: 0 14px 34px rgba(22, 26, 30, 0.1), 0 2px 6px rgba(0, 0, 0, 0.04);
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .mosaic-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 22px 45px rgba(22, 26, 30, 0.16);
    }

    .mosaic-card-tall {
        height: 500px;
    }

    .mosaic-card-half {
        height: 238px;
    }

    .mosaic-card-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .mosaic-card:hover .mosaic-card-img {
        transform: scale(1.05);
    }

    @media (max-width: 1024px) {
        .nature-retreat-grid {
            grid-template-columns: 1fr;
            gap: 3.5rem;
        }
        .nature-retreat-mosaic {
            max-width: 620px;
            margin: 0 auto;
            width: 100%;
        }
        .mosaic-col-right {
            transform: translateY(0);
        }
    }

    @media (max-width: 768px) {
        .nature-retreat-editorial-section {
            padding: 4rem 1.25rem 3.5rem;
        }
        .nature-retreat-grid {
            gap: 2.5rem;
        }
        .nature-retreat-headline {
            font-size: clamp(1.75rem, 5.2vw, 2.15rem);
            line-height: 1.25;
            margin-bottom: 1.25rem;
        }
        .nature-retreat-p {
            font-size: 0.96rem;
            line-height: 1.7;
        }
        .nature-retreat-text-flow {
            gap: 1rem;
            margin-bottom: 1.75rem;
        }
        .nature-retreat-highlights-list {
            grid-template-columns: 1fr;
            gap: 1rem;
            padding-top: 1.35rem;
        }
    }

    @media (max-width: 640px) {
        .nature-retreat-editorial-section {
            padding: 3.25rem 1rem 3rem;
        }
        .nature-retreat-eyebrow {
            font-size: 0.72rem;
            letter-spacing: 0.16em;
            margin-bottom: 0.75rem;
        }
        .nature-retreat-headline {
            font-size: 1.65rem;
            line-height: 1.28;
            margin-bottom: 1.15rem;
        }
        .nature-retreat-mosaic {
            grid-template-columns: 1.1fr 1fr;
            gap: 0.65rem;
            width: 100%;
        }
        .mosaic-col-right {
            gap: 0.65rem;
        }
        .mosaic-card {
            border-radius: 16px;
        }
        .mosaic-card-tall {
            height: 270px;
        }
        .mosaic-card-half {
            height: 130px;
        }
    }

    @media (max-width: 420px) {
        .nature-retreat-headline {
            font-size: 1.48rem;
        }
        .nature-retreat-mosaic {
            gap: 0.5rem;
        }
        .mosaic-col-right {
            gap: 0.5rem;
        }
        .mosaic-card {
            border-radius: 14px;
        }
        .mosaic-card-tall {
            height: 230px;
        }
        .mosaic-card-half {
            height: 110px;
        }
    }

    /* 3. AMENITIES & WELLNESS SLIDER SECTION */
    .wellness-amenities-section {
        position: relative;
        background: #090B0D;
        padding: 4.25rem 2rem 3.75rem;
        overflow: hidden;
    }

    .wellness-amenities-video-wrapper {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .wellness-amenities-bg-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 0.95;
        filter: brightness(0.92) contrast(1.06);
        transform: scale(1.02);
    }

    .wellness-amenities-dark-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(180deg, rgba(10, 14, 18, 0.58) 0%, rgba(12, 16, 20, 0.38) 50%, rgba(10, 14, 18, 0.62) 100%);
        pointer-events: none;
        z-index: 2;
    }

    .wellness-amenities-container {
        position: relative;
        z-index: 5;
        max-width: 1380px;
        margin: 0 auto;
    }

    .amenities-center-header {
        text-align: center;
        max-width: 840px;
        margin: 0 auto 1.85rem;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .amenities-center-tagline {
        font-family: var(--font-body);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658;
        margin-bottom: 0.45rem;
        text-shadow: 0 2px 8px rgba(0, 0, 0, 0.6);
    }

    .amenities-center-title {
        font-family: var(--font-heading);
        font-size: clamp(1.85rem, 3.2vw, 2.6rem);
        line-height: 1.18;
        color: #FFFFFF;
        font-weight: 400;
        margin-bottom: 0.5rem;
        text-shadow: 0 2px 16px rgba(0, 0, 0, 0.65);
    }

    .amenities-center-divider {
        width: 44px;
        height: 2px;
        background: #DCB658;
        margin: 0 auto 0.95rem;
        border-radius: 2px;
        box-shadow: 0 0 10px rgba(220, 182, 88, 0.5);
    }

    .amenities-center-subtitle {
        font-family: var(--font-body);
        font-size: 0.92rem;
        line-height: 1.55;
        color: rgba(255, 255, 255, 0.95);
        max-width: 680px;
        text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
    }

    .amenities-slider-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        gap: 1.25rem;
        margin-top: 1rem;
    }

    .amenities-slider-track-container {
        overflow: hidden;
        width: 100%;
        position: relative;
        padding: 12px 4px 18px;
    }

    .amenities-slider-track {
        display: flex;
        gap: 24px;
        width: max-content;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        will-change: transform;
    }

    .amenity-slider-card {
        flex: 0 0 calc((100% - (3 * 24px)) / 4);
        background: #FFFFFF;
        border: 1px solid rgba(220, 182, 88, 0.32);
        border-radius: 20px;
        display: flex;
        flex-direction: column;
        transition: all 0.45s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 12px 30px -4px rgba(0, 0, 0, 0.2), 0 4px 12px rgba(0, 0, 0, 0.05);
        position: relative;
        cursor: pointer;
        overflow: hidden;
    }

    .amenity-slider-card:hover {
        transform: translateY(-6px);
        border-color: #DCB658;
        box-shadow: 0 20px 45px -6px rgba(0, 0, 0, 0.32), 0 0 20px rgba(220, 182, 88, 0.22);
    }

    .amenity-card-img-box {
        position: relative;
        width: 100%;
        height: 175px;
        overflow: hidden;
        background: #EAE6DF;
    }

    .amenity-card-img-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.85s cubic-bezier(0.16, 1, 0.3, 1);
        display: block;
    }

    .amenity-slider-card:hover .amenity-card-img-box img {
        transform: scale(1.08);
    }

    .amenity-card-img-gradient {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 50%;
        background: linear-gradient(180deg, transparent 0%, rgba(10, 14, 18, 0.55) 100%);
        pointer-events: none;
    }

    .amenity-pill-tag {
        position: absolute;
        top: 12px;
        left: 12px;
        background: rgba(14, 18, 22, 0.82);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(220, 182, 88, 0.65);
        color: #DCB658;
        font-family: var(--font-body);
        font-size: 0.62rem;
        font-weight: 800;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        padding: 0.28rem 0.68rem;
        border-radius: 20px;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        z-index: 3;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    .pill-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: #DCB658;
        box-shadow: 0 0 6px #DCB658;
    }

    .amenity-card-number {
        position: absolute;
        top: 12px;
        right: 12px;
        font-family: var(--font-heading);
        font-size: 0.72rem;
        font-weight: 700;
        color: #FFFFFF;
        background: rgba(10, 14, 18, 0.65);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        padding: 0.2rem 0.55rem;
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.25);
        z-index: 3;
        letter-spacing: 0.05em;
    }

    .amenity-card-body {
        padding: 1.15rem 1.25rem 1.15rem;
        position: relative;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        background: #FFFFFF;
    }

    .amenity-card-meta {
        margin-bottom: 0.25rem;
    }

    .amenity-category {
        font-family: var(--font-body);
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.16em;
        color: #9C782F;
        text-transform: uppercase;
        display: block;
    }

    .amenity-card-title {
        font-family: var(--font-heading);
        font-size: 1.15rem;
        font-weight: 600;
        color: #14171A;
        margin-bottom: 0.35rem;
        letter-spacing: 0.01em;
        line-height: 1.3;
    }

    .amenity-card-desc {
        font-family: var(--font-body);
        font-size: 0.82rem;
        line-height: 1.5;
        color: #586068;
        margin-bottom: 0.85rem;
        flex-grow: 1;
    }

    .amenity-card-footer {
        margin-top: auto;
        padding-top: 0.75rem;
        border-top: 1px solid #F2ECE1;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
    }

    .amenity-action-btn {
        width: 100%;
        padding: 0.65rem 1.1rem;
        background: linear-gradient(135deg, #14181C 0%, #222930 100%);
        border: 1px solid rgba(220, 182, 88, 0.45);
        border-radius: 26px;
        color: #FFFFFF;
        font-family: var(--font-heading);
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        cursor: pointer;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.14);
        position: relative;
        overflow: hidden;
    }

    .amenity-action-btn:hover {
        background: linear-gradient(135deg, #DCB658 0%, #F5CE6E 100%);
        color: #0E1215;
        border-color: #DCB658;
        transform: translateY(-2px);
        box-shadow: 0 8px 22px rgba(220, 182, 88, 0.45);
    }

    .amenity-arrow-btn {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: rgba(14, 18, 22, 0.85);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(220, 182, 88, 0.5);
        color: #FFFFFF;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        flex-shrink: 0;
        z-index: 10;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    }

    .amenities-arrow-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: scale(1.08);
        box-shadow: 0 8px 26px rgba(220, 182, 88, 0.45);
    }

    .amenities-dots-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.65rem;
        margin-top: 1.25rem;
    }

    .amenity-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.35);
        border: none;
        cursor: pointer;
        transition: all 0.35s ease;
        padding: 0;
    }

    .amenity-dot.active {
        width: 28px;
        border-radius: 10px;
        background: #DCB658;
        box-shadow: 0 2px 8px rgba(220, 182, 88, 0.45);
    }

    /* 4. WELLNESS RETREAT & STRATEGIC DESTINATION (VIDEO BACKGROUND & DARK GRADIENT) */
    .about-retreat-section {
        position: relative;
        min-height: 420px;
        background: #080A0C;
        padding: 3.8rem 1.75rem 4.2rem;
        overflow: hidden;
        display: flex;
        align-items: center;
        border-top: 1px solid rgba(220, 182, 88, 0.2);
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .about-retreat-video-wrapper {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
    }

    .about-retreat-bg-video {
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        object-fit: cover;
        opacity: 0.88;
        filter: brightness(0.92) contrast(1.12) saturate(1.15);
        transform: scale(1.02);
    }

    .about-retreat-dark-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, rgba(8, 16, 13, 0.72) 0%, rgba(6, 12, 10, 0.55) 50%, rgba(8, 16, 13, 0.88) 100%),
                    radial-gradient(circle at 50% 50%, rgba(0, 0, 0, 0.2) 0%, rgba(6, 12, 10, 0.8) 100%);
        z-index: 2;
        pointer-events: none;
    }

    .about-retreat-container {
        position: relative;
        z-index: 5;
        max-width: 1280px;
        width: 100%;
        margin: 0 auto;
        display: grid;
        grid-template-columns: 1.18fr 0.82fr;
        gap: 3.25rem;
        align-items: center;
    }

    .about-retreat-left {
        display: flex;
        flex-direction: column;
    }

    .about-retreat-eyebrow {
        font-family: var(--font-heading);
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #DCB658;
        display: inline-block;
        margin-bottom: 0.5rem;
        text-shadow: 0 2px 8px rgba(0,0,0,0.6);
    }

    .about-retreat-title {
        font-family: var(--font-heading), 'Marcellus', serif !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-size: 42px !important;
        text-transform: none;
        color: #FFFFFF;
        line-height: 1.25;
        margin: 0 0 1rem;
        letter-spacing: -0.01em;
        text-shadow: 0 2px 12px rgba(0,0,0,0.7);
    }

    .about-retreat-desc {
        font-size: 0.83rem;
        color: rgba(255, 255, 255, 0.78);
        line-height: 1.68;
        margin: 0 0 1.25rem;
        font-weight: 400;
    }

    .about-retreat-badges-wrap {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 0.45rem;
    }

    .about-retreat-badge-label {
        font-family: var(--font-heading);
        font-size: 0.64rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        color: #DCB658;
        margin-right: 0.2rem;
    }

    .about-retreat-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.22rem 0.65rem;
        border-radius: 9999px;
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(220, 182, 88, 0.25);
        color: rgba(255, 255, 255, 0.88);
        font-family: var(--font-heading);
        font-size: 0.64rem;
        font-weight: 600;
        letter-spacing: 0.03em;
        text-transform: uppercase;
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
    }

    /* Right Column: Advisors / Veterans Profile Cards */
    .about-retreat-right {
        display: flex;
        flex-direction: column;
        gap: 0.85rem;
    }

    .about-advisor-card {
        position: relative;
        background: linear-gradient(135deg, rgba(20, 32, 26, 0.72) 0%, rgba(8, 14, 12, 0.82) 100%);
        border: 1px solid rgba(220, 182, 88, 0.28);
        border-left: 3px solid #DCB658;
        border-radius: 12px;
        padding: 0.9rem 1.15rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.38), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    }

    .about-advisor-card:hover {
        transform: translateY(-2px);
        border-color: rgba(220, 182, 88, 0.6);
        border-left-color: #DCB658;
        background: linear-gradient(135deg, rgba(26, 42, 34, 0.85) 0%, rgba(12, 20, 17, 0.92) 100%);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.45), 0 0 18px rgba(220, 182, 88, 0.18);
    }

    .about-advisor-avatar-frame {
        width: 52px;
        height: 52px;
        border-radius: 50%;
        overflow: hidden;
        flex-shrink: 0;
        border: 1.5px solid #DCB658;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.5), 0 0 10px rgba(220, 182, 88, 0.22);
        background: #08110D;
    }

    .about-advisor-avatar-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.5s ease;
    }

    .about-advisor-card:hover .about-advisor-avatar-img {
        transform: scale(1.08);
    }

    .about-advisor-info {
        display: flex;
        flex-direction: column;
        min-width: 0;
    }

    .about-advisor-name {
        font-family: var(--font-heading);
        font-size: 0.98rem;
        font-weight: 700;
        color: #FFFFFF;
        margin: 0 0 0.15rem;
        letter-spacing: 0.02em;
    }

    .about-advisor-role {
        font-size: 0.74rem;
        color: #DCB658;
        font-weight: 600;
        margin: 0 0 0.2rem;
        line-height: 1.35;
    }

    .about-advisor-tag {
        font-size: 0.65rem;
        color: rgba(255, 255, 255, 0.62);
        letter-spacing: 0.02em;
    }

    @media (max-width: 991px) {
        .about-retreat-container {
            grid-template-columns: 1fr;
            gap: 2.2rem;
        }
        .about-retreat-title {
            font-size: 32px !important;
        }
    }

    /* 5. A SANCTUARY FOR MIND, BODY & SOUL */
    .wellness-sanctuary-section {
        background: #FAF8F5;
        padding: 6.25rem 2rem;
        border-top: 1px solid #ECE3D4;
        border-bottom: 1px solid #ECE3D4;
        position: relative;
    }

    .wellness-sanctuary-container {
        max-width: 1360px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: 1.15fr 1fr 1.1fr;
        gap: 3.75rem;
        align-items: center;
    }

    .sanctuary-col-left {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
    }

    .sanctuary-eyebrow-row {
        display: inline-flex;
        align-items: center;
        gap: 0.6rem;
        font-family: var(--font-body);
        font-size: 0.8rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #9C782F;
        margin-bottom: 1rem;
    }

    .sanctuary-main-title {
        font-family: var(--font-heading);
        font-size: clamp(1.85rem, 3.2vw, 2.6rem);
        line-height: 1.18;
        color: #12161A;
        font-weight: 400;
        margin-bottom: 1.25rem;
        letter-spacing: -0.015em;
    }

    .sanctuary-desc {
        font-family: var(--font-body);
        font-size: 0.96rem;
        line-height: 1.78;
        color: #555E67;
        margin-bottom: 2.15rem;
        max-width: 450px;
    }

    .sanctuary-checklist {
        list-style: none;
        display: flex;
        flex-direction: column;
        gap: 0.95rem;
        margin-bottom: 2.25rem;
        padding: 0;
    }

    .sanctuary-checklist li {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        font-family: var(--font-body);
        font-size: 0.82rem;
        font-weight: 500;
        color: #2D343C;
        line-height: 1.52;
    }

    .check-icon {
        width: 22px;
        height: 22px;
        border-radius: 50%;
        background: rgba(220, 182, 88, 0.14);
        border: 1.5px solid #DCB658;
        color: #A37E31;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        box-shadow: 0 2px 6px rgba(220, 182, 88, 0.2);
    }

    .check-icon svg {
        width: 11px;
        height: 11px;
    }

    .wellness-learn-more-btn {
        background: #FFFFFF;
        color: #14181C !important;
        border: 1.5px solid #14181C;
        border-radius: 32px;
        padding: 0.85rem 1.95rem;
        font-family: var(--font-heading);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.12em;
        cursor: pointer;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        display: inline-flex;
        align-items: center;
        gap: 0.65rem;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.05);
        position: relative;
    }

    .wellness-learn-more-btn:hover {
        background: #14181C;
        color: #FFFFFF !important;
        border-color: #14181C;
        transform: translateY(-3px);
        box-shadow: 0 10px 24px rgba(20, 24, 28, 0.2);
    }

    .sanctuary-center-img-box {
        border-radius: 28px;
        overflow: hidden;
        box-shadow: 0 24px 50px -10px rgba(18, 22, 26, 0.22), 0 8px 20px rgba(0, 0, 0, 0.06);
        border: 1px solid rgba(220, 182, 88, 0.38);
        height: 510px;
        background: #E8E2D5;
        position: relative;
        transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .sanctuary-center-img-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.9s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .sanctuary-center-img-box:hover {
        transform: translateY(-5px);
        box-shadow: 0 32px 65px -12px rgba(18, 22, 26, 0.28), 0 0 24px rgba(220, 182, 88, 0.22);
        border-color: #DCB658;
    }

    .sanctuary-col-right {
        display: flex;
        flex-direction: column;
    }

    .why-choose-title {
        font-family: var(--font-heading);
        font-size: 1.25rem;
        letter-spacing: 0.15em;
        color: #14181C;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 2.25rem;
    }

    .why-choose-list {
        display: flex;
        flex-direction: column;
        gap: 1.65rem;
    }

    .why-choose-item {
        display: flex;
        align-items: flex-start;
        gap: 1.25rem;
        padding: 0.5rem 0.65rem;
        border-radius: 14px;
        transition: all 0.35s ease;
    }

    .why-choose-item:hover {
        background: #FFFFFF;
        box-shadow: 0 8px 22px rgba(20, 24, 28, 0.05);
        transform: translateX(6px);
    }

    .why-icon-box {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #FAF5EA;
        border: 1.5px solid #E6DAC8;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #A37E31;
        flex-shrink: 0;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
    }

    .why-choose-item:hover .why-icon-box {
        background: #DCB658;
        color: #0E1215;
        border-color: #DCB658;
        transform: scale(1.08);
        box-shadow: 0 6px 18px rgba(220, 182, 88, 0.4);
    }

    .why-icon-box svg {
        width: 22px;
        height: 22px;
    }

    .why-text-box h4 {
        font-family: var(--font-heading);
        font-size: 1.08rem;
        color: #14181C;
        margin-bottom: 0.25rem;
        font-weight: 600;
        line-height: 1.3;
        transition: color 0.3s ease;
    }

    .why-choose-item:hover .why-text-box h4 {
        color: #9C782F;
    }

    .why-text-box p {
        font-family: var(--font-body);
        font-size: 0.85rem;
        line-height: 1.58;
        color: #5F6770;
    }

    /* 6. TESTIMONIALS SLIDER */
    .wellness-testimonials-section {
        background: #FFFFFF;
        padding: 4.5rem 2rem 4.75rem;
        border-top: 1px solid #EFE8DC;
        position: relative;
    }

    .wellness-testimonials-container {
        max-width: 1360px;
        margin: 0 auto;
    }

    .wellness-testimonials-header {
        text-align: center;
        max-width: 780px;
        margin: 0 auto 2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .testimonials-eyebrow-row {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        font-family: var(--font-body);
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: #9C782F;
        margin-bottom: 0.45rem;
    }

    .wellness-testimonials-header .wellness-section-title {
        font-family: var(--font-heading);
        font-size: clamp(1.85rem, 3.2vw, 2.6rem);
        line-height: 1.18;
        color: #12161A;
        font-weight: 400;
        letter-spacing: -0.015em;
        margin-bottom: 0.5rem;
    }

    .testimonials-center-divider {
        width: 44px;
        height: 2px;
        background: #DCB658;
        margin: 0 auto 0.85rem;
        border-radius: 2px;
        box-shadow: 0 0 10px rgba(220, 182, 88, 0.4);
    }

    .testimonials-subtitle {
        font-family: var(--font-body);
        font-size: 0.92rem;
        line-height: 1.6;
        color: #58616A;
        margin: 0 auto;
    }

    .testimonials-slider-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        gap: 1.25rem;
    }

    .testimonials-slider-track-container {
        overflow: hidden;
        width: 100%;
        position: relative;
        padding: 10px 4px 18px;
    }

    .testimonials-slider-track {
        display: flex;
        gap: 22px;
        width: max-content;
        transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        will-change: transform;
    }

    .wellness-review-card {
        flex: 0 0 calc((100% - (2 * 22px)) / 3);
        background: #FFFFFF;
        border-radius: 20px;
        padding: 1.45rem 1.6rem 1.4rem;
        border: 1px solid #ECE3D4;
        display: flex;
        flex-direction: column;
        text-align: left;
        box-shadow: 0 8px 24px -4px rgba(20, 24, 28, 0.05), 0 2px 8px rgba(0, 0, 0, 0.02);
        transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        position: relative;
    }

    .wellness-review-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 16px 36px -6px rgba(20, 24, 28, 0.1), 0 0 18px rgba(220, 182, 88, 0.18);
        border-color: #DCB658;
    }

    .review-card-header {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        margin-bottom: 0.75rem;
    }

    .review-avatar-box {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        overflow: hidden;
        border: 2px solid #FFFFFF;
        outline: 1.5px solid #DCB658;
        box-shadow: 0 4px 10px rgba(220, 182, 88, 0.25);
        flex-shrink: 0;
    }

    .review-avatar-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .review-header-info {
        flex-grow: 1;
    }

    .review-author-name {
        font-family: var(--font-heading);
        font-size: 0.98rem;
        font-weight: 700;
        color: #14181C;
        margin: 0 0 0.15rem 0;
        line-height: 1.25;
    }

    .review-author-location {
        font-family: var(--font-body);
        font-size: 0.72rem;
        font-weight: 600;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #9C782F;
        display: block;
    }

    .review-quote-badge {
        flex-shrink: 0;
        opacity: 0.85;
    }

    .review-stars-row {
        color: #DCB658;
        font-size: 0.95rem;
        letter-spacing: 0.12rem;
        margin-bottom: 0.65rem;
        line-height: 1;
    }

    .review-quote-text {
        font-family: var(--font-body);
        font-size: 0.86rem;
        line-height: 1.6;
        color: #505860;
        font-style: italic;
        margin: 0;
        flex-grow: 1;
    }

    .testimonials-arrow-btn {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: #FFFFFF;
        border: 1px solid #DFD7C8;
        color: #161A1D;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        flex-shrink: 0;
        z-index: 10;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
    }

    .testimonials-arrow-btn:hover {
        background: #DCB658;
        color: #0E1114;
        border-color: #DCB658;
        transform: scale(1.08);
        box-shadow: 0 6px 18px rgba(220, 182, 88, 0.4);
    }

    .testimonials-dots-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.65rem;
        margin-top: 1.25rem;
    }

    .testim-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        background: #D8CEBE;
        border: none;
        cursor: pointer;
        transition: all 0.35s ease;
        padding: 0;
    }

    .testim-dot.active {
        width: 26px;
        border-radius: 8px;
        background: #DCB658;
        box-shadow: 0 2px 8px rgba(220, 182, 88, 0.45);
    }

    /* 7. INTERACTIVE MODAL & FORM */
    .wellness-modal-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(10, 12, 14, 0.7);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        z-index: 100002;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
    }

    .wellness-modal-backdrop.active {
        opacity: 1;
        visibility: visible;
    }

    .wellness-booking-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -46%) scale(0.96);
        width: 90%;
        max-width: 640px;
        background: #FAF8F5;
        border: 1px solid #DCB658;
        border-radius: 24px;
        padding: 2.75rem 2.5rem;
        z-index: 100003;
        opacity: 0;
        visibility: hidden;
        transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: 0 24px 60px rgba(0, 0, 0, 0.35);
        max-height: 90vh;
        overflow-y: auto;
    }

    .wellness-booking-modal.active {
        opacity: 1;
        visibility: visible;
        transform: translate(-50%, -50%) scale(1);
    }

    .wellness-modal-close {
        position: absolute;
        top: 20px;
        right: 20px;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #EFE9DE;
        border: none;
        font-size: 1rem;
        color: #161A1D;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
    }

    .wellness-modal-close:hover {
        background: #161A1D;
        color: #FFFFFF;
    }

    .wellness-modal-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .modal-eyebrow {
        font-family: var(--font-body);
        font-size: 0.72rem;
        font-weight: 700;
        letter-spacing: 0.2em;
        color: #9C782F;
    }

    .modal-title {
        font-family: var(--font-heading);
        font-size: 2rem;
        color: #161A1D;
        margin: 0.35rem 0 0.5rem;
    }

    .modal-sub {
        font-family: var(--font-body);
        font-size: 0.88rem;
        color: #666E75;
    }

    .wellness-modal-form .form-row-two {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.25rem;
        margin-bottom: 1.15rem;
    }

    .wellness-modal-form .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 1.15rem;
    }

    .wellness-modal-form label {
        font-family: var(--font-body);
        font-size: 0.78rem;
        font-weight: 600;
        color: #383E44;
        margin-bottom: 0.4rem;
    }

    .wellness-modal-form input,
    .wellness-modal-form select,
    .wellness-modal-form textarea {
        font-family: var(--font-body);
        font-size: 0.88rem;
        padding: 0.75rem 1rem;
        border-radius: 12px;
        border: 1px solid #D9D2C4;
        background: #FFFFFF;
        color: #161A1D;
        outline: none;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    .wellness-modal-form input:focus,
    .wellness-modal-form select:focus,
    .wellness-modal-form textarea:focus {
        border-color: #DCB658;
        box-shadow: 0 0 0 3px rgba(220, 182, 88, 0.15);
    }

    .wellness-modal-submit-btn {
        width: 100%;
        background: #161A1D;
        color: #FFFFFF !important;
        border: 1px solid #161A1D;
        border-radius: 32px;
        padding: 1rem 2rem;
        font-family: var(--font-heading);
        font-size: 0.9rem;
        letter-spacing: 0.1em;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-top: 0.5rem;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    }

    .wellness-modal-submit-btn:hover {
        background: #DCB658;
        color: #161A1D !important;
        border-color: #DCB658;
    }

    .modal-secure-note {
        font-family: var(--font-body);
        font-size: 0.75rem;
        color: #7D858C;
        text-align: center;
        margin-top: 1rem;
    }

    .wellness-booking-success {
        text-align: center;
        padding: 2rem 1rem;
    }

    .success-icon-box {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: #FAF4E6;
        border: 2px solid #DCB658;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
    }

    .success-icon-box svg {
        width: 32px;
        height: 32px;
    }

    .wellness-booking-success h3 {
        font-family: var(--font-heading);
        font-size: 1.85rem;
        color: #161A1D;
        margin-bottom: 0.5rem;
    }

    .wellness-booking-success p {
        font-family: var(--font-body);
        font-size: 0.92rem;
        color: #5B6269;
        max-width: 440px;
        margin: 0 auto;
        line-height: 1.6;
    }

    /* RESPONSIVE MEDIA QUERIES FOR WELLNESS & AMENITIES PAGE */
    @media (max-width: 1200px) {
        .amenity-slider-card {
            flex: 0 0 calc((100% - (2 * 24px)) / 3);
        }
    }

    @media (max-width: 1024px) {
        .wellness-hero-section {
            padding: 8.5rem 1.75rem 4rem;
        }
        .wellness-hero-container {
            gap: 2.25rem;
        }
        .wellness-hero-stats-grid {
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-top: 2rem;
        }
        .wellness-features-container {
            grid-template-columns: repeat(3, 1fr);
            gap: 1.25rem;
        }
        .wellness-sanctuary-container {
            grid-template-columns: 1fr;
            gap: 3rem;
        }
        .sanctuary-col-left {
            align-items: center;
            text-align: center;
        }
        .sanctuary-desc {
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .sanctuary-checklist {
            align-items: flex-start;
            text-align: left;
            max-width: 540px;
            margin: 0 auto 2.25rem;
        }
        .sanctuary-center-img-box {
            max-width: 540px;
            height: 380px;
            margin: 0 auto;
            width: 100%;
        }
        .why-choose-title {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .why-choose-list {
            max-width: 580px;
            margin: 0 auto;
        }
        .wellness-promo-card {
            grid-template-columns: 1fr;
            text-align: center;
        }
        .wellness-promo-content {
            align-items: center;
            text-align: center;
            padding: 3rem 2rem 1.5rem;
            max-width: 100%;
        }
        .wellness-promo-desc {
            margin-left: auto;
            margin-right: auto;
        }
        .wellness-promo-btn-group {
            justify-content: center;
        }
        .wellness-promo-badge-box {
            padding: 1rem 2rem 3rem;
        }
        .wellness-review-card {
            flex: 0 0 calc((100% - 22px) / 2);
        }
    }

    @media (max-width: 900px) {
        .amenity-slider-card {
            flex: 0 0 calc((100% - 24px) / 2);
        }
        .amenities-center-title {
            font-size: 2.3rem;
        }
        .wellness-amenities-section {
            padding: 3.5rem 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .wellness-top-bar {
            display: none;
        }
        .wellness-hero-section {
            padding: 8.5rem 1.25rem 4.5rem;
            min-height: 80vh;
        }
        .wellness-hero-container {
            gap: 1.75rem;
        }
        .wellness-hero-desc {
            font-size: 0.9rem;
            margin-bottom: 1.75rem;
        }
        .wellness-hero-btn-group {
            gap: 0.85rem;
        }
        .wellness-btn-primary,
        .wellness-btn-secondary {
            padding: 0.75rem 1.4rem;
            font-size: 0.78rem;
        }
        .wellness-hero-stats-grid {
            grid-template-columns: repeat(4, 1fr);
            gap: 0.65rem;
            margin-top: 1.75rem;
        }
        .wellness-hero-stat-card {
            padding: 0.6rem 0.5rem 0.55rem;
            border-radius: 10px;
        }
        .stat-card-num {
            font-size: 1.25rem;
            font-weight: 600;
        }
        .stat-card-title {
            font-size: 0.6rem;
            font-weight: 500;
        }
        .wellness-features-bar-section {
            padding: 3.5rem 1.25rem;
        }
        .features-section-header {
            margin-bottom: 2.25rem;
        }
        .wellness-features-container {
            grid-template-columns: repeat(2, 1fr);
            gap: 1.15rem;
        }
        .wellness-feature-card,
        .wellness-feature-item {
            padding: 1.6rem 1rem 1.4rem;
            border-radius: 16px;
        }
        .wellness-feature-icon-wrapper {
            width: 56px;
            height: 56px;
            margin-bottom: 1rem;
        }
        .wellness-feature-icon-wrapper svg {
            width: 24px;
            height: 24px;
        }
        .wellness-sanctuary-section {
            padding: 3.5rem 1.25rem;
        }
        .sanctuary-center-img-box {
            height: 280px;
            border-radius: 18px;
        }
        .wellness-promo-section {
            padding: 2.5rem 1.25rem 3.5rem;
        }
        .wellness-promo-content {
            padding: 2.5rem 1.25rem 1.25rem;
        }
        .wellness-circular-badge {
            width: 120px;
            height: 120px;
        }
        .circ-large {
            font-size: 1.75rem;
        }
        .wellness-modal-form .form-row-two {
            grid-template-columns: 1fr;
            gap: 0;
        }
        .wellness-booking-modal {
            padding: 2rem 1.25rem;
            width: 94%;
            border-radius: 18px;
        }
        .modal-title {
            font-size: 1.55rem;
        }
        .wellness-modal-form input,
        .wellness-modal-form select,
        .wellness-modal-form textarea {
            font-size: 16px !important;
        }
        .wellness-review-card {
            flex: 0 0 100%;
        }
        .testimonials-arrow-btn {
            display: none;
        }
        .wellness-testimonials-section {
            padding: 3.5rem 1.25rem 3.75rem;
        }
    }

    @media (max-width: 600px) {
        .amenity-slider-card {
            flex: 0 0 100%;
        }
        .amenities-arrow-btn {
            display: none;
        }
        .amenities-center-title {
            font-size: 1.9rem;
        }
        .wellness-amenities-section {
            padding: 3rem 1.25rem;
        }
    }

    @media (max-width: 520px) {
        .wellness-hero-btn-group {
            flex-direction: column;
            width: 100%;
        }
        .wellness-btn-primary,
        .wellness-btn-secondary {
            width: 100%;
            text-align: center;
        }
        .wellness-hero-stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.65rem;
        }
        .wellness-hero-stat-card {
            padding: 0.75rem 0.6rem 0.7rem;
            border-radius: 12px;
        }
        .stat-card-num {
            font-size: 1.35rem;
            margin-bottom: 0.2rem;
        }
        .stat-card-title {
            font-size: 0.62rem;
        }
        .wellness-features-container {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        .wellness-feature-desc {
            max-width: 100%;
        }
        .wellness-promo-btn-group {
            flex-direction: column;
            width: 100%;
        }
        .wellness-brochure-btn,
        .wellness-promo-btn {
            width: 100%;
            justify-content: center;
        }
    }
    </style>

<body class="wellness-page-body">

    <!-- GLASS HEADER NAVIGATION (SAME AS HOME PAGE) -->
    @include('Website.includes.Header')

    <!-- =========================================================
         1. HERO SECTION (WITH AERIAL MOUNTAINSIDE BACKGROUND & DUAL VIDEO COLLAGE)
    ========================================================= -->
    <section class="wellness-hero-section">
        <!-- Background Ambient Luxury Estate Video -->
        <div class="wellness-hero-video-wrapper">
            <video class="wellness-hero-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="auto" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/WhatsApp Image 2026-08-21 at 1.28.44 PM.jpeg') }}">
                <source src="{{ asset('Website/assets/images/amenities.mp4') }}" type="video/mp4">
                Your browser does not support HTML5 video.
            </video>
            <div class="wellness-hero-dark-overlay"></div>
        </div>

        <div class="wellness-hero-container">
            <!-- Left Text Content -->
            <div class="wellness-hero-content">
                <span class="wellness-eyebrow">SIGNATURE MOUNTAIN RETREAT</span>
                <h1 class="wellness-hero-title">Curated Living &amp;<br><span>Wellness Sanctuaries</span></h1>
                
                <p class="wellness-hero-desc">
                    Experience the pinnacle of alpine luxury with expansive emerald lawns, 100% power backup, 24/7 concierge security, and serene lifestyle spaces crafted for holistic mountain well-being.
                </p>

                <div class="wellness-hero-btn-group">
                    <a href="#signature-services" class="wellness-btn-primary">
                        EXPLORE AMENITIES
                    </a>
                    <a href="{{ url('/residences') }}" class="wellness-btn-secondary">
                        VIEW RESIDENCES <span class="btn-arrow">→</span>
                    </a>
                </div>
                <!-- Hero Stats / Number Cards Below Buttons (Compact & Minimal) -->
                <div class="wellness-hero-stats-grid">
                    <div class="wellness-hero-stat-card">
                        <span class="stat-card-num stat-counter" data-count-to="8" data-suffix="+">0</span>
                        <span class="stat-card-title">Amenities</span>
                    </div>
                    <div class="wellness-hero-stat-card">
                        <span class="stat-card-num stat-counter" data-count-to="100" data-suffix="%">0</span>
                        <span class="stat-card-title">Power Backup</span>
                    </div>
                    <div class="wellness-hero-stat-card">
                        <span class="stat-card-num stat-counter" data-count-to="20" data-suffix="+">0</span>
                        <span class="stat-card-title">Years Excellence</span>
                    </div>
                    <div class="wellness-hero-stat-card">
                        <span class="stat-card-num stat-counter" data-count-to="24" data-suffix="/7">0</span>
                        <span class="stat-card-title">Security</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         2. EDITORIAL SECTION: PROXIMITY TO NATURE, ADVENTURE & WELLNESS
    ========================================================= -->
    <section class="nature-retreat-editorial-section" id="nature-wellness-proximity">
        <div class="nature-retreat-container">
            <div class="nature-retreat-grid">
                
                <!-- Left Narrative Column -->
                <div class="nature-retreat-narrative">
                    <div class="nature-retreat-eyebrow">
                        <span class="nature-retreat-eyebrow-line"></span>
                        <span>EXQUISITE MOUNTAIN PROXIMITY &amp; WELLNESS</span>
                    </div>

                    <h2 class="nature-retreat-headline">
                        Achieve proximity to nature, adventure and a premium wellness retreat!
                    </h2>

                    <div class="nature-retreat-text-flow">
                        <p class="nature-retreat-p">
                            The location is poised to become a hub for world-class developments, featuring prestigious properties like <strong>Oberoi's</strong>, <strong>ITC</strong>, <strong>Radisson</strong>, and <strong>JW Marriott</strong>. Ulhas Vilas offers a unique mountain lifestyle amidst the serene Himalayan peaks.
                        </p>
                        <p class="nature-retreat-p">
                            Adjacent to this, <strong>Ayurvyaas</strong> stands as an oasis of holistic wellness, offering rejuvenating therapies and immersive experiences in harmony with nature.
                        </p>
                        <p class="nature-retreat-p">
                            Nearby destinations like <strong>Shimla</strong>, <strong>Kufri</strong> and <strong>Naldehra</strong> promise endless adventures, enhancing the allure of Ulhas Vilas. Embrace a life of tranquility and natural beauty, harmonized with wellness and adventure, all set against the mesmerizing backdrop of the Himalayas.
                        </p>
                    </div>

                    <!-- 3 Feature Takeaways (Non-card, inline editorial style) -->
                    <div class="nature-retreat-highlights-list">
                        <div class="nature-retreat-highlight-item">
                            <span class="nature-retreat-highlight-title">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
                                Luxury Hub
                            </span>
                            <span class="nature-retreat-highlight-sub">Oberoi's, ITC, Radisson &amp; JW Marriott</span>
                        </div>
                        <div class="nature-retreat-highlight-item">
                            <span class="nature-retreat-highlight-title">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
                                Ayurvyaas Oasis
                            </span>
                            <span class="nature-retreat-highlight-sub">Holistic therapies &amp; immersive rejuvenation</span>
                        </div>
                        <div class="nature-retreat-highlight-item">
                            <span class="nature-retreat-highlight-title">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
                                Alpine Expeditions
                            </span>
                            <span class="nature-retreat-highlight-sub">Shimla, Kufri &amp; Naldehra ridges</span>
                        </div>
                    </div>
                </div>

                <!-- Right Architectural Staggered Mosaic Column -->
                <div class="nature-retreat-visual-col">
                    <div class="nature-retreat-mosaic">
                        
                        <!-- Left Column: 1 Tall Portrait Image (amen-3) -->
                        <div class="mosaic-col mosaic-col-left">
                            <div class="mosaic-card mosaic-card-tall">
                                <img src="{{ asset('Website/assets/images/amen-3.jpg') }}" alt="Ulhas Vilas Luxury Mountain Estate" class="mosaic-card-img" loading="lazy">
                            </div>
                        </div>

                        <!-- Right Column: 2 Stacked Images (amen-1 and amen-2) -->
                        <div class="mosaic-col mosaic-col-right">
                            
                            <!-- Top: Ayurvyaas Holistic Wellness Sanctuary (amen-1) -->
                            <div class="mosaic-card mosaic-card-half">
                                <img src="{{ asset('Website/assets/images/amen-1.jpg') }}" alt="Ayurvyaas Holistic Wellness" class="mosaic-card-img" loading="lazy">
                            </div>

                            <!-- Bottom: Alpine Mountain Adventures (amen-2) -->
                            <div class="mosaic-card mosaic-card-half">
                                <img src="{{ asset('Website/assets/images/amen-2.jpg') }}" alt="Himalayan Alpine Adventures" class="mosaic-card-img" loading="lazy">
                            </div>

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- =========================================================
         3. AMENITIES & WELLNESS SLIDER SECTION (VIDEO BACKGROUND + 4 CARDS AT A TIME)
    ========================================================= -->
    <section class="wellness-amenities-section" id="signature-services">
        <!-- Background Ambient Video Player -->
        <div class="wellness-amenities-video-wrapper">
            <video class="wellness-amenities-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/amenities4.jpeg') }}">
                <!--<source src="{{ asset('Website/assets/images/townhouse.mp4') }}" type="video/mp4">-->
                Your browser does not support HTML5 video.
            </video>
            <div class="wellness-amenities-dark-overlay"></div>
        </div>

        <div class="wellness-amenities-container">
            
            <!-- Centered Header matching Image 2 -->
            <div class="amenities-center-header">
                <span class="amenities-center-tagline">HOLISTIC LIVING &amp; REFRESHMENT</span>
                <h2 class="amenities-center-title">Ayurvyaas Amenities
</h2>
                <div class="amenities-center-divider"></div>
                <p class="amenities-center-subtitle">
                    Immerse yourself in our curated sanctuaries of peace, movement, and rejuvenation designed to restore balance and vitality.
                </p>
            </div>

            <!-- 4-Cards-at-a-Time Slider Carousel -->
            <div class="amenities-slider-wrapper">
                <button type="button" class="amenities-arrow-btn prev-arrow" id="amenityPrevBtn" aria-label="Previous Amenities">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                </button>

                <div class="amenities-slider-track-container" id="amenitiesTrackContainer">
                    <div class="amenities-slider-track" id="amenitiesSliderTrack">
                        
                        <!-- 01. Ayurvedic Restaurant -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/ayurvedic-rest.jpg') }}" alt="Ayurvedic Restaurant" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Ayurvedic Restaurant</h3>
                                <p class="amenity-card-desc">Authentic Ayurvedic gastronomy, organic farm-to-table dining, and holistic nutritious cuisine.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 02. International Restaurant -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/international-rest.jpg') }}" alt="International Restaurant" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">International Restaurant</h3>
                                <p class="amenity-card-desc">Fine dining gourmet restaurant offering curated multi-cuisine delicacies and mountain views.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 03. Multipurpose Hall -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/hall.jpg') }}" alt="Multipurpose Hall" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Multipurpose Hall</h3>
                                <p class="amenity-card-desc">Grand versatile event pavilion for private celebrations, corporate retreats, and banquets.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 04. Yoga Room -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/yoga-room.jpg') }}" alt="Yoga Room" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Yoga Room</h3>
                                <p class="amenity-card-desc">Dedicated pine-facing sanctuary designed for pranayama, mindful movement, and yoga.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 05. Bar -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/bar.jpg') }}" alt="Bar" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Bar</h3>
                                <p class="amenity-card-desc">Refined mountain lounge bar serving signature cocktails, fine wines, and artisanal spirits.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 06. Indoor Swimming Pool -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/Swimming-pool.jpg') }}" alt="Indoor Swimming Pool" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Indoor Swimming Pool</h3>
                                <p class="amenity-card-desc">Temperature-controlled all-season indoor heated pool with panoramic mountain skylights.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 07. Spa Suites -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/Spa-Suites.jpg') }}" alt="Spa Suites" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Spa Suites</h3>
                                <p class="amenity-card-desc">Private luxury therapy suites featuring traditional Ayurvedic treatments, massages, and sauna.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- 08. Meditation Hall -->
                        <div class="amenity-slider-card" onclick="window.location.href='{{ url('/contact') }}'" style="cursor: pointer;">
                            <div class="amenity-card-img-box">
                                <img src="{{ asset('Website/assets/images/meditation-hall.jpg') }}" alt="Meditation Hall" loading="lazy">
                                <div class="amenity-card-img-gradient"></div>
                            </div>
                            <div class="amenity-card-body">
                                <h3 class="amenity-card-title">Meditation Hall</h3>
                                <p class="amenity-card-desc">Tranquil sanctuary of absolute silence and calm for deep meditation and inner peace.</p>
                                <div class="amenity-card-footer">
                                    <a href="{{ url('/contact') }}" class="amenity-action-btn" style="text-decoration: none;">
                                        <span>Explore Details</span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <button type="button" class="amenities-arrow-btn next-arrow" id="amenityNextBtn" aria-label="Next Amenities">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
                </button>
            </div>

            <!-- Dots Indicator Row -->
            <div class="amenities-dots-row" id="amenityDotsRow"></div>

        </div>
    </section>

    <!-- =========================================================
         4. A SANCTUARY FOR MIND, BODY & SOUL (3-COLUMNS MATCHING IMAGE)
    ========================================================= -->
    <section class="wellness-sanctuary-section">
        <div class="wellness-sanctuary-container">
            
            <!-- Column 1: Left Editorial & Bullets -->
            <div class="sanctuary-col-left">
                <div class="sanctuary-eyebrow-row">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#DCB658" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2C10 6 6 10 2 12C6 14 10 18 12 22C14 18 18 14 22 12C18 10 14 6 12 2Z"/>
                        <circle cx="12" cy="12" r="2.5" fill="#DCB658"/>
                    </svg>
                    <span>ABOUT ULHAS VILAS SANCTUARY</span>
                </div>
                <h2 class="sanctuary-main-title">A Sanctuary for<br>Mind, Body &amp; Soul</h2>
                <p class="sanctuary-desc">
                    At The Ulhas Vilas Wellness Haven, we blend time-honored Himalayan healing traditions with modern restorative therapies to offer a truly transformative rejuvenation journey.
                </p>

                <ul class="sanctuary-checklist">
                    <li>
                        <div class="check-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <span>Personalized treatments for your unique lifestyle &amp; wellness needs</span>
                    </li>
                    <li>
                        <div class="check-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <span>Tranquil alpine ambiance for deep meditation and sound sleep</span>
                    </li>
                    <li>
                        <div class="check-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <span>Committed to your absolute well-being, serenity &amp; vitality</span>
                    </li>
                </ul>

                <a href="{{ url('/about') }}" class="wellness-learn-more-btn" style="text-decoration:none;display:inline-flex;align-items:center;gap:0.65rem;">
                    <span>LEARN MORE ABOUT US</span>
                    <svg class="btn-arrow-svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
            </div>

            <!-- Column 2: Center Focal Image -->
            <div class="sanctuary-col-center">
                <div class="sanctuary-center-img-box">
                    <img src="{{ asset('Website/assets/images/amenities2.jpeg') }}" alt="Ulhas Vilas Spa Treatment Sanctuary" loading="lazy">
                </div>
            </div>

            <!-- Column 3: Right "Why Choose Us" Stack -->
            <div class="sanctuary-col-right">
                <h3 class="why-choose-title">WHY CHOOSE US</h3>
                
                <div class="why-choose-list">
                    
                    <!-- Item 1 -->
                    <div class="why-choose-item">
                        <div class="why-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="8" r="5"/>
                                <path d="M20 21a8 8 0 1 0-16 0"/>
                            </svg>
                        </div>
                        <div class="why-text-box">
                            <h4>Premium Quality Service</h4>
                            <p>Exceptional care with meticulous attention to every personal preference.</p>
                        </div>
                    </div>

                    <!-- Item 2 -->
                    <div class="why-choose-item">
                        <div class="why-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"/>
                                <polyline points="12 6 12 12 16 14"/>
                            </svg>
                        </div>
                        <div class="why-text-box">
                            <h4>Customized Experience</h4>
                            <p>Tailored treatments, steam duration &amp; aromatherapy oils for you.</p>
                        </div>
                    </div>

                    <!-- Item 3 -->
                    <div class="why-choose-item">
                        <div class="why-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2"/>
                                <path d="M3 9h18M9 21V9"/>
                            </svg>
                        </div>
                        <div class="why-text-box">
                            <h4>Luxurious Facilities</h4>
                            <p>Modern temperature-controlled hydro-pools, sauna &amp; zen deck.</p>
                        </div>
                    </div>

                    <!-- Item 4 -->
                    <div class="why-choose-item">
                        <div class="why-icon-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                <circle cx="9" cy="7" r="4"/>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
                            </svg>
                        </div>
                        <div class="why-text-box">
                            <h4>Trusted by Hundreds</h4>
                            <p>Cherished by discerning estate residents &amp; elite retreat patrons.</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>

    <!-- =========================================================
         5. WELLNESS RETREAT & STRATEGIC DESTINATION (VIDEO & DARK GRADIENT)
    ========================================================= -->
    <section class="about-retreat-section">
        <!-- Background Video & Dark Gradient -->
        <div class="about-retreat-video-wrapper">
            <video class="about-retreat-bg-video" autoplay loop muted playsinline webkit-playsinline x5-playsinline preload="metadata" disablepictureinpicture disableremoteplayback poster="{{ asset('Website/assets/images/WhatsApp Image 2026-08-22 at 4.05.04 PM.jpeg') }}">
                <source src="{{ asset('Website/assets/images/0_Coastal_Green_1920x1080.mp4') }}" type="video/mp4">
                <source src="{{ asset('Website/assets/images/2333673_Aerial_Mountainside_1920x1080.mp4') }}" type="video/mp4">
            </video>
            <div class="about-retreat-dark-overlay"></div>
        </div>

        <div class="about-retreat-container">
            <!-- Left: Headline, Strategic Location & Ayurvyaas Story -->
            <div class="about-retreat-left">
                <span class="about-retreat-eyebrow">STRATEGIC DESTINATION &amp; WELLNESS RETREAT</span>
                <h2 class="about-retreat-title">
                    World-Class Luxury Amidst Nature, Adventure And A Premium Wellness Retreat
                </h2>
                <p class="about-retreat-desc">
                    Indulge in mountain luxury at our prestigious location, surrounded by renowned properties such as Oberoi, ITC, Radisson and JW Marriott. Nearby destinations like Shimla, Kufri and Naldehra, offer a blend of urban conveniences and rich cultural experiences, enhancing the allure of Ulhas Vilas. Adjacent to Ulhas Vilas lies Ayurvyaas—a sanctuary of holistic wellness, currently under construction and soon to be a heaven. Brought to you by a team associated with Ananda Homes in the Himalayas, featuring industry veterans Nikhil Kapur and Colin Gary Hall, who are renowned for their expertise in managing luxury wellness properties.
                </p>

                <!-- Strategic Neighbor Badges -->
                <div class="about-retreat-badges-wrap">
                    <span class="about-retreat-badge-label">Distinguished Environs:</span>
                    <span class="about-retreat-badge">Oberoi</span>
                    <span class="about-retreat-badge">ITC Hotels</span>
                    <span class="about-retreat-badge">Radisson</span>
                    <span class="about-retreat-badge">JW Marriott</span>
                    <span class="about-retreat-badge">Ananda in the Himalayas</span>
                </div>
            </div>

            <!-- Right: Industry Veterans & Advisory Profiles -->
            <div class="about-retreat-right">
                <!-- Nikhil Kapur -->
                <div class="about-advisor-card">
                    <div class="about-advisor-avatar-frame">
                        <img src="{{ asset('Website/assets/images/nikhil_kapur.jpg') }}" alt="Nikhil Kapur" class="about-advisor-avatar-img" onerror="this.onerror=null; this.src='{{ asset('Website/assets/images/client_2.jpg') }}';">
                    </div>
                    <div class="about-advisor-info">
                        <h3 class="about-advisor-name">Nikhil Kapur</h3>
                        <p class="about-advisor-role">The Founder of Transformative Wellness</p>
                        <span class="about-advisor-tag">Industry Veteran • Wellness Leadership</span>
                    </div>
                </div>

                <!-- Colin Gary Hall -->
                <div class="about-advisor-card">
                    <div class="about-advisor-avatar-frame">
                        <img src="{{ asset('Website/assets/images/colin_gary_hall.jpg') }}" alt="Colin Gary Hall" class="about-advisor-avatar-img" onerror="this.onerror=null; this.src='{{ asset('Website/assets/images/client_3.jpg') }}';">
                    </div>
                    <div class="about-advisor-info">
                        <h3 class="about-advisor-name">Colin Gary Hall</h3>
                        <p class="about-advisor-role">Spa and Well-being Advisory at Spa Wallah</p>
                        <span class="about-advisor-tag">Global Spa Advisory • Ananda Associated</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- =========================================================
         6. WHAT OUR GUESTS SAY (COMPACT TESTIMONIALS SLIDER)
    ========================================================= -->
    <section class="wellness-testimonials-section">
        <div class="wellness-testimonials-container">
            
            <!-- Section Centered Header -->
            <div class="wellness-testimonials-header">
                <div class="testimonials-eyebrow-row">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#DCB658" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2C10 6 6 10 2 12C6 14 10 18 12 22C14 18 18 14 22 12C18 10 14 6 12 2Z"/>
                        <circle cx="12" cy="12" r="2.5" fill="#DCB658"/>
                    </svg>
                    <span>GUEST &amp; RESIDENT VOICES</span>
                </div>
                <h2 class="wellness-section-title">What Our Clients Say</h2>
                <div class="testimonials-center-divider"></div>
                <p class="testimonials-subtitle">
                    Reflections of serenity, transformative wellness journeys, and elevated mountain living at The Ulhas Vilas.
                </p>
            </div>

            <!-- Testimonials Slider Wrapper -->
            <div class="testimonials-slider-wrapper">
                <button type="button" class="testimonials-arrow-btn prev-arrow" id="testimPrevBtn" aria-label="Previous Reviews">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
                </button>

                <div class="testimonials-slider-track-container" id="testimTrackContainer">
                    <div class="testimonials-slider-track" id="testimSliderTrack">
                        
                        @if(isset($reviews) && count($reviews) > 0)
                            @foreach($reviews as $index => $review)
                                @php
                                    $imgSrc = '';
                                    if (!empty($review->image)) {
                                        $cleanImg = ltrim($review->image, '/');
                                        if (file_exists(public_path($cleanImg))) {
                                            $imgSrc = asset($cleanImg);
                                        } elseif (str_starts_with($review->image, 'http')) {
                                            $imgSrc = $review->image;
                                        } elseif (file_exists(public_path('storage/Admin/review/' . basename($review->image)))) {
                                            $imgSrc = asset('storage/Admin/review/' . basename($review->image));
                                        }
                                    }
                                    if (empty($imgSrc)) {
                                        $fallbackNum = ($index % 5) + 1;
                                        $imgSrc = asset('Website/assets/images/client_' . $fallbackNum . '.jpg');
                                    }
                                @endphp
                                <div class="wellness-review-card">
                                    <div class="review-card-header">
                                        <div class="review-avatar-box">
                                            <img src="{{ $imgSrc }}" alt="{{ $review->name }}" loading="lazy">
                                        </div>
                                        <div class="review-header-info">
                                            <h4 class="review-author-name">{{ $review->name }}</h4>
                                            <span class="review-author-location">{{ $review->designation ?: ($review->city ?: 'Resident & Patron') }}</span>
                                        </div>
                                        <div class="review-quote-badge">
                                            <svg width="18" height="18" viewBox="0 0 24 24" fill="#DCB658"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/></svg>
                                        </div>
                                    </div>
                                    <p class="review-quote-text">
                                        "{{ $review->feedback }}"
                                    </p>
                                </div>
                            @endforeach
                        @else
                            <!-- Default Fallback Reviews -->
                            <div class="wellness-review-card">
                                <div class="review-card-header">
                                    <div class="review-avatar-box">
                                        <img src="{{ asset('Website/assets/images/client_1.jpg') }}" alt="Jessica Malhotra" loading="lazy">
                                    </div>
                                    <div class="review-header-info">
                                        <h4 class="review-author-name">Jessica Malhotra</h4>
                                        <span class="review-author-location">New Delhi • Villa Resident</span>
                                    </div>
                                    <div class="review-quote-badge">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="#DCB658"><path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/></svg>
                                    </div>
                                </div>
                                <p class="review-quote-text">
                                    "The spa therapies and heated pools are world-class. Waking up to pristine Himalayan valley views every morning is pure magic."
                                </p>
                            </div>
                        @endif

                    </div>
                </div>

                <button type="button" class="testimonials-arrow-btn next-arrow" id="testimNextBtn" aria-label="Next Reviews">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
                </button>
            </div>

            <!-- Dots Indicator Row -->
            <div class="testimonials-dots-row" id="testimDotsRow"></div>

        </div>
    </section>

    <!-- MODAL & CAROUSEL SCRIPT -->
    <script>
        // --- 4-CARDS-AT-A-TIME AMENITIES SLIDER ---
        (function() {
            var track = document.getElementById('amenitiesSliderTrack');
            var container = document.getElementById('amenitiesTrackContainer');
            var prevBtn = document.getElementById('amenityPrevBtn');
            var nextBtn = document.getElementById('amenityNextBtn');
            var dotsRow = document.getElementById('amenityDotsRow');
            if (!track || !container) return;

            var cards = track.querySelectorAll('.amenity-slider-card');
            var totalCards = cards.length;
            var currentIndex = 0;
            var autoPlayTimer = null;
            var gap = 24;

            function getVisibleCards() {
                var width = window.innerWidth;
                if (width > 1200) return 4;
                if (width > 900) return 3;
                if (width > 600) return 2;
                return 1;
            }

            function getMaxIndex() {
                var visible = getVisibleCards();
                return Math.max(0, totalCards - visible);
            }

            function setCardDimensions() {
                var containerWidth = container.clientWidth;
                var visible = getVisibleCards();
                var totalGaps = (visible - 1) * gap;
                var cardWidth = (containerWidth - totalGaps) / visible;
                for (var i = 0; i < cards.length; i++) {
                    cards[i].style.width = cardWidth + 'px';
                    cards[i].style.minWidth = cardWidth + 'px';
                    cards[i].style.maxWidth = cardWidth + 'px';
                    cards[i].style.flex = '0 0 ' + cardWidth + 'px';
                }
                return cardWidth;
            }

            function renderDots() {
                if (!dotsRow) return;
                dotsRow.innerHTML = '';
                var maxIdx = getMaxIndex();
                var numDots = maxIdx + 1;
                for (var i = 0; i < numDots; i++) {
                    (function(idx) {
                        var dot = document.createElement('button');
                        dot.type = 'button';
                        dot.className = 'amenity-dot' + (idx === currentIndex ? ' active' : '');
                        dot.setAttribute('aria-label', 'Go to slide ' + (idx + 1));
                        dot.addEventListener('click', function(e) {
                            e.stopPropagation();
                            goToSlide(idx);
                        });
                        dotsRow.appendChild(dot);
                    })(i);
                }
            }

            function updateSlider() {
                var maxIdx = getMaxIndex();
                if (currentIndex > maxIdx) currentIndex = 0;
                if (currentIndex < 0) currentIndex = maxIdx;

                var cardWidth = setCardDimensions();
                var offset = currentIndex * (cardWidth + gap);
                track.style.transform = 'translateX(-' + offset + 'px)';

                // Update dots
                if (dotsRow) {
                    var dots = dotsRow.querySelectorAll('.amenity-dot');
                    dots.forEach(function(dot, idx) {
                        if (idx === currentIndex) {
                            dot.classList.add('active');
                        } else {
                            dot.classList.remove('active');
                        }
                    });
                }
            }

            function goToSlide(index) {
                var maxIdx = getMaxIndex();
                if (index > maxIdx) {
                    currentIndex = 0;
                } else if (index < 0) {
                    currentIndex = maxIdx;
                } else {
                    currentIndex = index;
                }
                updateSlider();
                startAutoplay();
            }

            function nextSlide() {
                var maxIdx = getMaxIndex();
                if (currentIndex >= maxIdx) {
                    currentIndex = 0; // Wrap around to start in loop
                } else {
                    currentIndex++;
                }
                updateSlider();
            }

            function prevSlide() {
                var maxIdx = getMaxIndex();
                if (currentIndex <= 0) {
                    currentIndex = maxIdx; // Wrap around to end in loop
                } else {
                    currentIndex--;
                }
                updateSlider();
            }

            if (prevBtn) {
                prevBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    prevSlide();
                    startAutoplay();
                });
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    nextSlide();
                    startAutoplay();
                });
            }

            // Auto-advance every 4.5 seconds in a continuous loop
            function startAutoplay() {
                stopAutoplay();
                autoPlayTimer = setInterval(nextSlide, 4500);
            }

            function stopAutoplay() {
                if (autoPlayTimer) clearInterval(autoPlayTimer);
            }

            container.addEventListener('mouseenter', stopAutoplay);
            container.addEventListener('mouseleave', startAutoplay);

            // Touch support
            var startX = 0;
            container.addEventListener('touchstart', function(e) {
                startX = e.touches[0].clientX;
                stopAutoplay();
            }, { passive: true });

            container.addEventListener('touchend', function(e) {
                var endX = e.changedTouches[0].clientX;
                if (startX - endX > 40) {
                    nextSlide();
                } else if (endX - startX > 40) {
                    prevSlide();
                }
                startAutoplay();
            }, { passive: true });

            window.addEventListener('resize', function() {
                setCardDimensions();
                renderDots();
                updateSlider();
            });

            setTimeout(function() {
                setCardDimensions();
                renderDots();
                updateSlider();
                startAutoplay();
            }, 50);
        })();

        // --- TESTIMONIALS SLIDER CONTROLLER ---
        (function initTestimonialsSlider() {
            var track = document.getElementById('testimSliderTrack');
            var container = document.getElementById('testimTrackContainer');
            var prevBtn = document.getElementById('testimPrevBtn');
            var nextBtn = document.getElementById('testimNextBtn');
            var dotsRow = document.getElementById('testimDotsRow');

            if (!track || !container) return;

            var cards = track.querySelectorAll('.wellness-review-card');
            var totalCards = cards.length;
            var currentIndex = 0;
            var autoPlayTimer = null;

            function getVisibleCount() {
                var w = window.innerWidth;
                if (w <= 680) return 1;
                if (w <= 1024) return 2;
                return 3;
            }

            function setCardDimensions() {
                var visibleCount = getVisibleCount();
                var gap = 22;
                var containerWidth = container.clientWidth;
                if (containerWidth <= 0) return;
                var cardWidth = (containerWidth - ((visibleCount - 1) * gap)) / visibleCount;
                cards.forEach(function(card) {
                    card.style.width = cardWidth + 'px';
                    card.style.flex = '0 0 ' + cardWidth + 'px';
                });
            }

            function maxIndex() {
                var visibleCount = getVisibleCount();
                return Math.max(0, totalCards - visibleCount);
            }

            function updateSlider() {
                var visibleCount = getVisibleCount();
                var gap = 22;
                var containerWidth = container.clientWidth;
                var cardWidth = (containerWidth - ((visibleCount - 1) * gap)) / visibleCount;
                var offset = currentIndex * (cardWidth + gap);
                track.style.transform = 'translateX(-' + offset + 'px)';

                var dots = dotsRow ? dotsRow.querySelectorAll('.testim-dot') : [];
                dots.forEach(function(dot, idx) {
                    if (idx === currentIndex) {
                        dot.classList.add('active');
                    } else {
                        dot.classList.remove('active');
                    }
                });
            }

            function renderDots() {
                if (!dotsRow) return;
                dotsRow.innerHTML = '';
                var count = maxIndex() + 1;
                for (var i = 0; i < count; i++) {
                    (function(idx) {
                        var dot = document.createElement('button');
                        dot.className = 'testim-dot' + (idx === currentIndex ? ' active' : '');
                        dot.setAttribute('type', 'button');
                        dot.setAttribute('aria-label', 'Go to review slide ' + (idx + 1));
                        dot.addEventListener('click', function() {
                            currentIndex = idx;
                            updateSlider();
                            startAutoplay();
                        });
                        dotsRow.appendChild(dot);
                    })(i);
                }
            }

            function nextSlide() {
                if (currentIndex >= maxIndex()) {
                    currentIndex = 0;
                } else {
                    currentIndex++;
                }
                updateSlider();
            }

            function prevSlide() {
                if (currentIndex <= 0) {
                    currentIndex = maxIndex();
                } else {
                    currentIndex--;
                }
                updateSlider();
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', function() {
                    nextSlide();
                    startAutoplay();
                });
            }

            if (prevBtn) {
                prevBtn.addEventListener('click', function() {
                    prevSlide();
                    startAutoplay();
                });
            }

            function startAutoplay() {
                stopAutoplay();
                autoPlayTimer = setInterval(nextSlide, 5000);
            }

            function stopAutoplay() {
                if (autoPlayTimer) clearInterval(autoPlayTimer);
            }

            container.addEventListener('mouseenter', stopAutoplay);
            container.addEventListener('mouseleave', startAutoplay);

            // Touch support
            var startX = 0;
            container.addEventListener('touchstart', function(e) {
                startX = e.touches[0].clientX;
                stopAutoplay();
            }, { passive: true });

            container.addEventListener('touchend', function(e) {
                var endX = e.changedTouches[0].clientX;
                if (startX - endX > 40) {
                    nextSlide();
                } else if (endX - startX > 40) {
                    prevSlide();
                }
                startAutoplay();
            }, { passive: true });

            window.addEventListener('resize', function() {
                setCardDimensions();
                renderDots();
                updateSlider();
            });

            setTimeout(function() {
                setCardDimensions();
                renderDots();
                updateSlider();
                startAutoplay();
            }, 60);
        })();
    </script>

    @include('Website.includes.Footer')
    @include('Website.includes.JsLink')
