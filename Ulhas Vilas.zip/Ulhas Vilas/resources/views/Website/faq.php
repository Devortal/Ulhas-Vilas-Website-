@include('Website.includes.CssLink')
@include('Website.includes.Header')

<!-- ==================== FREQUENTLY ASKED QUESTIONS (FAQ PAGE) ==================== -->
<section id="faqs" class="py-20 bg-[#FAF9F6] relative overflow-hidden font-sora border-b border-gray-100 min-h-screen">
    <div class="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            <!-- Left Column: Poster Image Banner Card -->
            <div class="lg:col-span-5 relative rounded-[2.2rem] overflow-hidden min-h-[660px] shadow-2xl flex flex-col justify-between p-7 sm:p-9 border border-white/20 bg-slate-900 group">
                <!-- High Resolution Himalayan Road / Jeep Adventure Image -->
                <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80" alt="Adventure Awaits You" class="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-out">
                <div class="absolute inset-0 bg-gradient-to-b from-black/70 via-black/30 to-black/85 pointer-events-none"></div>

                <!-- Top Poster Header Overlay -->
                <div class="relative z-10 space-y-2">
                    <span class="font-caveat text-[#cca43b] text-3xl sm:text-4xl font-medium tracking-wide block">Adventure Awaits You</span>
                    <h3 class="font-outfit text-3xl sm:text-4xl font-extrabold text-white leading-tight">We handle the details,<br>you enjoy the journey.</h3>
                </div>

                <!-- Bottom Poster Content & Features -->
                <div class="relative z-10 mt-auto">
                    <!-- Floating Support Card -->
                    <div class="bg-[#050c18]/90 backdrop-blur-md p-5 rounded-2xl border border-white/10 text-white shadow-2xl mb-6">
                        <div class="flex items-center gap-3.5">
                            <div class="w-11 h-11 rounded-full bg-[#cca43b]/20 text-[#cca43b] flex items-center justify-center text-xl shrink-0 border border-[#cca43b]/30">
                                <i class="fa-solid fa-headset"></i>
                            </div>
                            <div>
                                <h4 class="font-outfit text-sm font-bold text-white leading-tight">Need help planning your trip?</h4>
                                <p class="text-[11px] text-gray-300 mt-0.5 font-normal">Our travel experts are here for you.</p>
                            </div>
                        </div>
                        <div class="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between">
                            <a href="{{ url('/contact-us') }}" class="inline-flex items-center gap-2 text-xs font-bold text-[#cca43b] border border-[#cca43b]/50 hover:bg-[#cca43b] hover:text-white px-4 py-2 rounded-full transition group/link">
                                <span>Contact Support</span>
                                <i class="fa-solid fa-arrow-right text-[10px] transform group-hover/link:translate-x-1 transition-transform"></i>
                            </a>
                            <span class="text-[10px] text-gray-400 font-mono">24/7 Available</span>
                        </div>
                    </div>

                    <!-- 4 Icon Feature Highlights Row -->
                    <div class="grid grid-cols-4 gap-2 pt-3 border-t border-white/15 text-center text-white">
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-shield-halved text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Secure Booking</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Safe & trusted</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-award text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Best Price</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Get best deals</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-regular fa-calendar-xmark text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">Easy Cancel</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Hassle-free</span>
                        </div>
                        <div class="flex flex-col items-center">
                            <i class="fa-solid fa-phone-volume text-[#cca43b] text-lg mb-1"></i>
                            <span class="text-[10px] font-bold block leading-tight">24/7 Support</span>
                            <span class="text-[8.5px] text-gray-300 block leading-tight">Here always</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Accordion (Dynamic FAQs from Database) -->
            <div class="lg:col-span-7 space-y-5">
                <!-- Section Header with Mountain SVG Vector Art -->
                <div class="relative flex items-start justify-between gap-4">
                    <div>
                       
                        <h1 class="font-outfit text-3xl sm:text-4xl lg:text-4.5xl font-extrabold text-[#050c18] leading-tight">
                            Frequently Asked <span class="text-[#cca43b]">Questions</span>
                        </h1>
                        <p class="text-gray-500 text-sm mt-1.5 font-medium leading-relaxed max-w-xl">
                            Get answers to common questions about bookings, payments, cancellations, pickup points, activities and more.
                        </p>
                    </div>
                    <!-- Line Art Mountain Illustration -->
                    <div class="hidden sm:block opacity-30 shrink-0 pt-1">
                        <svg width="120" height="70" viewBox="0 0 120 70" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 60 L40 20 L60 45 L85 10 L110 60 Z" stroke="#050c18" stroke-width="2" stroke-linejoin="round"/>
                            <path d="M25 40 L40 20 L50 35" stroke="#cca43b" stroke-width="2"/>
                            <path d="M72 25 L85 10 L98 30" stroke="#cca43b" stroke-width="2"/>
                        </svg>
                    </div>
                </div>

                <!-- Dynamic Accordion Container -->
                <div id="pageFaqAccordion" class="space-y-3 pt-2">
                    @php
                        $badgeStyles = [
                            ['bg' => 'bg-indigo-50/80', 'text' => 'text-indigo-600', 'border' => 'border-indigo-100', 'icon' => 'fa-regular fa-calendar-check'],
                            ['bg' => 'bg-amber-50/80', 'text' => 'text-amber-600', 'border' => 'border-amber-100', 'icon' => 'fa-solid fa-location-dot'],
                            ['bg' => 'bg-blue-50/80', 'text' => 'text-blue-600', 'border' => 'border-blue-100', 'icon' => 'fa-regular fa-credit-card'],
                            ['bg' => 'bg-emerald-50/80', 'text' => 'text-emerald-600', 'border' => 'border-emerald-100', 'icon' => 'fa-solid fa-headset'],
                            ['bg' => 'bg-purple-50/80', 'text' => 'text-purple-600', 'border' => 'border-purple-100', 'icon' => 'fa-regular fa-circle-question'],
                        ];
                    @endphp
                    @forelse(($faqs ?? []) as $idx => $faq)
                        @php
                            $style = $badgeStyles[$idx % count($badgeStyles)];
                            $isOpenInitial = ($idx === 0);
                        @endphp
                        <div class="page-faq-item border border-gray-200/80 bg-white rounded-2xl transition-all duration-200 overflow-hidden shadow-2xs">
                            <!-- Question Header -->
                            <button type="button" onclick="togglePageFaq(this)" class="w-full flex items-center justify-between py-3.5 px-4 sm:px-5 text-left cursor-pointer hover:bg-gray-50/50 transition gap-3.5">
                                <div class="flex items-center gap-3.5 flex-1 min-w-0">
                                    <!-- Left Soft Colored Icon Badge -->
                                    <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-xl {{ $style['bg'] }} {{ $style['text'] }} border {{ $style['border'] }} flex items-center justify-center font-bold text-sm shrink-0">
                                        <i class="{{ $style['icon'] }}"></i>
                                    </div>
                                    <!-- Question Title -->
                                    <span class="font-outfit text-[#050c18] text-[15px] sm:text-base font-bold leading-snug">{{ $faq->question }}</span>
                                </div>
                                <!-- Right Plus/Minus Icon -->
                                <span class="page-faq-pm-icon w-7 h-7 sm:w-8 sm:h-8 rounded-full border border-gray-200 text-gray-500 flex items-center justify-center text-xs transition-all duration-200 shrink-0">
                                    <i class="fa-solid {{ $isOpenInitial ? 'fa-minus' : 'fa-plus' }} text-[11px]"></i>
                                </span>
                            </button>

                            <!-- Answer Body -->
                            <div class="page-faq-answer-body {{ $isOpenInitial ? '' : 'hidden' }} px-4 sm:px-5 pb-4 pl-[3.25rem] sm:pl-[4.25rem] text-gray-500 text-xs sm:text-sm leading-relaxed border-t border-gray-100/80 pt-3">
                                {!! nl2br(e($faq->answer)) !!}
                            </div>
                        </div>
                    @empty
                        <div class="text-center py-10 bg-white rounded-2xl border border-dashed border-gray-200 text-gray-400">
                            <i class="fa-regular fa-circle-question text-3xl mb-2 text-[#cca43b]"></i>
                            <p class="text-xs font-semibold">No questions available right now.</p>
                        </div>
                    @endforelse
                </div>

                <!-- Still Need Help Bottom Box -->
                <div class="bg-amber-50/70 border border-amber-200/60 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 mt-5">
                    <div class="flex items-center gap-3.5">
                        <div class="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#cca43b]/15 text-[#cca43b] flex items-center justify-center text-lg sm:text-xl shrink-0 border border-[#cca43b]/30">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <div>
                            <h4 class="font-outfit text-sm sm:text-base font-bold text-[#050c18] leading-tight">Still need help?</h4>
                            <p class="text-xs text-gray-500 mt-0.5 font-medium">Our travel experts are ready to assist you.</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 flex-wrap justify-center sm:justify-end">
                        <div class="bg-white border border-gray-200 px-3.5 py-1.5 rounded-full text-[#050c18] font-bold text-xs shadow-2xs flex items-center gap-2">
                            <i class="fa-solid fa-phone text-[#cca43b] text-xs"></i>
                            <div>
                                <a href="tel:{{ $info->mobile ?? '+918700663512' }}" class="block leading-none hover:text-[#cca43b] transition">{{ $info->mobile ?? '+91 8700663512' }}</a>
                                <span class="text-[9px] text-gray-400 font-normal">{{ $info->office_time ?? 'Mon - Sun, 9 AM - 9 PM' }}</span>
                            </div>
                        </div>
                        <a href="https://wa.me/{{ !empty($info->mobile) ? preg_replace('/[^0-9]/', '', $info->mobile) : '918700663512' }}" target="_blank" class="bg-[#cca43b] hover:bg-[#b08b2d] text-white px-4 py-2 rounded-full font-bold text-xs shadow-md transition flex items-center gap-2">
                            <i class="fa-brands fa-whatsapp text-sm"></i>
                            <span>Chat with an Expert</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

@include('Website.includes.JsLink')
@include('Website.includes.Footer')

<!-- Page FAQ Interactivity Script -->
<script>
    function togglePageFaq(btn) {
        const item = btn.closest('.page-faq-item');
        const body = item.querySelector('.page-faq-answer-body');
        const pmIcon = btn.querySelector('.page-faq-pm-icon');
        const icon = pmIcon.querySelector('i');
        const isOpen = !body.classList.contains('hidden');

        // Close all others
        document.querySelectorAll('.page-faq-item').forEach(other => {
            if (other !== item) {
                other.querySelector('.page-faq-answer-body').classList.add('hidden');
                const otherPm = other.querySelector('.page-faq-pm-icon');
                if (otherPm) {
                    otherPm.querySelector('i').className = 'fa-solid fa-plus text-[11px]';
                }
            }
        });

        // Toggle clicked item
        if (isOpen) {
            body.classList.add('hidden');
            icon.className = 'fa-solid fa-plus text-[11px]';
        } else {
            body.classList.remove('hidden');
            icon.className = 'fa-solid fa-minus text-[11px]';
        }
    }
</script>
