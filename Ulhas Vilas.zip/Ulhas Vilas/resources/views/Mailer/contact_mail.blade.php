<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Enquiry Confirmation — The Ulhas Vilas</title>
    
    <style type="text/css">
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse; }
        body { margin: 0; padding: 0; width: 100% !important; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
        
        @media only screen and (max-width: 600px) {
            .email-container { width: 100% !important; border-radius: 6px !important; }
            .content-cell { padding: 20px 16px !important; }
            .header-cell { padding: 24px 16px !important; }
            .header-title { font-size: 20px !important; }
            .summary-table td { padding: 9px 12px !important; }
            .summary-label { width: 100% !important; display: block !important; padding-bottom: 2px !important; }
            .summary-value { width: 100% !important; display: block !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; background-color: #f1f5f9; color: #1e293b;" bgcolor="#f1f5f9">

    <table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#f1f5f9" style="background-color: #f1f5f9; width: 100%;">
        <tr>
            <td align="center" style="padding: 30px 12px 40px 12px;">
                
                <!-- Main Card Container -->
                <table border="0" cellpadding="0" cellspacing="0" width="600" class="email-container" bgcolor="#ffffff" style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #d4af37; box-shadow: 0 10px 30px rgba(0,0,0,0.08);">
                    
                    <!-- Header -->
                    <tr>
                        <td align="center" class="header-cell" bgcolor="#071524" style="background-color: #071524; padding: 32px 24px; border-bottom: 3px solid #d4af37;">
                            <h1 class="header-title" style="margin: 0; font-size: 24px; font-weight: 800; color: #ffffff !important; letter-spacing: 2px; text-transform: uppercase; font-family: Georgia, 'Times New Roman', serif;">
                                THE ULHAS VILAS
                            </h1>
                            <p style="margin: 6px 0 0 0; font-size: 11px; color: #d4af37 !important; letter-spacing: 1.5px; text-transform: uppercase; font-weight: 700;">
                                Luxury Mountain Residences &bull; Himachal Pradesh
                            </p>
                        </td>
                    </tr>

                    <!-- Body Content -->
                    <tr>
                        <td class="content-cell" bgcolor="#ffffff" style="padding: 32px 36px 28px 36px; background-color: #ffffff;">
                            
                            <!-- Greeting -->
                            <h2 style="margin: 0 0 12px 0; font-size: 19px; font-weight: 700; color: #0b1f36 !important; font-family: Georgia, 'Times New Roman', serif;">
                                Dear {{ $data['name'] ?? 'Valued Guest' }},
                            </h2>
                            
                            <p style="margin: 0 0 20px 0; font-size: 14.5px; line-height: 1.65; color: #334155 !important;">
                                Thank you for contacting <strong>The Ulhas Vilas</strong>. We have received your inquiry regarding 
                                <strong style="color: #927220 !important;">{{ $data['configuration'] ?? $data['subject'] ?? 'our luxury mountain residences' }}</strong>. 
                                Our private residence advisory team is reviewing your requirements and will connect with you shortly.
                            </p>

                            <!-- Attachment Callout Notice -->
                            @if(!empty($data['has_brochure']) && !empty($data['brochure_file_path']))
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#fdfbf7" style="background-color: #fdfbf7; border-radius: 8px; border: 1.5px dashed #d4af37; margin-bottom: 24px;">
                                <tr>
                                    <td style="padding: 16px 18px;">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                            <tr>
                                                <td width="32" valign="top" style="font-size: 20px; line-height: 1;">
                                                    @if(!empty($data['is_pdf'])) 📄 @else 🖼️ @endif
                                                </td>
                                                <td valign="top" style="padding-left: 8px;">
                                                    <p style="margin: 0; font-size: 13.5px; font-weight: 700; color: #0b1f36 !important;">
                                                        Official Estate Brochure ({{ $data['brochure_type'] ?? 'PDF' }}) Attached
                                                    </p>
                                                    <p style="margin: 4px 0 0 0; font-size: 12.5px; color: #64748b !important; line-height: 1.45;">
                                                        The official architectural brochure &amp; master floor plans have been attached to this email. You can also download it anytime online using the button below.
                                                    </p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            @endif

                            <!-- Download Brochure CTA Button -->
                            @if(!empty($data['brochure_url']))
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin-bottom: 24px; text-align: center;">
                                <tr>
                                    <td align="center">
                                        <table border="0" cellpadding="0" cellspacing="0" style="margin: 0 auto;">
                                            <tr>
                                                <td align="center" bgcolor="#c99e32" style="background-color: #c99e32; border-radius: 6px;">
                                                    <a href="{{ $data['brochure_url'] }}" target="_blank" style="display: inline-block; padding: 12px 28px; font-size: 13px; font-weight: 700; color: #071524 !important; text-decoration: none; text-transform: uppercase; letter-spacing: 1px; border-radius: 6px;">
                                                        Download Brochure Online &rarr;
                                                    </a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            @endif

                            <!-- Enquiry Summary Table -->
                            <p style="margin: 0 0 10px 0; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #64748b !important;">
                                Enquiry Details Summary
                            </p>
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="summary-table" bgcolor="#f8fafc" style="background-color: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 24px;">
                                <tr>
                                    <td class="summary-label" width="35%" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #64748b !important; border-bottom: 1px solid #e2e8f0;">
                                        Full Name
                                    </td>
                                    <td class="summary-value" width="65%" style="padding: 10px 14px; font-size: 13.5px; font-weight: 700; color: #0f172a !important; border-bottom: 1px solid #e2e8f0;">
                                        {{ $data['name'] ?? '-' }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="summary-label" width="35%" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #64748b !important; border-bottom: 1px solid #e2e8f0;">
                                        Phone Number
                                    </td>
                                    <td class="summary-value" width="65%" style="padding: 10px 14px; font-size: 13.5px; font-weight: 600; color: #0284c7 !important; border-bottom: 1px solid #e2e8f0;">
                                        {{ $data['mobile'] ?? '-' }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="summary-label" width="35%" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #64748b !important; border-bottom: 1px solid #e2e8f0;">
                                        Residence Option
                                    </td>
                                    <td class="summary-value" width="65%" style="padding: 10px 14px; font-size: 13.5px; font-weight: 700; color: #927220 !important; border-bottom: 1px solid #e2e8f0;">
                                        {{ $data['configuration'] ?? $data['subject'] ?? 'Luxury Residence' }}
                                    </td>
                                </tr>
                                @if(!empty($data['city']) && $data['city'] !== 'Not specified')
                                <tr>
                                    <td class="summary-label" width="35%" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #64748b !important; @if(!empty($data['message'])) border-bottom: 1px solid #e2e8f0; @endif">
                                        City
                                    </td>
                                    <td class="summary-value" width="65%" style="padding: 10px 14px; font-size: 13px; color: #0f172a !important; @if(!empty($data['message'])) border-bottom: 1px solid #e2e8f0; @endif">
                                        {{ $data['city'] }}
                                    </td>
                                </tr>
                                @endif
                                @if(!empty($data['message']))
                                <tr>
                                    <td class="summary-label" width="35%" style="padding: 10px 14px; font-size: 12px; font-weight: 700; color: #64748b !important;">
                                        Message
                                    </td>
                                    <td class="summary-value" width="65%" style="padding: 10px 14px; font-size: 13px; color: #334155 !important;">
                                        {{ $data['message'] }}
                                    </td>
                                </tr>
                                @endif
                            </table>

                            <!-- Signoff -->
                            <p style="margin: 0; font-size: 14px; color: #475569 !important; line-height: 1.6;">
                                Warm regards,<br />
                                <strong style="color: #071524 !important;">The Ulhas Vilas Team</strong><br />
                                <span style="font-size: 12px; color: #64748b !important;">Solan, Himachal Pradesh, India</span>
                            </p>

                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td align="center" bgcolor="#071524" style="background-color: #071524; padding: 22px 24px; border-top: 1px solid #cca43b;">
                            <p style="margin: 0 0 6px 0; font-size: 13px; color: #cbd5e1 !important;">
                                <a href="{{ url('/') }}" target="_blank" style="color: #d4af37 !important; text-decoration: none; font-weight: 700;">
                                    Visit The Ulhas Vilas Website &rarr;
                                </a>
                            </p>
                            <p style="margin: 0; font-size: 11px; color: #94a3b8 !important;">
                                &copy; {{ date('Y') }} The Ulhas Vilas. All rights reserved.
                            </p>
                        </td>
                    </tr>

                </table>
                <!-- End Main Container -->

            </td>
        </tr>
    </table>

</body>
</html>
