<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\WebsiteController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

Route::get('/clear', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear');
    Artisan::call('optimize:clear');
    return 'Cache & System Cleared Successfully!';
});

// --- 1. Admin Authentication & Profile ---
Route::get('/login', function () {
    return view('Auth.login');
})->name('login');

Route::get('/admin-login', function () {
    return redirect('/login');
});
Route::post('/admin-login', [AdminController::class, 'admin_login']);
Route::get('/admin-dashboard', [AdminController::class, 'AdminDashboard']);
Route::get('/admin-logout', [AdminController::class, 'admin_logout']);

Route::get('/changepassword', function () {
    return view('Admin.pages.changepassword');
});
Route::post('/changepassword/admin', [AdminController::class, 'changepasswordset']);

Route::get('/admin-profile', function () {
    return view('Admin.pages.profile');
});
Route::post('/profile/admin', [AdminController::class, 'updateprofile']);

// --- 2. Subadmin Management ---
Route::get('/admin-subadmin', [AdminController::class, 'Subadmin'])->name('subadmin');
Route::post('/add_subadmin', [AdminController::class, 'AddSubadmin']);
Route::post('/show_subadmin', [AdminController::class, 'ShowSubadmin']);
Route::post('/delete_subadmin', [AdminController::class, 'DeleteSubadmin']);
Route::get('/edit_subadmin/{id}', [AdminController::class, 'EditSubadmin'])->name('edit.subadmin');
Route::post('/update_subadmin', [AdminController::class, 'UpdateSubadmin']);
Route::post('/check_subadmin_mobile', [AdminController::class, 'CheckMobileExist']);

// --- 3. Category & Subcategory Management ---
Route::get('/admin-category', [AdminController::class, 'category']);
Route::post('/add_category', [AdminController::class, 'add_category']);
Route::post('/searchdata', [AdminController::class, 'searchdata']);
Route::post('/delete_category', [AdminController::class, 'delete_category']);
Route::post('/update_category', [AdminController::class, 'update_category']);
Route::post('/switch_status_update', [AdminController::class, 'switch_status_update']);

Route::get('/admin-subcategory', [AdminController::class, 'subcategory']);
Route::post('/add_subcategory', [AdminController::class, 'add_subcategory']);
Route::post('/show_subcategory', [AdminController::class, 'show_subcategory']);
Route::post('/delete_subcategory', [AdminController::class, 'delete_subcategory']);
Route::post('/update_subcategory', [AdminController::class, 'update_subcategory']);

// --- 4. Residences Management (1 BHK, 2 BHK, 3 BHK, 4 BHK) ---
Route::get('/admin-residence', [AdminController::class, 'Residence']);
Route::post('/show_residence', [AdminController::class, 'ShowResidence']);
Route::post('/add_residence', [AdminController::class, 'AddResidence']);
Route::post('/update_residence', [AdminController::class, 'UpdateResidence']);
Route::post('/delete_residence', [AdminController::class, 'DeleteResidence']);

// --- 5. Amenities Management ---
Route::get('/admin-amenities', [AdminController::class, 'Amenities']);
Route::post('/show_amenities', [AdminController::class, 'ShowAmenities']);
Route::post('/add_amenity', [AdminController::class, 'AddAmenity']);
Route::post('/update_amenity', [AdminController::class, 'UpdateAmenity']);
Route::post('/delete_amenity', [AdminController::class, 'DeleteAmenity']);

// --- 6. Gallery Management ---
Route::get('/admin-gallery', [AdminController::class, 'Gallery']);
Route::post('/show_gallery', [AdminController::class, 'ShowGallery']);
Route::post('/add_gallery', [AdminController::class, 'AddGallery']);
Route::post('/update_gallery', [AdminController::class, 'UpdateGallery']);
Route::post('/delete_gallery', [AdminController::class, 'DeleteGallery']);

// --- 7. Blogs Management ---
Route::get('/admin-blogs', [AdminController::class, 'Blogs']);
Route::post('/show_blogs', [AdminController::class, 'ShowBlogs']);
Route::post('/add_blog', [AdminController::class, 'AddBlog']);
Route::post('/update_blog', [AdminController::class, 'UpdateBlog']);
Route::post('/delete_blog', [AdminController::class, 'DeleteBlog']);

// --- 8. FAQs Management (Question & Answer Only) ---
Route::get('/admin-faq', [AdminController::class, 'Faq']);
Route::post('/show_faq', [AdminController::class, 'ShowFaq']);
Route::post('/add_faq', [AdminController::class, 'AddFaq']);
Route::post('/update_faq', [AdminController::class, 'UpdateFaq']);
Route::post('/delete_faq', [AdminController::class, 'DeleteFaq']);

// --- 9. Guest Reviews & Testimonials Management ---
Route::get('/admin-review', [AdminController::class, 'Review']);
Route::get('/admin-reviews', [AdminController::class, 'Review']);
Route::post('/show_review', [AdminController::class, 'ShowReview']);
Route::post('/add_review', [AdminController::class, 'AddReview']);
Route::post('/update_review', [AdminController::class, 'UpdateReview']);
Route::post('/delete_review', [AdminController::class, 'DeleteReview']);

// --- 10. Contacts & Brochure Leads Management ---
Route::get('/admin-contact', [AdminController::class, 'contact']);
Route::post('/admin-contact', [AdminController::class, 'showContact']);
Route::post('/delete_enquiry', [AdminController::class, 'DeleteEnquiry']);

// --- 11. Newsletter Subscribers Management ---
Route::get('/admin-newsletter', [AdminController::class, 'Newsletter']);
Route::post('/show_newsletter', [AdminController::class, 'ShowNewsletter']);
Route::post('/delete_newsletter', [AdminController::class, 'DeleteNewsletter']);

// --- 12. Website Settings, Brochure File & Dynamic SEO ---
Route::get('/admin-website', [AdminController::class, 'Information']);
Route::match(['get', 'post'], '/update_website', [AdminController::class, 'UpdateWebsite']);
Route::get('/admin-info', [AdminController::class, 'Information']);

// =========================================================================
// 🌐 THE ULHAS VILAS - WEBSITE FRONTEND ROUTES
// =========================================================================

Route::get('/', [WebsiteController::class, 'index'])->name('home');
Route::get('/about', [WebsiteController::class, 'about'])->name('about');
Route::get('/about-us', function () {
    return redirect('/about', 301);
});

Route::get('/residences', [WebsiteController::class, 'residences'])->name('residences');
Route::get('/residence-by-category/{category_id}', [WebsiteController::class, 'residenceByCategory'])->name('residence.by.category');
Route::get('/residence/{slug}', [WebsiteController::class, 'residenceDetail'])->name('residence.detail');

Route::get('/amenities-wellness', [WebsiteController::class, 'amenities'])->name('amenities');
Route::get('/amenities', function () {
    return redirect('/amenities-wellness', 301);
});

Route::get('/gallery', [WebsiteController::class, 'gallery'])->name('gallery');

Route::get('/blogs', [WebsiteController::class, 'blogs'])->name('blogs');
Route::get('/blog/{slug}', [WebsiteController::class, 'blogDetail'])->name('blog.detail');

Route::get('/faq', [WebsiteController::class, 'faq'])->name('faq');
Route::get('/faqs', function () {
    return redirect('/faq', 301);
});

Route::get('/contact', [WebsiteController::class, 'contact'])->name('contact');
Route::get('/contact-us', function () {
    return redirect('/contact', 301);
});

Route::post('/contact_submit', [WebsiteController::class, 'contactSubmit'])->name('contact.submit');
Route::post('/capture-brochure-lead', [WebsiteController::class, 'contactSubmit']);
Route::post('/newsletter-submit', [WebsiteController::class, 'newsletterSubmit'])->name('newsletter.submit');
Route::post('/newsletter_submit', [WebsiteController::class, 'newsletterSubmit']);
Route::get('/download-brochure', [WebsiteController::class, 'downloadBrochure'])->name('download.brochure');
Route::get('/thank-you', [WebsiteController::class, 'thankYou'])->name('thankyou');
Route::get('/thankyou', function () {
    return redirect('/thank-you', 301);
});

// Legal Policies & Compliance Routes
Route::get('/terms-and-conditions', [WebsiteController::class, 'terms'])->name('terms');
Route::get('/terms-conditions', function () {
    return redirect('/terms-and-conditions', 301);
});
Route::get('/terms', function () {
    return redirect('/terms-and-conditions', 301);
});

Route::get('/privacy-policy', [WebsiteController::class, 'privacy'])->name('privacy');
Route::get('/privacy', function () {
    return redirect('/privacy-policy', 301);
});

Route::get('/disclaimer', [WebsiteController::class, 'disclaimer'])->name('disclaimer');
Route::get('/disclaimer-rera-compliance', function () {
    return redirect('/disclaimer', 301);
});
Route::get('/rera-compliance', function () {
    return redirect('/disclaimer', 301);
});

